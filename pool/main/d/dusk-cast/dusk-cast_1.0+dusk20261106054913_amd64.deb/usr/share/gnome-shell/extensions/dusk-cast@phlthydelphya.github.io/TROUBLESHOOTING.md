# Troubleshooting

Problems seen in the wild, what causes them, and how to fix them. The daemon
uses **GStreamer** to encode and **PipeWire** to capture, so a missing plugin or
package is the single most common cause of a cast that will not start — start
with [Dependencies](#dependencies) if you have never had a cast work.

If none of this helps, please
[open an issue](https://github.com/phlthydelphya/dusk-theme/issues) and include the
logs from [Collecting logs](#collecting-logs).

| Topic | What's in it |
|---|---|
| [Collecting logs](#collecting-logs) | Daemon, extension, and verbose-run log commands |
| [Dependencies](#dependencies) | What GStreamer/PipeWire pieces are needed, per-distro package lists, and which package fixes which symptom |
| [Picture](#picture) | Overscan cropping, black screen or break-up, the Chromecast backdrop |
| [Connection](#connection) | Unreachable routes, the HLS fallback, no devices found, broken pipe on exit |
| [Audio](#audio) | Silent casts, audio-only receivers, checking for encoders |
| [Extension](#extension) | A stale panel icon, `INACTIVE` state, a lingering screen-sharing indicator |
| [Developing](#developing) | Why a JS or daemon change appears to do nothing |

## Collecting logs

```sh
# Daemon logs (every line is tagged "dusk-cast")
journalctl --user -f -g dusk-cast

# Extension logs
journalctl -f -o cat /usr/bin/gnome-shell

# Verbose daemon run: stop the running one first, then start it by hand
pkill -x dusk-cast-daemo
RUST_LOG=debug /usr/libexec/dusk/dusk-cast-daemon
```

`RUST_LOG=debug` is worth the noise — RTP/RTCP problems are invisible at the
default level.

---

## Dependencies

> The daemon binary from the [Releases](https://github.com/phlthydelphya/dusk-theme/releases)
> is dynamically linked, so these libraries must be present at runtime even if
> you didn't build from source.

### What's needed

**Runtime (to cast):**

- GStreamer 1.x core and the **base**, **good**, **bad**, and **ugly** plugin sets
  - `x264enc` (H.264, from *ugly*) - the HLS fallback and a hardware-free H.264 path
  - `vp8enc` / `vp9enc` (VP8/VP9, from *good*/*vpx*) - Cast Streaming (mirroring)
  - `av1enc` (aom) or `svtav1enc` (SVT-AV1) - optional AV1 mirroring
  - an AAC encoder: `fdkaacenc` (*bad*), `avenc_aac` (*libav*), or `faac`
  - `lamemp3enc` (MP3, from *good*) - preferred for audio-only casts (speakers, smart displays, cast groups); the AAC encoder above is used if it is missing
  - `opusenc` (Opus audio, from *good*)
- **PipeWire** and its GStreamer plugin (`pipewiresrc`), plus `xdg-desktop-portal-gnome`
- `pactl` (for locating the system-audio monitor)
- Optional, for hardware encoding: the GStreamer **VA-API** plugin (`vah264enc`, …)
  or NVIDIA **nvcodec** plugin (`nvh264enc`, …)

**Build only (if compiling the daemon yourself):** the Rust toolchain and the
GStreamer development headers.

### Install by distribution

#### Debian / Ubuntu

```sh
sudo apt install \
    gstreamer1.0-plugins-base gstreamer1.0-plugins-good \
    gstreamer1.0-plugins-bad gstreamer1.0-plugins-ugly gstreamer1.0-libav \
    gstreamer1.0-pipewire pipewire pulseaudio-utils
# hardware encoding (Intel/AMD): gstreamer1.0-vaapi
# building from source: cargo libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev
```

#### Fedora

```sh
sudo dnf install \
    gstreamer1-plugins-base gstreamer1-plugins-good \
    gstreamer1-plugins-bad-free gstreamer1-plugins-ugly gstreamer1-libav \
    pipewire-gstreamer pipewire-utils pulseaudio-utils
# building from source: cargo gstreamer1-devel gstreamer1-plugins-base-devel
```

(For `x264enc`/`faac` and other patent-encumbered encoders, Fedora users
typically enable [RPM Fusion](https://rpmfusion.org/).)

#### Arch Linux

```sh
sudo pacman -S \
    gst-plugins-base gst-plugins-good gst-plugins-bad gst-plugins-ugly \
    gst-libav gst-plugin-pipewire pipewire-pulse libpulse
# AV1: aom or svt-av1 ;  hardware encoding: gstreamer-vaapi
# building from source: rust
```

#### openSUSE

```sh
sudo zypper install \
    gstreamer-plugins-base gstreamer-plugins-good \
    gstreamer-plugins-bad gstreamer-plugins-ugly gstreamer-plugins-libav \
    gstreamer-plugin-pipewire pipewire-tools pulseaudio-utils
# building from source: cargo gstreamer-devel gstreamer-plugins-base-devel
```

### Which package fixes which symptom

| Symptom | Likely cause | Install |
|---|---|---|
| No devices ever appear in the menu | not a library issue - mDNS (UDP 5353) blocked, or the device is on another subnet/VLAN (see [No devices found](#no-devices-found)) | - |
| Cast starts then fails; log says *"no video encoder is installed"* | no VP8/VP9/etc. encoder | plugins **good** (vpx) and **ugly** (x264) |
| Casting always uses HLS (multi-second lag), never low-latency | mirroring encoders missing, so it falls back | plugins **good** (`vp8enc`) |
| Log: *"no AAC encoder found"* | no AAC encoder for the HLS fallback | plugins **bad** (`fdkaacenc`) or **libav** |
| Video works but there's no audio | `pactl` missing, or no monitor source | `pulseaudio-utils` / `pipewire-pulse` |
| Casting to a speaker or cast group plays nothing | audio-only receivers need an MP3 or AAC encoder | plugins **good** (`lamemp3enc`) or **bad** (`fdkaacenc`) |
| Log: *"parsing the mirroring pipeline"* fails | GStreamer base/good plugins incomplete | plugins **base** + **good** |
| Details line never shows hardware | no VA-API/NVENC GStreamer plugin (software encoding is used, which still works) | `gstreamer-vaapi` (Intel/AMD) |
| Screen picker never opens | portal missing | `xdg-desktop-portal-gnome` + PipeWire |

Check which encoders GStreamer can see:

```sh
gst-inspect-1.0 vp8enc x264enc opusenc pipewiresrc   # should all print details
gst-inspect-1.0 | grep -iE 'vah264enc|nvh264enc'     # hardware H.264, if any
```

---

## Picture

### The picture is cut off on all four sides

Your TV is applying **overscan**, an old habit from analogue broadcast where the
panel zooms ~5 % and throws away the edges. Nothing is wrong with the cast: the
whole desktop is sent, scaled to the exact resolution you picked, with no
cropping on our side.

Fix it in the TV's picture settings. The option is per-input, so set it on the
input your Chromecast device is connected to:

| Vendor | Setting |
|---|---|
| Samsung, LG | *Just Scan* |
| Sony | *Screen Fit* or *Full Pixel* |
| Panasonic, Philips | *Unscaled*, *1:1*, or *Full* |

If your TV genuinely has no such setting, open an issue — we can add optional
overscan compensation (scaling the desktop down and padding it with black so
the TV's zoom eats the padding instead of your windows).

### Black screen, or the picture breaks up

Look for this in the daemon log:

```
WARN the network would not take N packet(s) of a frame; the picture will break
     up - try a lower bitrate
```

A key frame is a burst of 50–100 UDP packets. If the link cannot absorb the
burst, the receiver never gets a complete key frame and shows black. Fixes, in
order of effectiveness:

1. **Lower the bitrate** in preferences (the default 4000 kbit/s suits 720p).
2. **Lower the resolution or framerate.**
3. **Improve the Wi-Fi link** — check your ping to the device. On a LAN it
   should be single-digit milliseconds; 90–170 ms means a weak link, and casting
   will struggle no matter what you set.

### The TV shows the Chromecast logo (backdrop) instead of your screen

The receiver app exited or never started rendering. Check the log for
`device ended the mirroring session` or a fallback to HLS. See
[The cast falls back to HLS](#the-cast-falls-back-to-hls-or-the-receiver-never-answers)
below.

---

## Connection

### `probing route to device: Network is unreachable (os error 101)`

The device was resolved to an address your machine has no route to — almost
always an **IPv6 address on an IPv4-only network**. A single mDNS announcement
can carry only part of the record, and after a suspend/resume the AAAA record
often arrives minutes before the A record.

Check whether you have IPv6 at all:

```sh
ip -6 addr show scope global      # no output = no global IPv6
ip -6 route get <device-ipv6>     # "Network is unreachable" confirms it
```

Recent versions pick a *reachable* address, remember every address a device has
announced, and refuse to downgrade a working address to an unreachable one — so
this should resolve itself. If you hit it on an older build, restart the daemon
once the device has been announced fully:

```sh
pkill -x dusk-cast-daemo
```

### The cast falls back to HLS, or the receiver never answers

```
WARN mirroring unavailable, falling back to HLS: timed out waiting for the
     receiver's ANSWER
```

The mirroring app launched but never completed negotiation. The usual cause is
the receiver being **wedged after repeated rapid start/stop cycles** — common
while testing. Fixes:

1. Wait a minute and try again.
2. Power-cycle the Chromecast device, or force-stop the cast app on it.

HLS still works in this state; it just has seconds of latency instead of
sub-second. A cast that *always* falls back is usually a missing mirroring
encoder instead — see [Dependencies](#dependencies).

### No devices found

- The device must be on the same network/VLAN as your machine.
- mDNS (UDP 5353) must not be blocked — client isolation on guest Wi-Fi
  networks will do exactly this.
- Give it ~5 seconds after opening the menu; discovery is asynchronous.

### The daemon warns about a broken pipe and exits

```
WARN failed to emit signal: I/O error: Broken pipe (os error 32)
WARN D-Bus connection lost, exiting
```

Normal. The session bus went away (usually a logout), so the daemon shuts down
and D-Bus activation starts a fresh one when it is next needed.

---

## Audio

### No audio

System audio is captured from the default sink's monitor via
`pactl get-default-sink`. Check that `pactl` is installed, and that audio is
actually going to the sink you expect rather than a different one.

### Audio-only receivers reject the stream

Speakers, smart displays, and cast groups advertise no video and their Default
Media Receiver rejects live HLS. The daemon detects this and streams system
audio as MP3/AAC instead, offering a single **Cast audio** action. If that fails,
you are probably missing an AAC encoder — see below.

### Missing GStreamer plugins

```sh
gst-inspect-1.0 x264enc hlssink2     # HLS fallback path
gst-inspect-1.0 vp9enc               # Cast Streaming (mirroring) path
gst-inspect-1.0 fdkaacenc            # AAC for audio-only receivers
```

Anything not found needs its plugin package installed. The daemon tries several
AAC encoders in turn (`fdkaacenc`, `avenc_aac`, `voaacenc`, `faac`), so missing
`gst-libav` alone is not fatal. See [Dependencies](#dependencies) for package
names.

---

## Extension

### The panel icon or toggle does not update while casting

Fixed in recent versions. If you see the menu only catching up when you open it,
you are on an older build — update and log out and back in.

### The extension shows as INACTIVE

```
$ gnome-extensions info dusk-cast@phlthydelphya.github.io
  Enabled: Yes
  State: INACTIVE
```

Expected **while the screen is locked**: the extension does not declare the
`unlock-dialog` session mode, so GNOME disables it on the lock screen. It comes
back when you unlock. Confirm with:

```sh
loginctl show-session $(loginctl list-sessions --no-legend | awk 'NR==1{print $1}') -p LockedHint
```

If it is `LockedHint=no` and still inactive, check the shell log for an
exception thrown during enable.

### GNOME's "screen is being shared" indicator stays on

The portal session was not closed. Recent versions close it explicitly and wait
for the compositor to confirm. If it lingers, stopping the cast or letting the
daemon exit (~10 minutes idle) clears it.

---

## Developing

### Changes to the extension's JavaScript have no effect

GNOME Shell caches an extension's ES modules for the life of the process, so
`gnome-extensions disable/enable` does **not** reload changed JS. On X11 you can
restart the shell with <kbd>Alt</kbd>+<kbd>F2</kbd> → `r`; on **Wayland you must
log out and back in**.

`stylesheet.css` is the exception — the shell loads and unloads it on
enable/disable, so pure CSS changes apply with a quick disable/enable. Worth
keeping visual tweaks in CSS while iterating.

### Changes to the daemon have no effect

The old process keeps running after Dusk is reinstalled
(`bash cast/build.sh`, then `sudo setup/system/install-system.sh`). Stop it; the
session bus starts the new one on the next request:

```sh
pkill -x dusk-cast-daemo
```

`-x` matches the process name exactly (the kernel cuts it to 15 characters),
so it never hits the shell you are typing in.

Verify which build is installed:

```sh
md5sum cast/dist/dusk-cast-daemon /usr/libexec/dusk/dusk-cast-daemon
busctl --user call io.github.phlthydelphya.DuskCast /io/github/phlthydelphya/DuskCast io.github.phlthydelphya.DuskCast1 GetVersion
```

## Miracast

Dusk Cast reaches Miracast displays two ways. Both show up in the menu with a
tag beside the name.

- **Miracast** (over your network, MS-MICE): displays that announce
  `_display._tcp` on the local network, such as Windows 10/11 with the
  Wireless Display app ("Project to this PC"), Surface Hubs and some TVs.
  Check what the network announces with `avahi-browse -rt _display._tcp`.
- **Wi-Fi Direct**: classic Miracast TVs and dongles. This needs a Wi-Fi card
  whose driver supports P2P: `iw list` must show `P2P-client` and `P2P-GO`
  under "Supported interface modes", and `nmcli device` must list a
  `wifi-p2p` device. Many laptop cards (Realtek `rtw88`, for one) have no P2P
  mode; a USB Wi-Fi adapter that has one works. The search runs for 30 s
  each time the menu opens, and the Wi-Fi connection slows while it does.

The display asks to connect back to this computer on TCP port 7236. Some TVs
first ask on screen whether to allow it.

### "The display did not connect back"

A firewall dropped the display's connection. With ufw (Dusk's default denies
incoming connections), allow port 7236 from the network you are on and from
Wi-Fi Direct groups' address ranges. The rule for your network is tied to its
interface and subnet, so rerun the script after joining a different network:

```sh
sudo bash cast/allow-miracast.sh            # add the rules
sudo bash cast/allow-miracast.sh --remove   # take them away
```

Dusk Cast listens on the port only while a Miracast cast starts, and accepts
only the display it is casting to.

### "Port 7236 is in use by another program"

Another Miracast sender is running, often GNOME Network Displays. Quit it.

### The picture is 640x480, or there is no sound

Dusk Cast sends H.264 Constrained Baseline at the best of 1080p30, 720p60,
720p30 and 640x480p60 the display accepts in that profile, and AAC sound when
the display takes AAC. A display that takes only LPCM sound gets the picture
without sound. The journal shows what the display offered:

```sh
journalctl --user -g 'dusk-cast.*takes'
```

### Wi-Fi Direct displays never appear

Check that NetworkManager has a P2P device and can see the display:

```sh
nmcli device | grep wifi-p2p
busctl introspect org.freedesktop.NetworkManager \
  "$(nmcli -g GENERAL.DBUS-PATH device show p2p-dev-wlp2s0)" | grep -i peers
```

Replace `p2p-dev-wlp2s0` with the name `nmcli device` shows.
