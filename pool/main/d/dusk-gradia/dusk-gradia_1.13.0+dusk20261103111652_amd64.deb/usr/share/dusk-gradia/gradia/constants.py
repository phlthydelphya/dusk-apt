# Copyright (C) 2025 Alexander Vanhee
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: GPL-3.0-or-later

rootdir          = '/be/alexandervanhee/gradia'
datadir          = '/usr/share'
pkgdatadir       = '/usr/share/dusk-gradia'
pkglibdir        = '/usr/lib/x86_64-linux-gnu/dusk-gradia'
localedir        = '/usr/share/locale'

app_id           = 'io.github.phlthydelphya.DuskGradia'
rel_ver          = '1.13.0'
version          = '1.13.0'
build_type       = 'release'

project_url      = 'https://github.com/AlexanderVanhee/Gradia'
bugtracker_url   = 'https://github.com/AlexanderVanhee/Gradia'
help_url         = 'https://github.com/AlexanderVanhee/Gradia'
#translate_url   = ''

# OCR paths
ocr_enabled            = 'True'
ocr_tesseract_cmd      = '/usr/bin/tesseract'
ocr_original_tessdata  = '/usr/share/tesseract-ocr/5/tessdata'
