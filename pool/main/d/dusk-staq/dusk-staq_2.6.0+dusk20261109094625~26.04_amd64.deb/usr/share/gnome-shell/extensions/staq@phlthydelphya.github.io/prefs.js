// Staq extension preferences (docs/protocol-v2.md §11): where Staq shows in
// the top bar. The choice is Staq's own setting (TopBarStyle on its session
// bus), so it is read and written there; Staq must be running to change it.

import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Gtk from 'gi://Gtk';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

const BUS_NAME = 'io.github.phlthydelphya.staq';
const OBJECT_PATH = '/io/github/phlthydelphya/staq';
const INTERFACE_NAME = 'io.github.phlthydelphya.staq.Connection';
const STYLES = ['quick-settings', 'indicator'];

export default class StaqPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const page = new Adw.PreferencesPage();
        const group = new Adw.PreferencesGroup({
            title: 'Top bar',
            description: 'Both offer the connection switch and the same actions as Staq\'s menu.',
        });
        const row = new Adw.ComboRow({
            title: 'Show Staq in',
            model: Gtk.StringList.new(['Quick Settings', 'Status icon (app indicator)']),
        });
        group.add(row);
        page.add(group);
        window.add(page);

        const proxy = Gio.DBusProxy.new_for_bus_sync(Gio.BusType.SESSION,
            Gio.DBusProxyFlags.DO_NOT_AUTO_START, null,
            BUS_NAME, OBJECT_PATH, INTERFACE_NAME, null);

        let updating = false;
        const sync = () => {
            const running = proxy.g_name_owner !== null;
            const style = proxy.get_cached_property('TopBarStyle')?.unpack() ?? 'quick-settings';
            const iconHost = proxy.get_cached_property('StatusIconAvailable')?.unpack() ?? false;
            updating = true;
            row.selected = Math.max(0, STYLES.indexOf(style));
            updating = false;
            row.sensitive = running;
            if (!running)
                row.subtitle = 'Start Staq to choose.';
            else if (style === 'indicator' && !iconHost)
                row.subtitle = 'No status-icon host is running (the AppIndicator extension), so the Quick Settings toggle stays.';
            else
                row.subtitle = '';
        };

        row.connect('notify::selected', () => {
            if (updating)
                return;
            proxy.call('org.freedesktop.DBus.Properties.Set',
                new GLib.Variant('(ssv)', [INTERFACE_NAME, 'TopBarStyle',
                    new GLib.Variant('s', STYLES[row.selected])]),
                Gio.DBusCallFlags.NONE, -1, null,
                (source, result) => {
                    try {
                        source.call_finish(result);
                    } catch (e) {
                        console.warn(`Staq: could not save the choice: ${e.message}`);
                    }
                });
        });
        const ids = [
            proxy.connect('g-properties-changed', sync),
            proxy.connect('notify::g-name-owner', sync),
        ];
        window.connect('close-request', () => {
            ids.forEach(id => proxy.disconnect(id));
            return false;
        });
        sync();
    }
}
