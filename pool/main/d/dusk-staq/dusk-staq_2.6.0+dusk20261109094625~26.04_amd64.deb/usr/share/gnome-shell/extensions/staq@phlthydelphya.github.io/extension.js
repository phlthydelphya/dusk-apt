// Staq's Quick Settings toggle (docs/protocol-v2.md §11).
//
// Reads Staq's session-bus interface io.github.phlthydelphya.staq.Connection
// and shows one toggle in Quick Settings: the connection switch, with the
// phone's name or the state under it, a phone icon in the top bar while a
// phone is connected, and a menu with the same actions as Staq's status
// icon (Staq's MenuItems, run with Activate). With no Staq running the
// toggle and the menu start it from its desktop entry.
//
// Staq's TopBarStyle chooses between this toggle ("quick-settings") and
// Staq's own status icon ("indicator", shown through the AppIndicator
// extension). With "indicator" the toggle hides, unless no status-icon
// host runs (StatusIconAvailable), so Staq is never missing from the top
// bar. The choice is in this extension's preferences.
//
// During a phone call (§23) a widget in the top bar shows who the call is
// with, the time, Mute and End, whichever top-bar style is chosen.

import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Pango from 'gi://Pango';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {QuickMenuToggle, SystemIndicator} from 'resource:///org/gnome/shell/ui/quickSettings.js';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

const BUS_NAME = 'io.github.phlthydelphya.staq';
const OBJECT_PATH = '/io/github/phlthydelphya/staq';
const INTERFACE_NAME = 'io.github.phlthydelphya.staq.Connection';
const DESKTOP_ID = 'io.github.phlthydelphya.staq.desktop';
const ICON_NAME = 'phone-symbolic';

const ConnectionInterface = `
<node>
  <interface name="${INTERFACE_NAME}">
    <property name="Enabled" type="b" access="readwrite"/>
    <property name="Status" type="s" access="read"/>
    <property name="StatusText" type="s" access="read"/>
    <property name="PhoneName" type="s" access="read"/>
    <property name="MenuItems" type="a(ssbbb)" access="read"/>
    <property name="TopBarStyle" type="s" access="readwrite"/>
    <property name="StatusIconAvailable" type="b" access="read"/>
    <property name="CallState" type="s" access="read"/>
    <property name="CallCaller" type="s" access="read"/>
    <property name="CallSince" type="x" access="read"/>
    <property name="CallMuted" type="b" access="read"/>
    <method name="Show"/>
    <method name="Activate">
      <arg name="id" type="s" direction="in"/>
    </method>
    <method name="CallAction">
      <arg name="action" type="s" direction="in"/>
    </method>
  </interface>
</node>`;

const ConnectionProxy = Gio.DBusProxy.makeProxyWrapper(ConnectionInterface);

// The line under the toggle's title for a status group.
function subtitleFor(status, phoneName) {
    switch (status) {
    case 'connected':
        return phoneName || 'Connected';
    case 'waiting':
        return 'Waiting for phone';
    case 'problem':
        return 'Problem';
    default:
        return 'Off';
    }
}

function launchStaq() {
    const app = Gio.DesktopAppInfo.new(DESKTOP_ID);
    if (!app) {
        Main.notify('Staq', 'Staq is not installed.');
        return;
    }
    try {
        app.launch([], null);
    } catch (e) {
        Main.notify('Staq', `Could not start Staq: ${e.message}`);
    }
}

const StaqToggle = GObject.registerClass(
class StaqToggle extends QuickMenuToggle {
    _init(proxy) {
        super._init({
            title: 'Staq',
            iconName: ICON_NAME,
            // The tile opens Staq; it shows whether the connection is on.
            toggleMode: false,
        });

        this._proxy = proxy;
        this._menuKey = null;

        this.menu.setHeader(ICON_NAME, 'Staq');
        this._items = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this._items);

        this.connect('clicked', () => this._open());
        this._proxy.connectObject(
            'notify::g-name-owner', () => this._sync(),
            'g-properties-changed', () => this._sync(),
            this);
        this._sync();
    }

    get running() {
        return this._proxy.g_name_owner !== null;
    }

    get status() {
        return this.running ? this._proxy.Status ?? 'off' : 'off';
    }

    // Shown unless Staq's status icon was chosen and a host shows it.
    get wanted() {
        return !this.running ||
            this._proxy.TopBarStyle !== 'indicator' ||
            this._proxy.StatusIconAvailable !== true;
    }

    // Starts Staq, or brings its window up; the connection switch is in
    // the menu.
    _open() {
        Main.panel.closeQuickSettings();
        if (this.running)
            this._activate('show');
        else
            launchStaq();
    }

    _activate(id) {
        this._proxy.ActivateAsync(id).catch(e => console.warn(`Staq: ${id} failed: ${e.message}`));
    }

    // Staq's menu, rebuilt only when it changed: [id, label, enabled,
    // visible, checked] per action, "show" and "quit" after a separator as
    // in the status icon's menu.
    _buildMenu() {
        const items = this.running ? this._proxy.MenuItems ?? [] : [];
        const key = JSON.stringify(items);
        if (key === this._menuKey)
            return;
        this._menuKey = key;
        this._items.removeAll();

        if (!this.running) {
            const start = new PopupMenu.PopupMenuItem('Start Staq');
            start.connect('activate', () => launchStaq());
            this._items.addMenuItem(start);
            return;
        }
        for (const [id, label, enabled, visible, checked] of items) {
            if (!visible)
                continue;
            if (id === 'show')
                this._items.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
            let item;
            if (id === 'connection') {
                item = new PopupMenu.PopupSwitchMenuItem(label, checked);
                item.connect('toggled', () => this._activate(id));
            } else {
                item = new PopupMenu.PopupMenuItem(label);
                item.connect('activate', () => this._activate(id));
            }
            item.setSensitive(enabled);
            this._items.addMenuItem(item);
        }
    }

    _sync() {
        const running = this.running;
        this.visible = this.wanted;
        this.checked = running && this._proxy.Enabled === true;
        this.subtitle = running
            ? subtitleFor(this.status, this._proxy.PhoneName)
            : 'Not running';
        this.menu.setHeader(ICON_NAME, 'Staq',
            running ? this._proxy.StatusText ?? '' : 'Staq is not running');
        this._buildMenu();
    }
});

const StaqIndicator = GObject.registerClass(
class StaqIndicator extends SystemIndicator {
    _init(proxy) {
        super._init();

        this._proxy = proxy;
        this._indicator = this._addIndicator();
        this._indicator.icon_name = ICON_NAME;

        this._toggle = new StaqToggle(proxy);
        this.quickSettingsItems.push(this._toggle);

        this._proxy.connectObject(
            'notify::g-name-owner', () => this._sync(),
            'g-properties-changed', () => this._sync(),
            this);
        this._sync();
    }

    _sync() {
        this._indicator.visible = this._toggle.wanted && this._toggle.status === 'connected';
    }
});

function elapsed(since) {
    const seconds = Math.max(0, Math.floor(Date.now() / 1000) - since);
    const minutes = Math.floor(seconds / 60);
    return `${minutes}:${String(seconds % 60).padStart(2, '0')}`;
}

const StaqCallWidget = GObject.registerClass(
class StaqCallWidget extends PanelMenu.Button {
    _init(proxy) {
        super._init(0.0, 'Staq call', true);

        this._proxy = proxy;
        this._timer = 0;

        const box = new St.BoxLayout({style: 'spacing: 8px;'});
        this.add_child(box);

        box.add_child(new St.Icon({
            icon_name: 'call-start-symbolic',
            style_class: 'system-status-icon',
        }));

        this._label = new St.Label({
            y_align: Clutter.ActorAlign.CENTER,
            style: 'max-width: 260px;',
        });
        this._label.clutter_text.ellipsize = Pango.EllipsizeMode.END;
        box.add_child(this._label);

        this._muteIcon = new St.Icon({style_class: 'system-status-icon'});
        this._mute = new St.Button({
            child: this._muteIcon,
            accessible_name: 'Mute',
            y_align: Clutter.ActorAlign.CENTER,
        });
        this._mute.connect('clicked', () => this._action(
            this._proxy.CallMuted ? 'unmute' : 'mute'));
        box.add_child(this._mute);

        this._end = new St.Button({
            child: new St.Icon({
                icon_name: 'call-stop-symbolic',
                style_class: 'system-status-icon',
            }),
            accessible_name: 'End call',
            y_align: Clutter.ActorAlign.CENTER,
            style: 'background-color: #c01c28; color: #ffffff; border-radius: 99px; padding: 0 6px;',
        });
        this._end.connect('clicked', () => this._action('end'));
        box.add_child(this._end);

        this._proxy.connectObject(
            'notify::g-name-owner', () => this._sync(),
            'g-properties-changed', () => this._sync(),
            this);
        this.connect('destroy', () => this._stopTimer());
        this._sync();
    }

    get _state() {
        return this._proxy.g_name_owner !== null ? this._proxy.CallState ?? 'idle' : 'idle';
    }

    _action(action) {
        this._proxy.CallActionAsync(action)
            .catch(e => console.warn(`Staq: ${action} failed: ${e.message}`));
    }

    _stopTimer() {
        if (this._timer) {
            GLib.source_remove(this._timer);
            this._timer = 0;
        }
    }

    // The caller is the phone's text: St.Label shows it as plain text.
    _updateLabel() {
        const caller = this._proxy.CallCaller ?? '';
        const since = Number(this._proxy.CallSince ?? 0);
        if (this._state === 'ringing')
            this._label.text = `Incoming: ${caller}`;
        else if (since > 0)
            this._label.text = `Connected to ${caller} · ${elapsed(since)}`;
        else
            this._label.text = `Calling ${caller}…`;
    }

    _sync() {
        const state = this._state;
        this.visible = state !== 'idle';
        this._mute.visible = state === 'active';
        const muted = this._proxy.CallMuted === true;
        this._muteIcon.icon_name = muted
            ? 'microphone-sensitivity-muted-symbolic'
            : 'microphone-sensitivity-high-symbolic';
        this._mute.accessible_name = muted ? 'Unmute' : 'Mute';
        this._mute.style = muted
            ? 'background-color: rgba(255, 255, 255, 0.25); border-radius: 99px; padding: 0 6px;'
            : 'padding: 0 6px;';

        if (!this.visible) {
            this._stopTimer();
            return;
        }
        this._updateLabel();
        if (!this._timer) {
            this._timer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 1, () => {
                this._updateLabel();
                return GLib.SOURCE_CONTINUE;
            });
        }
    }
});

export default class StaqExtension extends Extension {
    enable() {
        // Staq is not started for the proxy: a missing name shows as
        // "Not running" and the toggle starts it on request.
        this._proxy = new ConnectionProxy(Gio.DBus.session, BUS_NAME, OBJECT_PATH,
            (proxy, error) => {
                if (error)
                    console.warn(`Staq: no proxy: ${error.message}`);
            },
            null,
            Gio.DBusProxyFlags.DO_NOT_AUTO_START);
        this._indicator = new StaqIndicator(this._proxy);
        Main.panel.statusArea.quickSettings.addExternalIndicator(this._indicator);
        this._callWidget = new StaqCallWidget(this._proxy);
        Main.panel.addToStatusArea('staq-call', this._callWidget, 0, 'right');
    }

    disable() {
        this._callWidget?.destroy();
        this._callWidget = null;
        this._indicator?.quickSettingsItems.forEach(item => item.destroy());
        this._indicator?.destroy();
        this._indicator = null;
        this._proxy = null;
    }
}
