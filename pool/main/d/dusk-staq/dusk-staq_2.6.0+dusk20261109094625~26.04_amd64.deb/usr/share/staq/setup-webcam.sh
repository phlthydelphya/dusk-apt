#!/usr/bin/env bash
# Staq's webcam (docs/protocol-v2.md §21): a v4l2loopback device named
# "Staq Camera", now and at every boot, so Chrome, Zoom, OBS and other
# V4L2 apps see the phone's camera. Without it only PipeWire apps do.
#
# Run as root (Staq runs it through pkexec). `--remove` undoes it.
#
# Existing v4l2loopback settings are left alone: the device is added next to
# any the machine already has with v4l2loopback-ctl, and the module's own
# options in /etc/modprobe.d are never written.
set -euo pipefail

unit=/etc/systemd/system/staq-webcam.service
helper=/usr/local/libexec/staq-webcam-device
helper_dir=$(dirname "$helper")
helper_name=$(basename "$helper")
label="Staq Camera"

# True when $helper_dir is root's own directory, not a link and writable by
# nobody else: the only place a file that runs as root at every boot is
# written to or removed from.
helper_dir_is_roots() {
    [[ ! -L "$helper_dir" && -d "$helper_dir" ]] || return 1
    [[ "$(stat -c %u "$helper_dir")" == 0 ]] || return 1
    [[ $(( 8#$(stat -c %a "$helper_dir") & 8#022 )) -eq 0 ]]
}

if [[ "$(id -u)" -ne 0 ]]; then
    echo "Run this as root: sudo $0" >&2
    exit 1
fi

# The setup made before the app was renamed (Phone Link) used other names;
# it goes whenever this script runs, so that one unit, not two, makes the
# device at boot.
remove_legacy() {
    systemctl disable --now phone-link-webcam.service 2>/dev/null || true
    rm -f /etc/systemd/system/phone-link-webcam.service /usr/local/libexec/phone-link-webcam-device
    # The device the old unit made this boot; busy, it goes at the next one.
    for name in /sys/class/video4linux/*/name; do
        [[ -e "$name" && "$(cat "$name")" == "Phone Link Camera" ]] || continue
        v4l2loopback-ctl delete "/dev/$(basename "$(dirname "$name")")" 2>/dev/null || true
    done
}

if [[ "${1:-}" == "--remove" ]]; then
    remove_legacy
    systemctl disable --now staq-webcam.service 2>/dev/null || true
    rm -f "$unit"
    if helper_dir_is_roots; then
        rm -f "$helper"
    else
        echo "$helper_dir is not root's own directory; $helper was left alone." >&2
    fi
    systemctl daemon-reload
    for name in /sys/class/video4linux/*/name; do
        [[ -e "$name" ]] || continue
        if [[ "$(cat "$name")" == "$label" || "$(cat "$name")" == "Phone Link Camera" ]]; then
            dev=/dev/$(basename "$(dirname "$name")")
            v4l2loopback-ctl delete "$dev" 2>/dev/null || echo "$dev is in use; it goes at the next boot." >&2
        fi
    done
    echo "Removed the Staq Camera setup."
    exit 0
fi

if ! modinfo v4l2loopback >/dev/null 2>&1; then
    echo "The v4l2loopback kernel module is not installed (package v4l2loopback-dkms)." >&2
    exit 3
fi
ctl=$(command -v v4l2loopback-ctl || true)
if [[ -z "$ctl" ]]; then
    echo "v4l2loopback-ctl is not installed (package v4l2loopback-utils)." >&2
    exit 4
fi

# What runs at boot:
# - loads the module if it is not loaded: with the machine's own options when
#   it has some, otherwise straight away as "Staq Camera" (the quotes
#   are part of the argument: the kernel reads card_label="a b" as one value);
# - adds "Staq Camera" when no device has that name yet.
# The helper runs as root at every boot, so it is written only into a
# directory that is root's own and that nobody else can write to, and never
# through a link: a user who could write there would otherwise have this
# script put their file, or a link to anywhere, in root's path. The script
# changes into the directory once checked and works with names relative to
# it, so a parent swapped under it afterwards changes nothing.
remove_legacy
install -d -m 0755 "$helper_dir"
if ! helper_dir_is_roots || [[ -L "$helper" || -d "$helper" ]]; then
    echo "$helper_dir is not root's own directory; refusing to write $helper there." >&2
    exit 6
fi
cd "$helper_dir"
helper_tmp=$(mktemp ".$helper_name.XXXXXX")
# Nothing half-written is left behind if a step below fails (the name is
# relative to $helper_dir, which stays the working directory).
trap 'rm -f "./$helper_tmp"' EXIT
cat > "$helper_tmp" <<HELPER
#!/bin/sh
# Written by Staq's setup-webcam.sh. Creates "$label".
set -e
if [ ! -e /sys/module/v4l2loopback ]; then
    if modprobe -c | grep -q '^options v4l2loopback'; then
        modprobe v4l2loopback
    else
        modprobe v4l2loopback 'card_label="$label"' exclusive_caps=1
    fi
fi
grep -qx "$label" /sys/class/video4linux/*/name 2>/dev/null || $ctl add -n "$label" -x 1
HELPER
chmod 0755 "$helper_tmp"
# rename() replaces whatever is at the name, a link included, instead of
# following it; -T never moves the file into a directory of that name.
mv -fT "$helper_tmp" "$helper_name"

cat > "$unit" <<UNIT
[Unit]
Description=Staq Camera (v4l2loopback device for Staq's webcam)
After=systemd-modules-load.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=$helper

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable staq-webcam.service
systemctl restart staq-webcam.service

if grep -qx "$label" /sys/class/video4linux/*/name 2>/dev/null; then
    echo "Staq Camera is ready."
else
    echo "The device was not created; see: journalctl -u staq-webcam" >&2
    exit 5
fi
