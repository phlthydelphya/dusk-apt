#!/usr/bin/env bash
# Lets phones reach Staq through ufw (docs/protocol-v2.md §10):
# TCP 47555 for the connection and UDP 5353 for mDNS discovery.
set -euo pipefail

if [[ "$(id -u)" -ne 0 ]]; then
    echo "Run this as root: sudo $0" >&2
    exit 1
fi

ufw allow 47555/tcp
ufw allow 5353/udp
