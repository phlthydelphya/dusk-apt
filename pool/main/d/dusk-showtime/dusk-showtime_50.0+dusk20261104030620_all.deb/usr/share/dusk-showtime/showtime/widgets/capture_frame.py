# SPDX-License-Identifier: GPL-3.0-or-later
# SPDX-FileCopyrightText: Copyright 2026 the Dusk contributors

"""The frame around the video, 16:9 and black-barred in clean capture mode."""

from typing import Any

from gi.repository import Gdk, GObject, Graphene, Gsk, Gtk

RATIO = 16 / 9


class CaptureFrame(Gtk.Widget):
    """Holds the video.

    Normally the child fills the frame. With `capture` on, the child gets the
    largest centred 16:9 area and the rest is black, so a window capture (OBS)
    sees a fixed 16:9 picture with the video letterboxed inside it.
    """

    __gtype_name__ = "CaptureFrame"

    _child: Gtk.Widget | None = None
    _capture: bool = False

    @GObject.Property(type=Gtk.Widget)
    def child(self) -> Gtk.Widget | None:
        """The video."""
        return self._child

    @child.setter
    def child(self, child: Gtk.Widget | None) -> None:
        if self._child:
            self._child.unparent()

        self._child = child
        if child:
            child.set_parent(self)

    @GObject.Property(type=bool, default=False)
    def capture(self) -> bool:
        """Whether the frame is 16:9 with black bars."""
        return self._capture

    @capture.setter
    def capture(self, capture: bool) -> None:
        if capture == self._capture:
            return

        self._capture = capture
        self.queue_allocate()
        self.queue_draw()

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.set_overflow(Gtk.Overflow.HIDDEN)

    def do_dispose(self) -> None:
        """Unparent the child."""
        if self._child:
            self._child.unparent()
            self._child = None

        Gtk.Widget.do_dispose(self)

    def do_measure(
        self, orientation: Gtk.Orientation, for_size: int
    ) -> tuple[int, int, int, int]:
        """Measure like the child."""
        if not self._child:
            return 0, 0, -1, -1

        return self._child.measure(orientation, for_size)

    def do_get_request_mode(self) -> Gtk.SizeRequestMode:
        """Same as the child."""
        return (
            self._child.get_request_mode()
            if self._child
            else Gtk.SizeRequestMode.CONSTANT_SIZE
        )

    def frame_rect(self, width: int, height: int) -> tuple[int, int, int, int]:
        """The child's area (x, y, width, height) in a `width`×`height` frame."""
        if not self._capture or not width or not height:
            return 0, 0, width, height

        if width / height > RATIO:
            frame_width, frame_height = round(height * RATIO), height
        else:
            frame_width, frame_height = width, round(width / RATIO)

        return (
            (width - frame_width) // 2,
            (height - frame_height) // 2,
            frame_width,
            frame_height,
        )

    def do_size_allocate(self, width: int, height: int, baseline: int) -> None:
        """Give the child its area."""
        if not self._child:
            return

        x, y, child_width, child_height = self.frame_rect(width, height)
        transform = _translate(x, y)
        self._child.allocate(child_width, child_height, baseline, transform)

    def do_snapshot(self, snapshot: Gtk.Snapshot) -> None:
        """Black behind everything in capture mode, then the child."""
        if self._capture:
            black = Gdk.RGBA()
            black.parse("black")
            rect = Graphene.Rect().init(0, 0, self.get_width(), self.get_height())
            snapshot.append_color(black, rect)

        if self._child:
            self.snapshot_child(self._child, snapshot)


def _translate(x: int, y: int) -> Gsk.Transform | None:
    """A transform moving by (x, y), or None for no move."""
    if not x and not y:
        return None

    point = Graphene.Point()
    point.x, point.y = x, y
    return Gsk.Transform.new().translate(point)
