# SPDX-License-Identifier: GPL-3.0-or-later
# SPDX-FileCopyrightText: Copyright 2026 the Dusk contributors

"""Dusk Showtime's playlist: items, folder scanning, natural sort, shuffle, repeat.

Nothing here touches GTK or GStreamer, so the unit tests load this module on
its own (tests/test_playlist.py).
"""

import random
import re
import threading
from collections.abc import Callable, Iterable, Sequence
from enum import IntEnum
from logging import getLogger
from pathlib import PurePath
from typing import Any

from gi.repository import Gio, GLib, GObject

logger = getLogger("showtime")


def redact_uri(uri: str | None) -> str:
    """`uri` made safe to log: no user:password@, no query, no fragment.

    A Jellyfin stream URL carries its api_key in the query, and the journal
    (and an Apport crash report built from it) keeps whatever is logged.
    """
    if not uri:
        return ""
    scheme, sep, rest = uri.partition("://")
    if not sep:
        return uri
    base = re.split(r"[?#]", rest, maxsplit=1)[0]
    authority, slash, path = base.partition("/")
    authority = authority.rpartition("@")[2]
    return f"{scheme}://{authority}{slash}{path}" + ("?…" if base != rest else "")


# Media by file name extension, the formats GStreamer (with gstreamer1.0-libav
# and the plugins-* packages) plays: VLC's own list, minus playlists, images
# and subtitles
VIDEO_EXTENSIONS = frozenset({
    "3g2", "3gp", "3gp2", "3gpp", "amv", "asf", "avi", "bik", "divx", "dv",
    "dvr-ms", "evo", "f4v", "flv", "gvi", "gxf", "h264", "h265", "hevc", "ivf",
    "m1v", "m2t", "m2ts", "m2v", "m4v", "mjpeg", "mjpg", "mkv", "mov", "mp2v",
    "mp4", "mp4v", "mpe", "mpeg", "mpeg1", "mpeg2", "mpeg4", "mpg", "mpv2",
    "mts", "mtv", "mxf", "nsv", "nut", "nuv", "obu", "ogm", "ogv", "ogx",
    "qt", "rec", "rm", "rmvb", "rpl", "thp", "tod", "tp", "trp", "ts", "tts",
    "vob", "vro", "webm", "wm", "wmv", "wtv", "xesc", "y4m",
})
AUDIO_EXTENSIONS = frozenset({
    "aac", "ac3", "adts", "aif", "aifc", "aiff", "alac", "amr", "ape", "au",
    "caf", "dts", "eac3", "flac", "m4a", "m4b", "mka", "mp1", "mp2", "mp3",
    "mpa", "mpc", "oga", "ogg", "opus", "spx", "tta", "voc", "w64", "wav",
    "weba", "wma", "wv",
})
MEDIA_EXTENSIONS = VIDEO_EXTENSIONS | AUDIO_EXTENSIONS

# Content types that are video/* or audio/* but are not media themselves
NOT_MEDIA_TYPES = frozenset({
    "audio/x-mpegurl",
    "audio/mpegurl",
    "audio/x-scpls",
    "audio/x-ms-asx",
    "video/vnd.mpegurl",
    "video/x-ms-asf-plugin",
})

_DIGITS = re.compile(r"(\d+)")


def natural_key(text: str) -> tuple:
    """Sort key that orders numbers by value: "ep2" before "ep10".

    Case-insensitive; the text itself breaks ties so the order is total.
    """
    parts = tuple(
        (0, int(chunk), "") if chunk.isdigit() else (1, 0, chunk.casefold())
        for chunk in _DIGITS.split(text)
        if chunk
    )
    return (parts, text)


def natural_path_key(path: str) -> tuple:
    """Natural sort key for a relative path, folder by folder."""
    return tuple(natural_key(part) for part in PurePath(path).parts)


def is_media_name(name: str, content_type: str | None = None) -> bool:
    """Whether a file name (and its guessed content type) looks like media."""
    if name.startswith("."):
        return False

    suffix = name.rsplit(".", 1)[-1].casefold() if "." in name else ""
    if suffix in MEDIA_EXTENSIONS:
        return True

    if content_type is None:
        content_type, _uncertain = Gio.content_type_guess(name, None)

    mime = Gio.content_type_get_mime_type(content_type) if content_type else None
    if not mime or mime in NOT_MEDIA_TYPES:
        return False

    return mime.startswith(("video/", "audio/"))


class RepeatMode(IntEnum):
    """What happens at the end of an item (GSettings repeat-mode nicks)."""

    OFF = 0
    ALL = 1
    ONE = 2

    @property
    def nick(self) -> str:
        """The GSettings / action state name."""
        return self.name.lower()

    @classmethod
    def from_nick(cls, nick: str) -> "RepeatMode":
        """The mode for a GSettings / action state name ("off" if unknown)."""
        try:
            return cls[nick.upper()]
        except KeyError:
            return cls.OFF


class PlaylistItem(GObject.Object):
    """One entry of the playlist."""

    __gtype_name__ = "PlaylistItem"

    _next_id = 0

    gfile = GObject.Property(type=Gio.File)
    title = GObject.Property(type=str, default="")
    folder = GObject.Property(type=str, default="")
    current = GObject.Property(type=bool, default=False)
    failed = GObject.Property(type=bool, default=False)

    def __init__(self, gfile: Gio.File, folder: str = "", **kwargs: Any) -> None:
        name = gfile.get_basename() or gfile.get_uri()
        stem = name.rsplit(".", 1)[0] if "." in name.lstrip(".") else name
        super().__init__(gfile=gfile, title=stem, folder=folder, **kwargs)

        PlaylistItem._next_id += 1
        self.item_id = PlaylistItem._next_id

    @property
    def uri(self) -> str:
        """The item's URI."""
        return self.gfile.get_uri()


class Playlist(GObject.Object):
    """An ordered list of media with a current item, shuffle and repeat.

    `items` is a `Gio.ListStore` for list views. Next and previous follow the
    list order, or with shuffle on, a random order that keeps the current item
    and is drawn again when Repeat All wraps around.
    """

    __gtype_name__ = "Playlist"

    changed = GObject.Signal(name="changed")

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.items = Gio.ListStore.new(PlaylistItem)
        self._current: PlaylistItem | None = None
        self._shuffle = False
        self._repeat = RepeatMode.OFF
        self._order: list[PlaylistItem] = []
        # Neighbours of a current item that was removed while it played, so
        # next and previous still continue from where it was
        self._gap: tuple[PlaylistItem | None, PlaylistItem | None] | None = None
        self.rng = random.Random()

    # Properties

    @GObject.Property(type=PlaylistItem)
    def current(self) -> PlaylistItem | None:
        """The item playing now."""
        return self._current

    @current.setter
    def current(self, item: PlaylistItem | None) -> None:
        if item is self._current:
            return

        if self._shuffle and item in self._order:
            # A picked item plays next in the random order: what played stays
            # played, what did not still comes
            index = self._order.index(item)
            anchor = (
                self._order.index(self._current)
                if self._current in self._order
                else -1
            )
            self._order.pop(index)
            if anchor > index:
                anchor -= 1
            self._order.insert(anchor + 1, item)  # pyright: ignore[reportArgumentType]

        if self._current:
            self._current.props.current = False

        self._current = item
        self._gap = None

        if item:
            item.props.current = True

        self.emit("changed")

    @GObject.Property(type=bool, default=False)
    def shuffle(self) -> bool:
        """Whether next and previous follow a random order."""
        return self._shuffle

    @shuffle.setter
    def shuffle(self, shuffle: bool) -> None:
        if shuffle == self._shuffle:
            return

        self._shuffle = shuffle
        if shuffle:
            self._reshuffle(keep_current_first=True)

        self.emit("changed")

    @GObject.Property(type=int, default=0)
    def repeat(self) -> int:
        """The `RepeatMode`."""
        return int(self._repeat)

    @repeat.setter
    def repeat(self, mode: int) -> None:
        mode = RepeatMode(mode)
        if mode == self._repeat:
            return

        self._repeat = mode
        self.emit("changed")

    # Contents

    def __len__(self) -> int:
        return self.items.get_n_items()

    def __bool__(self) -> bool:
        # A playlist object is always "there", empty or not
        return True

    def __iter__(self):
        return iter(self.items)

    def index_of(self, item: PlaylistItem) -> int | None:
        """The position of `item`, or None."""
        found, position = self.items.find(item)
        return position if found else None

    def replace(self, items: Sequence[PlaylistItem]) -> None:
        """Replace the whole playlist."""
        self._current = None
        self._gap = None
        self.items.splice(0, len(self), list(items))
        if self._shuffle:
            self._reshuffle(keep_current_first=False)
        self.emit("changed")

    def extend(self, items: Sequence[PlaylistItem]) -> None:
        """Add items at the end (queue them)."""
        if not items:
            return

        self.items.splice(len(self), 0, list(items))

        if self._shuffle:
            # New items land at random places after the current one
            start = (
                self._order.index(self._current) + 1
                if self._current in self._order
                else 0
            )
            for item in items:
                self._order.insert(self.rng.randint(start, len(self._order)), item)

        self.emit("changed")

    def remove(self, item: PlaylistItem) -> None:
        """Remove `item`; the current item keeps playing until it ends."""
        if (position := self.index_of(item)) is None:
            return

        if item is self._current:
            sequence = self._sequence()
            index = sequence.index(item)
            self._gap = (
                sequence[index - 1] if index > 0 else None,
                sequence[index + 1] if index + 1 < len(sequence) else None,
            )
            item.props.current = False
            self._current = None
        elif self._gap and item in self._gap:
            self._gap = tuple(None if i is item else i for i in self._gap)  # pyright: ignore[reportAttributeAccessIssue]

        self.items.remove(position)
        if item in self._order:
            self._order.remove(item)

        self.emit("changed")

    def clear(self) -> None:
        """Remove every item."""
        self.replace(())

    def move(self, item: PlaylistItem, position: int) -> None:
        """Move `item` to `position` (counted without the item itself)."""
        if (old := self.index_of(item)) is None:
            return

        position = max(0, min(position, len(self) - 1))
        if position == old:
            return

        self.items.remove(old)
        self.items.insert(position, item)
        self.emit("changed")

    # Navigation

    def _sequence(self) -> list[PlaylistItem]:
        return list(self._order) if self._shuffle else list(self.items)

    def _reshuffle(self, *, keep_current_first: bool) -> None:
        order = list(self.items)
        self.rng.shuffle(order)

        if keep_current_first and self._current in order:
            order.remove(self._current)
            order.insert(0, self._current)  # pyright: ignore[reportArgumentType]
        elif self._current in order and len(order) > 1 and order[0] is self._current:
            # A new round does not start with the item that just played
            order[0], order[1] = order[1], order[0]

        self._order = order

    def next_item(self, *, wrap: bool | None = None) -> PlaylistItem | None:
        """The item after the current one, or None at the end.

        Repeat All (or `wrap`) wraps around; with shuffle, that draws a new
        random order. Only peeks unless it wraps a shuffled list.
        """
        wrap = self._repeat == RepeatMode.ALL if wrap is None else wrap
        sequence = self._sequence()
        if not sequence:
            return None

        if self._current is None:
            if self._gap is not None:
                if self._gap[1] is not None:
                    return self._gap[1]
                if not wrap:
                    return None
            else:
                return sequence[0]
        elif (index := sequence.index(self._current)) + 1 < len(sequence):
            return sequence[index + 1]
        elif not wrap:
            return None

        if self._shuffle:
            self._reshuffle(keep_current_first=False)
            return self._order[0]

        return sequence[0]

    def previous_item(self, *, wrap: bool | None = None) -> PlaylistItem | None:
        """The item before the current one, or None at the start."""
        wrap = self._repeat == RepeatMode.ALL if wrap is None else wrap
        sequence = self._sequence()
        if not sequence:
            return None

        if self._current is None:
            if self._gap is not None and self._gap[0] is not None:
                return self._gap[0]
            return sequence[-1] if wrap else None

        if (index := sequence.index(self._current)) > 0:
            return sequence[index - 1]

        return sequence[-1] if wrap and len(sequence) > 1 else None

    def can_go_next(self) -> bool:
        """Whether there is an item to go to with Next."""
        sequence = self._sequence()
        if not sequence:
            return False
        if self._repeat == RepeatMode.ALL:
            return len(sequence) > 1 or self._current is None
        if self._current is None:
            return self._gap is None or self._gap[1] is not None
        return sequence.index(self._current) + 1 < len(sequence)

    def can_go_previous(self) -> bool:
        """Whether there is an item to go to with Previous."""
        sequence = self._sequence()
        if not sequence:
            return False
        if self._repeat == RepeatMode.ALL:
            return len(sequence) > 1 or self._current is None
        if self._current is None:
            return self._gap is not None and self._gap[0] is not None
        return sequence.index(self._current) > 0

    def item_after_end(self) -> PlaylistItem | None:
        """What plays when the current item ends (None: stop).

        Repeat One gives the current item again.
        """
        if self._repeat == RepeatMode.ONE and self._current is not None:
            return self._current

        return self.next_item()


# Folder scanning


def _scan(
    gfiles: Iterable[Gio.File],
    recursive: bool,
    cancellable: Gio.Cancellable | None,
) -> list[tuple[Gio.File, str]]:
    """List media: (file, parent folder name) pairs in natural order.

    Files named directly are kept whatever their type (the user chose them);
    folders contribute their media files, with subfolders if `recursive`.
    Hidden files and folders are skipped; symlinks are followed, but a folder
    is never entered twice, so symlink loops end.
    """
    attrs = ",".join((
        Gio.FILE_ATTRIBUTE_STANDARD_NAME,
        Gio.FILE_ATTRIBUTE_STANDARD_TYPE,
        Gio.FILE_ATTRIBUTE_STANDARD_IS_HIDDEN,
        Gio.FILE_ATTRIBUTE_STANDARD_FAST_CONTENT_TYPE,
        Gio.FILE_ATTRIBUTE_ID_FILE,
    ))
    found: list[tuple[Gio.File, str]] = []

    for gfile in gfiles:
        try:
            file_type = gfile.query_file_type(Gio.FileQueryInfoFlags.NONE, cancellable)
        except GLib.Error:
            file_type = Gio.FileType.UNKNOWN

        if file_type != Gio.FileType.DIRECTORY:
            parent = gfile.get_parent()
            found.append((gfile, (parent.get_basename() or "") if parent else ""))
            continue

        entries: list[tuple[str, Gio.File, str]] = []
        seen: set[str] = set()
        stack: list[tuple[Gio.File, str]] = [(gfile, "")]

        while stack:
            if cancellable and cancellable.is_cancelled():
                return []

            folder, rel = stack.pop()
            try:
                info = folder.query_info(Gio.FILE_ATTRIBUTE_ID_FILE, 0, cancellable)
                if (folder_id := info.get_attribute_string(Gio.FILE_ATTRIBUTE_ID_FILE)) is not None:
                    if folder_id in seen:
                        continue
                    seen.add(folder_id)

                enumerator = folder.enumerate_children(
                    attrs, Gio.FileQueryInfoFlags.NONE, cancellable
                )
            except GLib.Error as error:
                logger.warning("Cannot read folder %s: %s", redact_uri(folder.get_uri()), error.message)
                continue

            folder_name = folder.get_basename() or ""
            while True:
                try:
                    info = enumerator.next_file(cancellable)
                except GLib.Error as error:
                    logger.warning("Cannot list %s: %s", redact_uri(folder.get_uri()), error.message)
                    break

                if info is None:
                    break

                name = info.get_name()
                if info.get_is_hidden() or name.startswith("."):
                    continue

                child = folder.get_child(name)
                child_rel = f"{rel}/{name}" if rel else name

                match info.get_file_type():
                    case Gio.FileType.DIRECTORY:
                        if recursive:
                            stack.append((child, child_rel))
                    case Gio.FileType.REGULAR | Gio.FileType.SYMBOLIC_LINK:
                        if is_media_name(
                            name,
                            info.get_attribute_string(
                                Gio.FILE_ATTRIBUTE_STANDARD_FAST_CONTENT_TYPE
                            ),
                        ):
                            entries.append((child_rel, child, folder_name))

            enumerator.close(None)

        entries.sort(key=lambda entry: natural_path_key(entry[0]))
        found.extend((child, folder_name) for _rel, child, folder_name in entries)

    return found


def scan_async(
    gfiles: Sequence[Gio.File],
    recursive: bool,
    callback: Callable[[list[PlaylistItem]], None],
    cancellable: Gio.Cancellable | None = None,
) -> None:
    """Find the media in `gfiles` off the main thread.

    `callback` gets the new playlist items on the main thread (not called when
    cancelled).
    """

    def done(found: list[tuple[Gio.File, str]]) -> bool:
        if not (cancellable and cancellable.is_cancelled()):
            callback([PlaylistItem(gfile, folder) for gfile, folder in found])
        return GLib.SOURCE_REMOVE

    def run() -> None:
        try:
            found = _scan(gfiles, recursive, cancellable)
        except Exception:
            logger.exception("Scanning for media failed")
            found = []
        GLib.idle_add(done, found)

    threading.Thread(target=run, name="dusk-showtime-scan", daemon=True).start()


def scan_sync(gfiles: Sequence[Gio.File], recursive: bool) -> list[PlaylistItem]:
    """`scan_async` without the thread (for tests and small inputs)."""
    return [PlaylistItem(gfile, folder) for gfile, folder in _scan(gfiles, recursive, None)]
