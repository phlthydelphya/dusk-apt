# SPDX-License-Identifier: GPL-3.0-or-later
# SPDX-FileCopyrightText: Copyright 2024-2026 kramo

from functools import partial
from typing import Any

from gi.repository import (
    Gdk,
    GLib,
    GObject,
    Gst,
    GstPbutils,
    GstPlay,  # pyright: ignore[reportAttributeAccessIssue]
    Gtk,
)

from showtime import system, utils
from showtime.hwdecode import is_hardware
from showtime.vcam import VideoOutput


def gst_play_setup(
    picture: Gtk.Picture,
) -> tuple[Gdk.Paintable, GstPlay.Play, Gst.Element, Gst.Element, VideoOutput]:
    """Set up `GstPlay`.

    Dusk Showtime: the video sink is `VideoOutput.bin`, the display sink
    behind a tee that the virtual camera branches off.
    """
    sink = paintable_sink = Gst.ElementFactory.make("gtk4paintablesink")
    if not paintable_sink:
        msg = "Cannot make gtk4paintablesink"
        raise RuntimeError(msg)

    paintable = paintable_sink.props.paintable  # pyright: ignore[reportAttributeAccessIssue]
    picture.props.paintable = paintable

    # OpenGL doesn't work on macOS properly
    if paintable.props.gl_context and system != "Darwin":
        gl_sink = Gst.ElementFactory.make("glsinkbin")
        gl_sink.props.sink = paintable_sink  # pyright: ignore[reportAttributeAccessIssue, reportOptionalMemberAccess]
        sink = gl_sink

    output = VideoOutput(sink)

    play = GstPlay.Play(
        video_renderer=GstPlay.PlayVideoOverlayVideoRenderer.new_with_sink(
            None, output.bin
        )
    )

    pipeline = play.props.pipeline

    def set_subtitle_font_desc(*_args) -> None:
        pipeline.props.subtitle_font_desc = utils.get_subtitle_font_desc()

    if settings := Gtk.Settings.get_default():
        settings.connect("notify::gtk-xft-dpi", set_subtitle_font_desc)

    set_subtitle_font_desc()

    return paintable, play, pipeline, paintable_sink, output


class Messenger(GObject.Object):
    """A messenger between GStreamer and the app."""

    __gtype_name__ = "Messenger"

    state_changed = GObject.Signal(name="state-changed", arg_types=(object,))
    duration_changed = GObject.Signal(name="duration-changed", arg_types=(object,))
    position_updated = GObject.Signal(name="position-updated", arg_types=(object,))
    seek_done = GObject.Signal(name="seek-done")
    media_info_updated = GObject.Signal(name="media-info-updated", arg_types=(object,))
    volume_changed = GObject.Signal(name="volume-changed")
    end_of_stream = GObject.Signal(name="end-of-stream")
    warning = GObject.Signal(name="warning", arg_types=(object,))
    error = GObject.Signal(name="error", arg_types=(object,))
    missing_plugin = GObject.Signal(name="missing-plugin", arg_types=(object, str))
    decoder_added = GObject.Signal(name="decoder-added", arg_types=(str, bool))

    def __init__(
        self,
        play: GstPlay.Play,
        pipeline: Gst.Element,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)

        if bus := play.get_message_bus():
            bus.add_signal_watch()
            bus.connect("message", self._on_play_bus_message)

        # Dusk Showtime: report each decoder playbin picks (hardware or not)
        self._handlers: list[tuple[GObject.Object, int]] = [
            (
                pipeline,
                pipeline.connect("deep-element-added", self._on_deep_element_added),
            )
        ]

        # Dusk Showtime: the URI each missing-plugin message is about, noted
        # when it is posted, so one about the previous file of a playlist is
        # not taken for the next one's
        self._message_uris: dict[int, str] = {}
        self._pipeline = pipeline

        if bus := pipeline.get_bus():
            bus.enable_sync_message_emission()
            self._handlers.append(
                (
                    bus,
                    bus.connect(
                        "sync-message::element", self._on_sync_element_message
                    ),
                )
            )
            bus.add_signal_watch()
            # (GstPlay watches this bus from its own thread, so this handler
            # runs there; Dusk Showtime disconnects it in shutdown())
            self._handlers.append(
                (
                    bus,
                    bus.connect(
                        "message",
                        lambda bus, msg: GLib.idle_add(
                            partial(self._on_pipeline_bus_message, bus, msg)
                        ),
                    ),
                )
            )

    def _on_play_bus_message(self, _bus: Gst.Bus, msg: GstPlay.PlayMessage) -> None:
        match GstPlay.PlayMessage.parse_type(msg):
            case GstPlay.PlayMessage.STATE_CHANGED:
                self.emit(
                    "state-changed",
                    GstPlay.PlayMessage.parse_state_changed(msg),
                )

            case GstPlay.PlayMessage.DURATION_CHANGED:
                self.emit(
                    "duration-changed",
                    GstPlay.PlayMessage.parse_duration_changed(msg),
                )

            case GstPlay.PlayMessage.POSITION_UPDATED:
                self.emit(
                    "position-updated",
                    GstPlay.PlayMessage.parse_position_updated(msg),
                )

            case GstPlay.PlayMessage.SEEK_DONE:
                self.emit("seek-done")

            case GstPlay.PlayMessage.MEDIA_INFO_UPDATED:
                self.emit(
                    "media-info-updated",
                    GstPlay.PlayMessage.parse_media_info_updated(msg),
                )

            case GstPlay.PlayMessage.VOLUME_CHANGED:
                self.emit("volume-changed")

            case GstPlay.PlayMessage.END_OF_STREAM:
                self.emit("end-of-stream")

            case GstPlay.PlayMessage.WARNING:
                self.emit("warning", GstPlay.PlayMessage.parse_warning(msg))

            case GstPlay.PlayMessage.ERROR:
                error, _details = GstPlay.PlayMessage.parse_error(msg)
                self.emit("error", error)

    def shutdown(self) -> None:
        """Disconnect the handlers that GStreamer threads call.

        Call before the pipeline stops for good: GstPlay tears it down in its
        own thread, which must not call into Python while it exits.
        """
        if not self._handlers:
            return

        for obj, handler in self._handlers:
            obj.disconnect(handler)
        self._handlers = []

        if bus := self._pipeline.get_bus():
            bus.disable_sync_message_emission()

    def _on_deep_element_added(self, _bin, _sub_bin, element: Gst.Element) -> None:
        if not (factory := element.get_factory()):
            return

        if "Decoder" not in (factory.get_metadata(Gst.ELEMENT_METADATA_KLASS) or ""):
            return

        name = factory.get_name()
        hardware = is_hardware(factory)
        GLib.idle_add(self.emit, "decoder-added", name, hardware)

    def _on_sync_element_message(self, _bus: Gst.Bus, msg: Gst.Message) -> None:
        # Streaming thread: only note the URI
        if GstPbutils.is_missing_plugin_message(msg):
            self._message_uris[msg.get_seqnum()] = (
                self._pipeline.props.current_uri or ""
            )

    def _on_pipeline_bus_message(self, _bus: Gst.Bus, msg: Gst.Message) -> None:
        if GstPbutils.is_missing_plugin_message(msg):
            self.emit(
                "missing-plugin", msg, self._message_uris.pop(msg.get_seqnum(), "")
            )
