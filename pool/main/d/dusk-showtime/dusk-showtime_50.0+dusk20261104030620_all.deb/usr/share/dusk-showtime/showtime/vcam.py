# SPDX-License-Identifier: GPL-3.0-or-later
# SPDX-FileCopyrightText: Copyright 2026 the Dusk contributors

"""The video output: the display sink, plus an optional virtual camera.

`VideoOutput.bin` is the video sink handed to GstPlay:

    tee ─ queue ─ display sink (glsinkbin ! gtk4paintablesink)
        └ (virtual camera on) queue ─ [vapostproc] ─ videoconvert ─ videoscale
                               ─ videorate ─ capsfilter ─ appsink

The camera branch is added and removed while playing. It ends in an appsink;
a separate camera pipeline (appsrc ! v4l2sink) writes the frames to the
v4l2loopback device, so a busy, missing or failing device only stops the
camera, never playback. Only a v4l2loopback device labelled "Dusk Showtime" is
ever written to; the other loopback devices on Dusk machines ("OBS Cam",
"Staq Camera") belong to other apps.

Nothing here touches GTK, so the unit tests load this module on its own and
run the branch against a fake sink (tests/test_vcam.py).
"""

import os
from collections.abc import Callable
from dataclasses import dataclass
from logging import getLogger
from pathlib import Path
from typing import Any

from gi.repository import GLib, GObject, Gst

logger = getLogger("showtime")

DEVICE_LABEL = "Dusk Showtime"
# Loopback devices of other apps: never written to, whatever happens
PROTECTED_LABELS = frozenset({"OBS Cam", "Staq Camera"})
SYSFS_V4L = Path("/sys/class/video4linux")
SETUP_SCRIPT = "setup-virtual-camera.sh"

# Pixel format for the camera: packed 4:2:2, which every camera consumer
# (OBS, browsers, call apps) reads
CAMERA_FORMAT = "YUY2"


@dataclass(frozen=True)
class CameraDevice:
    """A v4l2loopback device that is Dusk Showtime's to write to."""

    path: str
    label: str


class DeviceError(Exception):
    """No usable virtual camera device, with a user-facing reason."""


def _read_label(entry: Path) -> str:
    try:
        return (entry / "name").read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return ""


def find_device(sysfs: Path = SYSFS_V4L, dev: Path = Path("/dev")) -> CameraDevice:
    """The v4l2loopback device labelled "Dusk Showtime".

    Raises `DeviceError` saying what is missing.
    """
    candidates = []
    try:
        entries = sorted(sysfs.glob("video*"), key=lambda p: p.name)
    except OSError:
        entries = []

    for entry in entries:
        label = _read_label(entry)
        if label != DEVICE_LABEL or label in PROTECTED_LABELS:
            continue

        # v4l2loopback devices are virtual; a real camera never qualifies
        try:
            real = entry.resolve(strict=True)
        except OSError:
            continue
        if "/devices/virtual/" not in str(real):
            logger.warning("%s is labelled %s but is not virtual", entry.name, label)
            continue

        candidates.append(dev / entry.name)

    if not candidates:
        raise DeviceError(
            _(
                "There is no “{}” camera device. Run {} once with sudo "
                "to set it up, then try again."
            ).format(DEVICE_LABEL, SETUP_SCRIPT)
        )

    path = candidates[0]
    if not path.exists():
        raise DeviceError(_("The camera device {} does not exist.").format(path))

    if not os.access(path, os.W_OK):
        raise DeviceError(
            _("No permission to write to the camera device {}.").format(path)
        )

    return CameraDevice(str(path), DEVICE_LABEL)


def check_device_label(path: str, sysfs: Path = SYSFS_V4L) -> bool:
    """Whether `path` (/dev/videoN) is still labelled "Dusk Showtime"."""
    label = _read_label(sysfs / Path(path).name)
    return label == DEVICE_LABEL and label not in PROTECTED_LABELS


def _make(factory: str, name: str | None = None, **props: Any) -> Gst.Element:
    if not (element := Gst.ElementFactory.make(factory, name)):
        msg = f"Cannot make {factory}"
        raise RuntimeError(msg)

    for key, value in props.items():
        # async_ for the "async" property (a Python keyword)
        element.set_property(key.rstrip("_").replace("_", "-"), value)

    return element


class _QuietBin(Gst.Bin):
    """A bin that keeps its children's errors and warnings to itself.

    They go to `on_problem` (on the main thread) instead of the pipeline bus,
    where GstPlay would take them for a playback error and stop.
    """

    __gtype_name__ = "DuskShowtimeQuietBin"

    on_problem: Callable[[str], None] | None = None

    def do_handle_message(self, message: Gst.Message) -> None:
        if message.type in (Gst.MessageType.ERROR, Gst.MessageType.WARNING):
            if message.type == Gst.MessageType.ERROR:
                error, debug = message.parse_error()
            else:
                error, debug = message.parse_warning()

            logger.warning("Virtual camera branch: %s (%s)", error.message, debug)

            if message.type == Gst.MessageType.ERROR and self.on_problem:
                GLib.idle_add(self.on_problem, error.message)
            return

        Gst.Bin.do_handle_message(self, message)


OVERLAY_META = "meta:GstVideoOverlayComposition"


def _memory_features(caps: Gst.Caps | None) -> set[str]:
    """The memory types in `caps` (system memory when none is named)."""
    if not caps or caps.is_empty() or caps.is_any():
        return set()

    features = caps.get_features(0)
    names = {features.get_nth(i) for i in range(features.get_size())} if features else set()
    return {n for n in names if n.startswith("memory:")} or {"memory:SystemMemory"}


def _without_overlay_meta(caps: Gst.Caps) -> Gst.Caps | None:
    """`caps` without the subtitle overlay feature, or None if it has none."""
    caps = caps.copy()
    changed = False
    for i in range(caps.get_size()):
        features = caps.get_features(i)
        if features and features.contains(OVERLAY_META):
            features.remove(OVERLAY_META)
            if features.get_size() == 0:
                features = Gst.CapsFeatures.new_empty()
                features.add("memory:SystemMemory")
            caps.set_features(i, features)
            changed = True
    return caps if changed else None


def _strip_overlay_meta(pad: Gst.Pad, info: Gst.PadProbeInfo) -> Gst.PadProbeReturn:
    """Probe on the camera branch's first pad: caps lose the overlay feature.

    With subtitles on, playbin may hand the display sink frames whose
    subtitles it is still to draw (caps feature
    meta:GstVideoOverlayComposition). The camera's converters do not take
    that feature, so it is dropped from the caps here: the camera gets the
    video without the subtitles, the display keeps them.
    """
    event = info.get_event()
    if event is None or event.type != Gst.EventType.CAPS:
        return Gst.PadProbeReturn.OK

    if (caps := _without_overlay_meta(event.parse_caps())) is None:
        return Gst.PadProbeReturn.OK

    pad.send_event(Gst.Event.new_caps(caps))
    return Gst.PadProbeReturn.DROP


def _keep_upstream_caps(_pad: Gst.Pad, info: Gst.PadProbeInfo) -> Gst.PadProbeReturn:
    """Probe on the tee's camera pad: no renegotiation for the camera.

    Linking the camera sends a reconfigure event upstream, and playbin would
    renegotiate what the display already plays. That fails for
    hardware-decoded video with subtitles (the overlay cannot draw into GPU
    memory: not-negotiated, playback stops). The branch takes the caps that
    are already flowing (see _strip_overlay_meta), so the event is dropped.
    Later files negotiate with the camera branch from the start.
    """
    event = info.get_event()
    if event is not None and event.type == Gst.EventType.RECONFIGURE:
        return Gst.PadProbeReturn.DROP
    return Gst.PadProbeReturn.OK


class VideoOutput(GObject.Object):
    """The video sink bin with the optional virtual camera branch."""

    __gtype_name__ = "DuskShowtimeVideoOutput"

    camera_stopped = GObject.Signal(name="camera-stopped", arg_types=(str,))

    def __init__(self, display_sink: Gst.Element, **kwargs: Any) -> None:
        super().__init__(**kwargs)

        self.bin = Gst.Bin.new("dusk-showtime-video-sink")
        self.tee = _make("tee", "video-tee", allow_not_linked=True)
        # A short queue: the display stays as close to the decoder as without
        # the tee, and the camera branch gets its own thread
        display_queue = _make(
            "queue",
            "display-queue",
            max_size_buffers=3,
            max_size_bytes=0,
            max_size_time=0,
        )

        for element in (self.tee, display_queue, display_sink):
            self.bin.add(element)

        self.tee.link(display_queue)
        display_queue.link(display_sink)

        if not (tee_sink := self.tee.get_static_pad("sink")):
            msg = "tee has no sink pad"
            raise RuntimeError(msg)

        self.bin.add_pad(Gst.GhostPad.new("sink", tee_sink))

        self._branch: _QuietBin | None = None
        self._tee_pad: Gst.Pad | None = None
        self._camera: Gst.Pipeline | None = None
        self._appsrc: Gst.Element | None = None
        self._frames = 0
        self._pending: tuple[Gst.Bin, Gst.Pad, int] | None = None
        self.device: str | None = None

    @property
    def camera_on(self) -> bool:
        """Whether the virtual camera branch is attached."""
        return self._branch is not None

    @property
    def frames_sent(self) -> int:
        """Frames handed to the camera since it started."""
        return self._frames

    def start_camera(
        self,
        device: str | None = None,
        *,
        width: int = 1280,
        height: int = 720,
        framerate: int = 30,
        sink: Gst.Element | None = None,
    ) -> None:
        """Send the video to `device` (or to `sink`, for tests).

        Without either, finds the "Dusk Showtime" device. Raises `DeviceError`
        or `RuntimeError` with a user-facing message; playback is untouched
        then.
        """
        if self.camera_on:
            return

        if sink is None:
            if device is None:
                device = find_device().path
            if not check_device_label(device):
                raise DeviceError(
                    _("{} is not the “{}” camera device; it is left alone.").format(
                        device, DEVICE_LABEL
                    )
                )
            sink = _make("v4l2sink", device=device, sync=False, qos=False)
        self.device = device

        # The camera pipeline, opened first: a busy or unwritable device fails
        # here, before anything is added to playback
        camera = Gst.Pipeline.new("dusk-showtime-camera")
        appsrc = _make(
            "appsrc",
            "camera-src",
            is_live=True,
            format=Gst.Format.TIME,
            do_timestamp=True,
            block=False,
            max_buffers=2,
            leaky_type=2,  # downstream: drop the oldest frame
        )
        camera.add(appsrc)
        camera.add(sink)
        appsrc.link(sink)

        if camera.set_state(Gst.State.READY) == Gst.StateChangeReturn.FAILURE:
            message = self._pop_error(camera) or _("Cannot open the camera device")
            camera.set_state(Gst.State.NULL)
            raise RuntimeError(message)

        if (bus := camera.get_bus()) is not None:
            bus.add_signal_watch()
            bus.connect("message::error", self._on_camera_error)

        branch = self._make_branch(width, height, framerate)

        self._camera = camera
        self._appsrc = appsrc
        self._frames = 0
        self._branch = branch

        appsrc.props.caps = Gst.Caps.from_string(self._caps_string(width, height, framerate))
        camera.set_state(Gst.State.PLAYING)

        self.bin.add(branch)
        branch.sync_state_with_parent()

        tee_pad = self.tee.request_pad_simple("src_%u")
        if not tee_pad or not (branch_sink := branch.get_static_pad("sink")):
            self.stop_camera()
            raise RuntimeError(_("Cannot attach the camera to playback"))

        self._tee_pad = tee_pad
        tee_pad.add_probe(Gst.PadProbeType.EVENT_UPSTREAM, _keep_upstream_caps)
        tee_pad.link(branch_sink)
        logger.info("Virtual camera on: %s", device or sink.get_factory().get_name())

    def stop_camera(self, *, immediate: bool = False) -> None:
        """Detach the camera branch and close the device.

        Normally the branch is unlinked between two frames, so playback goes
        on undisturbed. With `immediate` (the window closing), it is removed
        at once, so no GStreamer thread calls into Python afterwards.
        """
        branch, tee_pad, camera = self._branch, self._tee_pad, self._camera
        self._branch = self._tee_pad = self._camera = self._appsrc = None
        self.device = None

        # A branch still waiting to be unlinked between two frames goes now
        if immediate and self._pending is not None and branch is None:
            branch, tee_pad, probe = self._pending
            tee_pad.remove_probe(probe)
        self._pending = None

        if camera is not None:
            if (bus := camera.get_bus()) is not None:
                bus.remove_signal_watch()
            camera.set_state(Gst.State.NULL)

        if branch is None:
            return

        def remove_branch() -> bool:
            branch.set_state(Gst.State.NULL)
            if branch.get_parent() is self.bin:
                self.bin.remove(branch)
            return GLib.SOURCE_REMOVE

        if tee_pad is None:
            remove_branch()
            return

        if immediate:
            if (peer := tee_pad.get_peer()) is not None:
                tee_pad.unlink(peer)
            self.tee.release_request_pad(tee_pad)
            remove_branch()
            logger.info("Virtual camera off")
            return

        def unlink(pad: Gst.Pad, _info: Gst.PadProbeInfo) -> Gst.PadProbeReturn:
            self._pending = None
            if (peer := pad.get_peer()) is not None:
                pad.unlink(peer)
            self.tee.release_request_pad(pad)
            GLib.idle_add(remove_branch)
            return Gst.PadProbeReturn.REMOVE

        # Idle probe: runs at once when no buffer is passing, else right after
        self._pending = (branch, tee_pad, 0)
        probe = tee_pad.add_probe(Gst.PadProbeType.IDLE, unlink)
        if self._pending is not None:
            self._pending = (branch, tee_pad, probe)
        logger.info("Virtual camera off")

    # Internals

    @staticmethod
    def _caps_string(width: int, height: int, framerate: int) -> str:
        return (
            f"video/x-raw,format={CAMERA_FORMAT},width={width},height={height},"
            f"framerate={framerate}/1,pixel-aspect-ratio=1/1"
        )

    def _make_branch(self, width: int, height: int, framerate: int) -> _QuietBin:
        branch = _QuietBin()
        branch.on_problem = self._on_branch_problem

        elements = [
            # Leaky: a slow camera drops frames instead of holding up playback
            _make(
                "queue",
                max_size_buffers=2,
                max_size_bytes=0,
                max_size_time=0,
                leaky=2,
            )
        ]

        # The decoder may already hand GPU memory (VA or DMABuf) to the tee;
        # vapostproc takes that (and system memory) and gives system memory
        current = _memory_features(self.tee.get_static_pad("sink").get_current_caps())  # pyright: ignore[reportOptionalMemberAccess]

        if current - {"memory:SystemMemory"}:
            if current & {"memory:VAMemory", "memory:DMABuf"} and (
                post := Gst.ElementFactory.make("vapostproc")
            ):
                if post.find_property("add-borders"):
                    post.props.add_borders = True
                elements.append(post)
            elif "memory:GLMemory" in current and (
                download := Gst.ElementFactory.make("gldownload")
            ):
                elements.append(download)
            else:
                msg = _("The video is in a memory type the camera cannot read ({})").format(
                    ", ".join(sorted(current))
                )
                raise RuntimeError(msg)

        elements += [
            _make("videoconvert"),
            _make("videoscale", add_borders=True),
            # Fixed frame rate, but never a flood of copies: not before the
            # first frame, and not across gaps (odd timestamps, long stills)
            _make("videorate", skip_to_first=True, max_duplication_time=Gst.SECOND),
            _make(
                "capsfilter",
                caps=Gst.Caps.from_string(self._caps_string(width, height, framerate)),
            ),
            appsink := _make(
                "appsink",
                emit_signals=True,
                sync=False,
                async_=False,
                drop=True,
                max_buffers=1,
                enable_last_sample=False,
                qos=False,
            ),
        ]

        for element in elements:
            branch.add(element)
        for upstream, downstream in zip(elements, elements[1:], strict=False):
            if not upstream.link(downstream):
                msg = f"Cannot link {upstream.get_name()} to {downstream.get_name()}"
                raise RuntimeError(msg)

        appsink.connect("new-sample", self._on_new_sample)

        if not (queue_sink := elements[0].get_static_pad("sink")):
            msg = "queue has no sink pad"
            raise RuntimeError(msg)

        # On the branch's outer pad, the first the caps reach (it checks them)
        ghost = Gst.GhostPad.new("sink", queue_sink)
        ghost.add_probe(Gst.PadProbeType.EVENT_DOWNSTREAM, _strip_overlay_meta)
        branch.add_pad(ghost)
        return branch

    def _on_new_sample(self, appsink: Gst.Element) -> Gst.FlowReturn:
        sample = appsink.emit("pull-sample")
        appsrc = self._appsrc
        if sample is None or appsrc is None:
            return Gst.FlowReturn.OK

        if (buffer := sample.get_buffer()) is None:
            return Gst.FlowReturn.OK

        # The camera has its own clock: drop playback's timestamps
        buffer = buffer.copy()
        buffer.pts = buffer.dts = Gst.CLOCK_TIME_NONE
        if appsrc.emit("push-buffer", buffer) == Gst.FlowReturn.OK:
            self._frames += 1

        # Never report a camera problem back into playback
        return Gst.FlowReturn.OK

    @staticmethod
    def _pop_error(pipeline: Gst.Pipeline) -> str | None:
        if not (bus := pipeline.get_bus()):
            return None
        while msg := bus.pop_filtered(Gst.MessageType.ERROR):
            error, debug = msg.parse_error()
            logger.warning("Virtual camera: %s (%s)", error.message, debug)
            return error.message
        return None

    def _on_camera_error(self, _bus: Gst.Bus, message: Gst.Message) -> None:
        error, debug = message.parse_error()
        logger.warning("Virtual camera device: %s (%s)", error.message, debug)
        self._stop_with_reason(error.message)

    def _on_branch_problem(self, reason: str) -> bool:
        self._stop_with_reason(reason)
        return GLib.SOURCE_REMOVE

    def _stop_with_reason(self, reason: str) -> None:
        if not self.camera_on:
            return
        self.stop_camera()
        self.emit("camera-stopped", reason)
