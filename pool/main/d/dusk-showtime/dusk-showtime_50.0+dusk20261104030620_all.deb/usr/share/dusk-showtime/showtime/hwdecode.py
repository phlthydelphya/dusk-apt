# SPDX-License-Identifier: GPL-3.0-or-later
# SPDX-FileCopyrightText: Copyright 2026 the Dusk contributors

"""Hardware video decoding: the VA-API decoders of GStreamer's va plugin.

playbin picks decoders by rank. Since GStreamer 1.24 the va decoders rank
PRIMARY + 1, just above FFmpeg's (avdec_*, PRIMARY) and libvpx's, so a format
the GPU decodes goes to the GPU; formats it cannot decode (on an AMD Radeon of
this generation: VP8, AV1, MPEG-4 Part 2, Theora...) fall back to software.
Older GStreamer ranked them lower, and some systems lower them through
GST_PLUGIN_FEATURE_RANK; `apply()` raises them back to PRIMARY + 1 unless
that variable names them, and `apply(enabled=False)` turns hardware decoding
off (the `hardware-decoding` setting).
"""

import os
from logging import getLogger

from gi.repository import Gst

logger = getLogger("showtime")

HW_RANK = Gst.Rank.PRIMARY + 1
HW_PLUGINS = ("va",)


def hardware_decoders() -> list[Gst.ElementFactory]:
    """The VA-API decoder factories in the registry."""
    registry = Gst.Registry.get()
    decoders = []
    for plugin in HW_PLUGINS:
        for feature in registry.get_feature_list_by_plugin(plugin):
            if isinstance(feature, Gst.ElementFactory) and "Decoder" in (
                feature.get_metadata(Gst.ELEMENT_METADATA_KLASS) or ""
            ):
                decoders.append(feature)
    return decoders


def is_hardware(factory: Gst.ElementFactory | None) -> bool:
    """Whether `factory` is a hardware decoder."""
    return bool(factory) and factory.get_plugin_name() in HW_PLUGINS  # pyright: ignore[reportOptionalMemberAccess]


def apply(*, enabled: bool = True) -> list[str]:
    """Rank the hardware decoders for playbin; the names of those in use."""
    overridden = os.environ.get("GST_PLUGIN_FEATURE_RANK", "")
    used = []

    for factory in hardware_decoders():
        name = factory.get_name()
        if not enabled:
            factory.set_rank(Gst.Rank.NONE)
            continue

        if name in overridden:
            logger.debug("%s rank left to GST_PLUGIN_FEATURE_RANK", name)
        elif factory.get_rank() < HW_RANK and name != "vajpegdec":
            # (vajpegdec stays as it is: GStreamer leaves it unranked because
            # it handles few JPEG variants)
            factory.set_rank(HW_RANK)

        if factory.get_rank() > Gst.Rank.NONE:
            used.append(name)

    logger.debug(
        "Hardware decoding %s: %s",
        "on" if enabled else "off",
        ", ".join(used) or "no VA-API decoders",
    )
    return used
