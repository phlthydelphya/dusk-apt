#!/usr/bin/env bash
# Sets up the "Dusk Showtime" virtual camera for Dusk Showtime: rewrites the
# v4l2loopback module options so two fixed loopback devices exist,
#   /dev/video10  "OBS Cam"        (OBS Studio's virtual camera, as before)
#   /dev/video11  "Dusk Showtime"  (Dusk Showtime's virtual camera, new)
# each with exclusive_caps=1, and makes the module load at boot. Staq's camera
# ("Staq Camera") is not one of them: Staq adds it itself when it needs it
# (v4l2loopback-ctl add), so a fixed one would clash with that.
#
# What it does, in order (it prints every change):
#  1. Backs up every file it changes to /var/lib/dusk/v4l2loopback/<time>/
#     (same paths below that folder), with a RESTORE note.
#  2. Writes /etc/modprobe.d/v4l2loopback.conf with the options above; any
#     other option already set there (e.g. max_buffers) is kept. Lines setting
#     v4l2loopback options in other /etc/modprobe.d files are commented out,
#     because modprobe would merge them.
#  3. Adds v4l2loopback to /etc/modules-load.d/v4l2loopback.conf if missing.
#  4. Reloads the module, but only when no loopback device is open (no
#     process uses /dev/video2, /dev/video10, /dev/video11 or any other
#     v4l2loopback device, and the module's use count is 0). Otherwise it
#     changes nothing live and says to log out and back in, or reboot.
#     With --kill it first stops every process that holds a loopback device:
#     SIGTERM, up to 5 s to exit, then SIGKILL. Only loopback devices count,
#     never a real camera (/dev/video0), and never this script, its parent,
#     PipeWire, WirePlumber or systemd.
#
# Run it yourself with sudo:  sudo bash setup-virtual-camera.sh
# Options: --dry-run   show the changes, write nothing (no root needed)
#          --no-reload write the files, never reload the module
#          --kill      stop the processes that hold a loopback device (OBS,
#                      Staq, ...) so the module can be reloaded now
# DUSK_VCAM_ROOT=DIR treats DIR as / (for testing on a copy; implies no
# module reload).
set -euo pipefail

ROOT="${DUSK_VCAM_ROOT:-}"
DRY=0
RELOAD=1
KILL=0
for arg in "$@"; do
    case "$arg" in
        --dry-run) DRY=1 ;;
        --no-reload) RELOAD=0 ;;
        --kill) KILL=1 ;;
        -h|--help) sed -n '2,33p' "$0"; exit 0 ;;
        *) echo "setup-virtual-camera.sh: unknown argument $arg" >&2; exit 2 ;;
    esac
done
[[ -z "$ROOT" ]] || RELOAD=0

if (( ! DRY )) && [[ -z "$ROOT" ]] && (( EUID != 0 )); then
    echo "setup-virtual-camera.sh: run as root: sudo bash $0" >&2
    exit 1
fi

MODPROBE_DIR="$ROOT/etc/modprobe.d"
CONF="$MODPROBE_DIR/v4l2loopback.conf"
LOAD_CONF="$ROOT/etc/modules-load.d/v4l2loopback.conf"
BACKUP="$ROOT/var/lib/dusk/v4l2loopback/$(date -u +%Y%m%dT%H%M%SZ)"

# The devices, in module order (video_nr, card_label and exclusive_caps are
# per-device lists). Labels must not contain commas.
NRS=(10 11)
LABELS=("OBS Cam" "Dusk Showtime")
MANAGED_KEYS=" devices video_nr card_label exclusive_caps "

say() { printf '%s\n' "$*"; }

# Every option already given to v4l2loopback in modprobe.d, other than the
# ones this script sets, as KEY=VALUE words (the last one of a key wins)
declare -A kept=()
kept_order=()
other_files=()
shopt -s nullglob
for f in "$MODPROBE_DIR"/*.conf; do
    grep -Eq '^[[:space:]]*options[[:space:]]+v4l2loopback([[:space:]]|$)' "$f" || continue
    [[ "$f" == "$CONF" ]] || other_files+=("$f")
    while IFS= read -r line; do
        # Split KEY=VALUE words, keeping quoted values whole
        rest="${line#*v4l2loopback}"
        while [[ "$rest" =~ ^[[:space:]]*([A-Za-z0-9_]+)=(\"[^\"]*\"|[^[:space:]]*)(.*)$ ]]; do
            key="${BASH_REMATCH[1]}"
            value="${BASH_REMATCH[2]}"
            rest="${BASH_REMATCH[3]}"
            [[ "$MANAGED_KEYS" == *" $key "* ]] && continue
            [[ -n "${kept[$key]+x}" ]] || kept_order+=("$key")
            kept[$key]="$value"
        done
    done < <(grep -E '^[[:space:]]*options[[:space:]]+v4l2loopback([[:space:]]|$)' "$f")
done
shopt -u nullglob

join() { local IFS="$1"; shift; printf '%s' "$*"; }
caps=()
for _ in "${NRS[@]}"; do caps+=(1); done
options="options v4l2loopback devices=${#NRS[@]} video_nr=$(join , "${NRS[@]}")"
options+=" card_label=\"$(join , "${LABELS[@]}")\" exclusive_caps=$(join , "${caps[@]}")"
for key in "${kept_order[@]}"; do
    options+=" $key=${kept[$key]}"
done

new_conf="# v4l2loopback devices: OBS Cam (/dev/video10) and Dusk Showtime
# (/dev/video11); Staq adds its own camera when it needs one. Written by Dusk Showtime's
# setup-virtual-camera.sh; the previous file is in /var/lib/dusk/v4l2loopback/.
$options"

changes=0
backed_up=0
tmp="$(mktemp -d)"
trap 'rm -rf -- "$tmp"' EXIT

backup() {
    local file="$1"
    [[ -e "$file" ]] || return 0
    local rel="${file#"$ROOT"}"
    install -D -m 0644 -- "$file" "$BACKUP$rel"
    backed_up=1
}

# write FILE CONTENT: show the diff, back up, replace
write() {
    local file="$1" content="$2"
    printf '%s\n' "$content" > "$tmp/new"
    if [[ -f "$file" ]] && cmp -s "$file" "$tmp/new"; then
        say "unchanged: ${file#"$ROOT"}"
        return 0
    fi
    changes=$((changes + 1))
    say "change: ${file#"$ROOT"}"
    local before=/dev/null
    [[ -f "$file" ]] && before="$file"
    diff -u --label "${file#"$ROOT"} (before)" --label "${file#"$ROOT"} (after)" \
        "$before" "$tmp/new" || true
    (( DRY )) && return 0
    backup "$file"
    install -D -m 0644 -- "$tmp/new" "$file"
}

say "== v4l2loopback options"
write "$CONF" "$new_conf"

for f in "${other_files[@]}"; do
    content="$(sed -E 's/^([[:space:]]*options[[:space:]]+v4l2loopback([[:space:]]|$))/# Disabled by setup-virtual-camera.sh (now in v4l2loopback.conf): \1/' "$f")"
    write "$f" "$content"
done

say "== loading at boot"
if [[ -f "$LOAD_CONF" ]] && grep -Eq '^[[:space:]]*v4l2loopback[[:space:]]*$' "$LOAD_CONF"; then
    say "unchanged: ${LOAD_CONF#"$ROOT"}"
else
    load_content=""
    [[ -f "$LOAD_CONF" ]] && load_content="$(cat -- "$LOAD_CONF")"
    load_content="${load_content:+$load_content
}v4l2loopback"
    write "$LOAD_CONF" "$load_content"
fi

if (( backed_up )); then
    cat > "$BACKUP/RESTORE" <<EOF_RESTORE
Files replaced by Dusk Showtime's setup-virtual-camera.sh on $(date -u).
To undo: copy each file below this folder back to the same path under /,
then reload v4l2loopback (sudo modprobe -r v4l2loopback && sudo modprobe
v4l2loopback) or reboot.
EOF_RESTORE
    say "backup: ${BACKUP#"$ROOT"}"
fi

if (( DRY )); then
    say "== dry run: nothing written, module not touched"
    exit 0
fi

say "== module"
if (( ! RELOAD )); then
    say "not reloading v4l2loopback (--no-reload or DUSK_VCAM_ROOT); the new devices appear after a reboot"
    exit 0
fi

loaded=0
[[ -d /sys/module/v4l2loopback ]] && loaded=1

# Every v4l2loopback device now present, plus the three wanted ones
devices=()
for d in /sys/devices/virtual/video4linux/video*; do
    [[ -e "$d" ]] && devices+=("/dev/${d##*/}")
done
for nr in "${NRS[@]}"; do
    [[ " ${devices[*]} " == *" /dev/video$nr "* ]] || devices+=("/dev/video$nr")
done

in_use=()
holders=()
refcnt=0

# Fills in_use (for the report), holders (pids) and refcnt
find_holders() {
    in_use=()
    holders=()
    local dev real dir pid
    for dev in "${devices[@]}" /dev/v4l2loopback; do
        [[ -e "$dev" ]] || continue
        real="$(readlink -f -- "$dev")"
        # One find per device, not one readlink per fd: a desktop session
        # holds thousands of fds and forking for each took 30 s or more.
        while IFS= read -r dir; do
            pid="${dir#/proc/}"; pid="${pid%%/*}"
            holders+=("$pid")
            in_use+=("$dev: $(cat "/proc/$pid/comm" 2>/dev/null || echo '?') (pid $pid)")
        done < <(find /proc/[0-9]*/fd -maxdepth 1 -lname "$real" -printf '%h\n' 2>/dev/null | sort -u || true)
    done
    refcnt=0
    if (( loaded )); then
        refcnt="$(cat /sys/module/v4l2loopback/refcnt 2>/dev/null || echo 0)"
    fi
}

# --kill: SIGTERM every holder, wait up to 5 s, SIGKILL what is left, then
# wait up to 3 s for the module's use count to drop
stop_holders() {
    local pid alive i
    local -a targets=()
    while IFS= read -r pid; do
        [[ -n "$pid" && "$pid" != "$$" && "$pid" != "$PPID" ]] || continue
        # The sound server and the init are never stopped; if one of them
        # holds a device the module stays loaded and the report says so
        case "$(cat "/proc/$pid/comm" 2>/dev/null || true)" in
            pipewire|pipewire-pulse|wireplumber|systemd) continue ;;
        esac
        targets+=("$pid")
    done < <(printf '%s\n' "${holders[@]}" | sort -un)
    (( ${#targets[@]} )) || return 0
    say "stopping the processes that hold a loopback device (--kill):"
    for pid in "${targets[@]}"; do
        say "  $(cat "/proc/$pid/comm" 2>/dev/null || echo '?') (pid $pid)"
    done
    kill -TERM -- "${targets[@]}" 2>/dev/null || true
    for (( i = 0; i < 50; i++ )); do
        alive=0
        for pid in "${targets[@]}"; do
            kill -0 "$pid" 2>/dev/null && alive=1
        done
        (( alive )) || break
        sleep 0.1
    done
    for pid in "${targets[@]}"; do
        if kill -0 "$pid" 2>/dev/null; then
            say "  pid $pid ignored SIGTERM, sending SIGKILL"
            kill -KILL -- "$pid" 2>/dev/null || true
        fi
    done
    for (( i = 0; i < 30; i++ )); do
        refcnt="$(cat /sys/module/v4l2loopback/refcnt 2>/dev/null || echo 0)"
        (( refcnt == 0 )) && break
        sleep 0.1
    done
}

find_holders
if (( KILL && loaded && ${#holders[@]} )); then
    stop_holders
    find_holders
fi

if (( loaded )) && { (( ${#in_use[@]} )) || (( refcnt > 0 )); }; then
    say "v4l2loopback is in use, so it is not reloaded now:"
    for u in "${in_use[@]}"; do say "  $u"; done
    if (( refcnt > 0 )); then say "  (module use count $refcnt)"; fi
    if (( KILL )); then
        say "Something still holds it; see: sudo lsof /dev/video10 /dev/video11 /dev/video2"
    else
        say "Run again with --kill to stop those processes, or log out and back in (once nothing uses a camera), or reboot."
    fi
    exit 0
fi

if (( loaded )); then
    say "reloading v4l2loopback (no device is in use)"
    modprobe -r v4l2loopback
else
    say "loading v4l2loopback"
fi
modprobe v4l2loopback

say "== devices now"
status=0
for i in "${!NRS[@]}"; do
    nr="${NRS[$i]}" want="${LABELS[$i]}"
    got="$(cat "/sys/class/video4linux/video$nr/name" 2>/dev/null || echo "(missing)")"
    if [[ "$got" == "$want" ]]; then
        say "  /dev/video$nr  $got"
    else
        say "  /dev/video$nr  $got  (expected \"$want\")"
        status=1
    fi
done
if (( status )); then
    say "Some devices are not as expected; see dmesg (journalctl -k) for v4l2loopback messages."
fi
say "Note: Staq Camera is Staq's own, added by Staq when it needs it. If the module"
say "was reloaded, Staq adds it again the next time its camera is used."
exit "$status"
