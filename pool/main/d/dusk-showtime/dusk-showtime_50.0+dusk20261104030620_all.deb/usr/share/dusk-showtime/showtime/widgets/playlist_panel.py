# SPDX-License-Identifier: GPL-3.0-or-later
# SPDX-FileCopyrightText: Copyright 2026 the Dusk contributors

"""The playlist sidebar."""

from gettext import ngettext
from typing import Any

from gi.repository import Adw, Gdk, GObject, Gtk, Pango

from showtime import PREFIX
from showtime.playlist import Playlist, PlaylistItem, RepeatMode

REPEAT_ICONS = {
    RepeatMode.OFF: "media-playlist-consecutive-symbolic",
    RepeatMode.ALL: "media-playlist-repeat-symbolic",
    RepeatMode.ONE: "media-playlist-repeat-song-symbolic",
}


def repeat_tooltip(mode: RepeatMode) -> str:
    """The repeat button's tooltip for `mode`."""
    return {
        RepeatMode.OFF: _("Repeat: Off"),
        RepeatMode.ALL: _("Repeat: All"),
        RepeatMode.ONE: _("Repeat: Current Video"),
    }[mode]


class _Row(Gtk.Box):
    """A playlist row: state icon, title (and folder), remove button."""

    def __init__(self, panel: "PlaylistPanel") -> None:
        super().__init__(spacing=9)
        self.item: PlaylistItem | None = None
        self._handlers: list[int] = []

        self.icon = Gtk.Image(icon_name="media-playback-start-symbolic", opacity=0)
        self.icon.update_property((Gtk.AccessibleProperty.LABEL,), ("",))

        labels = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, hexpand=True, valign=Gtk.Align.CENTER)
        self.title = Gtk.Label(xalign=0, ellipsize=Pango.EllipsizeMode.END)
        self.folder = Gtk.Label(xalign=0, ellipsize=Pango.EllipsizeMode.END, visible=False)
        self.folder.add_css_class("caption")
        self.folder.add_css_class("dim-label")
        labels.append(self.title)
        labels.append(self.folder)

        remove = Gtk.Button(icon_name="list-remove-symbolic", valign=Gtk.Align.CENTER, tooltip_text=_("Remove"))
        remove.add_css_class("flat")
        remove.add_css_class("circular")
        remove.connect("clicked", lambda *_: self.item and panel.playlist.remove(self.item))

        self.append(self.icon)
        self.append(labels)
        self.append(remove)

        # Reorder by drag and drop
        drag = Gtk.DragSource(actions=Gdk.DragAction.MOVE)
        drag.connect("prepare", self._on_drag_prepare)
        drag.connect("drag-begin", self._on_drag_begin)
        self.add_controller(drag)

        drop = Gtk.DropTarget.new(PlaylistItem.__gtype__, Gdk.DragAction.MOVE)
        drop.connect("drop", self._on_drop, panel)
        self.add_controller(drop)

    def bind(self, item: PlaylistItem, show_folder: bool) -> None:
        self.unbind()
        self.item = item
        self.title.props.label = item.props.title
        self.title.props.tooltip_text = item.gfile.get_parse_name()
        self.folder.props.label = item.props.folder
        self.folder.props.visible = show_folder and bool(item.props.folder)
        self._handlers = [
            item.connect("notify::current", self._update_state),
            item.connect("notify::failed", self._update_state),
        ]
        self._update_state()

    def unbind(self) -> None:
        if self.item:
            for handler in self._handlers:
                self.item.disconnect(handler)
        self._handlers = []
        self.item = None

    def _update_state(self, *_args) -> None:
        if not self.item:
            return

        if self.item.props.failed:
            self.icon.props.icon_name = "dialog-warning-symbolic"
            self.icon.props.opacity = 1
            self.icon.props.tooltip_text = _("Cannot play this file")
        else:
            self.icon.props.icon_name = "media-playback-start-symbolic"
            self.icon.props.opacity = 1 if self.item.props.current else 0
            self.icon.props.tooltip_text = _("Playing") if self.item.props.current else None

        if self.item.props.current:
            self.title.add_css_class("heading")
        else:
            self.title.remove_css_class("heading")

    def _on_drag_prepare(self, *_args) -> Gdk.ContentProvider | None:
        if not self.item:
            return None
        return Gdk.ContentProvider.new_for_value(self.item)

    def _on_drag_begin(self, source: Gtk.DragSource, _drag: Gdk.Drag) -> None:
        source.set_icon(Gtk.WidgetPaintable.new(self), 0, 0)

    def _on_drop(
        self,
        _target: Gtk.DropTarget,
        dragged: PlaylistItem,
        _x: float,
        y: float,
        panel: "PlaylistPanel",
    ) -> bool:
        if not self.item or dragged is self.item:
            return False

        playlist = panel.playlist
        target = playlist.index_of(self.item)
        old = playlist.index_of(dragged)
        if target is None or old is None:
            return False

        # Drop on the lower half: after this row
        position = target + (1 if y > self.get_height() / 2 else 0)
        if old < position:
            position -= 1

        playlist.move(dragged, position)
        panel.select(dragged)
        return True


@Gtk.Template.from_resource(f"{PREFIX}/gtk/playlist-panel.ui")
class PlaylistPanel(Adw.Bin):
    """The playlist: current item highlighted, double-click to play."""

    __gtype_name__ = "PlaylistPanel"

    toolbar_view: Adw.ToolbarView = Gtk.Template.Child()
    header_bar: Adw.HeaderBar = Gtk.Template.Child()
    window_title: Adw.WindowTitle = Gtk.Template.Child()
    content_stack: Gtk.Stack = Gtk.Template.Child()
    empty_page: Adw.StatusPage = Gtk.Template.Child()
    list_page: Gtk.ScrolledWindow = Gtk.Template.Child()
    list_view: Gtk.ListView = Gtk.Template.Child()
    repeat_button: Gtk.Button = Gtk.Template.Child()
    position_label: Gtk.Label = Gtk.Template.Child()

    item_activated = GObject.Signal(name="item-activated", arg_types=(object,))
    files_dropped = GObject.Signal(name="files-dropped", arg_types=(object,))

    _playlist: Playlist | None = None
    _show_folders = False

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)

        factory = Gtk.SignalListItemFactory()
        factory.connect("setup", lambda _f, li: li.set_child(_Row(self)))
        factory.connect(
            "bind",
            lambda _f, li: li.get_child().bind(li.get_item(), self._show_folders),
        )
        factory.connect("unbind", lambda _f, li: li.get_child().unbind())
        self.list_view.props.factory = factory

        keys = Gtk.ShortcutController()
        for trigger, callback in (
            ("Delete", self._remove_selected),
            ("KP_Delete", self._remove_selected),
            ("<alt>Up", lambda *_: self._move_selected(-1)),
            ("<alt>Down", lambda *_: self._move_selected(1)),
        ):
            keys.add_shortcut(
                Gtk.Shortcut.new(
                    Gtk.ShortcutTrigger.parse_string(trigger),
                    Gtk.CallbackAction.new(callback),
                )
            )
        self.list_view.add_controller(keys)

    @property
    def playlist(self) -> Playlist:
        """The playlist shown."""
        assert self._playlist is not None
        return self._playlist

    @playlist.setter
    def playlist(self, playlist: Playlist) -> None:
        self._playlist = playlist
        self.selection = Gtk.SingleSelection(
            model=playlist.items, autoselect=False, can_unselect=True
        )
        self.list_view.props.model = self.selection
        playlist.connect("changed", self._on_changed)
        playlist.connect("notify::repeat", self._on_repeat_changed)
        playlist.connect("notify::current", self._on_current_changed)
        self._on_changed()
        self._on_repeat_changed()

    def select(self, item: PlaylistItem | None) -> None:
        """Select (and scroll to) `item`."""
        if item is None or (position := self.playlist.index_of(item)) is None:
            return

        self.list_view.scroll_to(position, Gtk.ListScrollFlags.SELECT, None)

    def _on_changed(self, *_args) -> None:
        count = len(self.playlist)
        self.content_stack.props.visible_child = (
            self.list_page if count else self.empty_page
        )

        show_folders = len({item.props.folder for item in self.playlist}) > 1
        if show_folders != self._show_folders:
            self._show_folders = show_folders
            # Rebind the rows so they show or hide their folder
            self.list_view.props.model = None
            self.list_view.props.model = self.selection

        if current := self.playlist.props.current:
            index = self.playlist.index_of(current)
            self.position_label.props.label = (
                _("{} of {}").format(index + 1, count) if index is not None else ""
            )
        else:
            self.position_label.props.label = (
                ngettext("{} video", "{} videos", count).format(count)
                if count
                else ""
            )

    def _on_repeat_changed(self, *_args) -> None:
        mode = RepeatMode(self.playlist.props.repeat)
        self.repeat_button.props.icon_name = REPEAT_ICONS[mode]
        self.repeat_button.props.tooltip_text = repeat_tooltip(mode)

    def _on_current_changed(self, *_args) -> None:
        self.select(self.playlist.props.current)

    def _selected_item(self) -> PlaylistItem | None:
        item = self.selection.get_selected_item()
        return item if isinstance(item, PlaylistItem) else None

    def _remove_selected(self, *_args) -> bool:
        if not (item := self._selected_item()):
            return False

        position = self.selection.get_selected()
        self.playlist.remove(item)
        if len(self.playlist):
            self.list_view.scroll_to(
                min(position, len(self.playlist) - 1), Gtk.ListScrollFlags.SELECT | Gtk.ListScrollFlags.FOCUS, None
            )
        return True

    def _move_selected(self, delta: int) -> bool:
        if not (item := self._selected_item()):
            return False

        position = self.selection.get_selected() + delta
        if not 0 <= position < len(self.playlist):
            return True

        self.playlist.move(item, position)
        self.list_view.scroll_to(position, Gtk.ListScrollFlags.SELECT | Gtk.ListScrollFlags.FOCUS, None)
        return True

    @Gtk.Template.Callback()
    def _on_activate(self, _list_view: Gtk.ListView, position: int) -> None:
        if isinstance(item := self.playlist.items.get_item(position), PlaylistItem):
            self.emit("item-activated", item)

    @Gtk.Template.Callback()
    def _on_drop(self, _target: Gtk.DropTarget, value: Gdk.FileList, _x, _y) -> bool:
        files = value.get_files() if isinstance(value, Gdk.FileList) else []
        if not files:
            return False

        self.emit("files-dropped", list(files))
        return True

