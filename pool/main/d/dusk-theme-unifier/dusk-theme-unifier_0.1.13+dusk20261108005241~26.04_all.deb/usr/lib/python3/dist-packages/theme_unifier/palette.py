"""The neutral palette format that every output generator reads.

A palette is plain JSON so it can be inspected, hand-edited, and shared.
Each color records where it came from, so a GUI can flag guessed values.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from .colors import Color

SCHEMA_VERSION = 2

# Role name -> what it means. Order here is the order in output files.
ROLES: dict[str, str] = {
    "window_bg": "Main window background",
    "window_fg": "Main window text",
    "view_bg": "Content areas: lists, text views, entries",
    "view_fg": "Text in content areas",
    "accent_bg": "Selection and suggested-action background",
    "accent_fg": "Text on accent_bg",
    "accent": "Accent used as a text or icon color (links, checked items)",
    "headerbar_bg": "Header bar / titlebar background",
    "headerbar_fg": "Header bar text",
    "headerbar_border": "Line under the header bar",
    "headerbar_backdrop": "Header bar background when the window is unfocused",
    "sidebar_bg": "Sidebar background",
    "sidebar_fg": "Sidebar text",
    "card_bg": "Cards and boxed lists",
    "popover_bg": "Popovers and menus",
    "dialog_bg": "Dialog background",
    "borders": "Widget borders and separators",
    "destructive_bg": "Destructive-action button background",
    "success": "Success color",
    "warning": "Warning color",
    "error": "Error color",
}


CONFIDENCE = ("high", "medium", "low")

# What a palette's status means (review finding 5). Analysis always returns a
# complete set of roles, so a full dictionary says nothing about extraction:
#   complete  every CORE role was read from the theme (or inherited from one
#             that was, as CSS does): preview and apply.
#   partial   some CORE roles are derived or defaulted: preview and apply,
#             with the guessed colors disclosed (D4).
#   invalid   no window background could be read, so every color is a guess:
#             preview only; apply refuses (exit 9).
# The status is about the colors only. Whether the stylesheets themselves
# loaded cleanly is reported apart, as source integrity (review of 72f581a):
#   clean     every import was read, with no cycle and no unreadable color.
#   degraded  `source_problems` lists what was skipped; the colors may still
#             be complete, from what could be read.
CORE_ROLES = ("window_bg", "window_fg", "view_bg", "view_fg", "accent_bg", "accent_fg")
STATUSES = ("complete", "partial", "invalid")


@dataclass
class Entry:
    color: Color
    source: str  # e.g. "@theme_bg_color", "rule: headerbar { color }", "derived: ..."
    confidence: str = "high"  # one of CONFIDENCE
    origin: str = ""  # stylesheet file or resource:// URI, empty when derived
    notes: list[str] = field(default_factory=list)  # why confidence is not high

    @property
    def guessed(self) -> bool:
        return self.source.startswith("derived") or self.source.startswith("default")

    @property
    def kind(self) -> str:
        """extracted, inherited, derived or defaulted."""
        for prefix, kind in (("default", "defaulted"), ("derived", "derived"), ("inherited", "inherited")):
            if self.source.startswith(prefix):
                return kind
        return "extracted"


@dataclass
class Palette:
    theme: str
    variant: str  # "light" or "dark": which of the theme's stylesheets was read
    colors: dict[str, Entry] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    stylesheet: str = ""  # entry stylesheet path or resource URI
    files: list[str] = field(default_factory=list)  # every stylesheet read
    source_problems: list[str] = field(default_factory=list)  # also in warnings

    @property
    def is_dark(self) -> bool:
        return self.colors["window_bg"].color.is_dark()

    def __getitem__(self, role: str) -> Color:
        return self.colors[role].color

    @property
    def guessed_core(self) -> list[str]:
        return [r for r in CORE_ROLES if r in self.colors and self.colors[r].kind in ("derived", "defaulted")]

    @property
    def status(self) -> str:
        if "window_bg" not in self.colors or self.colors["window_bg"].kind == "defaulted":
            return "invalid"
        return "partial" if self.guessed_core else "complete"

    @property
    def source_integrity(self) -> str:
        return "degraded" if self.source_problems else "clean"

    def to_dict(self) -> dict:
        return {
            "schema": SCHEMA_VERSION,
            "theme": self.theme,
            "variant": self.variant,
            "is_dark": self.is_dark,
            "stylesheet": self.stylesheet,
            "files": self.files,
            "status": self.status,
            "guessed_core": self.guessed_core,
            "source_integrity": self.source_integrity,
            "source_problems": self.source_problems,
            "colors": {
                role: {
                    "value": e.color.to_css(),
                    "source": e.source,
                    "kind": e.kind,
                    "confidence": e.confidence,
                    "origin": e.origin,
                    "notes": e.notes,
                }
                for role, e in self.colors.items()
            },
            "warnings": self.warnings,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2) + "\n"

    def save(self, path: Path) -> None:
        Path(path).write_text(self.to_json(), encoding="utf-8")

    @classmethod
    def from_dict(cls, data: dict) -> "Palette":
        from .colors import evaluate

        if data.get("schema") != SCHEMA_VERSION:
            raise ValueError(f"unsupported palette schema {data.get('schema')!r}")
        colors = {
            role: Entry(
                evaluate(item["value"]),
                item.get("source", "file"),
                item.get("confidence", "high"),
                item.get("origin", ""),
                list(item.get("notes", [])),
            )
            for role, item in data["colors"].items()
        }
        missing = [r for r in ROLES if r not in colors]
        if missing:
            raise ValueError(f"palette is missing roles: {', '.join(missing)}")
        return cls(
            data["theme"],
            data["variant"],
            colors,
            list(data.get("warnings", [])),
            data.get("stylesheet", ""),
            list(data.get("files", [])),
            list(data.get("source_problems", [])),
        )

    @classmethod
    def load(cls, path: Path) -> "Palette":
        return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
