"""A small, forgiving parser for GTK3 theme stylesheets.

It only extracts what the analyzer needs: @import targets, @define-color
declarations, and flat rule blocks (selectors plus declarations). Nested
at-rule blocks such as @keyframes are skipped.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

_COMMENT = re.compile(r"/\*.*?\*/", re.S)
_IMPORT = re.compile(r"""@import\s+(?:url\(\s*)?["']?([^"')\s;]+)["']?\s*\)?\s*;""")
_DEFINE = re.compile(r"@define-color\s+([\w-]+)\s+([^;]+);")


@dataclass
class Rule:
    selectors: list[str]
    declarations: dict[str, str]
    origin: str = ""  # file path or resource:// URI the rule came from


@dataclass
class Stylesheet:
    imports: list[str] = field(default_factory=list)
    defines: dict[str, str] = field(default_factory=dict)
    rules: list[Rule] = field(default_factory=list)
    # @define-color name -> every origin that defined it, in cascade order.
    define_origins: dict[str, list[str]] = field(default_factory=dict)
    # Every stylesheet that was read, in cascade order, and imports that failed.
    files: list[str] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)
    cycles: list[str] = field(default_factory=list)  # imports skipped because they lead back to themselves

    def extend(self, other: "Stylesheet") -> None:
        """Append another sheet; later definitions win, as in CSS."""
        self.defines.update(other.defines)
        self.rules.extend(other.rules)
        for name, origins in other.define_origins.items():
            self.define_origins.setdefault(name, []).extend(origins)
        self.files.extend(other.files)
        self.missing.extend(other.missing)
        self.cycles.extend(other.cycles)


def normalize_selector(sel: str) -> str:
    sel = re.sub(r"\s+", " ", sel.strip())
    return re.sub(r"\s*>\s*", " > ", sel)


def split_top_level(text: str, sep: str = ",") -> list[str]:
    """Split on `sep` while ignoring separators nested in parentheses."""
    parts, depth, cur = [], 0, []
    for ch in text:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if ch == sep and depth == 0:
            parts.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    parts.append("".join(cur))
    return [p.strip() for p in parts if p.strip()]


def _parse_declarations(body: str) -> dict[str, str]:
    decls: dict[str, str] = {}
    for item in split_top_level(body, ";"):
        if ":" not in item:
            continue
        prop, value = item.split(":", 1)
        decls[prop.strip().lower()] = value.strip()
    return decls


def strip_comments(text: str) -> str:
    return _COMMENT.sub("", text)


def split_imports(text: str) -> list[tuple[str, str | None]]:
    """Split comment-free CSS into (segment, import-target-after-it) pairs.

    GTK applies @import where it appears, so a stylesheet is processed as
    segment, import, segment, import, ... to keep cascade order.
    """
    parts: list[tuple[str, str | None]] = []
    pos = 0
    for m in _IMPORT.finditer(text):
        parts.append((text[pos : m.start()], m.group(1)))
        pos = m.end()
    parts.append((text[pos:], None))
    return parts


def parse(text: str, origin: str = "") -> Stylesheet:
    text = _COMMENT.sub("", text)
    sheet = Stylesheet()
    sheet.imports = _IMPORT.findall(text)
    sheet.defines = {name: value.strip() for name, value in _DEFINE.findall(text)}
    sheet.define_origins = {name: [origin] for name in sheet.defines}
    # Remove statements that end in ';' at top level so only blocks remain.
    text = _IMPORT.sub("", _DEFINE.sub("", text))

    i, n = 0, len(text)
    while i < n:
        open_at = text.find("{", i)
        if open_at == -1:
            break
        prelude = text[i:open_at].strip()
        # Find the matching close brace, allowing nested blocks.
        depth, j = 1, open_at + 1
        while j < n and depth:
            if text[j] == "{":
                depth += 1
            elif text[j] == "}":
                depth -= 1
            j += 1
        body = text[open_at + 1 : j - 1]
        i = j
        if prelude.startswith("@"):
            continue
        selectors = [normalize_selector(s) for s in split_top_level(prelude)]
        sheet.rules.append(Rule(selectors, _parse_declarations(body), origin))
    return sheet
