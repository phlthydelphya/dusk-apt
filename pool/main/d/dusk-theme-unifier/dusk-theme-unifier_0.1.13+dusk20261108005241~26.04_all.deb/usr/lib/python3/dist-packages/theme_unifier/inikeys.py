"""Key-level edits of INI-style files someone else owns (qt5ct.conf,
qt6ct.conf, kdeglobals), milestone 11.

The tool sets a few keys and records, for each, the value it found (None
when the key was absent) and the value it wrote. Everything else in the file
stays byte-for-byte. `unset` puts the found values back, but only for keys
that still hold what the tool wrote (D5/D7): a key changed since is the
user's now, and is left alone and reported.

Format: `[Group]` headers (KConfig's `[Colors:Header][Inactive]` is read as
one group name, "Colors:Header][Inactive"), `key=value` lines, `#` and `;`
comments. When a group appears more than once, its last `key=` wins, as in
KConfig and QSettings; that is the line read and edited.
"""

from __future__ import annotations

import re

GROUP = re.compile(r"^\[(.*)\]\s*$")


def _lines(data: bytes | None) -> list[str]:
    return [] if not data else data.decode("utf-8").splitlines(keepends=True)


def _key(line: str) -> str | None:
    s = line.strip()
    if not s or s[0] in "#;[" or "=" not in s:
        return None
    return s.split("=", 1)[0].strip()


def _groups(lines: list[str]) -> list[str | None]:
    """The group each line belongs to (None before the first header)."""
    out, group = [], None
    for line in lines:
        m = GROUP.match(line.strip())
        if m:
            group = m.group(1)
        out.append(group)
    return out


def _find(lines: list[str], group: str, key: str) -> int | None:
    groups = _groups(lines)
    found = None
    for i, line in enumerate(lines):
        if groups[i] == group and not GROUP.match(line.strip()) and _key(line) == key:
            found = i
    return found


def _split(line: str) -> tuple[str, str, str]:
    """`key = value  \\n` -> ("key = ", "value", "  \\n"): edits keep the spacing."""
    head, rest = line.split("=", 1)
    body = rest.rstrip()
    lead = body[: len(body) - len(body.lstrip())]
    return head + "=" + lead, body.lstrip(), rest[len(body):]


def get(data: bytes | None, group: str, key: str) -> str | None:
    lines = _lines(data)
    i = _find(lines, group, key)
    return None if i is None else _split(lines[i])[1]


def has_group(data: bytes | None, group: str) -> bool:
    return any(GROUP.match(line.strip()) and GROUP.match(line.strip()).group(1) == group for line in _lines(data))


def _insert(lines: list[str], group: str, key: str, value: str) -> None:
    """Add `key=value` at the end of the group's last block (adding the group if needed)."""
    groups = _groups(lines)
    if group not in groups:
        lines.append(f"[{group}]\n")
        groups.append(group)
    end = max(j for j, g in enumerate(groups) if g == group)
    while not GROUP.match(lines[end].strip()) and not lines[end].strip():
        end -= 1  # blank lines after the group's keys stay after them
    lines.insert(end + 1, f"{key}={value}\n")


def set_keys(data: bytes | None, values: dict[str, dict[str, str]]) -> tuple[bytes, dict]:
    """Set `values` ({group: {key: value}}). Returns the new bytes and the
    record `unset` needs: what each key held, which groups were added, and
    whether a final newline had to be added first."""
    lines = _lines(data)
    rec: dict = {"keys": [], "groups": [], "lead": ""}
    if lines and not lines[-1].endswith("\n"):
        lines[-1] += "\n"
        rec["lead"] = "\n"
    for group, keys in values.items():
        if not any(g == group for g in _groups(lines)):
            lines.append(f"[{group}]\n")
            rec["groups"].append(group)
        for key, value in keys.items():
            i = _find(lines, group, key)
            if i is not None:
                head, before, tail = _split(lines[i])
                lines[i] = head + value + tail
            else:
                before = None
                _insert(lines, group, key, value)
            rec["keys"].append({"group": group, "key": key, "before": before, "after": value})
    return "".join(lines).encode(), rec


def unset(data: bytes | None, rec: dict, force: bool = False) -> tuple[bytes | None, list[str]]:
    """Put back what `set_keys` found, for the keys that still hold what it
    wrote (all of them with force). Returns the bytes (None when nothing is
    left of a file that `rec["created"]` says the tool created) and the
    keys left alone, as "[group] key"."""
    lines = _lines(data)
    kept = []
    for k in reversed(rec["keys"]):
        i = _find(lines, k["group"], k["key"])
        cur = None if i is None else _split(lines[i])[1]
        if cur != k["after"] and not force:
            kept.append(f"[{k['group']}] {k['key']}")
            continue
        if k["before"] is None:
            if i is not None:
                del lines[i]
        elif i is None:
            _insert(lines, k["group"], k["key"], k["before"])  # only with force: the user took it out
        else:
            head, _, tail = _split(lines[i])
            lines[i] = head + k["before"] + tail
    for group in rec["groups"]:
        groups = _groups(lines)
        idx = [i for i, g in enumerate(groups) if g == group]
        headers = [i for i in idx if GROUP.match(lines[i].strip())]
        if len(headers) == 1 and all(not lines[i].strip() for i in idx if i != headers[0]):
            for i in reversed(idx):
                del lines[i]
    text = "".join(lines)
    if rec.get("lead") and text.endswith("\n") and not kept:
        text = text[:-1]
    if rec.get("created") and not text.strip():
        return None, kept[::-1]
    return text.encode(), kept[::-1]
