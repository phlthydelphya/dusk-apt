"""Apply and revert managed CSS in the user's GTK 4 stylesheet (milestone 3).

Rules (PLAN.md D5):

- The tool owns exactly one *managed region* in ~/.config/gtk-4.0/gtk.css,
  between a begin and an end marker that carry the manifest's ID. Nothing
  outside the region is ever changed.
- The manifest records the exact text the tool inserted and its hash. Revert
  removes that text only if it is still byte-for-byte what the tool wrote;
  otherwise it is a conflict and nothing is changed unless --force.
- Every write is journaled first, then done atomically (temp file in the same
  folder, fsync, rename, fsync the folder). An interrupted write is finished
  or rolled back on the next run by comparing hashes, never by guessing.
- Missing, duplicated, nested or out-of-order markers stop apply and revert.
- Backups are recovery material for `doctor`. Revert never restores them.
"""

from __future__ import annotations

import base64
import contextlib
import fcntl
import hashlib
import json
import os
import re
import tempfile
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

SCHEMA = 7  # 7 adds accent and app adapters; older manifests still load
MARKER = re.compile(r"^/\* theme-unifier:(begin|end) id=([0-9a-f]{32}) \*/$")
LOOSE_MARKER = re.compile(r"theme-unifier:(begin|end)")

# Exit statuses used by the CLI.
EXIT_OK, EXIT_ERROR, EXIT_MODE_UNAVAILABLE, EXIT_CONTRAST, EXIT_CONFLICT, EXIT_UNSAFE, EXIT_BUSY = 0, 1, 3, 4, 5, 6, 7
EXIT_PARTIAL, EXIT_INVALID = 8, 9  # analyze: some core colors guessed; nothing usable read (palette.py)
EXIT_INCOMPLETE = 10  # a change is still open: a desktop step failed, or recovery is pending


class HostError(Exception):
    """A refusal: nothing was changed. `code` is the exit status."""

    def __init__(self, message: str, code: int = EXIT_CONFLICT):
        super().__init__(message)
        self.code = code


class Incomplete(HostError):
    """Not a refusal: the files were changed, but a desktop step (a setting,
    the watcher) failed. The journal stays, so the next command tries the
    step again and `revert` can undo the whole change."""

    def __init__(self, message: str):
        super().__init__(message, EXIT_INCOMPLETE)


def _incomplete(failed: list[str]) -> Incomplete:
    return Incomplete("Not finished: " + " ".join(failed) + " The change stays open: the next theme-unifier "
                      "command tries again, and `theme-unifier revert` undoes all of it.")


# --- Locations -----------------------------------------------------------


def config_home() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")


def state_home() -> Path:
    return Path(os.environ.get("XDG_STATE_HOME") or Path.home() / ".local" / "state")


@dataclass
class Paths:
    target: Path
    state: Path

    @classmethod
    def default(cls) -> "Paths":
        return cls(config_home() / "gtk-4.0" / "gtk.css", state_home() / "theme-unifier")

    @property
    def manifest(self) -> Path:
        return self.state / "manifest.json"

    @property
    def journal(self) -> Path:
        return self.state / "journal.json"

    @property
    def backups(self) -> Path:
        return self.state / "backups"

    @property
    def lock(self) -> Path:
        return self.state / "lock"


# --- One operation at a time ----------------------------------------------------

_LOCK = threading.RLock()  # threads of one process (the GUI's workers)
_held: dict[str, int] = {}  # lock path -> open fd while held by this process
_depth: dict[str, int] = {}


@contextlib.contextmanager
def exclusive(paths: "Paths", timeout: float | None = None):
    """Hold the per-user operation lock: CLI, GUI and watcher never interleave
    their recover-load-plan-commit sequences. Re-entrant within a process."""
    if timeout is None:
        timeout = float(os.environ.get("THEME_UNIFIER_LOCK_TIMEOUT") or 60)
    key = str(paths.lock)
    deadline = time.monotonic() + timeout
    if not _LOCK.acquire(timeout=timeout):
        raise HostError("Another theme-unifier operation is still running in this program. Nothing was changed.",
                        EXIT_BUSY)
    try:
        if key not in _held:
            paths.state.mkdir(parents=True, exist_ok=True)
            fd = os.open(key, os.O_RDWR | os.O_CREAT, 0o600)
            while True:
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    if time.monotonic() >= deadline:
                        os.close(fd)
                        raise HostError("Another theme-unifier operation (the window, the watcher or a command) "
                                        "is still running. Nothing was changed; try again in a moment.", EXIT_BUSY)
                    time.sleep(0.05)
            _held[key], _depth[key] = fd, 0
        _depth[key] += 1
        try:
            yield
        finally:
            _depth[key] -= 1
            if _depth[key] == 0:
                fd = _held.pop(key)
                del _depth[key]
                fcntl.flock(fd, fcntl.LOCK_UN)
                os.close(fd)
    finally:
        _LOCK.release()


def _pause(name: str) -> None:
    """Hold still at a named step, for concurrency tests (THEME_UNIFIER_PAUSE=name:seconds)."""
    spec = os.environ.get("THEME_UNIFIER_PAUSE", "")
    if spec.partition(":")[0] == name:
        if os.environ.get("THEME_UNIFIER_PAUSED_FILE"):  # tells the test the pause has begun
            Path(os.environ["THEME_UNIFIER_PAUSED_FILE"]).touch()
        time.sleep(float(spec.partition(":")[2] or 1))


def sha256(data: bytes | None) -> str | None:
    return None if data is None else hashlib.sha256(data).hexdigest()


# --- Fault injection for crash tests --------------------------------------


def _crashpoint(name: str) -> None:
    """Simulate a crash (power loss, kill -9) at a named step, for tests."""
    if os.environ.get("THEME_UNIFIER_FAULT") == name:
        os._exit(70)


# --- Low-level atomic file operations --------------------------------------


def _fsync_dir(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _atomic_write(path: Path, data: bytes, mode: int = 0o644, fault: str | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.theme-unifier-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, mode)
        if fault:
            _crashpoint(fault)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise
    _fsync_dir(path.parent)


def _read(path: Path) -> bytes | None:
    try:
        return path.read_bytes()
    except FileNotFoundError:
        return None


def missing_dirs(path: Path) -> list[Path]:
    """Folders that writing `path` would create, outermost first."""
    out = []
    d = path.parent
    while not d.exists():
        out.append(d)
        d = d.parent
    return list(reversed(out))


# --- Manifest ----------------------------------------------------------------


@dataclass
class Manifest:
    id: str
    target: str
    theme: str
    mode: str
    region: str  # exact region text inserted, markers included, `lead` excluded
    lead: str  # "\n" when the file did not end in a newline before insertion
    created_file: bool
    applied_at: float
    created_dir: bool = False  # gtk-4.0/ did not exist before the first apply
    suspended: str | None = None  # "high-contrast" or "mode-unavailable"
    suspended_at: float | None = None
    disclosed: list[str] = field(default_factory=list)
    unit: dict | None = None  # {"path":..., "sha256":...} of an installed watcher unit
    restart_needed: list[dict] = field(default_factory=list)  # [{"pid","start","name"}]
    files: dict[str, str] = field(default_factory=dict)  # whole files the tool owns: path -> sha256
    dirs: list[str] = field(default_factory=list)  # folders the tool created for them, outermost first
    gtk4: str = ""  # what was done for plain GTK4 apps, in words
    adwaita: dict = field(default_factory=dict)  # chosen libadwaita style and copied GTK4 stylesheet names
    flatpak: dict[str, dict] = field(default_factory=dict)  # app ID -> override record (flatpak.py)
    shell: dict = field(default_factory=dict)  # GNOME Shell record, see ops._shell_*
    gtk3: dict = field(default_factory=dict)  # {"name", "before", "changed"}: the GTK theme setting
    window_buttons: dict = field(default_factory=dict)  # owned GNOME window-button layout
    flatpak_skip: list[str] = field(default_factory=list)  # apps the user turned off; `--flatpak all` skips them
    qt: dict = field(default_factory=dict)  # KDE/Qt record, see targets/qt.py
    accent: dict = field(default_factory=dict)  # {"name", "before", "changed", "color"}: targets/accent.py
    apps: dict[str, dict] = field(default_factory=dict)  # adapter name -> record: targets/apps/
    schema: int = SCHEMA

    @property
    def region_sha256(self) -> str:
        return sha256(self.region.encode())

    def to_json(self) -> bytes:
        d = dict(self.__dict__, region_sha256=self.region_sha256)
        return (json.dumps(d, indent=2) + "\n").encode()

    @classmethod
    def load(cls, path: Path) -> "Manifest | None":
        data = _read(path)
        if data is None:
            return None
        d = json.loads(data)
        if d.get("schema") not in (1, 2, 3, 4, 5, 6, SCHEMA):
            raise HostError(f"{path} has schema {d.get('schema')}, expected {SCHEMA}. Run `theme-unifier doctor`.")
        stored = d.pop("region_sha256", None)
        d["schema"] = SCHEMA
        m = cls(**d)
        if stored != m.region_sha256:
            raise HostError(f"{path} is damaged (region hash mismatch). Run `theme-unifier doctor`.")
        return m


# --- Markers -----------------------------------------------------------------


@dataclass
class Region:
    start: int  # offset of the begin marker line
    end: int  # offset just past the end marker line (and its newline)
    id: str

    def text(self, css: str) -> str:
        return css[self.start : self.end]


def find_region(css: str) -> Region | None:
    """The single well-formed managed region, or None if there are no markers.

    Raises HostError for anything else, so callers never guess.
    """
    strict: list[tuple[str, str, int, int]] = []
    loose = 0
    offset = 0
    for line in css.splitlines(keepends=True):
        bare = line.rstrip("\r\n")
        if LOOSE_MARKER.search(bare):
            loose += 1
            m = MARKER.match(bare)
            if m:
                strict.append((m.group(1), m.group(2), offset, offset + len(line)))
        offset += len(line)
    if loose == 0:
        return None
    if loose != len(strict):
        raise HostError("A theme-unifier marker in gtk.css is damaged (edited or partly deleted).")
    kinds = [k for k, *_ in strict]
    if kinds.count("begin") != 1 or kinds.count("end") != 1:
        raise HostError(f"gtk.css has {kinds.count('begin')} begin and {kinds.count('end')} end markers; "
                        "exactly one of each is required.")
    (k1, id1, s1, _), (k2, id2, _, e2) = strict
    if (k1, k2) != ("begin", "end"):
        raise HostError("The theme-unifier end marker comes before the begin marker in gtk.css.")
    if id1 != id2:
        raise HostError("The theme-unifier begin and end markers in gtk.css have different IDs.")
    return Region(s1, e2, id1)


def build_region(region_id: str, css: str, theme: str, mode: str) -> str:
    return (f"/* theme-unifier:begin id={region_id} */\n"
            f"/* Managed by theme-unifier ({theme}, {mode}). Put your own CSS outside the markers:\n"
            f"   changes inside are reported as conflicts. Undo with `theme-unifier revert`. */\n"
            f"{css.rstrip()}\n"
            f"/* theme-unifier:end id={region_id} */\n")


# --- Transactions ------------------------------------------------------------


class Host:
    def __init__(self, paths: Paths | None = None):
        self.paths = paths or Paths.default()
        self.log: list[str] = []
        self.unfinished: list[str] = []  # failed actions of a commit left open (see commit)

    # Journal ---------------------------------------------------------------

    def commit(self, new_target: bytes | None, manifest: Manifest | None,
               extra: dict[Path, bytes | None] | None = None, new_dirs: list[Path] | None = None,
               actions: list[dict] | None = None, remove_dirs: list[Path] | None = None) -> list[str]:
        """Replace gtk.css and any `extra` whole files (None deletes), then the
        manifest (None deletes it), and carry out `actions` (actions.py:
        settings and the watcher unit), as one journaled change. Returns the
        actions' lines for the user. A failed "before" action undoes the
        change and raises HostError. A failed "after" action leaves the
        journal open and is listed in `self.unfinished`; the operation then
        ends with Incomplete (ops._operation), and no further commit runs.

        The journal keeps every file's previous content and lists the
        actions, so an interruption can always be finished or rolled back as
        long as nothing else touched the files. Order: "before" actions,
        extra files, gtk.css, the manifest, `remove_dirs` (each only if
        empty, innermost first), "after" actions.
        """
        p = self.paths
        if self.unfinished:  # a new journal would drop the open one
            raise _incomplete(self.unfinished)
        _pause("commit")
        # The plan was made from what load() read; if gtk.css or the record
        # changed since (an editor, an older version without the lock), stop.
        for path, sha in getattr(self, "_loaded", {}).items():
            if sha256(_read(path)) != sha:
                raise HostError(f"{path} changed while theme-unifier was working on it. Nothing was changed; "
                                "run the command again.")
        changes = dict(extra or {})
        changes[p.target] = new_target
        entries = []
        for path, after in changes.items():
            before = _read(path)
            entries.append({"path": str(path), "after_sha256": sha256(after), "before_sha256": sha256(before),
                            "before_b64": None if before is None else base64.b64encode(before).decode()})
        actions = [dict(a) for a in actions or []]  # the journal records outcomes in them
        journal = {"entries": entries, "dirs_created": [str(d) for d in new_dirs or []],
                   "manifest_after": None if manifest is None else json.loads(manifest.to_json()),
                   "actions": actions, "remove_dirs": [str(d) for d in remove_dirs or []], "time": time.time()}
        self._save_journal(journal)
        _crashpoint("journal")
        lines, failed = self._run_actions(journal, "before")
        if failed:  # nothing else has changed yet: undo what ran and refuse
            self._roll_back(journal)
            raise HostError(" ".join(failed) + " Nothing was changed.", EXIT_ERROR)
        for i, (path, after) in enumerate(changes.items()):
            if path == p.target:
                continue
            self._put(path, after)
            if i == 0:
                _crashpoint("extra")
        self._put(p.target, new_target, fault="tmp")
        _crashpoint("target")
        self._write_manifest(manifest)
        _crashpoint("manifest")
        self._loaded = {p.target: sha256(_read(p.target)), p.manifest: sha256(_read(p.manifest))}
        self._remove_empty(journal["remove_dirs"])
        more, failed = self._run_actions(journal, "after")
        lines += more
        if failed:
            self.unfinished = failed
            return lines
        p.journal.unlink()
        _fsync_dir(p.state)
        return lines

    def _save_journal(self, journal: dict) -> None:
        _atomic_write(self.paths.journal, (json.dumps(journal, indent=2) + "\n").encode(), 0o600)

    @staticmethod
    def _remove_empty(dirs: list[str]) -> None:
        for d in dirs:
            try:
                Path(d).rmdir()  # only if empty
            except OSError:
                pass

    def _run_actions(self, journal: dict, phase: str) -> tuple[list[str], list[str]]:
        """Run the phase's actions that haven't reached a final outcome,
        recording each outcome in the journal. Returns the lines for the
        user and those of the failed actions."""
        from . import actions as act
        lines, failed = [], []
        for i, a in enumerate(journal.get("actions", [])):
            if a.get("phase", "after") != phase or a.get("outcome") in act.FINAL:
                continue

            def mark(step: str, a: dict = a) -> None:
                a["step"] = step
                self._save_journal(journal)
            o = act.forward(a, mark)
            a["outcome"] = o.status
            self._save_journal(journal)
            if o.line:
                lines.append(o.line)
            if o.status == act.FAILED:
                failed.append(o.line or f"A {a['kind']} step failed.")
            _crashpoint(f"action-{i}")
        return lines, failed

    def _roll_back(self, j: dict) -> None:
        """Put every file back as the journal found it, undo the actions, and close the journal."""
        for e in j["entries"]:
            if sha256(_read(Path(e["path"]))) != e["before_sha256"]:
                old = e["before_b64"]
                self._put(Path(e["path"]), None if old is None else base64.b64decode(old))
        for d in reversed(j.get("dirs_created", [])):
            try:
                Path(d).rmdir()
            except OSError:
                pass
        from . import actions as act
        for a in reversed(j.get("actions", [])):
            act.backward(a)
        self.paths.journal.unlink(missing_ok=True)

    @staticmethod
    def _put(path: Path, data: bytes | None, fault: str | None = None) -> None:
        before = _read(path)
        if data is None:
            if before is not None:
                path.unlink()
                _fsync_dir(path.parent)
        elif data != before:
            mode = path.stat().st_mode & 0o777 if before is not None else 0o644
            _atomic_write(path, data, mode, fault=fault)

    def _write_manifest(self, manifest: Manifest | None) -> None:
        if manifest is None:
            if self.paths.manifest.exists():
                self.paths.manifest.unlink()
        else:
            _atomic_write(self.paths.manifest, manifest.to_json(), 0o600)

    def recover(self, roll_back_unfinished: bool = False) -> str | None:
        """Finish or roll back an interrupted change. Returns what was done.

        Finished if every file already has its new content; rolled back (from
        the journal's copies) if every file has either its old or new content;
        otherwise something else changed a file, and nothing is touched.
        Finishing repeats the actions without a final outcome; if one still
        fails, the journal stays and Incomplete is raised, unless
        `roll_back_unfinished` (revert), which rolls the change back instead.
        """
        p = self.paths
        raw = _read(p.journal)
        if raw is None:
            stray = self._stray_tmp([p.target])
            for t in stray:
                t.unlink()
            return f"removed {len(stray)} leftover temporary file(s)" if stray else None
        try:
            j = json.loads(raw)
            entries = j["entries"]
        except (ValueError, KeyError):
            raise HostError(f"{p.journal} is unreadable. Run `theme-unifier doctor --discard-journal` after checking gtk.css.")
        for t in self._stray_tmp([Path(e["path"]) for e in entries]):
            t.unlink()
        cur = {e["path"]: sha256(_read(Path(e["path"]))) for e in entries}
        if all(cur[e["path"]] == e["after_sha256"] for e in entries):
            m = j["manifest_after"]
            if m is None:
                self._write_manifest(None)
            else:
                m.pop("region_sha256", None)
                self._write_manifest(Manifest(**m))
            self._remove_empty(j.get("remove_dirs", []))
            # Every action checks what it finds, so repeating one that may have run is harmless.
            lines, failed = self._run_actions(j, "before")
            more, failed_after = self._run_actions(j, "after")
            lines, failed = lines + more, failed + failed_after
            if failed and roll_back_unfinished:
                self._roll_back(j)
                return "rolled back an unfinished change (" + " ".join(failed) + ")"
            self.log.extend(lines)
            if failed:
                raise _incomplete(failed)
            p.journal.unlink()
            return "finished an interrupted change (the files already had their new content)"
        if all(cur[e["path"]] in (e["before_sha256"], e["after_sha256"]) for e in entries):
            self._roll_back(j)
            return "rolled back an interrupted change (the files are back to their old content)"
        changed = [e["path"] for e in entries if cur[e["path"]] not in (e["before_sha256"], e["after_sha256"])]
        raise HostError("An interrupted change was found, but " + ", ".join(changed) + " matches neither the "
                        "content before nor after it, so something else changed it in the meantime. Nothing was "
                        "touched. Check it, then run `theme-unifier doctor --discard-journal`.")

    @staticmethod
    def _stray_tmp(paths: list[Path]) -> list[Path]:
        out = []
        for path in paths:
            if path.parent.exists():
                out += path.parent.glob(f".{path.name}.theme-unifier-*.tmp")
        return out

    # State -----------------------------------------------------------------

    def load(self, recover: bool = True, roll_back_unfinished: bool = False) -> tuple[Manifest | None, str | None]:
        """The manifest and gtk.css, after recovery. With recover=False (a dry
        run) nothing is touched, and a pending change is refused instead."""
        if not recover:
            if self.paths.journal.exists():
                raise HostError("An earlier change was interrupted and hasn't been finished or rolled back, so "
                                "what Apply would do can't be worked out yet. A dry run doesn't recover it; run "
                                "`theme-unifier doctor` to do that. Nothing was changed.", EXIT_INCOMPLETE)
        else:
            note = self.recover(roll_back_unfinished)
            if note:
                self.log.append(note)
        self._loaded = {self.paths.target: sha256(_read(self.paths.target)),
                        self.paths.manifest: sha256(_read(self.paths.manifest))}
        return Manifest.load(self.paths.manifest), self._read_target_text()

    def _read_target_text(self) -> str | None:
        t = self.paths.target
        if t.is_symlink():
            raise HostError(f"{t} is a symbolic link (to {os.readlink(t)}). theme-unifier only edits a regular "
                            "file it can own a region in; nothing was changed.", EXIT_UNSAFE)
        data = _read(t)
        if data is None:
            return None
        try:
            return data.decode("utf-8")
        except UnicodeDecodeError:
            raise HostError(f"{t} is not valid UTF-8; nothing was changed.", EXIT_UNSAFE)

    def backup(self, text: str | None) -> Path | None:
        """Keep a copy of gtk.css as it was before the tool first touched it."""
        if text is None:
            return None
        data = text.encode()
        digest = sha256(data)
        self.paths.backups.mkdir(parents=True, exist_ok=True)
        for b in self.paths.backups.glob("*.css"):
            if sha256(b.read_bytes()) == digest:
                return b
        dest = self.paths.backups / f"{time.strftime('%Y%m%d-%H%M%S')}-{digest[:8]}-gtk.css"
        _atomic_write(dest, data, 0o600)
        return dest

    # Operations ------------------------------------------------------------

    def insert(self, text: str | None, region: str) -> tuple[str, str]:
        """New file text with `region` appended, and the lead that was needed."""
        text = text or ""
        lead = "\n" if text and not text.endswith("\n") else ""
        return text + lead + region, lead

    def remove(self, text: str, m: Manifest, force: bool = False) -> str:
        """File text with the manifest's region taken out exactly."""
        r = find_region(text)
        if r is None:
            raise HostError("The managed region is no longer in gtk.css (removed by hand?).", EXIT_CONFLICT)
        if r.id != m.id:
            raise HostError(f"gtk.css holds a region with ID {r.id}, but the manifest has {m.id}.")
        if r.text(text) != m.region and not force:
            raise HostError("The managed region in gtk.css was edited since theme-unifier wrote it. "
                            "Nothing was changed. Move your edits outside the markers, or use --force "
                            "to discard them.")
        start = r.start
        if m.lead and text[start - len(m.lead):start] == m.lead:
            start -= len(m.lead)
        return text[:start] + text[r.end:]

    def region_state(self, text: str | None, m: Manifest | None) -> str:
        try:
            r = find_region(text or "")
        except HostError as e:
            return f"damaged: {e}"
        if m is None:
            return "orphan region (no manifest)" if r else "none"
        if m.suspended:
            return "suspended" if r is None else "present while suspended (unexpected)"
        if r is None:
            return "missing (removed by hand?)"
        if r.id != m.id:
            return "foreign ID"
        try:
            self.remove(text, m)
        except HostError:
            return "edited"
        return "intact"
