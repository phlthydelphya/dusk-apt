"""What an apply would change, in words (apply --dry-run and the confirm screen)."""

from __future__ import annotations

import os
from pathlib import Path

from .. import flatpak as fp
from ..host import Host, Manifest
from . import apps, palette_export, qt, watcher

def home(p: Path | str) -> str:
    home = str(Path.home())
    return "~" + str(p)[len(home):] if str(p).startswith(home + os.sep) else str(p)


def describe(host: Host, text: str | None, new_text: str | None, extra: dict[Path, bytes | None],
                     acts: list[dict], m: Manifest, shell_file: str | None, gtk3_copy: set[Path]) -> list[str]:
    """Every file, setting, extension, service and Flatpak permission an apply
    would change, in words (apply --dry-run, and the window's confirm screen)."""
    lines = ["Apply would change the following. Nothing has been changed yet."]
    target = host.paths.target
    if new_text != text:
        verb = "create" if text is None else "update"
        what = "authored libadwaita styles" if m.adwaita.get("kind") == "authored" else "libadwaita colors"
        lines.append(f"File: {verb} {home(target)} (the theme-unifier section: {what}).")
    overrides = {fp.override_path(app): app for app in m.flatpak}
    groups: dict[str, list[Path]] = {}
    for path, data in extra.items():
        if path == watcher.unit_path():
            key = "unit"
        elif path == palette_export.path():
            key = "palette"
        elif apps.owner(path, m.apps):
            key = "app"
        elif qt.owns(path, m.qt):
            key = "qt"
        elif str(path) == shell_file:
            key = "shell"
        elif path in gtk3_copy:
            key = "gtk3"
        elif "theme-unifier-authored" in path.parts:
            key = "adwaita"
        elif path in overrides:
            key = "flatpak"
        else:
            key = "gtk4"
        groups.setdefault(key, []).append(path)
    if groups.get("gtk4"):
        folder = os.path.commonpath([str(p.parent) for p in groups["gtk4"]])
        lines.append(f"Files: write {len(groups['gtk4'])} generated GTK4 theme file(s) in {home(folder)}.")
    if groups.get("palette"):
        lines.append(f"File: write the palette export {home(groups['palette'][0])} (the applied colors, for other tools).")
    for name in sorted({apps.owner(p, m.apps) for p in groups.get("app", [])}):
        paths = [home(p) for p in groups["app"] if apps.owner(p, m.apps) == name]
        lines.append(f"Files: write the {name} theme files ({', '.join(paths)}).")
    if groups.get("adwaita"):
        lines.append(f"Files: update {len(groups['adwaita'])} authored GTK4 style file(s) for libadwaita apps "
                     "inside the GTK4 configuration directory.")
    if groups.get("shell"):
        lines.append(f"File: write the generated GNOME Shell theme {home(groups['shell'][0])}.")
    if groups.get("gtk3"):
        folder = next(q for q in groups["gtk3"][0].parents if q.name == "gtk-3.0")
        lines.append(f"Files: copy the theme's GTK3 styles to {home(folder)} ({len(groups['gtk3'])} files) so "
                     "Flatpak apps can see them.")
    for path in groups.get("qt", []):
        lines.append(qt.describe(path, extra[path], m.qt))
    if groups.get("unit"):
        lines.append(f"File: write the watcher service {home(watcher.unit_path())}.")
    for path in sorted(groups.get("flatpak", [])):
        app = overrides[path]
        kde = (m.flatpak.get(app) or {}).get("kde") or {}
        kde_env = [f"{k}={e['value']}" for k, e in kde.get("env", {}).items() if e.get("added")]
        lines.append(f"Flatpak {app}: let it read your GTK4 settings and themes folder"
                     + (", and kdeglobals with the KDE platform theme (" + ", ".join(kde_env) + ")" if kde_env else "")
                     + f" (read-only; override file {home(path)}).")
    for a in acts:
        if a["kind"] == "setting":
            name = {"gtk-theme": "GTK theme (org.gnome.desktop.interface gtk-theme)",
                    "user-theme": "GNOME Shell theme (User Themes extension)",
                    "button-layout": "Window button layout (org.gnome.desktop.wm.preferences)",
                    "accent-color": "Accent color (org.gnome.desktop.interface accent-color)"}.get(
                a["key"], a.get("label", a["key"]))
            show = lambda v: repr(v) if v else "default"  # noqa: E731
            lines.append(f"Setting: {name}: {show(a['before'])} -> {show(a['after'])}.")
        elif a["kind"] == "extension":
            lines.append(f"Extension: turn {'on' if a['op'] == 'add' else 'off'} {a['id']}.")
        elif a["kind"] == "unit":
            what = {"enable": "enable and start", "disable": "disable and stop", "restart": "restart"}[a["op"]]
            lines.append(f"Service: {what} {a['name']} (systemd --user).")
    lines.append("Revert undoes all of it.")
    return lines
