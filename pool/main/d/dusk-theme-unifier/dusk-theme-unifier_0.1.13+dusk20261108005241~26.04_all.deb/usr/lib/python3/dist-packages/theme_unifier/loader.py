"""Find installed GTK3 themes and load their full stylesheet.

Many themes ship a one-line gtk.css that imports the real stylesheet from a
compiled gtk.gresource bundle, so imports are followed into the bundle.
"""

from __future__ import annotations

import configparser
import os
import posixpath
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

from . import cssparse


# GTK 3.24 is the final GTK3 series and the version on every supported distro.
GTK3_MINOR = 24


def theme_search_dirs() -> list[Path]:
    home = Path.home()
    data_home = Path(os.environ.get("XDG_DATA_HOME", home / ".local/share"))
    data_dirs = os.environ.get("XDG_DATA_DIRS", "/usr/local/share:/usr/share").split(":")
    dirs = [home / ".themes", data_home / "themes"]
    dirs += [Path(d) / "themes" for d in data_dirs if d]
    seen: list[Path] = []
    for d in dirs:
        if d not in seen:
            seen.append(d)
    return seen


@dataclass
class Theme:
    name: str
    path: Path

    @property
    def gtk3_dir(self) -> Path:
        """The directory GTK 3.24 actually loads.

        GTK3 looks for gtk-3.<minor> from its own minor version down to
        gtk-3.0 in steps of two, so a theme's gtk-3.20 folder replaces its
        gtk-3.0 folder on any current system.
        """
        for minor in range(GTK3_MINOR, -1, -2):
            d = self.path / f"gtk-3.{minor}"
            if (d / "gtk.css").is_file():
                return d
        return self.path / "gtk-3.0"

    @property
    def has_dark_variant(self) -> bool:
        return self.name in ("Adwaita", "HighContrast") or (self.gtk3_dir / "gtk-dark.css").is_file()

    def metadata(self) -> dict[str, str]:
        index = self.path / "index.theme"
        if not index.is_file():
            return {}
        cp = configparser.ConfigParser(interpolation=None, strict=False)
        try:
            cp.read(index, encoding="utf-8")
        except configparser.Error:
            return {}
        return dict(cp["Desktop Entry"]) if "Desktop Entry" in cp else {}

    @property
    def builtin(self) -> bool:
        """True for themes compiled into GTK3, whose gtk.css is only a stub."""
        return self.name in BUILTIN_THEMES

    def dark_sibling(self) -> "Theme | None":
        """A separately installed dark theme, e.g. Breeze -> Breeze-Dark."""
        for suffix in ("-Dark", "-dark", "-Darker", "-darker"):
            for theme in list_themes():
                if theme.name == self.name + suffix:
                    return theme
        return None

    def stylesheet_path(self, dark: bool = False) -> str:
        if self.builtin:
            light, dark_css = BUILTIN_THEMES[self.name]
            return f"resource:///org/gtk/libgtk/theme/{dark_css if dark else light}"
        name = "gtk-dark.css" if dark and self.has_dark_variant else "gtk.css"
        return str(self.gtk3_dir / name)

    def stylesheet(self, dark: bool = False) -> cssparse.Stylesheet:
        return load_css(self.stylesheet_path(dark), self.gtk3_dir)


# Theme name -> (light, dark) stylesheets inside libgtk-3.
BUILTIN_THEMES: dict[str, tuple[str, str]] = {
    "Adwaita": ("Adwaita/gtk-contained.css", "Adwaita/gtk-contained-dark.css"),
    "Adwaita-dark": ("Adwaita/gtk-contained-dark.css", "Adwaita/gtk-contained-dark.css"),
    "HighContrast": ("HighContrast/gtk-contained.css", "HighContrast/gtk-contained-inverse.css"),
    "HighContrastInverse": ("HighContrast/gtk-contained-inverse.css",) * 2,
}


def list_themes() -> list[Theme]:
    """Installed themes that contain a GTK3 stylesheet, first match per name wins."""
    found: dict[str, Theme] = {}
    for d in theme_search_dirs():
        try:  # a folder on the search path may be unreadable (another user's, a broken mount)
            entries = sorted(d.iterdir()) if d.is_dir() else []
        except OSError:
            continue
        for entry in entries:
            if entry.name in found:
                continue
            theme = Theme(entry.name, entry)
            try:
                if (theme.gtk3_dir / "gtk.css").is_file():
                    found[entry.name] = theme
            except OSError:
                continue
    if _gtk3_library():
        for name in ("Adwaita", "Adwaita-dark", "HighContrast"):
            found.setdefault(name, Theme(name, Path("/usr/share/themes") / name))
    return sorted(found.values(), key=lambda t: t.name.lower())


def find_theme(name_or_path: str) -> Theme:
    p = Path(name_or_path).expanduser()
    if p.is_dir():
        theme = Theme(p.name, p.resolve())
        if (theme.gtk3_dir / "gtk.css").is_file():
            return theme
    for theme in list_themes():
        if theme.name == name_or_path:
            return theme
    raise LookupError(f"no installed GTK3 theme named {name_or_path!r}")


# --- Reading CSS, including from gresource bundles ----------------------


def _gtk3_library() -> Path | None:
    for pattern in ("/usr/lib/*/libgtk-3.so.0", "/usr/lib/libgtk-3.so.0", "/usr/lib64/libgtk-3.so.0"):
        hits = sorted(Path("/").glob(pattern.lstrip("/")))
        if hits:
            return hits[0]
    return None


def _read_resource(uri: str, search_dir: Path) -> str:
    """Read resource:///path from a gresource bundle in `search_dir`.

    GTK's own themes (Adwaita, HighContrast) live inside libgtk-3 itself,
    which the gresource tool can read like any other bundle.
    """
    res_path = uri[len("resource://") :]
    bundles = sorted(search_dir.glob("*.gresource"))
    if res_path.startswith("/org/gtk/libgtk/"):
        lib = _gtk3_library()
        bundles = [lib] if lib else []
    try:  # PyGObject, when it is available
        from gi.repository import Gio  # type: ignore

        for bundle in bundles:
            resource = Gio.Resource.load(str(bundle))
            try:
                data = resource.lookup_data(res_path, Gio.ResourceLookupFlags.NONE)
                return data.get_data().decode("utf-8")
            except Exception:
                continue
    except Exception:
        pass
    tool = shutil.which("gresource")
    if tool:
        for bundle in bundles:
            proc = subprocess.run(
                [tool, "extract", str(bundle), res_path], capture_output=True
            )
            if proc.returncode == 0:
                return proc.stdout.decode("utf-8")
    raise FileNotFoundError(
        f"could not read {uri} (install libglib2.0-bin for the gresource tool)"
    )


MAX_IMPORT_DEPTH = 32  # GTK themes nest a few levels; anything deeper is broken or hostile
MAX_IMPORTED_FILES = 500


def _normalize(target: str) -> str:
    """One spelling per file, so "./gtk.css", "a/../gtk.css" and the plain path compare equal."""
    if target.startswith("resource://"):
        return "resource://" + posixpath.normpath(target[len("resource://"):])
    return os.path.normpath(os.path.abspath(target))


def _child_target(target: str, parent: str) -> str:
    if target.startswith("resource://"):
        return _normalize(target)
    if target.startswith("file://"):
        return _normalize(target[len("file://") :])
    if parent.startswith("resource://"):
        return _normalize(parent.rsplit("/", 1)[0] + "/" + target)
    return _normalize(os.path.join(os.path.dirname(parent), target))


def load_css(path: Path | str, base_dir: Path, _stack: tuple[str, ...] = (), _count: list[int] | None = None
             ) -> cssparse.Stylesheet:
    """Parse a stylesheet and everything it imports, in cascade order.

    Imports are expanded where they appear, so a color defined before an
    @import and redefined inside the imported file ends up with the imported
    value, as in GTK. A file imported again later is read again (A, B, A ends
    with A's values); only an import that leads back to a file still being
    read is a cycle, which is skipped and recorded in `cycles`. Imports that
    cannot be read are recorded in `missing`.
    """
    key = _normalize(str(path))
    count = _count if _count is not None else [0]
    result = cssparse.Stylesheet()
    count[0] += 1
    if count[0] > MAX_IMPORTED_FILES:
        result.missing.append(f"{key} (more than {MAX_IMPORTED_FILES} imported files; stopped)")
        return result
    if key.startswith("resource://"):
        text = _read_resource(key, base_dir)
    else:
        text = Path(key).read_text(encoding="utf-8", errors="replace")
    result.files.append(key)
    stack = _stack + (key,)
    for segment, target in cssparse.split_imports(cssparse.strip_comments(text)):
        result.extend(cssparse.parse(segment, origin=key))
        if target is None:
            continue
        child = _child_target(target, key)
        if child in stack:
            result.cycles.append(" -> ".join(stack[stack.index(child):] + (child,)))
            continue
        if len(stack) >= MAX_IMPORT_DEPTH:
            result.missing.append(f"{child} (imports nested more than {MAX_IMPORT_DEPTH} deep; stopped)")
            continue
        try:
            result.extend(load_css(child, base_dir, stack, count))
        except (OSError, UnicodeDecodeError) as e:
            result.missing.append(f"{child} ({e.__class__.__name__})")
    return result
