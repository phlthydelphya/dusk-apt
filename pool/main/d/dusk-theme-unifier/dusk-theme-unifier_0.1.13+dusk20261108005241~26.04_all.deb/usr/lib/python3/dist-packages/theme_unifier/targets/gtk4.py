"""Plain GTK4 apps (milestone 4): the generated GTK4 theme files."""

from __future__ import annotations

from pathlib import Path

from .. import gtk4theme
from ..generate import generate
from ..host import HostError, Manifest, _read, missing_dirs, sha256
from ..loader import find_theme
from ..variants import discover

def changes(theme_ref: str, m: Manifest | None, gtk4: str, force: bool,
                  also: dict[Path, bytes] | None = None
                  ) -> tuple[dict[Path, bytes | None], dict[str, str], list[Path], str]:
    """Files to write or delete for plain GTK4 apps (and `also`: other whole
    files, e.g. the Shell theme), the new owned-file record, folders to
    create, and a note for the user. Raises HostError on conflicts."""
    desired: dict[Path, bytes] = {}
    note = "Plain GTK4 apps: left alone (--gtk4 off)."
    if gtk4 != "off":
        theme = find_theme(theme_ref)
        vs = discover(theme)
        gens = {mode: generate(pal, mode) for mode, pal in vs.palettes.items()}
        pl = gtk4theme.plan(theme.name, gens.get("light"), gens.get("dark"), vs.base_mode,
                            replace_own=gtk4 == "generated")
        desired = pl.files
        if desired:
            folder = next(iter(desired)).parent
            note = (f"Plain GTK4 apps: generated a GTK4 theme in {folder} "
                    f"({', '.join(p.name for p in desired)}). GTK4 uses it while the system theme is {theme.name}.")
        else:
            note = f"Plain GTK4 apps: nothing written. {pl.skipped}"
    desired = {**desired, **(also or {})}
    owned = dict(m.files) if m else {}
    changes: dict[Path, bytes | None] = {}
    for path_s, sha in owned.items():
        path = Path(path_s)
        cur = _read(path)
        if cur is not None and sha256(cur) != sha and not force:
            raise HostError(f"{path} was changed after theme-unifier wrote it. Nothing was changed; "
                            "use --force to replace it.")
        if path not in desired and cur is not None:
            changes[path] = None
    for path, data in desired.items():
        cur = _read(path)
        if cur is not None and str(path) not in owned:
            raise HostError(f"{path} already exists and wasn't written by theme-unifier. Nothing was changed.")
        if cur != data:
            changes[path] = data
    new_dirs = [d for path in desired for d in missing_dirs(path)]
    new_dirs = list(dict.fromkeys(new_dirs))
    return changes, {str(p): sha256(d) for p, d in desired.items()}, new_dirs, note
