"""Palette export: the applied colors as one JSON file other tools can read."""

from __future__ import annotations

import json
from pathlib import Path

from ..host import Manifest, _read, config_home, sha256

VERSION = 1


def path() -> Path:
    """Where the export lives (~/.config/theme-unifier/palette.json)."""
    return config_home() / "theme-unifier" / "palette.json"


def document(theme: str, mode: str, colors: dict[str, str], accent_name: str | None) -> bytes:
    """The export's bytes. They are the same for the same input, so a second
    apply finds the file already up to date. `accent_name` is left out when None."""
    roles = dict(colors)
    if accent_name is not None:
        roles["accent_name"] = accent_name
    doc = {"version": VERSION, "theme": theme, "mode": mode, "colors": roles}
    return (json.dumps(doc, indent=2, sort_keys=True) + "\n").encode()


def follow(m: Manifest, theme: str, mode: str, colors: dict[str, str], accent_name: str | None,
           out: list[str]) -> dict[Path, bytes]:
    """The watcher's switch to a new mode: the file's new bytes, updating m.files.
    A file edited by hand (or gone) is left as it is."""
    p = path()
    owned = m.files.get(str(p))
    if owned is None:
        return {}
    cur = _read(p)
    if cur is None or sha256(cur) != owned:
        out.append(f"Palette export: {p} was edited, so it was not switched.")
        return {}
    data = document(theme, mode, colors, accent_name)
    if data == cur:
        return {}
    m.files[str(p)] = sha256(data)
    return {p: data}
