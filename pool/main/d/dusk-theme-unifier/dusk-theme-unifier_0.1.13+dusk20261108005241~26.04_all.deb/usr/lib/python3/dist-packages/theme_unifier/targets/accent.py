"""The session's accent color: the libadwaita accent nearest to the theme's accent."""

from __future__ import annotations

import math

from .. import session
from ..colors import Color, to_oklab

ACCENTS: dict[str, str] = {  # the nine libadwaita 1.10 accents
    "blue": "#3584e4", "teal": "#2190a4", "green": "#3a944a", "yellow": "#c88800", "orange": "#ed5b00",
    "red": "#e62d42", "pink": "#d56199", "purple": "#9141ac", "slate": "#6f8396",
}
GRAY_CHROMA = 0.04  # below this OKLCh chroma a color is a gray, and gray means slate
LABEL = "Accent color"


def nearest(color_hex: str) -> str:
    """The accent name closest to a color (smallest OKLab distance); slate for grays."""
    lab = to_oklab(Color.from_hex(color_hex))
    if math.hypot(lab[1], lab[2]) < GRAY_CHROMA:
        return "slate"
    return min(ACCENTS, key=lambda name: math.dist(lab, to_oklab(Color.from_hex(ACCENTS[name]))))


def _action(before: str, after: str, done: str, force: bool = False) -> dict:
    return {"kind": "setting", "key": "accent-color", "before": before, "after": after, "force": force,
            "label": LABEL, "done": done}


def activate(color_hex: str, choice: str, old: dict, out: list[str]) -> tuple[dict, list[dict]]:
    """Plan setting the session's accent color to the accent nearest to the
    theme's, remembering what it was."""
    if choice == "off":
        out.append("Accent color: left alone (--accent off).")
        return {}, restore(old)
    cur = session.accent_color()
    if cur is None:
        out.append("Accent color: the setting can't be read on this desktop, so it was left alone.")
        return {}, []
    name = nearest(color_hex)
    before = old["before"] if old.get("changed") else cur
    if cur == name:
        out.append(f"Accent color: already {name}.")
        return {"name": name, "before": before, "changed": bool(old.get("changed")), "color": color_hex}, []
    rec = {"name": name, "before": before, "changed": True, "color": color_hex}
    return rec, [{"kind": "setting", "key": "accent-color", "before": cur, "after": name, "label": LABEL,
                  "done": f"Accent color: set to {name}, nearest to the theme's accent {color_hex} (was {cur}). "
                          "Revert sets it back."}]


def restore(rec: dict, force: bool = False) -> list[dict]:
    if not rec.get("changed"):
        return []
    return [_action(rec["name"], rec["before"], f"Accent color: set back to {rec['before']}.", force)]


def follow(rec: dict, color_hex: str, out: list[str]) -> tuple[dict, list[dict]]:
    """The watcher's light/dark switch: move the accent to the match for the
    new mode's accent color. A value the user changed by hand is left alone
    (the action then reports a conflict)."""
    if not rec:
        return rec, []
    name = nearest(color_hex)
    if name == rec["name"]:
        return dict(rec, color=color_hex), []
    new = {"name": name, "before": rec["before"], "changed": True, "color": color_hex}
    return new, [_action(rec["name"], name, f"Accent color: now {name}, nearest to the theme's accent {color_hex}.")]
