"""GNOME Shell (milestone 7): the generated stylesheet and the User Themes settings."""

from __future__ import annotations

from pathlib import Path

from .. import session, shelltheme
from ..generate import generate
from ..host import Host, Manifest, _read, sha256
from ..loader import find_theme
from ..variants import discover

# The manifest's `shell` record: {"choice", "name" (the user-theme name we
# want, or None), "file" (generated stylesheet or None), "state" ("active",
# "suspended" under high contrast, or "inactive"), "name_before" (the
# user-theme name before us), "extension_added" (we added User Themes to
# enabled-extensions)}.


def plan(theme_ref: str, mode: str, choice: str) -> tuple[dict[Path, bytes], dict, str]:
    """Generated Shell stylesheet to own, the new record (without the
    activation fields), and a note."""
    if choice == "off":
        return {}, {"choice": choice, "name": None, "file": None}, "GNOME Shell: left alone (--shell off)."
    if session.user_theme_name() is None:
        return {}, {"choice": choice, "name": None, "file": None}, (
            "GNOME Shell: left alone, because the User Themes extension isn't installed. Install it with "
            "`sudo apt install gnome-shell-extensions`, log out and back in, then apply again.")
    theme = find_theme(theme_ref)
    vs = discover(theme)
    try:
        pl = shelltheme.plan(theme.name, generate(vs.palettes[mode], mode),
                             "generated" if choice == "generated" else "auto")
    except shelltheme.ShellError as e:
        return {}, {"choice": choice, "name": None, "file": None}, f"GNOME Shell: left alone. {e}"
    files = {path: css.encode() for path, css in pl.write.items()}
    return files, {"choice": choice, "name": pl.name, "file": str(next(iter(files))) if files else None,
                   "mode": mode}, \
        " ".join(pl.notes)


def activate(rec: dict, old: dict, hc: bool, reload: bool, out: list[str]) -> tuple[dict, list[dict]]:
    """Plan pointing User Themes at rec["name"] (or keeping it off under high
    contrast): the record with its activation fields, and the actions that
    do it (carried out by Host.commit). `old` is the previous record."""
    rec = dict(rec)
    was_on = old.get("state") in ("active", "suspended")
    rec["name_before"] = old.get("name_before") if was_on else session.user_theme_name()
    rec["extension_added"] = bool(old.get("extension_added")) if was_on else False
    if not rec.get("name"):
        rec["state"] = "inactive"
        return rec, restore(old, force=False) if was_on else []
    acts = []
    exts = session.enabled_extensions()
    if exts is not None and shelltheme.EXTENSION not in exts:
        rec["extension_added"] = True
        acts.append({"kind": "extension", "op": "add", "id": shelltheme.EXTENSION,
                     "done": "GNOME Shell: turned on the User Themes extension (revert turns it off again)."})
    if session.user_extensions_disabled():
        out.append("GNOME Shell: extensions are switched off in your session (Extensions app), so the Shell "
                   "theme won't show until you turn them on.")
    cur = session.user_theme_name() or ""
    if hc:
        rec["state"] = "suspended"
        acts.append(user_theme(cur, ""))
        out.append("GNOME Shell: high contrast is on, so the Shell keeps its own high-contrast style for now.")
        return rec, acts
    rec["state"] = "active"
    acts.append(user_theme(cur, rec["name"], reload=reload))
    return rec, acts


def user_theme(before: str, after: str, reload: bool = False, force: bool = False, done: str | None = None) -> dict:
    return {"kind": "setting", "key": "user-theme", "before": before, "after": after, "reload": reload,
            "force": force, "label": "GNOME Shell: the User Themes theme", "done": done}


def restore(rec: dict, force: bool) -> list[dict]:
    """The actions that undo what activate did: only our own settings (D5)."""
    acts = []
    if rec.get("state") in ("active", "suspended"):
        ours = rec["name"] if rec["state"] == "active" else ""
        back = rec.get("name_before") or ""
        acts.append(user_theme(ours, back, force=force,
                                done="GNOME Shell: theme set back to " + (f"{back}." if back else "the default.")))
    if rec.get("extension_added"):
        acts.append({"kind": "extension", "op": "remove", "id": shelltheme.EXTENSION,
                     "done": "GNOME Shell: turned the User Themes extension off again."})
    return acts


def sync(m: Manifest, hc: bool | None, scheme: str | None, host: Host, out: list[str]) -> None:
    """The watcher's part for the Shell: off under high contrast (the Shell
    then shows its own high-contrast style at once), back afterwards, and a
    regenerated stylesheet when the color scheme changes."""
    rec = m.shell
    if rec.get("state") == "active" and hc:
        rec["state"] = "suspended"
        out.extend(host.commit(_read(host.paths.target), m, actions=[user_theme(rec["name"], "")]))
        out.append("GNOME Shell: high contrast is on, so the Shell shows its own high-contrast style.")
        return
    if rec.get("state") == "suspended" and hc is False:
        rec["state"] = "active"
        out.extend(host.commit(_read(host.paths.target), m, actions=[user_theme("", rec["name"])]))
        out.append(f"GNOME Shell: high contrast is off, so {rec['name']} is back.")
    if rec.get("state") != "active" or not rec.get("file") or not scheme or scheme == rec.get("mode"):
        return
    vs = discover(find_theme(m.theme))
    if scheme not in vs.palettes:
        return  # the region code explains the unavailable mode (D2)
    path = Path(rec["file"])
    cur = _read(path)
    if cur is None or sha256(cur) != m.files.get(rec["file"]):
        out.append(f"GNOME Shell: {path} was changed after theme-unifier wrote it, so it wasn't switched to "
                   f"{scheme}.")
        return
    try:
        css = shelltheme.compile_css(generate(vs.palettes[scheme], scheme), shelltheme.shell_version() or "")
    except shelltheme.ShellError as e:
        out.append(f"GNOME Shell: not switched to {scheme}. {e}")
        return
    data = css.encode()
    m.files[rec["file"]] = sha256(data)
    rec["mode"] = scheme
    out.extend(host.commit(_read(host.paths.target), m, {path: data},
                           actions=[user_theme(rec["name"], rec["name"], reload=True)]))
    out.append(f"GNOME Shell: switched to {rec['name']} ({scheme}).")


def status(rec: dict) -> list[str]:
    if not rec or not rec.get("name"):
        return []
    state = rec.get("state")
    if state == "suspended":
        return [f"GNOME Shell: {rec['name']} is off while high contrast is on."]
    if state != "active":
        return [f"GNOME Shell: {rec['name']} is recorded but not set."]
    cur = session.user_theme_name()
    if cur != rec["name"]:
        return [f"GNOME Shell: User Themes now uses {cur!r}, not {rec['name']} (changed outside theme-unifier)."]
    what = f"generated, {rec.get('mode')}" if rec.get("file") else "the theme's own"
    line = f"GNOME Shell: {rec['name']} ({what})."
    exts = session.enabled_extensions()
    if exts is not None and shelltheme.EXTENSION not in exts:
        line += " The User Themes extension is turned off, so the Shell isn't showing it."
    return [line]
