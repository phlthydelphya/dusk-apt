"""Desktop changes that aren't files: GSettings keys and the watcher's systemd unit.

They are part of a Host.commit transaction (host.py): written into its
journal before anything changes, carried out after the files (phase
"after") or before them (phase "before"), and repeated or undone by
recovery when a run is interrupted. So every action must be safe to run
again, and each one says what it expects to find:

    {"kind": "setting", "key": "gtk-theme" | "user-theme" | "button-layout", "before": X, "after": Y,
     "reload": bool, "force": bool, "label": "...", "done": "..."}
        Sets the key to `after` only if it still holds `before` (or `after`
        already, which counts as done). Anything else means someone changed
        it in the meantime, and it is left alone (D5) unless `force`.
        `reload` sets "" first when the key already holds `after` (User
        Themes reloads only when the name changes). That in-between step is
        recorded in the journal first ("step": "cleared"), so a run
        interrupted between the two writes finishes the reload instead of
        taking "" for a change made by someone else.
    {"kind": "extension", "op": "add" | "remove", "id": "...", "done": "..."}
        Adds or removes one extension from the enabled list, leaving the rest.
    {"kind": "unit", "op": "enable" | "disable" | "restart", "name": "...", "path": "...", "done": "...",
     "failed": "..."}
        systemctl --user enable/disable --now, or restart after the unit file changed.

Each run ends in an Outcome, which the journal records ("outcome"):
ok (done, or already done), skipped (nothing can be done here: no systemd,
no such setting), conflict (someone else changed it; left alone) or failed
(the write or command didn't work). The first three are final; a failed or
unfinished action keeps the transaction open, and recovery tries it again.
"""

from __future__ import annotations

import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from . import session
from .host import _crashpoint

OK, SKIPPED, CONFLICT, FAILED = "ok", "skipped", "conflict", "failed"
FINAL = (OK, SKIPPED, CONFLICT)

_SETTINGS = {  # looked up on each use, so tests can stand in for the session
    "gtk-theme": ("gtk_theme", "set_gtk_theme"),
    "user-theme": ("user_theme_name", "set_user_theme_name"),
    "button-layout": ("button_layout", "set_button_layout"),
    "accent-color": ("accent_color", "set_accent_color"),
}


def _setting(key: str):
    get, put = _SETTINGS[key]
    return getattr(session, get), getattr(session, put)


@dataclass
class Outcome:
    status: str
    line: str | None = None  # for the user


def _systemctl(*args: str) -> bool | None:
    """True or False for the command's success; None when there is no systemd --user to ask
    (no systemctl, or no user manager in this session: its socket is missing)."""
    if os.environ.get("THEME_UNIFIER_NO_SYSTEMD") or not shutil.which("systemctl"):
        return None
    runtime = os.environ.get("XDG_RUNTIME_DIR")
    if not runtime or not (Path(runtime) / "systemd" / "private").exists():
        return None
    try:
        return subprocess.run(["systemctl", "--user", *args], capture_output=True, timeout=15).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def forward(a: dict, mark: Callable[[str], None] | None = None) -> Outcome:
    """Carry out one action. `mark(step)` records progress in the journal
    before an in-between write (the reload's "")."""
    kind = a["kind"]
    if kind == "setting":
        get, put = _setting(a["key"])
        cur = get()
        if cur is None:
            return Outcome(SKIPPED, f"{a['label']}: the setting isn't there any more (extension removed?), "
                                    "so it was left as it is.")
        expected = (a["before"], a["after"]) + (("",) if a.get("step") == "cleared" else ())
        if cur == a["after"] and not a.get("reload"):
            return Outcome(OK)  # already done (a repeat after an interruption)
        if cur not in expected and not a.get("force"):
            return Outcome(CONFLICT, f"{a['label']} was changed to {cur!r} in the meantime, so it was left as it is.")
        if a.get("reload") and cur == a["after"]:
            if mark:
                mark("cleared")
            if not put(""):
                return Outcome(FAILED, f"{a['label']}: couldn't change the setting.")
            _crashpoint("reload-cleared")
        if not put(a["after"]):
            return Outcome(FAILED, f"{a['label']}: couldn't change the setting.")
        return Outcome(OK, a.get("done"))
    if kind == "extension":
        exts = session.enabled_extensions()
        if exts is None:
            return Outcome(SKIPPED)
        if a["op"] == "add" and a["id"] not in exts:
            new = exts + [a["id"]]
        elif a["op"] == "remove" and a["id"] in exts:
            new = [e for e in exts if e != a["id"]]
        else:
            return Outcome(OK)
        if not session.set_enabled_extensions(new):
            return Outcome(FAILED, f"GNOME Shell: couldn't turn {'on' if a['op'] == 'add' else 'off'} {a['id']}.")
        return Outcome(OK, a.get("done"))
    if kind == "unit":
        if a["op"] == "enable":
            ok = _systemctl("daemon-reload")
            if ok is None:
                return Outcome(SKIPPED, a.get("failed"))
            ok = ok and _systemctl("enable", "--now", a["name"])
            return Outcome(OK, a.get("done")) if ok else Outcome(FAILED, a.get("failed"))
        if a["op"] == "restart":
            ok = _systemctl("daemon-reload")
            if ok is None:
                return Outcome(SKIPPED)
            if not (ok and _systemctl("restart", a["name"])):
                return Outcome(FAILED, f"Watcher: `systemctl --user restart {a['name']}` failed, so it may "
                                       "still run the previous copy of theme-unifier.")
            return Outcome(OK, a.get("done"))
        ok = _systemctl("disable", "--now", a["name"])
        if ok is None:
            return Outcome(SKIPPED, a.get("done"))  # no systemd --user, so nothing runs under it
        if not ok and not (a.get("path") and not Path(a["path"]).exists()):  # a missing unit has nothing to stop
            return Outcome(FAILED, f"Watcher: `systemctl --user disable --now {a['name']}` failed, so the "
                                   "watcher may still be running.")
        _systemctl("daemon-reload")
        return Outcome(OK, a.get("done"))
    raise ValueError(f"unknown action {kind!r}")


def backward(a: dict) -> None:
    """Undo one action that may or may not have run (rollback of an interrupted change)."""
    kind = a["kind"]
    if kind == "setting":
        get, put = _setting(a["key"])
        cur = get()
        if a.get("step") == "cleared" and cur == "":
            put(a["before"])  # a reload stopped between its two writes
        elif a["before"] != a["after"] and cur == a["after"]:
            put(a["before"])
    elif kind == "extension":
        forward({**a, "op": "remove" if a["op"] == "add" else "add", "done": None})
    elif kind == "unit":
        if a["op"] == "restart":
            forward(a)  # the old unit file is back: run it again
        else:
            forward({**a, "op": "disable" if a["op"] == "enable" else "enable"})
