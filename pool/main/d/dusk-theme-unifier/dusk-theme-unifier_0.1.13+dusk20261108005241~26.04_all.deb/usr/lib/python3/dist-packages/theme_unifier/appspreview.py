"""Picture the kinds of apps Apply reaches, drawn the way each one will draw, without applying anything.

    python3 -m theme_unifier.appspreview THEME light|dark CSS OUT_DIR [--authored]

CSS is the stylesheet the preview shows (generated colors, or with
--authored the theme's own GTK4 gtk.css). One throwaway headless GNOME Shell
(the recipe in shellpreview.py) opens one sample window per kind of app,
takes a picture of each window, and closes it:

- libadwaita: the preview's sample widgets with CSS, drawn by this computer's
  libadwaita.
- Flatpak: the same widgets and CSS, run inside the GNOME runtime that most
  of the Flatpak apps Apply covers use, so that runtime's libadwaita draws
  them. Apply gives every Flatpak app ~/.config/gtk-4.0 (D7), the whole
  folder, so a theme's own styles reach them too.
- Snap: a confined snap reads gtk.css through a link its launcher keeps in
  ~/snap/NAME/REVISION/.config/gtk-4.0. A relative @import there would
  resolve inside the snap's own folder and fail, so Apply imports a theme's
  own styles by absolute path, which the snap can read (verified on stonking,
  2026-11-01). So snaps get the same stylesheet as other apps, colors only or
  the theme's own styles, except images those styles load: confinement lets
  a snap read only .css files under ~/.config/gtk-4.0. Drawn by this
  computer's libadwaita, since a snap's own can't run in the hidden Shell.
- Qt: qt6ct's (or qt5ct's) own window, a real Qt program, with the palette
  and settings Apply writes, read through QT_QPA_PLATFORMTHEME=qt5ct as Apply
  sets it.

Prints {"panels": [{"kind", "title", "png", "note"}, ...]} as JSON. The
Shell, the sample windows and the Flatpak sandbox get a temporary HOME, so
nothing in the real HOME or session is touched.
"""

from __future__ import annotations

import collections
import glob
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

from . import flatpak as fp
from . import inikeys, qtcolors, session
from .host import Paths, _read, config_home
from .shellpreview import (NO_SIDE_SERVICES, SOCKET_PATH_MAX, Stop, _appearance, _on_term, _run_shell,
                           _unmount_below)

PROBE = r"""
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as Scripting from 'resource:///org/gnome/shell/ui/scripting.js';
export var METRICS = {};
const stopped = () => GLib.file_test(GLib.getenv('TU_STOP'), GLib.FileTest.EXISTS);
async function wait(ms) {
    for (let t = 0; t < ms; t += 100) {
        if (stopped())
            return false;
        await Scripting.sleep(100);
    }
    return !stopped();
}
const windows = () => global.get_window_actors().map(a => a.meta_window)
    .filter(w => w.get_window_type() === Meta.WindowType.NORMAL);
export async function run() {
    const results = {};
    const save = () => GLib.file_set_contents(GLib.getenv('TU_RESULTS'), JSON.stringify(results));
    if (!await wait(1000))
        return;
    Main.overview.hide();
    for (const source of Main.messageTray.getSources())
        source.destroy();
    for (const app of JSON.parse(GLib.getenv('TU_APPS'))) {
        const before = new Set(windows());
        try {
            GLib.spawn_async(null, app.argv, GLib.get_environ(), GLib.SpawnFlags.SEARCH_PATH, null);
        } catch (e) {
            results[app.kind] = {error: e.message};
            continue;
        }
        let win = null;
        for (let t = 0; t < app.timeout && !win; t += 100) {
            if (!await wait(100))
                return save();
            win = windows().find(w => !before.has(w)) ?? null;
        }
        if (!win) {
            results[app.kind] = {error: 'no window appeared'};
            continue;
        }
        Main.activateWindow(win);
        if (!await wait(1500))  // let it draw its first frames
            return save();
        const r = win.get_frame_rect();
        const x = Math.max(0, r.x), y = Math.max(0, r.y);
        const w = Math.min(global.stage.width, r.x + r.width) - x, h = Math.min(global.stage.height, r.y + r.height) - y;
        const stream = Gio.File.new_for_path(app.png).replace(null, false, Gio.FileCreateFlags.NONE, null);
        await new Shell.Screenshot().screenshot_area(x, y, w, h, stream);
        stream.close(null);
        results[app.kind] = {ok: true, title: win.get_title()};
        win.delete(global.get_current_time());
        for (let t = 0; t < 3000 && windows().includes(win); t += 100) {
            if (!await wait(100))
                return save();
        }
        if (windows().includes(win))
            win.minimize();  // out of the way of the next picture
    }
    save();
}
export function finish() {}
"""

KINDS = ("libadwaita", "flatpak", "snap", "qt")
TITLES = {"libadwaita": "libadwaita apps", "flatpak": "Flatpak apps", "snap": "Snap apps", "qt": "Qt and KDE apps"}
SAMPLE_SIZE = "760x600"  # each sample window, inside the 1280x800 screen
GNOME_RUNTIME = "org.gnome.Platform"
VERSIONS = "TU_VERSIONS"  # the Flatpak sample's first stderr line: "TU_VERSIONS gtk=4.24.1 adw=1.10.0"


@dataclass
class Panel:
    kind: str
    note: str
    argv: list[str] | None = None  # the sample window's command line inside the hidden Shell; None: no picture
    png: str | None = None
    timeout: int = 20000  # ms to wait for its window
    log: str | None = None  # where the sample's stderr goes
    title: str = ""
    extra: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.title = self.title or TITLES[self.kind]


def _join(names: list[str], limit: int = 4) -> str:
    shown = ", ".join(names[:limit])
    return shown + (f" and {len(names) - limit} more" if len(names) > limit else "")


def _sample(css: Path, mode: str, theme: str, log: Path, python: str = sys.executable) -> list[str]:
    """The preview's own sample widgets (gui/preview.py) with `css`, errors to `log`."""
    return ["sh", "-c", 'exec "$@" 2>"$0"', str(log), python, "-m", "theme_unifier.gui.preview", str(css), mode,
            theme, "none"]


def _host_versions() -> str:
    try:
        import gi
        gi.require_version("Gtk", "4.0")
        gi.require_version("Adw", "1")
        from gi.repository import Adw, Gtk
    except (ImportError, ValueError):
        return ""
    return (f"GTK {Gtk.get_major_version()}.{Gtk.get_minor_version()}.{Gtk.get_micro_version()}, libadwaita "
            f"{Adw.get_major_version()}.{Adw.get_minor_version()}.{Adw.get_micro_version()}")


# --- libadwaita on this computer ---------------------------------------------------


def plan_libadwaita(tmp: Path, css: Path, mode: str, theme: str, authored: bool) -> Panel:
    versions = _host_versions()
    what = f"{theme}'s own GTK4 styles" if authored else f"{theme}'s colors"
    return Panel("libadwaita", f"Apps from your distribution's packages get {what}. "
                 f"Drawn by this computer's {versions or 'libadwaita'}.",
                 argv=_sample(css, mode, theme, tmp / "libadwaita.log"), log=str(tmp / "libadwaita.log"))


# --- Flatpak -------------------------------------------------------------------------


def _skipped_flatpaks() -> set[str]:
    """Apps the user turned off (theme-unifier flatpak remove), which Apply leaves alone."""
    try:
        return set(json.loads(Paths.default().manifest.read_text()).get("flatpak_skip", []))
    except (OSError, ValueError, AttributeError):
        return set()


def _branch_key(branch: str) -> tuple:
    return tuple(int(p) if p.isdigit() else -1 for p in re.split(r"[.-]", branch))


def pick_runtime(apps: list[tuple[str, str]]) -> tuple[str, list[str]] | None:
    """The GNOME runtime branch the most apps use (the newest on a tie), and those apps."""
    by_branch: dict[str, list[str]] = collections.defaultdict(list)
    for app, runtime in apps:
        parts = runtime.split("/")
        if parts[0] == GNOME_RUNTIME and len(parts) == 3:
            by_branch[parts[2]].append(app)
    if not by_branch:
        return None
    branch = max(by_branch, key=lambda b: (len(by_branch[b]), _branch_key(b)))
    return branch, sorted(by_branch[branch])


FLATPAK_SAMPLE = r"""
import runpy, sys
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gtk
v = lambda m: f"{m.get_major_version()}.{m.get_minor_version()}.{m.get_micro_version()}"
print(f"%s gtk={v(Gtk)} adw={v(Adw)}", file=sys.stderr, flush=True)
runpy.run_path(sys.argv[0].replace("sample.py", "preview.py"), run_name="__main__")
""" % VERSIONS


def plan_flatpak(tmp: Path, css: Path, mode: str, theme: str, authored: bool) -> Panel:
    if not shutil.which("flatpak"):
        return Panel("flatpak", "Flatpak isn't installed.")
    skipped = _skipped_flatpaks()
    installed = fp.installed_apps()
    apps = [(a, r) for a, r in installed if a not in skipped]
    if not apps:
        return Panel("flatpak", "No Flatpak apps are installed." if not installed else
                     "Every installed Flatpak app is turned off for theme-unifier, so Apply leaves them alone.")
    picked = pick_runtime(apps)
    gnome = [a for a, r in apps if r.startswith(GNOME_RUNTIME + "/")]
    others = len(apps) - len(gnome)
    if picked is None:
        return Panel("flatpak", f"None of your {len(apps)} Flatpak apps uses the GNOME runtime, so there is no "
                     "libadwaita app to show.")
    branch, users = picked
    share = tmp / "flatpak-share"
    share.mkdir()
    shutil.copyfile(Path(__file__).resolve().parent / "gui" / "preview.py", share / "preview.py")
    (share / "sample.py").write_text(FLATPAK_SAMPLE)
    if authored:  # the theme's whole gtk-4.0 folder: its gtk.css imports and loads files next to it
        shutil.copytree(css.parent, share / "theme")
        inside = share / "theme" / css.name
    else:
        shutil.copyfile(css, share / "app.css")
        inside = share / "app.css"
    log = tmp / "flatpak.log"
    argv = ["sh", "-c", 'exec "$@" 2>"$0"', str(log), "flatpak", "run", "--no-documents-portal",
            "--nosocket=x11", "--nosocket=fallback-x11", "--socket=wayland", "--device=dri",
            f"--filesystem={share}:ro", "--env=GTK_A11Y=none", "--env=NO_AT_BRIDGE=1",
            f"--env=THEME_UNIFIER_PREVIEW_SIZE={SAMPLE_SIZE}", "--command=python3",
            f"{GNOME_RUNTIME}//{branch}", str(share / "sample.py"), str(inside), mode, theme, "none"]
    what = f"{theme}'s own GTK4 styles" if authored else f"{theme}'s colors"
    note = (f"Apply gives {what} to {len(apps)} Flatpak app{'s' if len(apps) != 1 else ''}. "
            f"Drawn inside the GNOME {branch} runtime, which "
            + (f"{len(users)} of them use." if len(apps) > 1 else "it uses."))
    if len(gnome) > len(users):
        note += f" {len(gnome) - len(users)} use another GNOME runtime version."
    if others:
        note += f" {others} use KDE or freedesktop runtimes, not shown here."
    if skipped & {a for a, _ in installed}:
        note += f" Turned off, so left alone: {_join(sorted(skipped & {a for a, _ in installed}))}."
    return Panel("flatpak", note, argv=argv, timeout=40000, log=str(log), extra={"branch": branch})


def flatpak_versions(log: str | None) -> str:
    """'GTK 4.24.1, libadwaita 1.10.0' from the Flatpak sample's stderr, or ''."""
    try:
        text = Path(log).read_text(errors="replace") if log else ""
    except OSError:
        return ""
    m = re.search(VERSIONS + r" gtk=(\S+) adw=(\S+)", text)
    return f"GTK {m.group(1)}, libadwaita {m.group(2)}" if m else ""


# --- Snap ----------------------------------------------------------------------------


def snap_home() -> Path:
    return Path(os.environ.get("THEME_UNIFIER_SNAP_HOME") or Path.home() / "snap")


def linked_snaps(target: Path | None = None) -> list[str]:
    """Snaps whose own gtk-4.0/gtk.css is a link to the user's gtk.css (what their launcher makes)."""
    target = (target or config_home() / "gtk-4.0" / "gtk.css")
    names = []
    for link in sorted(snap_home().glob("*/current/.config/gtk-4.0/gtk.css")):
        try:
            if link.is_symlink() and Path(os.path.normpath(link.parent / os.readlink(link))) == target:
                names.append(link.parts[-5])
        except OSError:
            continue
    return names


def snap_gtk_versions(root: str = "/snap") -> dict[str, str]:
    """GTK4 in each GNOME content snap, from its library's file name: {'gnome-46-2404': '4.20.4'}."""
    found = {}
    for lib in sorted(glob.glob(os.path.join(root, "gnome-*", "current", "usr", "lib", "*", "libgtk-4.so.1.*.*"))):
        m = re.search(r"libgtk-4\.so\.1\.(\d+)\.(\d+)$", lib)  # 1.2000.4 is GTK 4.20.4
        if m:
            found[Path(lib).parts[len(Path(root).parts)]] = f"4.{int(m.group(1)) // 100}.{m.group(2)}"
    return found


def plan_snap(tmp: Path, css: Path, mode: str, theme: str, authored: bool) -> Panel:
    if not shutil.which("snap"):
        return Panel("snap", "Snap isn't installed.")
    snaps = linked_snaps()
    if authored:
        # Apply imports the authored copy by absolute path, which a confined snap can read
        note = (f"Snap apps read your gtk.css through a link their launcher makes, and the copy of {theme}'s "
                "own GTK4 styles it imports by absolute path, so they get those styles too.")
        # snapd's desktop rules: owner @{HOME}/.config/gtk-4.0/{*.css,**/*.css} r (checked 2026-11-01)
        if any(p.is_file() and p.suffix != ".css" for p in css.parent.rglob("*")):
            note += (" Confinement lets snaps read only the .css files there, so images the styles load from "
                     "files (such as check marks) are missing in snap apps.")
            # draw what a snap draws: the same stylesheets, without the files it can't open
            copy = tmp / "snap-theme"
            for path in css.parent.rglob("*.css"):
                if path.is_file():
                    dest = copy / path.relative_to(css.parent)
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(path, dest)
            css = copy / css.name
    else:
        note = f"Snap apps read your gtk.css through a link their launcher makes, so they get {theme}'s colors."
    note += f" Linked now: {_join(snaps)}." if snaps else " No snap has linked your gtk.css yet."
    gtks = snap_gtk_versions()
    note += (" Drawn by this computer's libadwaita; snaps bring their own" +
             (f" ({', '.join(f'{k}: GTK {v}' for k, v in gtks.items())})." if gtks else "."))
    return Panel("snap", note, argv=_sample(css, mode, theme, tmp / "snap.log"), log=str(tmp / "snap.log"))


# --- Qt ------------------------------------------------------------------------------


def qt_version(major: int) -> str:
    libs = sorted(glob.glob(f"/usr/lib/*/libQt{major}Core.so.{major}.*.*"))
    return libs[-1].rsplit(".so.", 1)[1] if libs else ""


def plan_qt(tmp: Path, home: Path, mode: str, theme: str) -> Panel:
    from .generate import generate
    from .loader import find_theme
    from .targets import qt as t_qt
    from .variants import discover
    reason = t_qt._skip_reason({})
    if reason:
        return Panel("qt", f"Apply leaves Qt apps alone here: {reason}.")
    have = t_qt.plugins()
    major = next((m for m in (6, 5) if have[m] and shutil.which(f"qt{m}ct")), None)
    if major is None:
        return Panel("qt", "Apply gives Qt apps the theme's colors, but there is no qt5ct or qt6ct window to show "
                     "them with.")
    gen = generate(discover(find_theme(theme)).palettes[mode], mode)
    folder = home / ".config" / f"qt{major}ct"
    (folder / "colors").mkdir(parents=True)
    scheme = folder / "colors" / t_qt.SCHEME
    scheme.write_text(qtcolors.qtct_scheme(gen))
    base = _read(t_qt.conf_path(major))  # the user's own settings (style, font, icons), with Apply's keys set
    keys = t_qt._qtct_keys(major, base)
    keys["Appearance"]["color_scheme_path"] = str(scheme)
    # QT_STYLE_OVERRIDE (set in the session) wins over qtNct's style for every Qt app. The window
    # gets that style through its config instead: with the variable set, qtNct shows a banner.
    override = t_qt.style_override()
    if override:
        keys["Appearance"]["style"] = override
    conf, _ = inikeys.set_keys(base, keys)
    (folder / f"qt{major}ct.conf").write_bytes(conf)
    style = inikeys.get(conf, "Appearance", "style") or "Fusion"
    if style.lower().startswith("kvantum") and (config_home() / "Kvantum").is_dir():
        shutil.copytree(config_home() / "Kvantum", home / ".config" / "Kvantum", symlinks=True)
    log = tmp / "qt.log"
    argv = ["sh", "-c", 'exec "$@" 2>"$0"', str(log), "env", "-u", "QT_STYLE_OVERRIDE",
            f"{t_qt.ENV}={t_qt.ENV_VALUE}", "QT_QPA_PLATFORM=wayland", f"qt{major}ct"]
    version = qt_version(major)
    note = (f"qt{major}ct's own window, a Qt {version or major} program, with the colors Apply gives Qt "
            "apps.")
    kvantum = style.lower().startswith("kvantum")
    name = t_qt.kvantum_theme() if kvantum else None
    drawer = f"the Kvantum theme {name}" if name else f"the {style} style"
    if override:
        note += f" Your session sets QT_STYLE_OVERRIDE={override}, so {drawer} draws every Qt app"
    else:
        note += f" {drawer[:1].upper() + drawer[1:]} draws the shapes"
    note += ", and can replace these colors with its own." if kvantum else "."
    if major == 6 and have[5]:
        note += " Qt5 apps get the same colors through qt5ct."
    elif major == 5:
        note += " Qt6 apps keep their default colors until qt6ct is installed."
    note += " KDE apps also get them through kdeglobals."
    if os.environ.get(t_qt.ENV) not in ("qt5ct", "qt6ct"):
        note += " Qt apps pick the colors up after you log out and back in once."
    return Panel("qt", note, argv=argv, log=str(log))


# --- The hidden Shell ------------------------------------------------------------------


def render(theme: str, mode: str, css: Path, out: Path, authored: bool = False,
           kinds: tuple[str, ...] = KINDS, size: str = "1280x800") -> list[Panel]:
    """One panel per kind, in `kinds` order; a panel's png is set when its picture was taken."""
    tmp = Path(tempfile.mkdtemp(prefix="theme-unifier-apps-preview-"))
    sockets = Path(tempfile.mkdtemp(prefix="tu-sock-", dir="/tmp" if os.access("/tmp", os.W_OK) else None))
    daemon = None
    try:
        home, run = tmp / "home", sockets / "run"
        settings = home / ".config" / "glib-2.0" / "settings"
        settings.mkdir(parents=True)
        run.mkdir(mode=0o700)
        if not authored:  # a copy: the sample window deletes a CSS file named theme-unifier-* on exit
            shutil.copyfile(css, tmp / "app.css")
            css = tmp / "app.css"
        planners = {
            "libadwaita": lambda: plan_libadwaita(tmp, css, mode, theme, authored),
            "flatpak": lambda: plan_flatpak(tmp, css, mode, theme, authored),
            "snap": lambda: plan_snap(tmp, css, mode, theme, authored),
            "qt": lambda: plan_qt(tmp, home, mode, theme),
        }
        panels = []
        for kind in kinds:
            try:
                panels.append(planners[kind]())
            except Exception as e:  # noqa: BLE001 - one kind failing must not hide the others
                panels.append(Panel(kind, f"No preview: {e}"))
        wanted = [p for p in panels if p.argv]
        for p in wanted:
            p.png = str(out / f"{p.kind}.png")
            Path(p.png).unlink(missing_ok=True)
        if not wanted:
            return panels
        for tool in ("gnome-shell", "dbus-run-session", "dbus-daemon"):
            if not shutil.which(tool):
                for p in wanted:
                    p.png, p.note = None, p.note + f" No picture: the preview needs `{tool}`."
                return panels
        if len(str(run / "wayland-0")) > SOCKET_PATH_MAX:
            for p in wanted:
                p.png, p.note = None, p.note + f" No picture: the folder {sockets} is too long for sockets."
            return panels

        scheme = "prefer-dark" if mode == "dark" else "default"
        (settings / "keyfile").write_text(_appearance(scheme))
        (tmp / "probe.js").write_text(PROBE)
        sysbus = sockets / "bus"
        daemon = subprocess.Popen(["dbus-daemon", "--session", f"--address=unix:path={sysbus}", "--nofork"],
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        apps = [{"kind": p.kind, "argv": p.argv, "png": p.png, "timeout": p.timeout} for p in wanted]
        env = dict(os.environ, HOME=str(home), XDG_CONFIG_HOME=str(home / ".config"),
                   XDG_DATA_HOME=str(home / ".local" / "share"), XDG_STATE_HOME=str(home / ".local" / "state"),
                   XDG_CACHE_HOME=str(home / ".cache"), XDG_RUNTIME_DIR=str(run), GSETTINGS_BACKEND="keyfile",
                   DBUS_SYSTEM_BUS_ADDRESS=f"unix:path={sysbus}", TU_STOP=str(tmp / "stop"),
                   TU_RESULTS=str(tmp / "results.json"), TU_APPS=json.dumps(apps), GDK_BACKEND="wayland",
                   THEME_UNIFIER_PREVIEW_SIZE=SAMPLE_SIZE)
        if (fp.user_dir() / "runtime").is_dir():  # a runtime may be in the user's installation
            env["FLATPAK_USER_DIR"] = str(fp.user_dir())
        for k in ("WAYLAND_DISPLAY", "DISPLAY", "DBUS_SESSION_BUS_ADDRESS", "QT_QPA_PLATFORMTHEME"):
            env.pop(k, None)
        env.update(NO_SIDE_SERVICES)
        pkg_parent = str(Path(__file__).resolve().parent.parent)  # the samples run this same copy
        env["PYTHONPATH"] = os.pathsep.join([pkg_parent, *filter(None, [env.get("PYTHONPATH")])])
        flags = ["--headless", "--wayland", "--no-x11", "--virtual-monitor", size]
        timeout = 30 + sum(p.timeout for p in wanted) / 1000 + 5 * len(wanted)
        while True:
            stderr = _run_shell(["dbus-run-session", "--", "gnome-shell", *flags,
                                 f"--automation-script={tmp / 'probe.js'}"], env, tmp / "stop", timeout=timeout)
            unknown = next((f for f in ("--no-x11", "--wayland") if f in flags and "Unknown option " + f in stderr),
                           None)
            if unknown is None:
                break
            flags.remove(unknown)  # newer Shells are Wayland-only and dropped these
        try:
            results = json.loads((tmp / "results.json").read_text())
        except (OSError, ValueError):
            results = {}
        for p in wanted:
            r = results.get(p.kind) or {}
            if p.kind == "flatpak":
                versions = flatpak_versions(p.log)
                if versions:
                    branch = p.extra["branch"]
                    p.note = p.note.replace(f"GNOME {branch} runtime", f"GNOME {branch} runtime ({versions})", 1)
            if not (r.get("ok") and Path(p.png).is_file()):
                p.png = None
                why = r.get("error") or (stderr.strip().splitlines() or ["the hidden Shell stopped early"])[-1]
                p.note += f" No picture: {why}."
                if os.environ.get("THEME_UNIFIER_DEBUG") and p.log and Path(p.log).exists():
                    sys.stderr.write(Path(p.log).read_text(errors="replace"))
        return panels
    finally:
        if daemon is not None:
            daemon.send_signal(signal.SIGTERM)
            daemon.wait(5)
        _unmount_below(sockets)
        _unmount_below(tmp)
        for _ in range(50):  # a Shell that is still stopping may write a last file or two
            shutil.rmtree(tmp, ignore_errors=True)
            shutil.rmtree(sockets, ignore_errors=True)
            if not tmp.exists() and not sockets.exists():
                break
            time.sleep(0.1)


def main() -> int:
    signal.signal(signal.SIGTERM, _on_term)  # the preview stops a render it no longer needs
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    theme, mode, css, out = args[:4]
    try:
        panels = render(theme, mode, Path(css), Path(out), authored="--authored" in sys.argv[1:])
    except Stop:
        return 1
    print(json.dumps({"panels": [{k: v for k, v in asdict(p).items() if k in ("kind", "title", "png", "note")}
                                 for p in panels]}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
