"""Command line entry point: `theme-unifier`."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from .analyzer import analyze
from .loader import find_theme, list_themes
from .generate import generate
from .palette import ROLES
from .variants import discover

from .host import EXIT_CONTRAST, EXIT_INVALID, EXIT_MODE_UNAVAILABLE, EXIT_PARTIAL  # noqa: E402


EXIT_HELP = """exit status:
  0  done (analyze: palette complete; check "sources" / source_integrity for import problems)
  1  error
  3  the theme has no palette for the requested light/dark mode (D2)
  4  contrast still failing after adjustment (generate prints the CSS anyway; apply refuses)
  5  conflict: something theme-unifier wrote was changed; nothing was changed
  6  unsafe target (symlink or non-UTF-8 gtk.css)
  7  another theme-unifier operation is running
  8  analyze: palette partial, some core colors derived or defaulted (preview and apply allowed)
  9  palette invalid, no window background read (preview only; apply refuses)
 10  unfinished: a desktop setting or the watcher failed, or an interrupted change is
     pending (dry run); the next command retries it, revert undoes it"""


def _swatch(css_hex: str) -> str:
    """A colored block for terminals that support 24-bit color."""
    h = css_hex.lstrip("#")[:6]
    if len(h) != 6 or not sys.stdout.isatty():
        return ""
    r, g, b = (int(h[i : i + 2], 16) for i in (0, 2, 4))
    return f"\033[48;2;{r};{g};{b}m    \033[0m "


def cmd_list(args: argparse.Namespace) -> int:
    for theme in list_themes():
        dark = " (has dark variant)" if theme.has_dark_variant else ""
        print(f"{theme.name}{dark}  {theme.path}")
    return 0


def cmd_analyze(args: argparse.Namespace) -> int:
    try:
        theme = find_theme(args.theme)
    except LookupError as e:
        print(e, file=sys.stderr)
        return 1
    pal = analyze(theme, dark=args.dark)
    code = {"complete": 0, "partial": EXIT_PARTIAL, "invalid": EXIT_INVALID}[pal.status]
    if args.output:
        pal.save(Path(args.output))
        print(f"Wrote {args.output}")
    if args.json:
        sys.stdout.write(pal.to_json())
        return code
    if not args.output or args.verbose:
        sheet = "gtk-dark.css" if pal.variant == "dark" else "gtk.css"
        print(f"{pal.theme} ({sheet}, {'dark' if pal.is_dark else 'light'} theme)")
        print(f"  status: {pal.status}" + (f" (guessed: {', '.join(pal.guessed_core)})" if pal.guessed_core else ""))
        print(f"  sources: {pal.source_integrity}"
              + (f" ({len(pal.source_problems)} problem(s), see warnings)" if pal.source_problems else ""))
        width = max(len(r) for r in ROLES)
        for role, entry in pal.colors.items():
            value = entry.color.to_css()
            conf = {"high": " ", "medium": "~", "low": "?"}[entry.confidence]
            print(f"  {_swatch(value)}{role:<{width}}  {value:<26} {conf} {entry.source}")
            if args.verbose:
                if entry.origin:
                    print(f"  {'':<{width}}    from {entry.origin}")
                for note in entry.notes:
                    print(f"  {'':<{width}}    - {note}")
        for w in pal.warnings:
            print(f"  warning: {w}")
    return code


def cmd_variants(args: argparse.Namespace) -> int:
    try:
        vs = discover(find_theme(args.theme))
    except LookupError as e:
        print(e, file=sys.stderr)
        return 1
    print(f"{vs.theme}: {vs.category}")
    for mode, pal in vs.palettes.items():
        print(f"  {mode:<5} from {pal.stylesheet}")
    for s in vs.skipped:
        print(f"  skipped {s}")
    for mode, names in vs.suggestions.items():
        print(f"  no {mode} palette; same-family themes that have one (not used): {', '.join(names)}")
    return 0


def cmd_generate(args: argparse.Namespace) -> int:
    """Print or write libadwaita CSS. Never touches anything when the mode is missing."""
    try:
        vs = discover(find_theme(args.theme))
    except LookupError as e:
        print(e, file=sys.stderr)
        return 1
    if args.mode not in vs.palettes:
        print(vs.missing_mode_message(args.mode), file=sys.stderr)
        return EXIT_MODE_UNAVAILABLE
    pal = vs.palettes[args.mode]
    gen = generate(pal, args.mode)
    css = gen.css()
    if args.output:
        Path(args.output).write_text(css, encoding="utf-8")
        print(f"Wrote {args.output}", file=sys.stderr)
    else:
        sys.stdout.write(css)
    out = sys.stderr if not args.output else sys.stdout
    if gen.disclosed:
        print(f"{len(gen.disclosed)} colors were not read from the theme as-is:", file=out)
        for i in gen.disclosed:
            why = i.reason or f"{i.confidence} confidence"
            print(f"  {i.name}: {i.color.to_css()} from {i.role or 'computed'} ({i.source}); {why}", file=out)
    print(f"Left at libadwaita defaults: {', '.join(gen.not_overridden)}", file=out)
    for fg, bg, r, need in gen.unresolved:
        print(f"Still below {need}:1 after adjustment: {fg} on {bg} ({r}:1)", file=out)
    # The CSS is written either way, for previewing; the status says whether apply would take it.
    if pal.status == "invalid":
        print("Palette status: invalid (no window background read); apply would refuse it.", file=out)
        return EXIT_INVALID
    if gen.unresolved:
        print("Apply would refuse this palette until the contrast failures above are resolved.", file=out)
        return EXIT_CONTRAST
    return 0


def _host_op(fn, *a, **kw) -> int:
    from .host import HostError

    try:
        lines = fn(*a, **kw)
    except HostError as e:
        print(e, file=sys.stderr)
        return e.code
    for line in lines:
        print(line)
    return 0


def cmd_apply(args: argparse.Namespace) -> int:
    from . import ops

    from . import settings

    # Options left off the command line come from GSettings, else the defaults
    opts = settings.resolve({name: getattr(args, name) for name in (*settings.CHOICES, "watcher")})
    mode = opts.pop("mode")
    return _host_op(ops.apply, args.theme, mode, force=args.force, dry_run=args.dry_run, **opts)


def cmd_revert(args: argparse.Namespace) -> int:
    from . import ops

    return _host_op(ops.revert, force=args.force)


def cmd_status(args: argparse.Namespace) -> int:
    from . import ops

    return _host_op(ops.status)


def cmd_doctor(args: argparse.Namespace) -> int:
    from . import ops

    return _host_op(ops.doctor, discard_journal=args.discard_journal)


def cmd_sync(args: argparse.Namespace) -> int:
    from . import ops

    return _host_op(ops.sync)


def cmd_flatpak(args: argparse.Namespace) -> int:
    from . import ops

    if args.action == "add":
        return _host_op(ops.flatpak_add, args.apps)
    if args.action == "remove":
        return _host_op(ops.flatpak_remove, args.apps, force=args.force)
    return _host_op(ops.flatpak_list)


def cmd_watch(args: argparse.Namespace) -> int:
    from . import ops

    return ops.watch()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="theme-unifier", description=__doc__, epilog=EXIT_HELP,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("list", help="list installed GTK3 themes")
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("analyze", help="extract a theme's palette")
    p.add_argument("theme", help="theme name or path to a theme folder")
    p.add_argument("--dark", action="store_true", help="use the theme's gtk-dark.css")
    p.add_argument("-o", "--output", help="write the palette JSON to this file")
    p.add_argument("--json", action="store_true", help="print the palette JSON")
    p.add_argument("-v", "--verbose", action="store_true")
    p.set_defaults(func=cmd_analyze)

    p = sub.add_parser("variants", help="show which light/dark palettes a theme provides")
    p.add_argument("theme")
    p.set_defaults(func=cmd_variants)

    p = sub.add_parser("generate", help="generate libadwaita CSS for one mode")
    p.add_argument("theme")
    p.add_argument("--mode", choices=["light", "dark"], required=True)
    p.add_argument("-o", "--output", help="write CSS to this file instead of stdout")
    p.set_defaults(func=cmd_generate)

    p = sub.add_parser("apply", help="apply the theme's styles and colors to supported apps and the Shell",
                       description="Options left off the command line come from GSettings "
                                   "(io.github.phlthydelphya.ThemeUnifier) when its schema is installed, "
                                   "else the defaults shown.")
    p.add_argument("theme")
    p.add_argument("--mode", choices=["light", "dark", "auto"], default=None,
                   help="auto (default) follows the system color scheme")
    p.add_argument("--force", action="store_true", help="replace a managed region that was edited by hand")
    p.add_argument("--dry-run", action="store_true",
                   help="list every file, setting, extension, service and Flatpak app apply would change, "
                        "and change nothing")
    p.add_argument("--no-watcher", dest="watcher", action="store_const", const=False, default=None,
                   help="don't install the high-contrast/scheme watcher")
    p.add_argument("--gtk4", choices=["auto", "generated", "off"], default=None,
                   help="plain GTK4 apps: auto = generate a GTK4 theme only if the theme has none (default); "
                        "generated = also replace the theme's own GTK4 styles; off = leave them alone")
    p.add_argument("--libadwaita", dest="adwaita", choices=["auto", "palette"], default=None,
                   help="libadwaita: auto uses the theme's own GTK4 styles when available; palette uses colors only")
    p.add_argument("--shell", choices=["auto", "generated", "off"], default=None,
                   help="GNOME Shell (needs the User Themes extension): auto uses the theme's own Shell theme "
                        "when it ships one and generates one otherwise; generated always builds one from your "
                        "Shell's own stylesheet; off leaves the Shell alone")
    p.add_argument("--buttons", choices=["auto", "off"], default=None,
                   help="window-button layout: auto follows theme metadata when available; off leaves it alone")
    p.add_argument("--gtk3", choices=["set", "off"], default=None,
                   help="set (default) switches the session's GTK theme, used by GTK3 apps, to this theme; "
                        "revert sets it back. off leaves it alone")
    p.add_argument("--accent", choices=["set", "off"], default=None,
                   help="set: change the session's accent color to the libadwaita accent nearest to the "
                        "theme's accent; revert sets it back. off (default) leaves it alone, for desktops where "
                        "something else owns the accent")
    p.add_argument("--apps", choices=["auto", "off"], default=None,
                   help="apps with their own theme option (teams-for-linux): auto (default) gives an installed app "
                        "the palette through that option, using files theme-unifier owns; off leaves them alone")
    p.add_argument("--flatpak", choices=["all", "chosen"], default=None,
                   help="all (default) lets every installed Flatpak app read the palette, except apps you "
                        "turned off with `flatpak remove`; chosen only keeps the apps already enabled")
    p.add_argument("--qt", choices=["auto", "off"], default=None,
                   help="KDE/Qt apps: auto (default) writes a qt5ct/qt6ct palette and KDE's colors when qt5ct "
                        "or qt6ct is installed, and sets QT_QPA_PLATFORMTHEME=qt5ct from your next login; "
                        "off leaves Qt apps alone")
    p.set_defaults(func=cmd_apply)

    p = sub.add_parser("revert", help="remove exactly what apply added")
    p.add_argument("--force", action="store_true", help="remove the region even if it was edited")
    p.set_defaults(func=cmd_revert)

    p = sub.add_parser("status", help="show what is applied and which apps need a restart")
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("doctor", help="finish or roll back an interrupted change, check markers")
    p.add_argument("--discard-journal", action="store_true",
                   help="drop an interrupted-change record that can't be resolved automatically")
    p.set_defaults(func=cmd_doctor)

    p = sub.add_parser("sync", help="apply the watcher's rules once (high contrast, color scheme)")
    p.set_defaults(func=cmd_sync)

    p = sub.add_parser("flatpak", help="let chosen Flatpak apps read the managed gtk.css (per app)")
    fsub = p.add_subparsers(dest="action", required=True)
    f = fsub.add_parser("add", help="grant read-only access to ~/.config/gtk-4.0 via a Flatpak override")
    f.add_argument("apps", nargs="+", metavar="APP_ID")
    f = fsub.add_parser("remove", help="take out only the override entry theme-unifier added")
    f.add_argument("apps", nargs="+", metavar="APP_ID")
    f.add_argument("--force", action="store_true", help="forget an app whose entry was changed by someone else")
    fsub.add_parser("list", help="installed Flatpak apps and which are enabled")
    p.set_defaults(func=cmd_flatpak)

    p = sub.add_parser("watch", help="run the watcher in the foreground")
    p.set_defaults(func=cmd_watch)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
