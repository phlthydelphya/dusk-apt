"""Flatpak apps (milestone 5): per-app override entries."""

from __future__ import annotations

from pathlib import Path

from .. import flatpak as fp
from ..host import HostError, Manifest, _read, missing_dirs
from . import qt

def kde_wanted(m: Manifest) -> bool:
    """KDE apps on the KDE runtime get the KDE platform theme only when the Qt
    part wrote kdeglobals, which is what that theme reads (PLAN.md 11)."""
    return str(qt.kdeglobals_path()) in m.qt.get("keys", {})


def kde_app(record: dict) -> bool:
    return fp.KDE_RUNTIME in str(record.get("runtime") or "")


def _add_kde(app: str, old: dict | None, current, out: list[str]) -> tuple[object, bool, dict]:
    """kdeglobals access and the KDE_ENV entries, planned on `current`. On a
    refusal nothing of it is planned, and the old record stays for revert."""
    old = old or {}
    cur, changed = current, False
    try:
        kg = fp.plan_add(app, old.get("kdeglobals"), fp.KDEGLOBALS, current=cur)
        if kg.changed:
            cur, changed = kg.after, True
        env = {}
        for key, value in fp.KDE_ENV.items():
            ev = fp.plan_env_add(app, old.get("env", {}).get(key), key, value, current=cur)
            if ev.changed:
                cur, changed = ev.after, True
            env[key] = ev.record
    except HostError as e:
        out.append(f"{app}: KDE colors not added. {e}")
        return current, False, old or {"skipped": str(e)}
    return cur, changed, {"kdeglobals": kg.record, "env": env}


def _remove_parts(app: str, rec: dict, force: bool, current, out: list[str]) -> tuple[object, bool, list[str]]:
    """Take out the KDE entries and the themes entry (each one a conflict is
    reported and left), before the gtk-4.0 entry goes."""
    cur, changed, notes = current, False, []
    kde = rec.get("kde") or {}
    steps = [(f"{key} entry", lambda r, c: fp.plan_env_remove(app, r, force, current=c), r)
             for key, r in reversed(list(kde.get("env", {}).items()))]
    if kde.get("kdeglobals"):
        steps.append(("kdeglobals access", lambda r, c: fp.plan_remove(app, r, force, current=c), kde["kdeglobals"]))
    if rec.get("themes"):
        steps.append(("GTK3 theme access", lambda r, c: fp.plan_remove(app, r, force, current=c), rec["themes"]))
    for what, remove, r in steps:
        try:
            ch = remove(r, cur)
        except HostError as e:
            out.append(f"{app}: {what} left in place. {e}")
            continue
        if ch.changed:
            cur, changed = ch.after, True
            notes.append(what)
    return cur, changed, notes


def plan_add(app: str, rec: dict | None, out: list[str], kde: bool = False) -> fp.Change:
    """The entries for one app: gtk-4.0 (libadwaita/GTK4 palette, required),
    themes (so GTK3 apps can see the theme; skipped with a note if denied) and,
    with `kde`, for an app on the KDE runtime, kdeglobals access and the KDE
    platform theme (skipped with a note if refused)."""
    ch = fp.plan_add(app, rec, fp.TARGET)
    ch.record = dict(ch.record)
    cur, changed = (ch.after, True) if ch.changed else (fp._DISK, False)
    try:
        th = fp.plan_add(app, (rec or {}).get("themes"), fp.THEMES, current=cur)
    except HostError as e:
        out.append(f"{app}: GTK3 theme access not added. {e}")
        th = None
    ch.record["themes"] = th.record if th else None
    if th and th.changed:
        cur, changed = th.after, True
    old_kde = (rec or {}).get("kde")
    if kde and kde_app(ch.record):
        cur, kde_changed, ch.record["kde"] = _add_kde(app, old_kde, cur, out)
        changed = changed or kde_changed
        if kde_changed:
            ch.note += " Also set the KDE platform theme and kdeglobals access (KDE colors)."
    elif old_kde:
        cur, kde_changed, _ = _remove_parts(app, {"kde": old_kde}, False, cur, out)
        changed = changed or kde_changed
        ch.record.pop("kde", None)
    if changed:
        ch.after, ch.changed = (None if cur is fp._DISK else cur), True
    return ch


def plan_remove(app: str, rec: dict, force: bool, out: list[str]) -> fp.Change:
    """Take out the KDE and themes entries, then the gtk-4.0 one (raises on a
    gtk-4.0 conflict)."""
    current, changed, notes = _remove_parts(app, rec, force, fp._DISK, out)
    ch = fp.plan_remove(app, rec, force, current=current)
    if not ch.changed and changed:
        ch.after, ch.changed = current, True
    if notes:
        ch.note += f" Also removed theme-unifier's {', '.join(notes)}."
    return ch


def add_into(m: Manifest, apps: list[str], out: list[str], strict: bool
                      ) -> tuple[dict[Path, bytes | None], list[Path], bool]:
    """Plan overrides for `apps` into m.flatpak. With strict=False an app that
    can't be enabled (a deny, a hand-edited file) is reported and skipped."""
    extra: dict[Path, bytes | None] = {}
    new_dirs: list[Path] = []
    changed = False
    for app in dict.fromkeys(apps):
        try:
            ch = plan_add(app, m.flatpak.get(app), out, kde_wanted(m))
        except HostError as e:
            if strict:
                raise
            out.append(f"{app}: skipped. {e}")
            continue
        if ch.changed:
            extra[ch.path] = ch.after
            dirs = [d for d in missing_dirs(ch.path) if d not in new_dirs]
            new_dirs += dirs
            ch.record["dirs"] = [str(d) for d in dirs]
            changed = True
        m.flatpak[ch.app] = ch.record
        if app in m.flatpak_skip:
            m.flatpak_skip.remove(app)
        if strict:
            out.append(ch.note)
    return extra, new_dirs, changed


def status(m: Manifest) -> list[str]:
    if not m.flatpak:
        return ["Flatpak apps: none enabled (`theme-unifier flatpak add APP_ID`)."]
    out = ["Flatpak apps:"]
    for app, r in m.flatpak.items():
        if r.get("added"):
            state = "intact" if r["entry"] in fp.filesystems(_read(Path(r["override"]))) else "entry gone (conflict)"
            how = f"access added by theme-unifier, {state}"
        else:
            how = f"already had access ({r.get('why')})"
        out.append(f"  {app}: {how}; runtime {r.get('runtime') or 'unknown'}")
        kde = r.get("kde") or {}
        if kde.get("env"):
            data = _read(fp.override_path(app))
            ours = [k for k, e in kde["env"].items() if e.get("added")]
            gone = [k for k in ours if fp.env_value(data, k) != kde["env"][k]["value"]]
            out.append(f"    KDE colors: platform theme {'set by theme-unifier' if ours else 'left as it was'}"
                       + (f", changed since: {', '.join(gone)}" if gone else "") + ".")
        elif kde.get("skipped"):
            out.append(f"    KDE colors: not added ({kde['skipped']})")
    return out
