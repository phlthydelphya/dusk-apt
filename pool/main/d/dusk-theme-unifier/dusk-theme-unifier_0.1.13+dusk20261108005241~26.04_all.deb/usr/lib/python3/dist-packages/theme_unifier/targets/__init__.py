"""Planning for each kind of target an apply touches. Each module works out
files and actions for one Host.commit (host.py); none of them changes the
desktop itself. ops.py puts the plans together and commits them.
"""
