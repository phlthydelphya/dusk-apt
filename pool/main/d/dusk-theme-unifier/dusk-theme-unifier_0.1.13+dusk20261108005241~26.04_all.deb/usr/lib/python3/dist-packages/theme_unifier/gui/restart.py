"""Restarting the apps that still show the old theme.

An app is asked to quit through its own `quit` action (org.gtk.Actions over
D-Bus), the same as choosing Quit in it, so it can ask to save first. When it
has quit, it is started again from its desktop file. Nothing is ever killed:
an app that doesn't quit within the timeout is left running.

Some apps are only listed, for the user to restart: terminals (quitting one
closes its sessions), apps without a desktop file or a quit action, and this
window itself.
"""

from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass
from pathlib import Path

import gi

gi.require_version("Gio", "2.0")
from gi.repository import Gio, GLib  # noqa: E402

try:  # GLib 2.86 moved it to GioUnix; Ubuntu 24.04 (GLib 2.80) only has Gio's
    gi.require_version("GioUnix", "2.0")
    from gi.repository import GioUnix  # noqa: E402
    DesktopAppInfo = GioUnix.DesktopAppInfo
except (ValueError, ImportError):
    DesktopAppInfo = Gio.DesktopAppInfo

from .. import session  # noqa: E402

# Units apps run in: app-gnome-<desktop id>-<pid>.scope and app-flatpak-<app id>-<n>.scope
# (started by GNOME Shell or Flatpak), dbus-:1.<n>-<app id>@<n>.service (started over D-Bus;
# the app ID is then also the desktop ID). systemd escapes "-" in the id as \x2d.
_SCOPE = re.compile(r"app-(?:gnome|flatpak)-(.+)-\d+\.scope$|dbus-:[\d.]+-(.+)@\d+\.service$")
TIMEOUT = 10.0  # seconds an app gets to quit (it may be asking to save)


@dataclass
class Target:
    pid: int
    start: float
    name: str  # what the user sees
    desktop_id: str | None = None
    bus_name: str | None = None  # the app's D-Bus name, which takes the quit action
    reason: str | None = None  # why it can't be restarted from here

    @property
    def restartable(self) -> bool:
        return self.reason is None


def scope_id(cgroup: str) -> str | None:
    """The desktop or app ID in an app's systemd scope, from /proc/PID/cgroup text."""
    lines = cgroup.strip().splitlines()
    if not lines:
        return None
    m = _SCOPE.match(lines[-1].rsplit("/", 1)[-1])
    if not m:
        return None
    return re.sub(r"\\x([0-9a-fA-F]{2})", lambda e: chr(int(e.group(1), 16)), m.group(1) or m.group(2))


def service_unit(cgroup: str) -> str | None:
    """A plain systemd user service the process runs in (started at login, like
    gnome-software.service), not an app unit. Reopening one from its desktop file
    would turn a background service into a window."""
    lines = cgroup.strip().splitlines()
    unit = lines[-1].rsplit("/", 1)[-1] if lines else ""
    return unit if unit.endswith(".service") and not _SCOPE.match(unit) else None


def _desktop_id(pid: int) -> str | None:
    try:
        found = scope_id(Path(f"/proc/{pid}/cgroup").read_text())
    except OSError:
        found = None
    if found:
        return found if found.endswith(".desktop") else f"{found}.desktop"
    try:
        env = Path(f"/proc/{pid}/environ").read_bytes().split(b"\0")
    except OSError:
        return None
    launched = next((e for e in env if e.startswith(b"GIO_LAUNCHED_DESKTOP_FILE=")), None)
    return os.path.basename(launched.split(b"=", 1)[1].decode()) if launched else None


def _object_path(bus_name: str) -> str:
    return "/" + bus_name.replace(".", "/").replace("-", "_")


def has_quit(bus: Gio.DBusConnection, bus_name: str) -> bool:
    try:
        actions = bus.call_sync(bus_name, _object_path(bus_name), "org.gtk.Actions", "List", None,
                                GLib.VariantType("(as)"), Gio.DBusCallFlags.NONE, 2000, None).unpack()[0]
    except GLib.Error:
        return False
    return "quit" in actions


def names_by_pid(bus: Gio.DBusConnection) -> dict[int, list[str]]:
    """Well-known D-Bus names on the session bus, by the pid that owns them."""
    owners: dict[int, list[str]] = {}
    names = bus.call_sync("org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus", "ListNames",
                          None, GLib.VariantType("(as)"), Gio.DBusCallFlags.NONE, 2000, None).unpack()[0]
    for name in names:
        if name.startswith((":", "org.freedesktop.")):
            continue
        try:
            pid = bus.call_sync("org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus",
                                "GetConnectionUnixProcessID", GLib.Variant("(s)", (name,)),
                                GLib.VariantType("(u)"), Gio.DBusCallFlags.NONE, 2000, None).unpack()[0]
        except GLib.Error:
            continue
        owners.setdefault(pid, []).append(name)
    return owners


def describe(entry: dict, owners: dict[int, list[str]], quits, find_info=DesktopAppInfo.new) -> Target | None:
    """What can be done for one entry of the restart list (pid, start, name).
    `quits(bus_name)` says whether that name takes a quit action. None for this
    process itself."""
    pid = entry["pid"]
    if pid == os.getpid():
        return None
    t = Target(pid, entry["start"], entry["name"])
    try:
        unit = service_unit(Path(f"/proc/{pid}/cgroup").read_text())
    except OSError:
        unit = None
    if unit:
        t.reason = f"A background service: restart it with systemctl --user restart {unit}"
        return t

    def lookup(desktop_id):
        try:
            return find_info(desktop_id)
        except TypeError:  # PyGObject raises for a missing desktop file on some versions
            return None

    t.desktop_id = _desktop_id(pid)
    info = lookup(t.desktop_id) if t.desktop_id else None
    if info is None:
        # No unit or launch record (started over D-Bus outside systemd): a D-Bus-activatable
        # app owns a name equal to its desktop ID.
        for name in owners.get(pid, []):
            info = lookup(f"{name}.desktop") if quits(name) else None
            if info is not None:
                t.desktop_id = f"{name}.desktop"
                break
    if info is None:
        t.reason = "No app launcher found for it. Close and reopen it yourself"
        return t
    t.name = info.get_name() or t.name
    if "TerminalEmulator" in (info.get_categories() or ""):
        t.reason = "A terminal: quitting it closes its sessions. Close and reopen it yourself"
        return t
    flatpak_id = t.desktop_id.removesuffix(".desktop")
    if Path(f"/proc/{pid}/root/.flatpak-info").exists():
        candidates = [flatpak_id]  # sandboxed apps can only own names under their app ID
    else:
        candidates = owners.get(pid, [])
    t.bus_name = next((n for n in candidates if quits(n)), None)
    if t.bus_name is None:
        t.reason = "It has no Quit action to ask. Close and reopen it yourself"
    return t


def targets(entries: list[dict], bus: Gio.DBusConnection | None = None) -> list[Target]:
    bus = bus or Gio.bus_get_sync(Gio.BusType.SESSION)
    owners = names_by_pid(bus)
    found = (describe(e, owners, lambda n: has_quit(bus, n)) for e in entries)
    return [t for t in found if t is not None]


def quit_and_wait(t: Target, bus: Gio.DBusConnection | None = None, timeout: float = TIMEOUT) -> str | None:
    """Ask the app to quit and wait for it to go. None when it has quit, else why not.
    Safe to run off the main thread."""
    bus = bus or Gio.bus_get_sync(Gio.BusType.SESSION)
    try:
        bus.call_sync(t.bus_name, _object_path(t.bus_name), "org.gtk.Actions", "Activate",
                      GLib.Variant("(sava{sv})", ("quit", [], {})), None, Gio.DBusCallFlags.NONE, 5000, None)
    except GLib.Error as e:
        return f"{t.name}: couldn't ask it to quit ({e.message})"
    end = time.monotonic() + timeout
    entry = {"pid": t.pid, "start": t.start}
    while session.still_running([entry]):
        if time.monotonic() > end:
            return f"{t.name} didn't quit (it may be asking to save), so it was left running"
        time.sleep(0.2)
    return None


def launch(t: Target, context: Gio.AppLaunchContext | None = None) -> str | None:
    """Start the app again from its desktop file. None when it started, else why not.
    Call on the main thread."""
    try:
        info = DesktopAppInfo.new(t.desktop_id)
        if info is not None and info.launch([], context):
            return None
    except (GLib.Error, TypeError) as e:
        return f"{t.name} quit, but couldn't be started again ({e}). Open it yourself"
    return f"{t.name} quit, but couldn't be started again. Open it yourself"
