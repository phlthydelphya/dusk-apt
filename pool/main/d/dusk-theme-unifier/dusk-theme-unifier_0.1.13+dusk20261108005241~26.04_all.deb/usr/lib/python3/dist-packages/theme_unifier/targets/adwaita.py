"""Plan a reversible copy of a theme's authored GTK4 styles for libadwaita."""

from __future__ import annotations

import re
from pathlib import Path

from .. import gtk4theme
from ..host import HostError, config_home
from ..loader import find_theme

_ACCENT_DEFINE = re.compile(r"(?im)^[ \t]*@define-color[ \t]+accent_bg_color[ \t]+(#[0-9a-f]{6})[ \t]*;[ \t]*$")
_STRINGS_COMMENTS = re.compile(r'''/\*.*?\*/|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*' ''', re.S | re.X)
_PROTECTED = re.compile(r'''(/\*.*?\*/|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|@define-color\s+[^;]+;|--accent-bg-color\s*:[^;{}]*;)''', re.I | re.S)


def _dynamic_declarations(css: str, literal: re.Pattern, rgba: re.Pattern) -> str:
    """Add dynamic declarations after literal fallbacks, preserving older GTK."""
    result, start, depth, parens, i = [], 0, 0, 0, 0
    while i < len(css):
        if css.startswith("/*", i):
            end = css.find("*/", i + 2)
            i = len(css) if end < 0 else end + 2
            continue
        if css[i] in "\"'":
            quote = css[i]
            i += 1
            while i < len(css):
                if css[i] == "\\":
                    i += 2
                elif css[i] == quote:
                    i += 1
                    break
                else:
                    i += 1
            continue
        ch = css[i]
        if ch == "(":
            parens += 1
        elif ch == ")":
            parens = max(0, parens - 1)
        elif parens == 0 and ch in "{};":
            part = css[start:i]
            result.append(part + ch)
            if ch == ";" and depth:
                match = re.match(r"(\s*[-\w]+\s*:\s*)(.*)\Z", part, re.S)
                if match and not match.group(1).strip().startswith("--accent-bg-color"):
                    pieces = _PROTECTED.split(match.group(2))
                    for j in range(0, len(pieces), 2):
                        pieces[j] = rgba.sub(r"alpha(var(--accent-bg-color),\1)", pieces[j])
                        pieces[j] = literal.sub("var(--accent-bg-color)", pieces[j])
                    changed = "".join(pieces)
                    if changed != match.group(2):
                        result.append(match.group(1) + changed + ";")
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth = max(0, depth - 1)
            start = i + 1
        i += 1
    result.append(css[start:])
    return "".join(result)


def adaptive_accent(data: bytes) -> tuple[bytes, bool]:
    """Replace a theme's explicit accent literal with libadwaita's system accent.

    Only a simple, unambiguous named hex accent is adapted; other styles are
    kept intact. CSS strings, comments and other named colors are untouched.
    """
    try:
        css = data.decode("utf-8")
    except UnicodeError:
        return data, False
    protected = [(m.start(), m.end()) for m in _STRINGS_COMMENTS.finditer(css)]
    outside = lambda m: not any(start <= m.start() < end for start, end in protected)
    matches = [m for m in _ACCENT_DEFINE.finditer(css) if outside(m)]
    if len(matches) != 1:
        return data, False
    accent = matches[0].group(1)
    text_color = re.compile(r"(?im)^[ \t]*@define-color[ \t]+accent_color[ \t]+" + re.escape(accent) +
                            r"[ \t]*;[ \t]*$")
    changes = [(matches[0], "/* theme-unifier: use the system accent */")]
    changes += [(m, "/* theme-unifier: use the system accent text color */")
                for m in text_color.finditer(css) if outside(m)]
    for match, replacement in sorted(changes, key=lambda item: item[0].start(), reverse=True):
        css = css[:match.start()] + replacement + css[match.end():]
    rgb = tuple(int(accent[i:i + 2], 16) for i in (1, 3, 5))
    rgba = re.compile(r"rgba\(\s*" + r"\s*,\s*".join(map(str, rgb)) +
                      r"\s*,\s*(0(?:\.\d+)?|1(?:\.0+)?)\s*\)", re.I)
    literal = re.compile(re.escape(accent) + r"(?![\w-])", re.I)
    return _dynamic_declarations(css, literal, rgba).encode("utf-8"), True


SWATCH_CSS = """\n/* Keep GNOME Settings' per-color accent swatches distinct. */
preferencesgroup button.accent-button,
preferencesgroup button.accent-button:hover,
preferencesgroup button.accent-button:active,
preferencesgroup button.accent-button:checked,
preferencesgroup button.accent-button:checked:hover {
  background: var(--accent-bg-color);
}
preferencesgroup button.accent-button:checked,
preferencesgroup button.accent-button:checked:hover {
  box-shadow: 0 0 0 3px alpha(var(--accent-bg-color), 0.5);
}
"""


def system_accent_palette(css: str) -> str:
    """Leave the system accent unpinned when applying generated colors."""
    if not gtk4theme.css_variables():
        return css
    css = re.sub(r"(?m)^@define-color\s+(?:accent_bg_color|accent_fg_color|accent_color)\s+[^\n]*\n", "", css)
    css = re.sub(r"(?m)^\s*--accent-color\s*:[^\n]*\n", "", css)
    return css + SWATCH_CSS


def plan(theme_ref: str, choice: str) -> tuple[dict[Path, bytes], dict, str]:
    if choice == "palette":
        return {}, {"choice": choice, "kind": "palette"}, "Libadwaita apps: generated colors, with system accent."
    theme = find_theme(theme_ref)
    folder = gtk4theme.own_gtk4_dir(theme.name)
    if folder is None:
        return {}, {"choice": choice, "kind": "palette"}, (
            "Libadwaita apps: theme has no authored GTK4 styles; using generated colors and the system accent.")
    target = config_home() / "gtk-4.0" / "theme-unifier-authored"
    try:
        if any(p.is_symlink() and p.is_dir() for p in folder.rglob("*")):
            raise HostError(f"{folder} contains a linked directory; authored GTK4 styles cannot be copied safely. "
                            "Choose Colors only, or use --libadwaita palette.")
        files = {target / p.relative_to(folder): p.read_bytes() for p in sorted(folder.rglob("*")) if p.is_file()}
    except OSError as e:
        raise HostError(f"Could not read {folder}: {e}. Nothing was changed.") from e
    if target / "gtk.css" not in files:
        raise HostError(f"{folder} has no readable gtk.css. Nothing was changed.")
    if (target / "gtk.gresource") in files:
        raise HostError(f"{folder} uses a GTK resource bundle, which cannot yet be applied safely to libadwaita. "
                        "Choose Colors only, or use --libadwaita palette.")
    adapted = False
    if gtk4theme.css_variables():
        for name in ("gtk.css", "gtk-dark.css"):
            path = target / name
            if path in files:
                files[path], changed = adaptive_accent(files[path])
                adapted = adapted or changed
    for path in files:
        for parent in (path, *path.parents):
            if parent == target.parent:
                break
            if parent.is_symlink():
                raise HostError(f"{parent} is a symlink; authored GTK4 files were not written.")
    dark = "gtk-dark.css" if target / "gtk-dark.css" in files else "gtk.css"
    return files, {"choice": choice, "kind": "authored", "light": "gtk.css", "dark": dark}, (
        f"Libadwaita apps: use {theme.name}'s authored GTK4 styles copied from {folder}; "
        "apps must restart and some styles may not work with their GTK version." +
        (" Common accent colors follow GNOME Settings." if adapted else
         " Accent behavior depends on the theme."))


def stylesheet(rec: dict, mode: str, folder: Path) -> str:
    """The managed region's CSS for authored styles: an import of the copy in `folder`.

    The import names the file by absolute file URL. A confined snap reads
    gtk.css through a link in its own config folder, and GTK resolves a
    relative @import next to that link, where the copy isn't. The theme's own
    url()s still resolve next to the imported file. Installs written with the
    older relative line stay recognized: the manifest keeps the exact region
    text, and the next apply or light/dark switch rewrites it in this form.
    """
    uri = (folder.absolute() / rec[mode]).as_uri()  # percent-encodes spaces and quotes
    return f'@import url("{uri}");\n' + (SWATCH_CSS if gtk4theme.css_variables() else "")
