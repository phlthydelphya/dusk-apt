"""What the desktop session is doing: color scheme, high contrast, and which
libadwaita apps are running (for the restart notice in D3).

Settings are read with the `gsettings` command, so this works without
PyGObject. On GNOME these keys are what xdg-desktop-portal-gnome reports to
libadwaita as color-scheme and contrast. Other desktops may use other
sources; that is an assumption recorded in docs/MILESTONE3.md.
"""

from __future__ import annotations

import ast
import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

HC_SCHEMA, HC_KEY = "org.gnome.desktop.a11y.interface", "high-contrast"
SCHEME_SCHEMA, SCHEME_KEY = "org.gnome.desktop.interface", "color-scheme"
WM_SCHEMA, WM_BUTTON_KEY = "org.gnome.desktop.wm.preferences", "button-layout"


def _gsettings_get(schema: str, key: str) -> str | None:
    if not shutil.which("gsettings"):
        return None
    try:
        out = subprocess.run(["gsettings", "get", schema, key], capture_output=True, text=True, timeout=5)
    except (OSError, subprocess.TimeoutExpired):
        return None
    return out.stdout.strip() if out.returncode == 0 else None


def _gsettings_set(schema: str, key: str, value: str) -> bool:
    if not shutil.which("gsettings"):
        return False
    try:
        return subprocess.run(["gsettings", "set", schema, key, value], capture_output=True,
                              timeout=5).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def high_contrast() -> bool | None:
    """True/False, or None when it can't be read."""
    v = _gsettings_get(HC_SCHEMA, HC_KEY)
    return None if v is None else v == "true"


def gtk_theme() -> str | None:
    """The GTK theme name the session asks apps to use (GTK3 and plain GTK4)."""
    v = _gsettings_get(SCHEME_SCHEMA, "gtk-theme")
    return None if v is None else v.strip("'")


def set_gtk_theme(name: str) -> bool:
    return _gsettings_set(SCHEME_SCHEMA, "gtk-theme", _gvariant_str(name))


def accent_color() -> str | None:
    """The session's accent color name (blue, teal, ...), or None when it can't be read
    (an older GNOME has no such setting)."""
    return interface_string("accent-color")


def set_accent_color(name: str) -> bool:
    return _gsettings_set(SCHEME_SCHEMA, "accent-color", _gvariant_str(name))


def button_layout() -> str | None:
    value = _gsettings_get(WM_SCHEMA, WM_BUTTON_KEY)
    if value is None:
        return None
    try:
        result = ast.literal_eval(value)
        return result if isinstance(result, str) else None
    except (ValueError, SyntaxError):
        return None


def set_button_layout(layout: str) -> bool:
    return _gsettings_set(WM_SCHEMA, WM_BUTTON_KEY, _gvariant_str(layout))


def color_scheme() -> str | None:
    """"light" or "dark", or None when it can't be read."""
    v = _gsettings_get(SCHEME_SCHEMA, SCHEME_KEY)
    if v is None:
        return None
    return "dark" if v.strip("'") == "prefer-dark" else "light"


def interface_string(key: str) -> str | None:
    """A string key of org.gnome.desktop.interface (icon-theme, font-name,
    monospace-font-name), or None when it can't be read."""
    v = _gsettings_get(SCHEME_SCHEMA, key)
    if v is None:
        return None
    try:
        return ast.literal_eval(v)
    except (ValueError, SyntaxError):
        return None


# --- GNOME Shell (User Themes extension) ------------------------------------

SHELL_SCHEMA = "org.gnome.shell"
USER_THEME_SCHEMA = "org.gnome.shell.extensions.user-theme"


def _gvariant_str(s: str) -> str:
    return "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'"


def user_theme_name() -> str | None:
    """The User Themes theme name, or None when the extension's schema isn't installed."""
    v = _gsettings_get(USER_THEME_SCHEMA, "name")
    if v is None:
        return None
    return ast.literal_eval(v)


def set_user_theme_name(name: str) -> bool:
    return _gsettings_set(USER_THEME_SCHEMA, "name", _gvariant_str(name))


def enabled_extensions() -> list[str] | None:
    v = _gsettings_get(SHELL_SCHEMA, "enabled-extensions")
    if v is None:
        return None
    return list(ast.literal_eval(v.removeprefix("@as ").strip()))


def set_enabled_extensions(uuids: list[str]) -> bool:
    return _gsettings_set(SHELL_SCHEMA, "enabled-extensions", "[" + ", ".join(_gvariant_str(u) for u in uuids) + "]")


def user_extensions_disabled() -> bool:
    return _gsettings_get(SHELL_SCHEMA, "disable-user-extensions") == "true"


# --- Processes -------------------------------------------------------------


@dataclass(frozen=True)
class App:
    pid: int
    start: float  # Unix time the process started
    name: str
    flatpak: bool
    app_id: str | None = None  # Flatpak application ID

    def to_dict(self) -> dict:
        return {"pid": self.pid, "start": round(self.start, 2), "name": self.app_id or self.name}


def _boot_time() -> float:
    for line in Path("/proc/stat").read_text().splitlines():
        if line.startswith("btime "):
            return float(line.split()[1])
    raise OSError("no btime in /proc/stat")


def _start_time(pid: int, btime: float, hz: int) -> float:
    stat = Path(f"/proc/{pid}/stat").read_text()
    fields = stat[stat.rindex(")") + 2 :].split()
    return btime + int(fields[19]) / hz  # field 22 overall: starttime in clock ticks


def _flatpak_id(info: Path) -> str | None:
    group = None
    for line in info.read_text().splitlines():
        if line.startswith("["):
            group = line.strip()
        elif group == "[Application]" and line.startswith("name="):
            return line.split("=", 1)[1].strip()
    return None


# Desktop components that load libadwaita but aren't apps a user restarts
# (GNOME 49+ shell, its helpers, portals). Matched on the executable's name.
SESSION_PARTS = ("gnome-shell", "goa-daemon", "mutter-x11-frames", "gnome-initial-setup")
SESSION_PREFIXES = ("xdg-desktop-portal", "gsd-", "gnome-shell-", "goa-")


def is_session_part(exe_name: str) -> bool:
    return exe_name in SESSION_PARTS or exe_name.startswith(SESSION_PREFIXES)


def libadwaita_apps() -> list[App]:
    """This user's running apps that have libadwaita loaded. Leaves out desktop
    components (is_session_part) and this process itself."""
    btime, hz, uid = _boot_time(), os.sysconf("SC_CLK_TCK"), os.getuid()
    apps = []
    for d in Path("/proc").iterdir():
        if not d.name.isdigit():
            continue
        try:
            if d.stat().st_uid != uid or int(d.name) == os.getpid():
                continue
            maps = (d / "maps").read_text()
            if "libadwaita-1.so" not in maps:
                continue
            name = (d / "comm").read_text().strip()
            try:
                exe = os.path.basename(os.readlink(d / "exe")).removesuffix(" (deleted)")
            except OSError:
                exe = name
            if is_session_part(exe) or is_session_part(name):
                continue
            info = d / "root" / ".flatpak-info"
            flatpak = info.exists()
            app_id = _flatpak_id(info) if flatpak else None
            apps.append(App(int(d.name), _start_time(int(d.name), btime, hz), name, flatpak, app_id))
        except OSError:
            continue
    return sorted(apps, key=lambda a: a.start)


def still_running(recorded: list[dict]) -> list[dict]:
    """Entries of a stored restart list whose process is still the same one."""
    if not recorded:
        return []
    btime, hz = _boot_time(), os.sysconf("SC_CLK_TCK")
    alive = []
    for r in recorded:
        try:
            if abs(_start_time(r["pid"], btime, hz) - r["start"]) < 1.0:
                alive.append(r)
        except (OSError, ValueError):
            continue
    return alive


def notify(summary: str, body: str) -> bool:
    """Desktop notification when possible. Returns whether one was sent."""
    if shutil.which("notify-send"):
        try:
            return subprocess.run(["notify-send", "--app-name=theme-unifier", summary, body],
                                  capture_output=True, timeout=5).returncode == 0
        except (OSError, subprocess.TimeoutExpired):
            return False
    return False
