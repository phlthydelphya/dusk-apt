"""apply's options as GSettings (io.github.phlthydelphya.ThemeUnifier).

A settings panel writes these keys; `theme-unifier apply` takes every option
left off its command line from them, and the watcher re-applies when one
changes. Without the schema installed (or without `gsettings`) everything
falls back to apply's built-in defaults, which are also the schema's.
Read with the `gsettings` command, like session.py, so no PyGObject is needed.
"""

from __future__ import annotations

import ast
import shutil
import subprocess

SCHEMA = "io.github.phlthydelphya.ThemeUnifier"

# key: (choices, default). The defaults must match the schema file.
CHOICES: dict[str, tuple[tuple[str, ...], str]] = {
    "mode": (("auto", "light", "dark"), "auto"),
    "adwaita": (("auto", "palette"), "auto"),  # schema key "libadwaita"
    "gtk4": (("auto", "generated", "off"), "auto"),
    "gtk3": (("set", "off"), "set"),
    "shell": (("auto", "generated", "off"), "auto"),
    "flatpak": (("all", "chosen"), "all"),
    "qt": (("auto", "off"), "auto"),
    "apps": (("auto", "off"), "auto"),
    "buttons": (("auto", "off"), "auto"),
    "accent": (("set", "off"), "off"),
}
DEFAULT_WATCHER = True
# apply's keyword -> schema key, where they differ
KEY_NAMES = {"adwaita": "libadwaita"}


def read() -> dict[str, object]:
    """The schema's keys, by apply keyword; {} when the schema or gsettings is missing."""
    if not shutil.which("gsettings"):
        return {}
    try:
        res = subprocess.run(["gsettings", "list-recursively", SCHEMA], capture_output=True, text=True,
                             timeout=5)
    except (OSError, subprocess.TimeoutExpired):
        return {}
    if res.returncode != 0:
        return {}
    by_key = {v: k for k, v in KEY_NAMES.items()}
    values: dict[str, object] = {}
    for line in res.stdout.splitlines():
        parts = line.split(" ", 2)
        if len(parts) != 3 or parts[0] != SCHEMA:
            continue
        key, raw = parts[1], parts[2].strip()
        if raw in ("true", "false"):
            value: object = raw == "true"
        else:
            try:
                value = ast.literal_eval(raw)
            except (ValueError, SyntaxError):
                continue
        values[by_key.get(key, key)] = value
    return values


def resolve(given: dict[str, object], stored: dict[str, object] | None = None) -> dict[str, object]:
    """apply's options: a value given on the command line (not None), else the
    stored setting when it is valid, else the default. "mode" auto becomes None
    (follow the system color scheme)."""
    stored = read() if stored is None else stored
    out: dict[str, object] = {}
    for name, (choices, default) in CHOICES.items():
        value = given.get(name)
        if value is None:
            value = stored.get(name)
            if value not in choices:
                value = default
        out[name] = value
    if out["mode"] == "auto":
        out["mode"] = None
    watcher = given.get("watcher")
    if watcher is None:
        watcher = stored.get("watcher")
        if not isinstance(watcher, bool):
            watcher = DEFAULT_WATCHER
    out["watcher"] = watcher
    return out


def monitor_command() -> list[str] | None:
    """The command that prints a line whenever a key changes, or None without the schema."""
    if not shutil.which("gsettings"):
        return None
    try:
        ok = subprocess.run(["gsettings", "list-keys", SCHEMA], capture_output=True, timeout=5).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return None
    return ["gsettings", "monitor", SCHEMA] if ok else None
