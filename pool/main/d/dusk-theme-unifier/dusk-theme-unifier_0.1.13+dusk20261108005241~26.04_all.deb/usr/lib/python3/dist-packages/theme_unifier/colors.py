"""Color values and the GTK3 CSS color expression language.

GTK3 themes describe colors with plain CSS literals plus a few GTK-only
functions (alpha, shade, mix, lighter, darker) and @name references to
colors declared with @define-color. This module evaluates those expressions.
"""

from __future__ import annotations

import colorsys
import re
from dataclasses import dataclass
from typing import Callable, Mapping


@dataclass(frozen=True)
class Color:
    r: float
    g: float
    b: float
    a: float = 1.0

    @classmethod
    def from_hex(cls, text: str) -> "Color":
        h = text.lstrip("#")
        if len(h) in (3, 4):
            h = "".join(c * 2 for c in h)
        if len(h) not in (6, 8):
            raise ValueError(f"bad hex color: {text!r}")
        parts = [int(h[i : i + 2], 16) / 255 for i in range(0, len(h), 2)]
        return cls(*parts) if len(parts) == 4 else cls(*parts, 1.0)

    def to_hex(self) -> str:
        rgb = "".join(f"{round(_clamp(c) * 255):02x}" for c in (self.r, self.g, self.b))
        if self.a >= 1.0:
            return f"#{rgb}"
        return f"#{rgb}{round(_clamp(self.a) * 255):02x}"

    def to_css(self) -> str:
        """Hex when opaque, rgba() otherwise (readable by GTK3, GTK4 and Qt)."""
        if self.a >= 1.0:
            return self.to_hex()
        r, g, b = (round(_clamp(c) * 255) for c in (self.r, self.g, self.b))
        return f"rgba({r}, {g}, {b}, {round(self.a, 3)})"

    def luminance(self) -> float:
        """WCAG relative luminance, ignoring alpha."""

        def lin(c: float) -> float:
            return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4

        return 0.2126 * lin(self.r) + 0.7152 * lin(self.g) + 0.0722 * lin(self.b)

    def is_dark(self) -> bool:
        return self.luminance() < 0.18

    def over(self, background: "Color") -> "Color":
        """Composite this color over an opaque background."""
        a = self.a
        return Color(
            self.r * a + background.r * (1 - a),
            self.g * a + background.g * (1 - a),
            self.b * a + background.b * (1 - a),
            1.0,
        )


def contrast_ratio(a: Color, b: Color) -> float:
    la, lb = sorted((a.luminance(), b.luminance()), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def _clamp(v: float) -> float:
    return max(0.0, min(1.0, v))


# --- GTK color functions -------------------------------------------------


def shade(c: Color, factor: float) -> Color:
    """GTK's shade(): scale lightness and saturation in HLS space."""
    h, l, s = colorsys.rgb_to_hls(c.r, c.g, c.b)
    r, g, b = colorsys.hls_to_rgb(h, _clamp(l * factor), _clamp(s * factor))
    return Color(r, g, b, c.a)


def alpha(c: Color, factor: float) -> Color:
    return Color(c.r, c.g, c.b, _clamp(c.a * factor))


def mix(c1: Color, c2: Color, factor: float) -> Color:
    def m(x: float, y: float) -> float:
        return x + (y - x) * factor

    return Color(m(c1.r, c2.r), m(c1.g, c2.g), m(c1.b, c2.b), m(c1.a, c2.a))


# --- Named colors --------------------------------------------------------

NAMED_COLORS: dict[str, str] = {
    "transparent": "#00000000",
    "black": "#000000", "white": "#ffffff", "red": "#ff0000", "green": "#008000",
    "blue": "#0000ff", "yellow": "#ffff00", "cyan": "#00ffff", "magenta": "#ff00ff",
    "gray": "#808080", "grey": "#808080", "silver": "#c0c0c0", "maroon": "#800000",
    "olive": "#808000", "lime": "#00ff00", "aqua": "#00ffff", "teal": "#008080",
    "navy": "#000080", "fuchsia": "#ff00ff", "purple": "#800080", "orange": "#ffa500",
    "darkgray": "#a9a9a9", "darkgrey": "#a9a9a9", "lightgray": "#d3d3d3",
    "lightgrey": "#d3d3d3", "dimgray": "#696969", "dimgrey": "#696969",
    "gainsboro": "#dcdcdc", "whitesmoke": "#f5f5f5", "snow": "#fffafa",
    "ivory": "#fffff0", "beige": "#f5f5dc", "linen": "#faf0e6",
    "darkred": "#8b0000", "darkgreen": "#006400", "darkblue": "#00008b",
    "crimson": "#dc143c", "tomato": "#ff6347", "coral": "#ff7f50",
    "gold": "#ffd700", "goldenrod": "#daa520", "chocolate": "#d2691e",
    "steelblue": "#4682b4", "royalblue": "#4169e1", "dodgerblue": "#1e90ff",
    "skyblue": "#87ceeb", "slategray": "#708090", "slategrey": "#708090",
    "seagreen": "#2e8b57", "forestgreen": "#228b22", "limegreen": "#32cd32",
    "indigo": "#4b0082", "violet": "#ee82ee", "orchid": "#da70d6", "pink": "#ffc0cb",
}


# --- Expression evaluation -----------------------------------------------


class ColorError(ValueError):
    pass


_TOKEN = re.compile(
    r"\s*(?:(?P<hex>#[0-9a-fA-F]{3,8}\b)|(?P<ref>@[\w-]+)|(?P<num>-?\d*\.?\d+%?)"
    r"|(?P<ident>[A-Za-z_][\w-]*)|(?P<punct>[(),]))"
)


def _tokenize(text: str) -> list[tuple[str, str]]:
    tokens: list[tuple[str, str]] = []
    pos = 0
    text = text.strip()
    while pos < len(text):
        m = _TOKEN.match(text, pos)
        if not m or m.end() == pos:
            raise ColorError(f"cannot parse color expression: {text!r}")
        kind = m.lastgroup or ""
        tokens.append((kind, m.group(kind)))
        pos = m.end()
    return tokens


Resolver = Callable[[str], Color]


class _Parser:
    def __init__(self, text: str, resolve: Resolver):
        self.text = text
        self.tokens = _tokenize(text)
        self.i = 0
        self.resolve = resolve

    def peek(self) -> tuple[str, str] | None:
        return self.tokens[self.i] if self.i < len(self.tokens) else None

    def take(self) -> tuple[str, str]:
        tok = self.peek()
        if tok is None:
            raise ColorError(f"unexpected end of {self.text!r}")
        self.i += 1
        return tok

    def expect(self, value: str) -> None:
        kind, v = self.take()
        if v != value:
            raise ColorError(f"expected {value!r} in {self.text!r}, got {v!r}")

    def number(self) -> float:
        kind, v = self.take()
        if kind != "num":
            raise ColorError(f"expected number in {self.text!r}, got {v!r}")
        return float(v[:-1]) / 100 if v.endswith("%") else float(v)

    def color(self) -> Color:
        kind, v = self.take()
        if kind == "hex":
            try:
                return Color.from_hex(v)
            except ValueError as e:
                raise ColorError(str(e)) from None
        if kind == "ref":
            return self.resolve(v[1:])
        if kind != "ident":
            raise ColorError(f"expected color in {self.text!r}, got {v!r}")
        name = v.lower()
        nxt = self.peek()
        if nxt is None or nxt[1] != "(":
            if name in NAMED_COLORS:
                return Color.from_hex(NAMED_COLORS[name])
            raise ColorError(f"unknown color name {v!r}")
        self.expect("(")
        if name in ("rgb", "rgba"):
            parts = [self.channel()]
            while self.peek() and self.peek()[1] == ",":
                self.take()
                parts.append(self.channel())
            self.expect(")")
            want = 3 if name == "rgb" else 4  # GTK3 is strict: rgb() takes three values, rgba() four
            if len(parts) != want:
                raise ColorError(f"{name}() takes {want} values, got {len(parts)} in {self.text!r}")
            r, g, b = (p / 255 if not isinstance(p, tuple) else p[0] for p in parts[:3])
            a = 1.0
            if len(parts) > 3:
                a = parts[3][0] if isinstance(parts[3], tuple) else parts[3]
            return Color(r, g, b, a)
        if name in ("alpha", "shade"):
            c = self.color()
            self.expect(",")
            f = self.number()
            self.expect(")")
            return alpha(c, f) if name == "alpha" else shade(c, f)
        if name == "mix":
            c1 = self.color()
            self.expect(",")
            c2 = self.color()
            self.expect(",")
            f = self.number()
            self.expect(")")
            return mix(c1, c2, f)
        if name in ("lighter", "darker"):
            c = self.color()
            self.expect(")")
            return shade(c, 1.3 if name == "lighter" else 0.7)
        raise ColorError(f"unsupported color function {v!r}")

    def channel(self):
        """rgb() channel: a 0-255 number, or a percentage returned as (fraction,)."""
        kind, v = self.take()
        if kind != "num":
            raise ColorError(f"expected number in {self.text!r}, got {v!r}")
        if v.endswith("%"):
            return (float(v[:-1]) / 100,)
        return float(v)

    def parse(self) -> Color:
        c = self.color()
        if self.peek() is not None:
            raise ColorError(f"trailing input in {self.text!r}")
        return c


def evaluate(expr: str, defines: Mapping[str, str] | None = None) -> Color:
    """Evaluate a GTK3 color expression, resolving @refs against `defines`."""
    defines = defines or {}
    stack: list[str] = []

    def resolve(name: str) -> Color:
        if name in stack:
            raise ColorError(f"circular @define-color: {' -> '.join(stack + [name])}")
        if name not in defines:
            raise ColorError(f"undefined color @{name}")
        stack.append(name)
        try:
            return _Parser(defines[name], resolve).parse()
        finally:
            stack.pop()

    return _Parser(expr, resolve).parse()


def try_evaluate(expr: str, defines: Mapping[str, str] | None = None) -> Color | None:
    try:
        return evaluate(expr, defines)
    except (ColorError, ValueError):
        return None


# --- OKLab ---------------------------------------------------------------


def to_oklab(c: Color) -> tuple[float, float, float]:
    """The color as OKLab (L, a, b), using Björn Ottosson's matrices. Alpha is ignored."""

    def lin(v: float) -> float:
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4

    r, g, b = lin(_clamp(c.r)), lin(_clamp(c.g)), lin(_clamp(c.b))
    l = (0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b) ** (1 / 3)
    m = (0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b) ** (1 / 3)
    s = (0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b) ** (1 / 3)
    return (0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
            1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
            0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s)
