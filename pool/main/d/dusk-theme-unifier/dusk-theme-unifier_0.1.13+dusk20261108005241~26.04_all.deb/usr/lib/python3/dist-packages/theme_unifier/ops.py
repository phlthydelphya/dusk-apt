"""apply / revert / status / doctor / watch: the host CLI's operations.

Each operation returns a list of lines to show the user and raises HostError
for a refusal (nothing changed). See host.py for the file-level rules and
PLAN.md D2, D3 and D5 for the behavior.
"""

from __future__ import annotations

import functools
import json
import selectors
import subprocess
import sys
import time
import uuid
from pathlib import Path

from . import flatpak as fp
from . import actions, gtk4theme, session, settings
from .generate import generate
from .host import (EXIT_CONTRAST, exclusive, EXIT_ERROR, EXIT_INVALID, EXIT_MODE_UNAVAILABLE, Host, HostError, Incomplete, Manifest, _incomplete, _read,
                   build_region, find_region, missing_dirs, sha256)
from .loader import find_theme
from .targets import changes
from .targets import adwaita as t_adwaita
from .targets import apps as t_apps
from .targets import flatpak as t_flatpak
from .targets import accent as t_accent
from .targets import gtk3 as t_gtk3
from .targets import gtk4 as t_gtk4
from .targets import palette_export as t_palette
from .targets import qt as t_qt
from .targets import shell as t_shell
from .targets import watcher as t_watcher
from .targets import window_buttons as t_window_buttons
from .variants import discover

# Tests and the GUI look these up here.
UNIT_NAME = t_watcher.UNIT_NAME
unit_path = t_watcher.unit_path


def _restart_list(before: float, flatpak_apps=()) -> list[dict]:
    """Running libadwaita apps that started before `before`: host apps, and
    Flatpak apps enabled with `theme-unifier flatpak add`."""
    try:
        return [a.to_dict() for a in session.libadwaita_apps()
                if (not a.flatpak or a.app_id in flatpak_apps) and a.start < before]
    except OSError:
        return []


def _names(apps: list[dict]) -> str:
    return ", ".join(f"{a['name']} ({a['pid']})" for a in apps)


def _generate(theme_ref: str, mode: str) -> tuple[str, list[str], str, dict[str, str]]:
    """CSS, disclosed lines, theme name, and the generated colors (name -> #rrggbb)."""
    try:
        theme = find_theme(theme_ref)
    except LookupError as e:
        raise HostError(str(e), EXIT_ERROR)
    vs = discover(theme)
    if mode not in vs.palettes:
        raise HostError(vs.missing_mode_message(mode), EXIT_MODE_UNAVAILABLE)
    pal = vs.palettes[mode]
    if pal.status == "invalid":
        raise HostError(f"{theme.name} ({mode}): no window background could be read from the theme, so every color "
                        "would be a guess. Nothing was changed. `theme-unifier analyze` shows what was read.",
                        EXIT_INVALID)
    gen = generate(pal, mode)
    if gen.unresolved:
        pairs = "; ".join(f"{fg} on {bg} {r}:1 (needs {need})" for fg, bg, r, need in gen.unresolved)
        raise HostError(f"{theme.name} ({mode}) still fails contrast after adjustment: {pairs}. "
                        "Nothing was changed.", EXIT_CONTRAST)
    disclosed = [f"{i.name} {i.color.to_css()}" + (f" (theme {i.adjusted_from.to_css()})" if i.adjusted_from else "")
                 for i in gen.disclosed]
    colors = {i.name: i.color.to_hex() for i in gen.items}
    return gen.css(css_vars=gtk4theme.css_variables()), disclosed, theme.name, colors


# --- Operations ----------------------------------------------------------------


def _operation(fn):
    """Run an operation under the per-user lock, from recovery through its last commit."""
    @functools.wraps(fn)
    def run(*args, host: Host | None = None, **kw):
        host = host or Host()
        with exclusive(host.paths):
            try:
                out = fn(*args, host=host, **kw)
            except Incomplete as e:  # recovery couldn't finish: keep what it did say
                raise Incomplete("\n".join([*host.log, str(e)])) from None
            if host.unfinished:  # the files changed, but a desktop step failed
                raise Incomplete("\n".join([*out, str(_incomplete(host.unfinished))]))
            return out
    return run



@_operation
def apply(theme_ref: str, mode: str | None = None, force: bool = False, watcher: bool = True,
          host: Host | None = None, gtk4: str = "auto", shell: str = "auto", gtk3: str = "set",
          flatpak: str = "all", dry_run: bool = False, qt: str = "auto", buttons: str = "auto",
          adwaita: str = "auto", accent: str = "off", apps: str = "auto") -> list[str]:
    host = host or Host()
    out = host.log
    m, text = host.load(recover=not dry_run)
    region = find_region(text or "")  # raises on damaged markers
    if region and m is None:
        raise HostError("gtk.css has a theme-unifier region but there is no manifest for it. "
                        "Run `theme-unifier doctor`; nothing was changed.")
    if m and region and region.id != m.id:
        raise HostError(f"gtk.css holds region {region.id}, but the manifest is for {m.id}. Nothing was changed.")
    if m and region and region.text(text) != m.region and not force:
        raise HostError("The managed region in gtk.css was edited since theme-unifier wrote it. Nothing was "
                        "changed. Move your edits outside the markers, or use --force to replace them.")

    if mode is None:
        mode = session.color_scheme()
        if mode is None:
            raise HostError("Could not read the system color scheme; pass --mode light or --mode dark.", EXIT_ERROR)
        out.append(f"System color scheme: {mode}.")
    css, disclosed, theme_name, colors = _generate(theme_ref, mode)
    adw_files, adw_rec, adw_note = t_adwaita.plan(theme_ref, adwaita)
    if adw_rec["kind"] == "authored":
        css = t_adwaita.stylesheet(adw_rec, mode, host.paths.target.parent / "theme-unifier-authored")
    elif adw_rec["kind"] == "palette":
        css = t_adwaita.system_accent_palette(css)
    button_layout = t_window_buttons.theme_layout(theme_ref) if buttons == "auto" else None
    shell_files, shell_rec, shell_note = t_shell.plan(theme_ref, mode, shell)
    gtk3_files = t_gtk3.copy_for_flatpak(theme_ref, m.files if m else {}) if flatpak == "all" or (m and m.flatpak) else {}
    qt_files, qt_edits, qt_rec, qt_note = t_qt.plan(theme_ref, mode, qt, m.qt if m else {}, force)
    palette_file = {t_palette.path(): t_palette.document(theme_name, mode, colors,
                                                         t_accent.nearest(colors["accent_color"]))}
    app_out: list[str] = []
    app_recs, app_files, app_acts = t_apps.plan_all(json.loads(palette_file[t_palette.path()]), mode,
                                                    m.apps if m else {}, apps, app_out)
    owned_now = m.files if m else {}
    for p in [p for p in palette_file if p.exists() and str(p) not in owned_now]:
        del palette_file[p]
        app_out.append(f"Palette export: {p} exists and wasn't written by theme-unifier, so it was not replaced.")
    for name in t_apps.foreign(app_recs, app_files, owned_now):
        app_out.append(f"{name}: a theme file exists that wasn't written by theme-unifier, so the app was "
                       "left alone.")
        app_files = {p: d for p, d in app_files.items() if str(p) not in app_recs[name].get("files", [])}
        app_recs[name] = {}
    for p in (t_apps.released(m.apps, app_recs, m.files) if m else []):
        del m.files[p]  # the app changed it; forget it before the owned-file check (m is not saved on a dry run)
        app_out.append(f"{t_apps.owner(Path(p), m.apps)}: {p} was changed by the app after theme-unifier "
                       "wrote it, so theme-unifier no longer manages it (left as it is).")
    gtk4_changes, gtk4_files, gtk4_dirs, gtk4_note = t_gtk4.changes(
        theme_ref, m, gtk4, force,
        {**shell_files, **gtk3_files, **qt_files, **adw_files, **palette_file, **app_files})
    qt_dirs = [d for p in qt_edits for d in missing_dirs(p) if d not in gtk4_dirs]

    region_id = m.id if m else uuid.uuid4().hex
    new_region = build_region(region_id, css, theme_name, mode)
    hc = session.high_contrast()
    if m is None and not dry_run:
        b = host.backup(text)
        if b:
            out.append(f"Backup of your gtk.css: {b}")

    now = time.time()
    if hc:
        # D3: nothing goes into gtk.css while high contrast is on.
        new_text = text if not region else text[: region.start] + text[region.end :]
        lead = m.lead if m else ""
        suspended = "high-contrast"
    elif region:
        new_text = text[: region.start] + new_region + text[region.end :]
        lead = m.lead
        suspended = None
    else:
        new_text, lead = host.insert(text, new_region)
        suspended = None

    created_file = m.created_file if m else text is None
    unchanged = (m is not None and new_text == text and m.region == new_region
                 and m.suspended == suspended and m.mode == mode and not gtk4_changes and m.files == gtk4_files
                 and not qt_edits and m.qt == qt_rec
                 and m.adwaita == adw_rec and m.apps == app_recs
                 and {k: m.shell.get(k) for k in shell_rec} == shell_rec
                 and m.shell.get("state") == ("suspended" if hc else "active" if shell_rec["name"] else "inactive"))
    if unchanged and gtk3 != "off" and session.gtk_theme() != theme_name:
        unchanged = False
    if unchanged and accent != "off":
        cur_accent = session.accent_color()
        if cur_accent is not None and cur_accent != t_accent.nearest(colors["accent_color"]):
            unchanged = False
    if unchanged and accent == "off" and m.accent.get("changed"):
        unchanged = False
    if unchanged and ((button_layout is not None and session.button_layout() != button_layout) or
                      (button_layout is None and m.window_buttons.get("changed"))):
        unchanged = False
    if unchanged and watcher and m.unit and t_watcher.refresh(m.unit, []):
        unchanged = False  # the watcher runs another copy of theme-unifier
    if unchanged and flatpak == "all":
        try:
            unchanged = all(a in m.flatpak or a in m.flatpak_skip for a, _ in fp.installed_apps())
            want = str(t_qt.kdeglobals_path()) in qt_rec.get("keys", {})
            unchanged = unchanged and all(bool(r.get("kde")) == (want and t_flatpak.kde_app(r))
                                          for r in m.flatpak.values())
        except HostError:
            pass
    if unchanged:
        out.append(f"{theme_name} ({mode}) is already applied; nothing " + ("would change." if dry_run
                                                                            else "was changed."))
        return out

    manifest = Manifest(id=region_id, target=str(host.paths.target), theme=theme_ref, mode=mode,
                        region=new_region, lead=lead, created_file=created_file, applied_at=now,
                        suspended=suspended, suspended_at=now if suspended else None, disclosed=disclosed,
                        unit=m.unit if m else None,
                        restart_needed=[] if suspended else _restart_list(now, m.flatpak if m else ()),
                        created_dir=m.created_dir if m else not host.paths.target.parent.exists(),
                        files=gtk4_files, dirs=(m.dirs if m else []) + [str(d) for d in gtk4_dirs + qt_dirs],
                        gtk4=gtk4_note, flatpak=m.flatpak if m else {}, shell=dict(m.shell) if m else {},
                        gtk3=dict(m.gtk3) if m else {}, flatpak_skip=list(m.flatpak_skip) if m else [],
                        qt=qt_rec, window_buttons=dict(m.window_buttons) if m else {}, adwaita=adw_rec,
                        apps=app_recs)
    # Everything goes into one journaled commit: files, records and the
    # settings/watcher actions, so an interruption is finished or rolled back
    # as a whole (host.Host.recover).
    shell_out: list[str] = list(app_out)
    old_shell_file = m.shell.get("file") if m and m.shell.get("name") == shell_rec.get("name") else None
    shell_reload = (any(str(p) == shell_rec.get("file") for p in gtk4_changes) or
                    bool(old_shell_file and Path(old_shell_file) in gtk4_changes))
    manifest.shell, acts = t_shell.activate(shell_rec, m.shell if m else {}, bool(hc),
                                           reload=shell_reload,
                                           out=shell_out)
    manifest.gtk3, gtk3_acts = t_gtk3.activate(theme_name, gtk3, m.gtk3 if m else {}, shell_out)
    acts += gtk3_acts
    manifest.accent, accent_acts = t_accent.activate(colors["accent_color"], accent, m.accent if m else {}, shell_out)
    acts += accent_acts + app_acts
    manifest.window_buttons, button_acts = t_window_buttons.activate(
        button_layout, m.window_buttons if m else {}, shell_out)
    acts += button_acts
    if button_layout is None:
        shell_out.append("Window buttons: " + ("no valid layout in the theme; " if buttons == "auto" else "") +
                         "layout left alone." if not button_acts else "Window buttons: restoring the previous layout.")
    extra, dirs = {**gtk4_changes, **qt_edits}, list(gtk4_dirs) + qt_dirs
    if flatpak == "all":
        try:
            apps = [a for a, _ in fp.installed_apps() if a not in manifest.flatpak_skip]
        except HostError:
            apps = []
        new_apps = [a for a in apps if a not in manifest.flatpak]
        fp_extra, fp_dirs, fp_changed = t_flatpak.add_into(manifest, apps, shell_out, strict=False)
        extra.update(fp_extra)
        dirs += fp_dirs
        if new_apps and fp_changed:
            shell_out.append(f"Flatpak apps: {len(new_apps)} can now read the palette ({', '.join(new_apps)}). "
                             "Turn one off with `theme-unifier flatpak remove APP_ID`.")
        kde_apps = [a for a, r in manifest.flatpak.items()
                    if any(e.get("added") for e in ((r.get("kde") or {}).get("env") or {}).values())]
        if kde_apps and fp_changed:
            shell_out.append(f"Flatpak KDE apps: {', '.join(kde_apps)} use the KDE platform theme, so they read "
                             "the KDE colors, GNOME's font and icons, and open GNOME's file dialog.")
    unit_lines: list[str] = []
    if watcher and not manifest.unit:
        planned = t_watcher.install(unit_lines)
        if planned:
            manifest.unit, unit_file, unit_acts = planned
            unit_dirs = missing_dirs(t_watcher.unit_path())
            manifest.dirs += [str(d) for d in unit_dirs]  # revert removes them again if empty
            extra.update(unit_file)
            dirs += unit_dirs
            acts += unit_acts
    elif watcher:
        planned = t_watcher.refresh(manifest.unit, unit_lines)
        if planned:
            manifest.unit, unit_file, unit_acts = planned
            extra.update(unit_file)
            acts += unit_acts
    elif not manifest.unit:
        unit_lines.append("No watcher: turning on high contrast will not remove the palette until you revert.")
    if dry_run:
        return out + changes.describe(host, text, new_text, extra, acts, manifest, shell_rec.get("file"),
                                      set(gtk3_files))
    done = host.commit(None if new_text is None else new_text.encode(), manifest, extra, dirs, acts)
    unit_lines += [line for line in done if line.startswith("Watcher")]
    shell_out = [line for line in done if not line.startswith("Watcher")] + shell_out

    if suspended:
        out.append(f"High contrast is on, so {theme_name} ({mode}) was recorded but not written to gtk.css. "
                   "It will be added when high contrast is turned off (by the watcher, or by running apply again).")
    else:
        out.append(f"Applied {theme_name} ({mode}) to {host.paths.target}.")
        out.append("Apps started from now on use it. Apps already open keep their current colors until restarted"
                   + (f": {_names(manifest.restart_needed)}." if manifest.restart_needed else "."))
    out.append(gtk4_note)
    out.append(adw_note)
    if gtk3_files:
        folder = next(q for q in next(iter(gtk3_files)).parents if q.name == "gtk-3.0")
        out.append(f"Flatpak GTK3 apps: copied {theme_name}'s GTK3 styles to {folder} ({len(gtk3_files)} files) "
                   "so sandboxed apps can see them. Revert removes the copy.")
    out.append(shell_note)
    out.extend(shell_out)
    out.append(qt_note)
    if disclosed:
        out.append(f"{len(disclosed)} colors were not read from the theme as-is: " + "; ".join(disclosed))
    out.extend(unit_lines)
    return out


@_operation
def revert(force: bool = False, host: Host | None = None) -> list[str]:
    host = host or Host()
    out = host.log
    m, text = host.load(roll_back_unfinished=True)  # a change left open is undone with the rest
    if m is None:
        region = find_region(text or "")
        if region is None:
            out.append("Nothing to revert: theme-unifier has not applied anything.")
            return out
        if not force:
            raise HostError("gtk.css has a theme-unifier region but there is no manifest for it, so it can't be "
                            "checked. Nothing was changed. Use `revert --force` to remove the region anyway.")
        new_text = text[: region.start] + text[region.end :]
        host.commit(new_text.encode(), None)
        out.append("Removed the unrecorded theme-unifier region (--force).")
        return out

    region = find_region(text or "")
    if region is None:
        new_text = text
        if not m.suspended:
            out.append("The managed region was already gone from gtk.css (removed by hand); only the record "
                       "was cleared.")
    else:
        new_text = host.remove(text, m, force)
    delete = m.created_file and new_text == ""
    owned: dict[Path, bytes | None] = {}
    app_changed = set(t_apps.released(m.apps, {}, m.files))  # the app's own edits: never deleted, even with --force
    for path_s, sha in m.files.items():
        cur = _read(Path(path_s))
        if cur is None:
            continue
        if (sha256(cur) != sha and not force) or path_s in app_changed:
            out.append(f"Conflict: {path_s} was changed after theme-unifier wrote it, so it was left in place.")
            continue
        owned[Path(path_s)] = None
    flatpak_notes = []
    for app, record in m.flatpak.items():
        try:
            ch = t_flatpak.plan_remove(app, record, force, out)
        except HostError as e:
            out.append(f"{app}: {e}".replace("Nothing was changed; use --force to forget the app.",
                                            "It was left alone."))
            continue
        if ch.changed:
            owned[ch.path] = ch.after
        flatpak_notes.append(ch.note)
    unit_files, acts = t_watcher.remove(m.unit, out, force)
    owned.update(unit_files)
    qt_restored = t_qt.restore(m.qt, force, out)
    owned.update(qt_restored)
    acts += t_shell.restore(m.shell, force) + t_gtk3.restore(m.gtk3, force) + t_window_buttons.restore(m.window_buttons, force)
    acts += t_accent.restore(m.accent, force)
    app_undo, app_undo_acts = t_apps.restore_all(m.apps, force)
    owned.update(app_undo)
    acts += app_undo_acts
    empty = [Path(d) for d in reversed(m.dirs)] + [Path(d) for r in m.flatpak.values()
                                                   for d in reversed(r.get("dirs", []))]
    if m.created_dir:
        empty.append(host.paths.target.parent)
    out.extend(host.commit(None if delete or new_text is None else new_text.encode(), None, owned, actions=acts,
                           remove_dirs=empty))
    gtk3_copy = [p for p in owned if str(p) in m.files and "gtk-3.0" in p.parts]
    adw_copy = [p for p in owned if str(p) in m.files and "theme-unifier-authored" in p.parts]
    palette_removed = t_palette.path() in owned and str(t_palette.path()) in m.files
    gtk4_removed = [p.name for p in owned if str(p) in m.files and str(p) != m.shell.get("file")
                    and p not in gtk3_copy and p not in adw_copy and not t_qt.owns(p, m.qt)
                    and p != t_palette.path() and str(p) not in t_apps.owned_paths(m.apps)]
    if gtk3_copy:
        out.append(f"Removed the copy of the theme's GTK3 styles for Flatpak apps ({len(gtk3_copy)} files).")
    if gtk4_removed:
        out.append(f"Removed the generated GTK4 theme ({', '.join(gtk4_removed)}).")
    if adw_copy:
        out.append(f"Removed the authored GTK4 style copy ({len(adw_copy)} files).")
    if m.shell.get("file") and Path(m.shell["file"]) in owned:
        out.append(f"Removed the generated Shell theme ({m.shell['file']}).")
    if palette_removed:
        out.append(f"Removed the palette export ({t_palette.path()}).")
    out.extend(t_apps.removed_lines(m.apps, {p for p in owned if str(p) in m.files}))
    out.extend(flatpak_notes)
    if m.qt.get("keys"):
        out.append("KDE/Qt apps: took out theme-unifier's colors and settings (qt5ct/qt6ct, kdeglobals)"
                   + (", and the login setting; log out and back in for Qt apps to drop the palette."
                      if m.qt.get("env") else "."))
    out.append(f"Reverted {m.theme} ({m.mode}): gtk.css is back to its content without theme-unifier"
               + (" (the file was created by theme-unifier and has been removed)." if delete else "."))
    running = _restart_list(time.time(), m.flatpak)
    if running and region is not None:
        out.append(f"Apps already open keep the palette until restarted: {_names(running)}.")
    return out


@_operation
def status(host: Host | None = None) -> list[str]:
    host = host or Host()
    out = host.log
    m, text = host.load()
    hc, scheme = session.high_contrast(), session.color_scheme()
    out.append(f"gtk.css: {host.paths.target}" + ("" if text is not None else " (does not exist)"))
    out.append(f"System: {scheme or 'unknown'} scheme, high contrast {'unknown' if hc is None else 'on' if hc else 'off'}.")
    out.append(f"Managed region: {host.region_state(text, m)}.")
    if m is None:
        out.append("Nothing applied.")
        return out
    when = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(m.applied_at))
    out.append(f"Applied: {m.theme} ({m.mode}) at {when}" + (f"; suspended ({m.suspended})" if m.suspended else ""))
    if m.gtk4:
        out.append(m.gtk4)
        copies: dict[str, int] = {}
        authored_copies: dict[str, int] = {}
        for path_s, sha in m.files.items():
            cur = _read(Path(path_s))
            state = "missing" if cur is None else "intact" if sha256(cur) == sha else "edited"
            if "gtk-3.0" in Path(path_s).parts:
                copies[state] = copies.get(state, 0) + 1
                continue
            if "theme-unifier-authored" in Path(path_s).parts:
                authored_copies[state] = authored_copies.get(state, 0) + 1
                continue
            if t_qt.owns(Path(path_s), m.qt):
                continue
            if Path(path_s) == t_palette.path() or path_s in t_apps.owned_paths(m.apps):
                continue
            out.append(f"  {path_s}: {state}")
        if copies:
            out.append("  GTK3 copy for Flatpak apps: " + ", ".join(f"{n} {st}" for st, n in copies.items()))
        if authored_copies:
            out.append("  Authored GTK4 style copy: " + ", ".join(f"{n} {st}" for st, n in authored_copies.items()))
        gtk4_file = next((p for p in m.files if Path(p).parent.name == "gtk-4.0"), None)
        if gtk4_file:
            current = session.gtk_theme()
            name = Path(gtk4_file).parent.parent.name
            if current and current != name:
                out.append(f"  Note: the system GTK theme is {current}, so plain GTK4 apps don't use it now.")
    palette_sha = m.files.get(str(t_palette.path()))
    if palette_sha is not None:
        cur = _read(t_palette.path())
        state = "missing" if cur is None else "intact" if sha256(cur) == palette_sha else "edited"
        out.append(f"Palette export: {t_palette.path()} ({state}).")
    out.extend(t_apps.status_lines(m.apps, m.files))
    if m.adwaita.get("kind") == "authored":
        out.append("Libadwaita apps: the theme's authored GTK4 styles.")
    elif m.adwaita.get("kind") == "palette":
        out.append("Libadwaita apps: generated colors only.")
    out.extend(t_shell.status(m.shell))
    if m.window_buttons.get("layout"):
        current = session.button_layout()
        out.append(f"Window buttons: {current!r}" +
                   ("." if current == m.window_buttons['layout'] else
                    f" (changed from {m.window_buttons['layout']!r} outside theme-unifier)."))
    if m.accent.get("name"):
        out.append(f"Accent: {m.accent['name']} (nearest to {m.accent['color']})")
    out.extend(t_flatpak.status(m))
    out.extend(t_qt.status(m.qt, m.files))
    if m.unit:
        active = actions._systemctl("is-active", "--quiet", t_watcher.UNIT_NAME)
        out.append(f"Watcher: {'running' if active else 'installed, not running'} ({m.unit['path']}).")
    else:
        out.append("Watcher: not installed.")
    waiting = session.still_running(m.restart_needed)
    if waiting:
        verb = "still have the theme (opened before high contrast)" if m.suspended else "don't have the theme yet"
        out.append(f"Need a restart: {_names(waiting)} {verb}.")
    if m.disclosed:
        out.append(f"Not read from the theme as-is: {'; '.join(m.disclosed)}")
    return out


@_operation
def doctor(discard_journal: bool = False, host: Host | None = None) -> list[str]:
    host = host or Host()
    out = host.log
    p = host.paths
    if discard_journal and p.journal.exists():
        p.journal.unlink()
        out.append(f"Discarded {p.journal}.")
    try:
        m, text = host.load()
    except HostError as e:
        out.append(f"Problem: {e}")
        return out
    out.append(f"Managed region: {host.region_state(text, m)}.")
    if m is None and t_watcher.unit_path().exists():
        out.append(f"Stray watcher unit with nothing applied: {t_watcher.unit_path()} (safe to delete).")
    backups = sorted(p.backups.glob("*.css")) if p.backups.exists() else []
    if backups:
        out.append("Backups (recovery material only; revert never restores them):")
        out.extend(f"  {b}" for b in backups)
    if not p.journal.exists():
        out.append("No interrupted writes pending.")
    return out


def _qt_follow(m: Manifest, mode: str, out: list[str]) -> dict[Path, bytes | None]:
    """The Qt files for `mode` (the watcher's dark/light switch), updating m.
    Only files the tool already owns or edits are touched; a scheme file
    edited by hand, or a Qt key changed since, keeps Qt apps as they are."""
    if not m.qt.get("keys") or m.qt.get("mode") == mode:
        return {}
    try:
        files, edits, rec, _ = t_qt.plan(m.theme, mode, m.qt.get("choice", "auto"), m.qt, False)
    except (HostError, LookupError, KeyError) as e:
        out.append(f"KDE/Qt apps: kept their {m.qt.get('mode')} colors ({e}).")
        return {}
    if not rec.get("keys"):
        return {}
    extra: dict[Path, bytes | None] = {p: d for p, d in edits.items() if str(p) in rec["keys"]}
    hashes = {}
    for path, data in files.items():
        sha = m.files.get(str(path))
        if sha is None:
            continue
        if sha256(_read(path)) != sha:
            out.append(f"KDE/Qt apps: kept their {m.qt.get('mode')} colors, because {path} was edited.")
            return {}
        extra[path] = data
        hashes[str(path)] = sha256(data)
    m.files.update(hashes)
    m.qt = dict(rec, env=m.qt.get("env", False))
    return extra


def _follow(m: Manifest, name: str, mode: str, colors: dict[str, str], out: list[str]
            ) -> tuple[dict[Path, bytes | None], list[dict]]:
    """Everything outside gtk.css that follows a switch to `mode` (the
    watcher): Qt files, the accent color, the palette export and the app
    adapters' files. Updates m; returns the files and actions for the same commit."""
    extra = _qt_follow(m, mode, out)
    m.accent, acts = t_accent.follow(m.accent, colors["accent_color"], out)
    accent_name = t_accent.nearest(colors["accent_color"])
    extra.update(t_palette.follow(m, name, mode, colors, accent_name, out))
    app_files, app_acts = t_apps.follow(m, json.loads(t_palette.document(name, mode, colors, accent_name)), mode, out)
    extra.update(app_files)
    return extra, acts + app_acts


def _adwaita_for_sync(m: Manifest, mode: str, css: str, host: Host, out: list[str]) -> str | None:
    if m.adwaita.get("kind") != "authored":
        return t_adwaita.system_accent_palette(css) if m.adwaita.get("kind") == "palette" else css
    folder = host.paths.target.parent / "theme-unifier-authored"
    path = folder / m.adwaita[mode]
    expected = m.files.get(str(path))
    if expected is None or sha256(_read(path)) != expected:
        out.append(f"Libadwaita apps: {path} is missing or changed; the authored style was not switched.")
        return None
    return t_adwaita.stylesheet(m.adwaita, mode, folder)


@_operation
def sync(host: Host | None = None) -> list[str]:
    """Bring gtk.css in line with high contrast and the color scheme (the watcher's job)."""
    host = host or Host()
    out = host.log
    m, text = host.load()
    if m is None:
        return out
    hc, scheme = session.high_contrast(), session.color_scheme()
    now = time.time()
    t_shell.sync(m, hc, scheme, host, out)
    region = find_region(text or "")

    if hc and m.suspended != "high-contrast":
        if region is None:
            return out
        new_text = host.remove(text, m)
        m.suspended, m.suspended_at = "high-contrast", now
        m.restart_needed = _restart_list(now, m.flatpak)
        host.commit(new_text.encode() if not (m.created_file and new_text == "") else None, m)
        msg = "High contrast is on: the theme palette was removed for apps started from now on."
        if m.restart_needed:
            msg += f" Restart these to see high contrast: {_names(m.restart_needed)}."
        out.append(msg)
        session.notify("High contrast: restart open apps", msg)
        return out

    if not hc and m.suspended:
        mode = scheme or m.mode
        try:
            css, disclosed, name, colors = _generate(m.theme, mode)
        except HostError as e:
            if e.code != EXIT_MODE_UNAVAILABLE:
                raise
            out.append(str(e).replace("Nothing was generated or changed.", "") + f"Keeping {m.mode}.")
            session.notify("Theme mode unavailable", out[-1])
            mode = m.mode
            css, disclosed, name, colors = _generate(m.theme, mode)
        css = _adwaita_for_sync(m, mode, css, host, out)
        if css is None:
            return out
        new_region = build_region(m.id, css, name, mode)
        new_text, lead = host.insert(text, new_region)
        m.region, m.lead, m.mode, m.disclosed = new_region, lead, mode, disclosed
        m.suspended = m.suspended_at = None
        m.applied_at, m.restart_needed = now, _restart_list(now, m.flatpak)
        extra, acts = _follow(m, name, mode, colors, out)
        out.extend(host.commit(new_text.encode(), m, extra, actions=acts))
        out.append(f"High contrast is off: {name} ({mode}) is back for apps started from now on.")
        return out

    if not hc and not m.suspended and scheme and scheme != m.mode and region is not None:
        try:
            css, disclosed, name, colors = _generate(m.theme, scheme)
        except HostError as e:
            if e.code != EXIT_MODE_UNAVAILABLE:
                raise
            msg = str(e).replace("Nothing was generated or changed.", f"The {m.mode} palette stays in place.")
            out.append(msg)
            session.notify("Theme mode unavailable", msg)
            return out
        css = _adwaita_for_sync(m, scheme, css, host, out)
        if css is None:
            return out
        if region.text(text) != m.region:
            out.append("The managed region was edited by hand, so it was not switched to the new scheme.")
            return out
        new_region = build_region(m.id, css, name, scheme)
        new_text = text[: region.start] + new_region + text[region.end :]
        m.region, m.mode, m.disclosed, m.applied_at = new_region, scheme, disclosed, now
        m.restart_needed = _restart_list(now, m.flatpak)
        extra, acts = _follow(m, name, scheme, colors, out)
        out.extend(host.commit(new_text.encode(), m, extra, actions=acts))
        out.append(f"Switched to {name} ({scheme}) for apps started from now on.")
    return out


def reapply_from_settings(host: Host | None = None) -> list[str]:
    """Apply the applied theme again with the options in GSettings (the
    watcher's job when a key changes). Nothing applied: nothing to do. The
    watcher keeps itself (watcher=True); the `watcher` key takes effect at
    the next apply from the command line."""
    m, _ = (host or Host()).load(recover=False)
    if m is None:
        return []
    opts = settings.resolve({})
    mode = opts.pop("mode")
    opts["watcher"] = True
    return apply(m.theme, mode, host=host, **opts)


# A settings panel often writes several keys at once: wait this long after
# the last change before re-applying
SETTINGS_SETTLE = 0.5


def watch() -> int:
    """Run sync now and whenever high contrast or the color scheme changes;
    re-apply when theme-unifier's own settings change."""
    procs = [subprocess.Popen(["gsettings", "monitor", schema, key], stdout=subprocess.PIPE, text=True)
             for schema, key in ((session.HC_SCHEMA, session.HC_KEY), (session.SCHEME_SCHEMA, session.SCHEME_KEY))]
    settings_cmd = settings.monitor_command()
    settings_proc = subprocess.Popen(settings_cmd, stdout=subprocess.PIPE, text=True) if settings_cmd else None
    if settings_proc:
        procs.append(settings_proc)
    sel = selectors.DefaultSelector()
    for p in procs:
        sel.register(p.stdout, selectors.EVENT_READ)

    def run_reapply() -> None:
        # Drain the burst of changes, then apply once
        while any(key.fileobj is settings_proc.stdout and key.fileobj.readline()
                  for key, _ in sel.select(timeout=SETTINGS_SETTLE)):
            pass
        try:
            for line in reapply_from_settings(host=Host()):
                print(line, flush=True)
        except HostError as e:
            print(f"theme-unifier watch: {e}", file=sys.stderr, flush=True)

    def run_sync() -> bool:
        try:
            for line in sync(host=Host()):
                print(line, flush=True)
        except HostError as e:
            print(f"theme-unifier watch: {e}", file=sys.stderr, flush=True)
        return Host().paths.manifest.exists()

    try:
        if not run_sync():
            print("Nothing applied; watcher exiting.", flush=True)
            return 0
        while True:
            # Under systemd, revert stops the unit. A watcher started by hand
            # notices a revert within a few seconds.
            if not Host().paths.manifest.exists():
                print("Applied palette was reverted; watcher exiting.", flush=True)
                return 0
            for key, _ in sel.select(timeout=2):
                if not key.fileobj.readline():
                    return 1  # gsettings exited
                if settings_proc and key.fileobj is settings_proc.stdout:
                    run_reapply()
                    continue
                if not run_sync():
                    print("Applied palette was reverted; watcher exiting.", flush=True)
                    return 0
    finally:
        for p in procs:
            p.terminate()


@_operation
def flatpak_add(apps: list[str], host: Host | None = None) -> list[str]:
    host = host or Host()
    out = host.log
    m, text = host.load()
    if m is None:
        raise HostError("Nothing is applied yet. Run `theme-unifier apply THEME` first; Flatpak apps get the "
                        "same gtk.css.", EXIT_ERROR)
    extra, new_dirs, changed = t_flatpak.add_into(m, apps, out, strict=True)
    host.commit(None if text is None else text.encode(), m, extra, new_dirs)
    if changed:
        out.append("Restart these apps to pick up the colors. High contrast and light/dark switches apply to "
                   "them the same way as to other apps.")
    return out


@_operation
def flatpak_remove(apps: list[str], force: bool = False, host: Host | None = None) -> list[str]:
    host = host or Host()
    out = host.log
    m, text = host.load()
    if m is None:
        out.append("Nothing to remove: theme-unifier has not applied anything.")
        return out
    extra: dict[Path, bytes | None] = {}
    done = []
    for app in dict.fromkeys(apps):
        if app not in m.flatpak:
            out.append(f"{app}: not enabled by theme-unifier; nothing to remove.")
            continue
        ch = t_flatpak.plan_remove(app, m.flatpak[app], force, out)
        if ch.changed:
            extra[ch.path] = ch.after
        done.append(m.flatpak[app])
        del m.flatpak[app]
        if app not in m.flatpak_skip:
            m.flatpak_skip.append(app)  # `apply --flatpak all` won't add it back
        out.append(ch.note)
    if done:
        host.commit(None if text is None else text.encode(), m, extra,
                    remove_dirs=[Path(d) for r in done for d in reversed(r.get("dirs", []))])
    return out


@_operation
def flatpak_list(host: Host | None = None) -> list[str]:
    host = host or Host()
    m, _ = host.load()
    enabled = m.flatpak if m else {}
    rows = fp.installed_apps()
    if not rows:
        return ["No Flatpak apps installed (or `flatpak` isn't available)."]
    return [f"{'*' if app in enabled else ' '} {app}  ({runtime})" for app, runtime in rows] + \
        ["* = enabled with `theme-unifier flatpak add`"]
