"""Which light and dark palettes a theme actually provides (PLAN.md, D1).

Only the theme's own stylesheets count: gtk.css and, when shipped,
gtk-dark.css (for GTK's built-in themes, the matching stylesheets inside
libgtk-3). Each one is classified light or dark by the luminance of the
window background it produces, never by its file name.

A separately installed sibling theme (Breeze / Breeze-Dark) is reported as a
suggestion but never used: per decision D2 there is no automatic mode
fallback, and borrowing another theme's palette would be one.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .analyzer import analyze
from .loader import Theme, list_themes
from .palette import Palette

MODES = ("light", "dark")


@dataclass
class VariantSet:
    theme: str
    palettes: dict[str, Palette] = field(default_factory=dict)  # mode -> palette
    # Stylesheets that were read but not used, with the reason.
    skipped: list[str] = field(default_factory=list)
    # Other installed themes that provide a missing mode. Never used.
    suggestions: dict[str, list[str]] = field(default_factory=dict)
    # Mode of the theme's main stylesheet (gtk.css), which GTK uses by default.
    base_mode: str = ""

    @property
    def modes(self) -> list[str]:
        return [m for m in MODES if m in self.palettes]

    @property
    def category(self) -> str:
        if len(self.palettes) == 2:
            return "paired"
        return f"{self.modes[0]}-only" if self.palettes else "none"

    def missing_mode_message(self, mode: str) -> str:
        """The plain-language explanation required by D2."""
        have = " and ".join(self.modes) or "no usable"
        msg = (f"{self.theme} has no {mode} palette (it provides {have} only), "
               f"so {mode} mode is unavailable. Nothing was generated or changed.")
        others = self.suggestions.get(mode)
        if others:
            msg += f" Installed themes with a {mode} palette of the same family: {', '.join(others)}."
        return msg


def _mode_of(pal: Palette) -> str:
    return "dark" if pal.is_dark else "light"


def _family_siblings(theme: Theme) -> list[Theme]:
    base = theme.name
    for suffix in ("-Dark", "-dark", "-Darker", "-darker", "-Light", "-light"):
        if base.endswith(suffix):
            base = base[: -len(suffix)]
            break
    names = {base} | {base + s for s in ("-Dark", "-dark", "-Darker", "-darker", "-Light", "-light")}
    return [t for t in list_themes() if t.name in names and t.name != theme.name]


def discover(theme: Theme) -> VariantSet:
    vs = VariantSet(theme.name)
    candidates = [False] + ([True] if theme.has_dark_variant else [])
    for dark_sheet in candidates:
        pal = analyze(theme, dark=dark_sheet)
        mode = _mode_of(pal)
        sheet = "gtk-dark.css" if dark_sheet else "gtk.css"
        if not dark_sheet:
            vs.base_mode = mode
        if mode in vs.palettes:
            vs.skipped.append(f"{sheet}: also {mode}; kept {vs.palettes[mode].stylesheet}")
            continue
        vs.palettes[mode] = pal
    for mode in MODES:
        if mode in vs.palettes:
            continue
        for sib in _family_siblings(theme):
            try:
                if _mode_of(analyze(sib)) == mode:
                    vs.suggestions.setdefault(mode, []).append(sib.name)
            except (OSError, ValueError):
                continue
    return vs
