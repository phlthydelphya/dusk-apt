"""KDE and Qt apps (milestone 11): a qt5ct/qt6ct palette and KDE's colors.

Verified on Ubuntu 24.04 with KCalc 23.08 (Qt5) and Qt5/Qt6 probes, 2026-10-27:

- KDE apps need both: kdeglobals alone colors the views but leaves Qt's gray
  buttons; with the qt5ct/qt6ct palette as well, every part matches.
- The palette is used only when QT_QPA_PLATFORMTHEME=qt5ct. The qt6ct plugin
  answers to that name too, so one value covers Qt5 and Qt6. A Qt app
  without the plugin (a Flatpak, Qt without qt6ct) falls back to the
  desktop's default, as if the variable weren't set.
- On GNOME that default is Qt's gtk3 platform theme, which gives Qt apps
  GNOME's font, icon theme and GTK file dialogs. qt5ct/qt6ct with no
  settings gives a different font and no icon theme, so apply also writes
  those three settings from GNOME's when the user has none of their own.

What the tool owns: the two scheme files and the environment.d file (whole
files, in Manifest.files) and the keys it set in qt5ct.conf, qt6ct.conf and
kdeglobals (inikeys.py: revert puts back only keys that still hold our value).
"""

from __future__ import annotations

import glob
import os
from pathlib import Path

from .. import inikeys, qtcolors, session
from ..generate import generate
from ..host import HostError, _read, config_home, sha256
from ..loader import find_theme
from ..variants import discover

ENV = "QT_QPA_PLATFORMTHEME"
ENV_VALUE = "qt5ct"
SCHEME = "theme-unifier.conf"


def _plugin(major: int, name: str) -> bool:
    dirs = [f"/usr/lib/*/qt{major}/plugins", f"/usr/lib/qt{major}/plugins", f"/usr/lib64/qt{major}/plugins"]
    if major == 5:
        dirs.append("/usr/lib/qt/plugins")  # Arch's Qt5
    if os.environ.get("THEME_UNIFIER_QT_PLUGINS") is not None:  # tests: <dir>/qtN/platformthemes/
        dirs = [os.path.join(os.environ["THEME_UNIFIER_QT_PLUGINS"], f"qt{major}")]
    return any(glob.glob(os.path.join(d, "platformthemes", name)) for d in dirs)


def plugins() -> dict[int, bool]:
    """Which qtNct platform theme plugins are installed: {5: bool, 6: bool}."""
    return {5: _plugin(5, "libqt5ct.so"), 6: _plugin(6, "libqt6ct.so")}


def gtk_dialogs(major: int) -> bool:
    """Qt's gtk3 platform theme, which qtNct's standard_dialogs=gtk3 uses."""
    return _plugin(major, "libqgtk3.so")


def conf_path(major: int) -> Path:
    return config_home() / f"qt{major}ct" / f"qt{major}ct.conf"


def scheme_path(major: int) -> Path:
    return config_home() / f"qt{major}ct" / "colors" / SCHEME


def kdeglobals_path() -> Path:
    return config_home() / "kdeglobals"


def env_path() -> Path:
    return config_home() / "environment.d" / "90-theme-unifier-qt.conf"


# --- Kvantum ----------------------------------------------------------------------------
# QT_STYLE_OVERRIDE wins over qt5ct/qt6ct's `style=` for every Qt app, and a Kvantum theme
# draws its own colors in many places, so the palette written here may not show.

STYLE_ENV = "QT_STYLE_OVERRIDE"


def style_override() -> str | None:
    """The session's QT_STYLE_OVERRIDE, or None when unset or empty."""
    return os.environ.get(STYLE_ENV) or None


def kvantum_theme() -> str | None:
    """The Kvantum theme named in ~/.config/Kvantum/kvantum.kvconfig, if readable."""
    return inikeys.get(_read(config_home() / "Kvantum" / "kvantum.kvconfig"), "General", "theme")


def _is_kvantum(style: str | None) -> bool:
    return bool(style) and style.lower().startswith("kvantum")


def _environment_d_dirs() -> list[Path]:
    """Where systemd reads environment.d files, user's first (it shadows /etc by file name)."""
    system = os.environ.get("THEME_UNIFIER_ENVIRONMENT_D")  # tests: stand-in for /etc/environment.d
    return [config_home() / "environment.d", Path(system) if system is not None else Path("/etc/environment.d")]


def style_override_source(value: str) -> Path | None:
    """The environment.d file that sets QT_STYLE_OVERRIDE=<value>, when one can be found
    (the last file by name wins, as in systemd). None when none of them sets that value."""
    files: dict[str, Path] = {}
    for d in reversed(_environment_d_dirs()):  # the user's directory shadows /etc
        try:
            for f in d.glob("*.conf"):
                files[f.name] = f
        except OSError:
            continue
    found = None
    for name in sorted(files):
        data = _read(files[name])
        for line in (data or b"").decode("utf-8", "replace").splitlines():
            key, sep, val = line.strip().partition("=")
            if sep and key.strip() == STYLE_ENV:
                found = (files[name], val.strip().strip("\"'"))
    return found[0] if found and found[1] == value else None


def kvantum_draws() -> dict | None:
    """Is Kvantum set to draw Qt apps? {"via": "env" | "conf", "value", "theme", "source"} or None.
    A QT_STYLE_OVERRIDE decides alone (Fusion there means no Kvantum, even if a qtNct conf says
    kvantum); otherwise the style in qt5ct.conf or qt6ct.conf does."""
    override = style_override()
    if override:
        if not _is_kvantum(override):
            return None
        return {"via": "env", "value": override, "theme": kvantum_theme(), "source": style_override_source(override)}
    for major in (6, 5):
        style = inikeys.get(_read(conf_path(major)), "Appearance", "style")
        if _is_kvantum(style):
            return {"via": "conf", "value": style, "theme": kvantum_theme(), "source": conf_path(major)}
    return None


def kvantum_note() -> str | None:
    """A plain warning that Kvantum may replace the palette, or None when it isn't drawing Qt."""
    k = kvantum_draws()
    if k is None:
        return None
    from .changes import home
    drawer = f"the Kvantum theme {k['theme']}" if k["theme"] else "Kvantum"
    if k["via"] == "env":
        where = f"your session sets {STYLE_ENV}={k['value']}"
        if k["source"]:
            where += f" (from {home(k['source'])})"
        fix = (f"To see the palette, pick a Kvantum theme that follows it, or remove the {STYLE_ENV} variable"
               + (f" (it is set in {home(k['source'])}; theme-unifier doesn't edit it)." if k["source"] else "."))
    else:
        where = f"{home(k['source'])} sets style={k['value']}"
        fix = ("To see the palette, pick a Kvantum theme that follows it, or choose another style in "
               f"{k['source'].name}.")
    return (f"Qt apps may not show these colors: {where}, so {drawer} draws every Qt app and can replace the "
            f"theme's colors with its own. {fix}")


def _pango_to_qfont(desc: str | None, major: int) -> str | None:
    """A GNOME font ("Ubuntu Sans Bold 11") as QFont::toString() for Qt5 or Qt6."""
    if not desc:
        return None
    words = desc.split()
    try:
        size = float(words[-1])
    except (ValueError, IndexError):
        return None
    words = words[:-1]
    weights = {"Light": (25, 300), "Medium": (57, 500), "Bold": (75, 700), "Regular": None, "Book": None}
    weight, italic = (50, 400), 0
    while words and (words[-1] in weights or words[-1] in ("Italic", "Oblique")):
        w = words.pop()
        if w in ("Italic", "Oblique"):
            italic = 1
        elif weights[w]:
            weight = weights[w]
    if not words:
        return None
    size_s = f"{size:g}"
    if major == 5:
        return f'"{" ".join(words)},{size_s},-1,5,{weight[0]},{italic},0,0,0,0"'
    return f'"{" ".join(words)},{size_s},-1,5,{weight[1]},{italic},0,0,0,0,0,0,0,0,0,1"'


def _qtct_keys(major: int, pristine: bytes | None) -> dict[str, dict[str, str]]:
    """The palette keys, and GNOME's font, icon theme and dialogs where the user set none."""
    keys = {"Appearance": {"custom_palette": "true", "color_scheme_path": str(scheme_path(major))}}
    icons = session.interface_string("icon-theme")
    if icons and inikeys.get(pristine, "Appearance", "icon_theme") is None:
        keys["Appearance"]["icon_theme"] = icons
    if gtk_dialogs(major) and inikeys.get(pristine, "Appearance", "standard_dialogs") is None:
        keys["Appearance"]["standard_dialogs"] = "gtk3"
    fonts = {}
    for key, gkey in (("general", "font-name"), ("fixed", "monospace-font-name")):
        value = _pango_to_qfont(session.interface_string(gkey), major)
        if value and inikeys.get(pristine, "Fonts", key) is None:
            fonts[key] = value
    if fonts:
        keys["Fonts"] = fonts
    return keys


def _kde_keys(gen, pristine: bytes | None) -> dict[str, dict[str, str]]:
    """The KDE color scheme, and GNOME's font and icon theme where the user set
    none. Only the KDE platform theme reads the font and icon keys: Flatpak KDE
    apps get it (targets/flatpak.py); on the host, qt5ct's own keys win. The
    Qt5 font format is used because Qt6 reads it too (verified on Qt 6.11)."""
    keys = qtcolors.kde_colors(gen)
    general = {}
    for key, gkey in (("font", "font-name"), ("fixed", "monospace-font-name")):
        value = _pango_to_qfont(session.interface_string(gkey), 5)
        if value and inikeys.get(pristine, "General", key) is None:
            general[key] = value.strip('"')
    if general:
        keys["General"] = general
    icons = session.interface_string("icon-theme")
    if icons and inikeys.get(pristine, "Icons", "Theme") is None:
        keys["Icons"] = {"Theme": icons}
    return keys


def _undo(old: dict, force: bool, out: list[str] | None) -> dict[Path, bytes | None]:
    """Every key-edited file as it was before the tool's keys (the "pristine"
    content). Keys changed since: HostError, or with `out`, reported and left."""
    files = {}
    for path_s, rec in old.get("keys", {}).items():
        path = Path(path_s)
        cur = _read(path)
        before, kept = inikeys.unset(cur, rec, force)
        if kept and out is None:
            raise HostError(f"{path}: {', '.join(kept)} changed after theme-unifier set them. Nothing was changed; "
                            "use --force to set them again, or --qt off to leave Qt apps alone.")
        if kept:
            out.append(f"Conflict: {path}: {', '.join(kept)} changed after theme-unifier set them, so they were "
                       "left as they are.")
        files[path] = before
    return files


def _skip_reason(old: dict) -> str | None:
    if "KDE" in os.environ.get("XDG_CURRENT_DESKTOP", "").split(":"):
        return "this is a Plasma session, and Plasma sets Qt and KDE colors itself"
    have = plugins()
    if not any(have.values()):
        return ("qt5ct and qt6ct aren't installed. Install them with `sudo apt install qt5ct qt6ct`, then "
                "apply again")
    env = os.environ.get(ENV)
    if env and env not in ("qt5ct", "qt6ct") and not old.get("env"):
        return f"{ENV} is set to {env!r} in your session, so Qt apps use that instead"
    return None


def plan(theme_ref: str, mode: str, choice: str, old: dict, force: bool
         ) -> tuple[dict[Path, bytes], dict[Path, bytes | None], dict, str]:
    """Whole files to own (passed to gtk4.changes), key-edited files' new
    content, the new record, and a note. Raises HostError on a key changed
    since the last apply (unless force)."""
    if choice == "off":
        # --qt off is the way out of a Qt conflict: a key changed since the
        # last apply is reported and left as the user set it, not an error
        conflicts: list[str] = []
        pristine = _undo(old, force, conflicts)
        edits = {p: d for p, d in pristine.items() if d != _read(p)}
        note = " ".join(["KDE/Qt apps: left alone (--qt off).", *conflicts])
        return {}, edits, {"choice": choice}, note
    pristine = _undo(old, force, None)
    reason = _skip_reason(old)
    if reason:
        edits = {p: d for p, d in pristine.items() if d != _read(p)}
        return {}, edits, {"choice": choice}, f"KDE/Qt apps: {reason}."

    theme = find_theme(theme_ref)
    gen = generate(discover(theme).palettes[mode], mode)
    scheme = qtcolors.qtct_scheme(gen).encode()
    owned: dict[Path, bytes] = {}
    edits: dict[Path, bytes | None] = {}
    rec: dict = {"choice": choice, "mode": mode, "keys": {}, "majors": []}

    def edit(path: Path, values: dict[str, dict[str, str]]) -> None:
        base = pristine[path] if path in pristine else _read(path)
        data, r = inikeys.set_keys(base, values)
        r["created"] = base is None
        rec["keys"][str(path)] = r
        if data != _read(path):
            edits[path] = data

    for major, ok in plugins().items():
        if not ok:
            continue
        rec["majors"].append(major)
        owned[scheme_path(major)] = scheme
        base = pristine[conf_path(major)] if conf_path(major) in pristine else _read(conf_path(major))
        edit(conf_path(major), _qtct_keys(major, base))
    base = pristine[kdeglobals_path()] if kdeglobals_path() in pristine else _read(kdeglobals_path())
    edit(kdeglobals_path(), _kde_keys(gen, base))
    for path, before in pristine.items():  # files no longer edited (a Qt major uninstalled)
        if str(path) not in rec["keys"] and before != _read(path):
            edits[path] = before

    env = os.environ.get(ENV)
    if old.get("env") or env not in ("qt5ct", "qt6ct"):
        owned[env_path()] = f"{ENV}={ENV_VALUE}\n".encode()
        rec["env"] = True
    relogin = env not in ("qt5ct", "qt6ct")
    names = " and ".join(f"Qt{m} (qt{m}ct)" for m in rec["majors"])
    note = (f"KDE/Qt apps: {theme.name} ({mode}) colors for {names} and KDE apps (kdeglobals); the font, icons "
            "and file dialogs stay GNOME's.")
    if relogin:
        note += f" Log out and back in once: Qt apps pick the palette up from {env_path().name} at login."
    if 5 in rec["majors"] and 6 not in rec["majors"]:
        note += " Qt6 apps keep their default colors until qt6ct is installed (`sudo apt install qt6ct`)."
    warning = kvantum_note()
    if warning:
        note += " " + warning
    return owned, edits, rec, note


def restore(old: dict, force: bool, out: list[str]) -> dict[Path, bytes | None]:
    """Key-edited files with the tool's keys taken out (revert)."""
    return {p: d for p, d in _undo(old, force, out).items() if d != _read(p)}


def owns(path: Path, rec: dict | None = None) -> bool:
    """Is `path` one of the Qt target's files (schemes, environment.d, key-edited)?"""
    return (path in (scheme_path(5), scheme_path(6), conf_path(5), conf_path(6), kdeglobals_path(), env_path())
            or str(path) in (rec or {}).get("keys", {}))


def describe(path: Path, data: bytes | None, rec: dict) -> str:
    """One Qt file change, in words (apply --dry-run)."""
    from .changes import home
    if path == env_path():
        return (f"File: {'write' if data is not None else 'remove'} {home(path)} ({ENV}={ENV_VALUE} for Qt apps, "
                "from your next login).")
    if path in (scheme_path(5), scheme_path(6)):
        return f"File: {'write' if data is not None else 'remove'} the Qt color scheme {home(path)}."
    r = rec.get("keys", {}).get(str(path))
    what = "KDE colors, font and icon theme" if path == kdeglobals_path() else "palette, font, icons and dialogs"
    if r is None:
        return f"File: take theme-unifier's keys back out of {home(path)}."
    verb = "create" if r.get("created") and _read(path) is None else "set keys in"
    return f"File: {verb} {home(path)} ({len(r['keys'])} keys: {what}; other keys are left alone)."


def status(rec: dict, files: dict[str, str]) -> list[str]:
    if not rec.get("keys"):
        return []
    out = [f"KDE/Qt apps: {rec.get('mode')} colors for " + ", ".join(f"Qt{m}" for m in rec.get("majors", []))
           + (", KDE" if str(kdeglobals_path()) in rec["keys"] else "") + "."]
    for path_s, r in rec["keys"].items():
        data = _read(Path(path_s))
        edited = [f"[{k['group']}] {k['key']}" for k in r["keys"]
                  if inikeys.get(data, k["group"], k["key"]) != k["after"]]
        out.append(f"  {path_s}: {len(r['keys'])} keys, " + (f"changed since: {', '.join(edited)}" if edited
                                                             else "intact"))
    for path_s, sha in files.items():
        if owns(Path(path_s), rec):
            cur = _read(Path(path_s))
            out.append(f"  {path_s}: " + ("missing" if cur is None else "intact" if sha256(cur) == sha else "edited"))
    env = os.environ.get(ENV)
    if rec.get("env") and env not in ("qt5ct", "qt6ct"):
        out.append(f"  {ENV} isn't set in this session yet: log out and back in.")
    warning = kvantum_note()
    if warning:
        out.append("  " + warning)
    return out
