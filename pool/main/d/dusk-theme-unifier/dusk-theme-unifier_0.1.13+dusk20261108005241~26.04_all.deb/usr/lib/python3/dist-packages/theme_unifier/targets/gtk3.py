"""GTK3 apps: the session's GTK theme setting, and the copy Flatpak apps can see."""

from __future__ import annotations

import os
from pathlib import Path

from .. import flatpak as fp
from .. import session
from ..host import HostError, _read
from ..loader import find_theme

def activate(theme_name: str, choice: str, old: dict, out: list[str]) -> tuple[dict, list[dict]]:
    """Plan setting the session's GTK theme (GTK3 apps; plain GTK4 apps follow
    it too) to the applied theme, remembering what it was."""
    if choice == "off":
        out.append("GTK3 apps: theme setting left alone (--gtk3 off).")
        return {}, restore(old)
    cur = session.gtk_theme()
    before = old["before"] if old.get("changed") else cur
    if cur == theme_name:
        out.append(f"GTK3 apps: already set to {theme_name}.")
        return {"name": theme_name, "before": before, "changed": bool(old.get("changed"))}, []
    return {"name": theme_name, "before": before, "changed": True}, [
        {"kind": "setting", "key": "gtk-theme", "before": cur, "after": theme_name, "label": "GTK3 apps: the GTK theme",
         "done": f"GTK3 apps: GTK theme set to {theme_name} (was {cur}). Revert sets it back."}]


def restore(rec: dict, force: bool = False) -> list[dict]:
    if not rec.get("changed"):
        return []
    return [{"kind": "setting", "key": "gtk-theme", "before": rec["name"], "after": rec["before"], "force": force,
             "label": "GTK3 apps: the GTK theme", "done": f"GTK3 apps: GTK theme set back to {rec['before']}."}]


def copy_for_flatpak(theme_ref: str, owned: dict[str, str] | None = None) -> dict[Path, bytes]:
    """A copy of a theme's GTK3 folder in ~/.local/share/themes, which
    Flatpak apps can be given (they can't see /usr/share/themes). Empty when
    the theme already lives there, or no Flatpak app is installed. A theme in
    ~/.themes is copied too: the override only exposes ~/.local/share/themes."""
    theme = find_theme(theme_ref)
    data_home = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")
    themes = data_home / "themes"
    if themes.exists() and theme.path.resolve().is_relative_to(themes.resolve()):
        # A prior apply may have created this very copy. Keep its owned files
        # in the desired set; otherwise the next apply would delete the theme
        # that find_theme just found.
        source = theme.path / "gtk-3.0"
        previous = [Path(p) for p in (owned or {}) if Path(p).is_relative_to(source)]
        if previous:
            files = {p: _read(p) for p in previous}
            missing = next((p for p, data in files.items() if data is None), None)
            if missing:
                raise HostError(f"The managed Flatpak GTK3 copy is missing {missing}. Nothing was changed.")
            return files
        return {}
    try:
        if not fp.installed_apps():
            return {}
    except HostError:
        return {}
    src = theme.path / "gtk-3.0"
    dest = data_home / "themes" / theme.name / "gtk-3.0"
    files = {}
    for f in sorted(src.rglob("*")):
        if f.is_file():  # follows symlinks: the copy must work without the original
            files[dest / f.relative_to(src)] = f.read_bytes()
    return files
