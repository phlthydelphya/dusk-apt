"""Generate libadwaita CSS from a palette.

The output redefines libadwaita's documented named colors with
@define-color. On libadwaita 1.5 that is the whole mechanism. On 1.6+ most
CSS variables (--window-bg-color, ...) follow the named colors, but the
standalone colors (accent, error, warning, success) are derived from the
*_bg_color values, so `css(css_vars=True)` also sets those variables in a
:root block. Checked on libadwaita 1.10 (docs/evidence/m2/adw-roles-*.json).

Names whose value is not read from the theme are disclosed (decision D4):
every generated name records the palette role it came from, and names the
generator has to compute itself are marked as derived with the reason.
Named colors with no palette role are left to libadwaita and listed too.

Text colors that would render below their contrast target are adjusted
(decision 2026-10-26, "adjust failing text, disclose it"): the foreground is
mixed toward white or black, which keeps its hue, by the smallest amount
that reaches the target. Backgrounds are never changed. Every adjusted
color is disclosed with its original value and both ratios. Targets: 4.5:1
for text (WCAG SC 1.4.3) and 3:1 for disabled text (project policy, D4).
"""

from __future__ import annotations

from dataclasses import dataclass, field

from . import __version__
from .colors import Color, contrast_ratio, mix
from .palette import Palette

# libadwaita name -> palette role it is taken from.
DIRECT: dict[str, str] = {
    "window_bg_color": "window_bg",
    "window_fg_color": "window_fg",
    "view_bg_color": "view_bg",
    "view_fg_color": "view_fg",
    "accent_bg_color": "accent_bg",
    "accent_fg_color": "accent_fg",
    "accent_color": "accent",
    "headerbar_bg_color": "headerbar_bg",
    "headerbar_fg_color": "headerbar_fg",
    "headerbar_backdrop_color": "headerbar_backdrop",
    "sidebar_bg_color": "sidebar_bg",
    "sidebar_fg_color": "sidebar_fg",
    "card_bg_color": "card_bg",
    "popover_bg_color": "popover_bg",
    "dialog_bg_color": "dialog_bg",
    "destructive_bg_color": "destructive_bg",
    "destructive_color": "error",
    "error_color": "error",
    "warning_color": "warning",
    "success_color": "success",
}

# Foreground names with no palette role of their own: taken from the text
# role that sits on the same kind of surface.
PAIRED_FG: dict[str, tuple[str, str]] = {
    "card_fg_color": ("view_fg", "cards hold view content"),
    "popover_fg_color": ("window_fg", "popovers use window text in GTK3 themes"),
    "dialog_fg_color": ("window_fg", "dialogs use window text in GTK3 themes"),
}

# libadwaita names deliberately left at libadwaita's defaults.
NOT_OVERRIDDEN = {
    "headerbar_border_color": "GTK3 has no equivalent; libadwaita draws it with transparency",
    "headerbar_shade_color": "shadow, not a theme color",
    "sidebar_backdrop_color": "no GTK3 equivalent",
    "secondary_sidebar_bg_color": "no GTK3 equivalent",
    "success_bg_color": "GTK3 themes define success only as a text color",
    "warning_bg_color": "GTK3 themes define warning only as a text color",
    "error_bg_color": "GTK3 themes define error only as a text color",
    "shade_color": "shadow, not a theme color",
}

WCAG_TEXT = 4.5  # WCAG 2.2 SC 1.4.3, normal-size text
POLICY_DISABLED = 3.0  # project policy (PLAN.md D4), not WCAG
# Aim slightly above the target so 8-bit rounding and antialiasing in the
# rendered check can't push a just-passing color below it.
MARGIN = 1.03
DISABLED_OPACITY = 0.5  # libadwaita 1.5 $disabled_opacity (0.4 in high contrast)

# Text pairs libadwaita draws: foreground name -> background names.
TEXT_PAIRS: dict[str, tuple[str, ...]] = {
    "window_fg_color": ("window_bg_color",),
    "view_fg_color": ("view_bg_color",),
    "headerbar_fg_color": ("headerbar_bg_color",),
    "sidebar_fg_color": ("sidebar_bg_color",),
    "card_fg_color": ("card_bg_color",),
    "popover_fg_color": ("popover_bg_color",),
    "dialog_fg_color": ("dialog_bg_color",),
    "accent_color": ("window_bg_color", "view_bg_color"),
    "error_color": ("window_bg_color", "view_bg_color"),
    "destructive_color": ("window_bg_color", "view_bg_color"),
    "warning_color": ("window_bg_color", "view_bg_color"),
    "success_color": ("window_bg_color", "view_bg_color"),
    "accent_fg_color": ("accent_bg_color",),
    "destructive_fg_color": ("destructive_bg_color",),
}


@dataclass
class Item:
    name: str
    color: Color
    role: str  # palette role, or "" when computed here
    source: str  # where the palette got it, or how it was computed
    confidence: str
    derived: bool  # not read from the theme as-is
    reason: str = ""
    adjusted_from: Color | None = None  # theme value before a contrast adjustment


# Standalone colors (text and icons on window or view backgrounds). libadwaita
# 1.6+ computes them as CSS variables from the matching *_bg_color with
# oklab(from bg min(l, 0.5) a b) (light) and ignores these named colors
# (libadwaita 1.10 src/stylesheet/_colors.scss).
STANDALONE = ("accent_color", "destructive_color", "success_color", "warning_color", "error_color")


@dataclass
class Generated:
    theme: str
    mode: str
    items: list[Item] = field(default_factory=list)
    not_overridden: dict[str, str] = field(default_factory=lambda: dict(NOT_OVERRIDDEN))
    # Pairs still below target after adjustment: (fg, bg, ratio, target).
    unresolved: list[tuple[str, str, float, float]] = field(default_factory=list)

    def __getitem__(self, name: str) -> Item:
        return next(i for i in self.items if i.name == name)

    @property
    def disclosed(self) -> list[Item]:
        """Items the user must be told were not read from the theme as-is."""
        return [i for i in self.items if i.derived or i.confidence == "low"]

    def css(self, css_vars: bool = False) -> str:
        """libadwaita CSS. With `css_vars`, also set the standalone colors as
        CSS variables, which libadwaita 1.6+ reads instead of the named colors
        (it derives them from the *_bg_color values). Only GTK 4.16+ parses
        `:root` and custom properties; GTK 4.14 prints a warning for them."""
        lines = [
            f"/* Generated by theme-unifier {__version__} from the GTK3 theme",
            f"   \"{self.theme}\" ({self.mode} palette). Colors only.",
            "   Values marked DERIVED were not read from the theme as-is. */",
            "",
        ]
        width = max(len(i.name) for i in self.items)
        for i in self.items:
            note = f"  /* {i.role or 'computed'}: {i.source}"
            if i.adjusted_from is not None:
                note += f"; theme value {i.adjusted_from.to_css()}"
            if i.derived or i.confidence == "low":
                note += f"; DERIVED, {i.reason}" if i.derived else f"; LOW CONFIDENCE"
            note += " */"
            lines.append(f"@define-color {i.name:<{width}} {i.color.to_css()};{note}")
        standalone = [i for i in self.items if i.name in STANDALONE]
        if css_vars and standalone:
            lines += ["", "/* libadwaita 1.6+ ignores the five named colors above and derives them from",
                      "   accent/destructive/success/warning/error_bg_color, so they are set here too. */",
                      ":root {"]
            lines += [f"  --{i.name.replace('_', '-')}: {i.color.to_css()};" for i in standalone]
            lines.append("}")
        return "\n".join(lines) + "\n"


def _is_derived(source: str) -> bool:
    return source.startswith(("derived", "inherited", "default"))


def _readable_fg(bg: Color) -> tuple[Color, str]:
    white, black = Color(1, 1, 1), Color(0, 0, 0, 0.8)
    if contrast_ratio(white, bg) >= contrast_ratio(black.over(bg), bg):
        return white, "white has the higher contrast on destructive_bg"
    return black, "dark text has the higher contrast on destructive_bg"


def _ratio(fg: Color, bg: Color, base: Color, opacity: float = 1.0) -> float:
    """Contrast of fg drawn on bg, both composited over the opaque base."""
    bg = bg.over(base)
    fg = Color(fg.r, fg.g, fg.b, fg.a * opacity)
    return contrast_ratio(fg.over(bg), bg)


def _disabled_ratios(fg: Color, win: Color) -> tuple[float, float]:
    """Disabled label and disabled button contrast, as libadwaita 1.5 draws them.

    A disabled widget is drawn at DISABLED_OPACITY. A button's own background
    is alpha(currentColor, 0.1), so the whole button fades together.
    """
    label = _ratio(fg, win, win, DISABLED_OPACITY)
    btn_bg = Color(fg.r, fg.g, fg.b, fg.a * 0.1).over(win)
    faded_bg = Color(btn_bg.r, btn_bg.g, btn_bg.b, DISABLED_OPACITY).over(win)
    text = fg.over(btn_bg)
    faded_fg = Color(text.r, text.g, text.b, DISABLED_OPACITY).over(win)
    return label, contrast_ratio(faded_fg, faded_bg)


def _adjust(fg: Color, ok) -> tuple[Color, bool]:
    """Smallest mix of fg toward white or black for which ok(color) holds.

    Alpha is dropped first (an 80% text color becomes the opaque color it
    renders as only when that's needed). Returns the best color found and
    whether it reached the target.
    """
    best = None
    for end in (Color(1, 1, 1, 1), Color(0, 0, 0, 1)):
        start = Color(fg.r, fg.g, fg.b, 1.0) if fg.a < 1 and not ok(Color(fg.r, fg.g, fg.b, 1.0)) else fg
        if not ok(mix(start, end, 1.0)):
            continue
        lo, hi = 0.0, 1.0
        for _ in range(30):
            mid = (lo + hi) / 2
            lo, hi = (lo, mid) if ok(mix(start, end, mid)) else (mid, hi)
        if best is None or hi < best[0]:
            best = (hi, mix(start, end, hi))
    return (best[1], True) if best else (fg, False)


def _enforce_contrast(gen: Generated) -> None:
    win = gen["window_bg_color"].color

    def fix(item: Item, ok, why: str) -> None:
        if ok(item.color):
            return
        new, reached = _adjust(item.color, ok)
        if not reached:
            return
        if item.adjusted_from is None:
            item.adjusted_from = item.color
        item.color = new
        item.derived = True
        item.reason = "; ".join(r for r in (item.reason, why) if r)

    # Disabled text first: it can only be fixed through the window text color.
    fg = gen["window_fg_color"]
    before = min(_disabled_ratios(fg.color, win))
    fix(fg, lambda c: min(_disabled_ratios(c, win)) >= POLICY_DISABLED * MARGIN,
        f"adjusted so disabled text reaches {POLICY_DISABLED}:1 (was {before:.2f}:1)")
    for name, (role, _) in PAIRED_FG.items():
        if role == "window_fg" and fg.adjusted_from is not None:
            item = gen[name]
            item.adjusted_from, item.color = item.color, fg.color
            item.reason += "; follows the adjusted window_fg_color"

    for name, bgs in TEXT_PAIRS.items():
        item = gen[name]
        bg_colors = [gen[b].color for b in bgs]
        worst = min(_ratio(item.color, b, win) for b in bg_colors)
        fix(item, lambda c: all(_ratio(c, b, win) >= WCAG_TEXT * MARGIN for b in bg_colors),
            f"adjusted to reach {WCAG_TEXT}:1 on {', '.join(bgs)} (was {worst:.2f}:1)")

    for name, bgs in TEXT_PAIRS.items():
        for b in bgs:
            r = _ratio(gen[name].color, gen[b].color, win)
            if r < WCAG_TEXT:
                gen.unresolved.append((name, b, round(r, 2), WCAG_TEXT))
    for kind, r in zip(("disabled label", "disabled button"), _disabled_ratios(gen["window_fg_color"].color, win)):
        if r < POLICY_DISABLED:
            gen.unresolved.append((kind, "window_bg_color", round(r, 2), POLICY_DISABLED))


def generate(pal: Palette, mode: str) -> Generated:
    gen = Generated(pal.theme, mode)
    for name, role in DIRECT.items():
        e = pal.colors[role]
        derived = _is_derived(e.source)
        reason = "; ".join(e.notes) if derived else ""
        gen.items.append(Item(name, e.color, role, e.source, e.confidence, derived, reason))
    for name, (role, why) in PAIRED_FG.items():
        e = pal.colors[role]
        gen.items.append(Item(name, e.color, role, e.source, e.confidence, True,
                              f"no {name.removesuffix('_color')} role in GTK3; {why}"))
    fg, why = _readable_fg(pal["destructive_bg"])
    gen.items.append(Item("destructive_fg_color", fg, "", "computed", "low", True, why))
    _enforce_contrast(gen)
    return gen
