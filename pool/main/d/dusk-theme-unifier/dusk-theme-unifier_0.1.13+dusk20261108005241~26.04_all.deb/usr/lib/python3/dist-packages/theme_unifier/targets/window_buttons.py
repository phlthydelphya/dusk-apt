"""Plan and restore the GNOME window-button layout owned by theme-unifier."""

from __future__ import annotations

import configparser
from pathlib import Path

from .. import session
from ..loader import find_theme, theme_search_dirs

BUTTONS = {"close", "minimize", "maximize", "menu", "appmenu"}


def theme_layout(theme_ref: str) -> str | None:
    """Look for ButtonLayout, including behind a partial theme-unifier copy."""
    theme = find_theme(theme_ref)
    candidates = [theme.path]
    if not Path(theme_ref).expanduser().is_dir():
        candidates += [base / theme.name for base in theme_search_dirs() if base / theme.name != theme.path]
    for path in candidates:
        config = configparser.ConfigParser(interpolation=None, strict=False)
        try:
            config.read(path / "index.theme", encoding="utf-8")
            value = config.get("X-GNOME-Metatheme", "ButtonLayout", fallback=None)
        except (OSError, UnicodeError, configparser.Error):
            continue
        if value is not None:
            return value if valid_layout(value) else None
    return None


def valid_layout(value: str) -> bool:
    if value.count(":") != 1:
        return False
    buttons = [v.strip() for side in value.split(":") for v in side.split(",") if v.strip()]
    return bool(buttons) and len(buttons) == len(set(buttons)) and all(b in BUTTONS for b in buttons)


def restore(rec: dict, force: bool = False) -> list[dict]:
    if not rec.get("changed"):
        return []
    return [{"kind": "setting", "key": "button-layout", "before": rec["layout"], "after": rec["before"],
             "force": force, "label": "Window buttons: layout", "done": "Window buttons: layout restored."}]


def activate(layout: str | None, old: dict, out: list[str]) -> tuple[dict, list[dict]]:
    if layout is None:
        return {}, restore(old)
    cur = session.button_layout()
    if cur is None:
        out.append("Window buttons: layout setting is unavailable; left alone.")
        return dict(old), []
    before = old["before"] if old.get("changed") else cur
    if cur == layout:
        return {"layout": layout, "before": before, "changed": bool(old.get("changed"))}, []
    return {"layout": layout, "before": before, "changed": True}, [
        {"kind": "setting", "key": "button-layout", "before": cur, "after": layout,
         "label": "Window buttons: layout", "done": f"Window buttons: layout set to {layout}."}]
