"""Unify GTK3 themes across libadwaita, Flatpak, Qt and more."""

__version__ = "0.1.13"
