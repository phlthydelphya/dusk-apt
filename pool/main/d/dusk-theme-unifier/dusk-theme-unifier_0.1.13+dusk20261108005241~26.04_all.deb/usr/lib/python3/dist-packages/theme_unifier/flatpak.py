"""Per-app Flatpak access to the managed gtk.css (milestone 5, D5 and D7).

A Flatpak app reads gtk.css from its own config folder
(~/.var/app/<id>/config/gtk-4.0/), not from ~/.config. Flatpak mounts the
host folder there only for an app granted `xdg-config/gtk-4.0` (verified on
Flatpak 1.14.6: `xdg-config` or `home` don't do it). So enabling an app means
adding one entry, ENTRY, to its user override file.

Rules:

- Apply runs `flatpak override --user` (against a scratch copy, so the change
  goes through the same journal as gtk.css). The result must turn back into
  the original bytes when ENTRY is taken out again. If Flatpak would also
  rewrite something else, such as dropping a comment, the app is refused.
- Revert takes out ENTRY only, by editing that one line of the override
  file (D7). `flatpak override --nofilesystem` can't do this: it adds a deny
  entry instead of removing ours.
- An app that already has access (its own permissions or the user's
  override) gets nothing added, so revert won't take anything away from it.
- An app whose access was denied, by the user or an administrator, is
  refused rather than overridden.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

from .host import EXIT_ERROR, HostError, _read

TARGET = "xdg-config/gtk-4.0"
ENTRY = TARGET + ":ro"
# GTK3 Flatpak apps can't see system themes. Flatpak mounts the host's
# ~/.local/share/themes at the app's own data folder for this entry, where
# GTK3 looks (verified with a GTK3 probe in a sandbox, 2026-10-27).
THEMES = "xdg-data/themes"
THEMES_ENTRY = THEMES + ":ro"
# KDE apps on the KDE runtime (PLAN.md 11): the runtime's KDE platform theme
# reads the host's kdeglobals, which Flatpak mounts for this entry (verified
# with Flathub KCalc on org.kde.Platform 6.11, 2026-10-27). Without that
# platform theme Qt picks its portal theme and ignores kdeglobals.
KDE_RUNTIME = "org.kde.Platform/"
KDEGLOBALS = "xdg-config/kdeglobals"
# The KDE platform theme opens KDE's own file dialog unless told to use the
# portal, which shows the desktop's (GNOME's) dialog (verified, Qt 6.11).
KDE_ENV = {"QT_QPA_PLATFORMTHEME": "kde", "PLASMA_INTEGRATION_USE_PORTAL": "1"}
_DISK = object()  # plan_add/plan_remove: read the override file from disk
APP_ID = re.compile(r"^[A-Za-z_][A-Za-z0-9_-]*(\.[A-Za-z_][A-Za-z0-9_-]*)+$")
GROUP = re.compile(r"^\[(.*)\]\s*$")


def user_dir() -> Path:
    env = os.environ.get("FLATPAK_USER_DIR")
    if env:
        return Path(env)
    data = os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share"
    return Path(data) / "flatpak"


def system_dir() -> Path:
    return Path(os.environ.get("FLATPAK_SYSTEM_DIR") or "/var/lib/flatpak")


def override_path(app: str) -> Path:
    return user_dir() / "overrides" / app


# --- Override keyfiles ---------------------------------------------------------


def _lines(data: bytes | None) -> list[str]:
    return [] if not data else data.decode("utf-8").splitlines(keepends=True)


def _filesystems_line(lines: list[str]) -> tuple[int | None, int | None]:
    """Index of the [Context] header and of its filesystems= line."""
    group = header = None
    for i, line in enumerate(lines):
        m = GROUP.match(line.strip())
        if m:
            group = m.group(1)
            if group == "Context":
                header = i
            continue
        if group == "Context" and line.split("=", 1)[0].strip() == "filesystems":
            return header, i
    return header, None


def filesystems(data: bytes | None) -> list[str]:
    """The entries of [Context] filesystems= in a keyfile (app metadata or override)."""
    lines = _lines(data)
    _, i = _filesystems_line(lines)
    if i is None:
        return []
    value = lines[i].split("=", 1)[1].strip()
    return [t for t in value.split(";") if t]


def access(entries: list[str], target: str = TARGET) -> str | None:
    """"grant", "deny" or None: what these entries say about `target`."""
    for e in entries:
        neg = e.startswith("!")
        path = e.lstrip("!").split(":", 1)[0].rstrip("/")
        if path == target:
            return "deny" if neg else "grant"
    return None


def remove_entry(data: bytes, entry: str = ENTRY) -> bytes | None:
    """`data` with `entry` taken out of [Context] filesystems=, changing
    nothing else. An emptied key, then an emptied [Context] group, are
    removed. Returns None when nothing is left of the file."""
    lines = _lines(data)
    header, i = _filesystems_line(lines)
    if i is None:
        raise ValueError(f"no filesystems= entry to remove {entry} from")
    key, value = lines[i].split("=", 1)
    end = "\r\n" if value.endswith("\r\n") else "\n" if value.endswith("\n") else ""
    value = value[:-len(end)] if end else value
    entries = value.split(";")
    if entry not in entries:
        raise ValueError(f"{entry} is not in filesystems=")
    index = entries.index(entry)
    del entries[index]
    # Keep the other entries' original spelling and trailing delimiter.
    remaining = ";".join(entries)
    if remaining:
        lines[i] = f"{key}={remaining}{end}"
    else:
        del lines[i]
        # Drop the [Context] group if only its header (and blank lines) remain.
        j = header + 1
        while j < len(lines) and not GROUP.match(lines[j].strip()):
            if lines[j].strip():
                break
            j += 1
        else:
            del lines[header:j]
    text = "".join(lines)
    return text.encode() if text.strip() else None


def _group_key(lines: list[str], group: str, key: str) -> tuple[int | None, int | None]:
    """Index of the [group] header and of its `key=` line."""
    cur = header = None
    for i, line in enumerate(lines):
        m = GROUP.match(line.strip())
        if m:
            cur = m.group(1)
            if cur == group:
                header = i
            continue
        if cur == group and line.split("=", 1)[0].strip() == key:
            return header, i
    return header, None


def env_value(data: bytes | None, key: str) -> str | None:
    """The value [Environment] gives `key` in a keyfile (None: not set)."""
    lines = _lines(data)
    _, i = _group_key(lines, "Environment", key)
    return None if i is None else lines[i].split("=", 1)[1].rstrip("\r\n")


def env_unset(data: bytes | None, key: str) -> bool:
    """True if [Context] unset-environment= names `key` (`flatpak override --unset-env`)."""
    lines = _lines(data)
    _, i = _group_key(lines, "Context", "unset-environment")
    return i is not None and key in lines[i].split("=", 1)[1].strip().split(";")


def remove_env(data: bytes, key: str) -> bytes | None:
    """`data` without the [Environment] `key=` line, changing nothing else. An
    emptied [Environment] group is removed; None when nothing is left."""
    lines = _lines(data)
    header, i = _group_key(lines, "Environment", key)
    if i is None:
        raise ValueError(f"{key} is not in [Environment]")
    del lines[i]
    j = header + 1
    while j < len(lines) and not GROUP.match(lines[j].strip()):
        if lines[j].strip():
            break
        j += 1
    else:
        # Only the header (and blank lines) left: drop it, and the blank line
        # Flatpak puts before a group.
        start = header - 1 if header and not lines[header - 1].strip() else header
        del lines[start:j]
    text = "".join(lines)
    return text.encode() if text.strip() else None


def _user_installation() -> bool:
    # Our override files create user_dir() on their own; a real installation has a repo.
    return (user_dir() / "repo").exists()


def _run(*args: str, env: dict | None = None) -> subprocess.CompletedProcess:
    if not shutil.which("flatpak"):
        raise HostError("The `flatpak` command isn't installed.", EXIT_ERROR)
    if args[0] in ("list", "info") and env is None and not _user_installation():
        args = (args[0], "--system", *args[1:])  # querying the user installation would create it
    return subprocess.run(["flatpak", *args], capture_output=True, text=True, timeout=60, env=env)


def add_with_flatpak(app: str, before: bytes | None, entry: str = ENTRY) -> bytes:
    """What `flatpak override --user --filesystem=ENTRY app` would make of the
    override file, computed on a scratch copy."""
    with tempfile.TemporaryDirectory(prefix="theme-unifier-flatpak-") as tmp:
        scratch = Path(tmp) / "overrides" / app
        scratch.parent.mkdir()
        if before is not None:
            scratch.write_bytes(before)
        r = _run("override", "--user", f"--filesystem={entry}", app, env=dict(os.environ, FLATPAK_USER_DIR=tmp))
        if r.returncode != 0:
            raise HostError(f"`flatpak override` failed for {app}: {r.stderr.strip()}", EXIT_ERROR)
        return scratch.read_bytes()


def _add_preserving_existing(app: str, before: bytes | None, entry: str) -> bytes | None:
    """Prepend to a simple existing list, then ask Flatpak to parse it.

    This fallback avoids rewriting unrelated keys and comments. More complex
    keyfiles remain conflicts rather than being guessed at.
    """
    if before is None:
        return None
    try:
        lines = _lines(before)
        _, i = _filesystems_line(lines)
        if i is None or sum(1 for line in lines if GROUP.match(line.strip()) and
                            GROUP.match(line.strip()).group(1) == "Context") != 1:
            return None
        key, value = lines[i].split("=", 1)
        raw = value.rstrip("\r\n")
        tokens = raw.split(";")
        if not raw or any(not re.fullmatch(r"[A-Za-z0-9_./~:+!-]+", token) for token in tokens if token):
            return None
        if any(not token for token in tokens[:-1]):
            return None
        lines[i] = f"{key}={entry};{value}"
        after = "".join(lines).encode("utf-8")
        if remove_entry(after, entry) != before:
            return None
        with tempfile.TemporaryDirectory(prefix="theme-unifier-flatpak-check-") as tmp:
            scratch = Path(tmp) / "overrides" / app
            scratch.parent.mkdir()
            scratch.write_bytes(after)
            result = _run("override", "--user", "--show", app, env=dict(os.environ, FLATPAK_USER_DIR=tmp))
            if result.returncode != 0 or access(filesystems(result.stdout.encode()), entry.removesuffix(":ro")) != "grant":
                return None
        return after
    except (OSError, UnicodeError, ValueError, subprocess.SubprocessError):
        return None


def env_with_flatpak(app: str, before: bytes | None, key: str, value: str) -> bytes:
    """What `flatpak override --user --env=KEY=VALUE app` would make of the
    override file, computed on a scratch copy."""
    with tempfile.TemporaryDirectory(prefix="theme-unifier-flatpak-") as tmp:
        scratch = Path(tmp) / "overrides" / app
        scratch.parent.mkdir()
        if before is not None:
            scratch.write_bytes(before)
        r = _run("override", "--user", f"--env={key}={value}", app, env=dict(os.environ, FLATPAK_USER_DIR=tmp))
        if r.returncode != 0:
            raise HostError(f"`flatpak override` failed for {app}: {r.stderr.strip()}", EXIT_ERROR)
        return scratch.read_bytes()


# --- Installed apps --------------------------------------------------------------


def _info(*args: str) -> str | None:
    r = _run("info", *args)
    return r.stdout.strip() if r.returncode == 0 else None


def branches(app: str) -> list[str]:
    """`app//branch` for every installed branch of `app`, or just `app` if
    `flatpak list` can't tell (one branch is the common case)."""
    r = _run("list", "--app", "--columns=application,branch")
    found = [f"{app}//{line.split(chr(9))[1]}" for line in r.stdout.splitlines()
             if r.returncode == 0 and line.split("\t")[0] == app and "\t" in line]
    return found or [app]


def runtime_of(app: str) -> dict:
    """The app's runtime ref and the commit installed for it now (one entry
    per installed branch when there are several)."""
    refs = branches(app)
    if len(refs) > 1:
        each = {ref: runtime_of(ref) for ref in refs}
        return {"runtime": ", ".join(sorted({v["runtime"] or "?" for v in each.values()})), "branches": each}
    ref = _info("--show-runtime", refs[0])
    commit = None
    if ref and ref.count("/") == 2:
        name, arch, branch = ref.split("/")
        commit = _info("--show-commit", f"--arch={arch}", f"{name}//{branch}")
    return {"runtime": ref, "runtime_commit": commit}


def installed_apps() -> list[tuple[str, str]]:
    # `flatpak list` creates the user installation when it's missing; _run
    # only asks about the installations that already exist.
    if not _user_installation() and not (system_dir() / "app").exists():
        return []
    r = _run("list", "--app", "--columns=application,runtime")
    if r.returncode != 0:
        return []
    return [tuple(line.split("\t")[:2]) for line in r.stdout.splitlines() if "\t" in line]


# --- Planning ----------------------------------------------------------------------


@dataclass
class Change:
    app: str
    path: Path
    after: bytes | None  # new override file content (None deletes); unused if not `changed`
    changed: bool
    record: dict | None  # manifest entry after the change (None: forget the app)
    note: str


def plan_add(app: str, existing: dict | None, target: str = TARGET, current=_DISK) -> Change:
    """Add `target` read-only for `app`. `current` stands in for the override
    file's bytes when another change to the same file is planned first."""
    entry = target + ":ro"
    if not APP_ID.match(app):
        raise HostError(f"{app!r} isn't a Flatpak application ID (like org.gnome.TextEditor).", EXIT_ERROR)
    path = override_path(app)
    before = _read(path) if current is _DISK else current
    if existing and existing.get("added") and entry in filesystems(before):
        return Change(app, path, None, False, existing, f"{app}: already enabled.")
    metadata = [_info("--show-metadata", ref) for ref in branches(app)]
    if None in metadata:
        raise HostError(f"{app} isn't installed (`flatpak info {app}` failed). Nothing was changed.", EXIT_ERROR)
    base = {"entry": entry, "override": str(path), "at": time.time(), **runtime_of(app)}
    user = access(filesystems(before), target)
    if user == "deny":
        raise HostError(f"{app}: your Flatpak overrides deny it access to {target} ({path}). theme-unifier "
                        "doesn't override that. Nothing was changed.")
    if user == "grant":
        return Change(app, path, None, False, dict(base, added=False, why="your own override"),
                      f"{app}: already has access through your own override; nothing added.")
    if all(access(filesystems(md.encode()), target) == "grant" for md in metadata):
        return Change(app, path, None, False, dict(base, added=False, why="the app's own permissions"),
                      f"{app}: already has access through its own permissions; nothing added.")
    if access(filesystems(_read(system_dir() / "overrides" / app)), target) == "deny":
        raise HostError(f"{app}: a system-wide Flatpak override denies it access to {target}. "
                        "theme-unifier doesn't override that. Nothing was changed.")
    after = add_with_flatpak(app, before, entry)
    try:
        round_trip = remove_entry(after, entry)
    except ValueError:
        round_trip = b"<missing>"
    if round_trip != before:
        after = _add_preserving_existing(app, before, entry)
        if after is None:
            raise HostError(f"{app}: `flatpak override` would also rewrite other parts of {path} (for example "
                            "drop comments), so the change couldn't be undone exactly. Nothing was changed.")
    return Change(app, path, after, True, dict(base, added=True, created_file=before is None),
                  f"{app}: gave it read-only access to {target} (Flatpak override {path}).")


def plan_remove(app: str, record: dict, force: bool = False, current=_DISK) -> Change:
    path = Path(record["override"])
    if not record.get("added"):
        return Change(app, path, None, False, None, f"{app}: nothing to undo (access came from {record.get('why')}).")
    cur = _read(path) if current is _DISK else current
    entries = filesystems(cur)
    if record["entry"] not in entries:
        what = access(entries)
        now = {"deny": "now denies it", "grant": "now grants it differently", None: "no longer mentions it"}[what]
        if not force:
            raise HostError(f"Conflict: {path} {now}, so theme-unifier's entry is gone. Nothing was changed; "
                            "use --force to forget the app.")
        return Change(app, path, None, False, None, f"{app}: forgot it; {path} {now} and was left alone.")
    after = remove_entry(cur, record["entry"])
    if after is None and not record.get("created_file"):
        after = b""
    return Change(app, path, after, True, None, f"{app}: removed theme-unifier's {record['entry']} from {path}.")


def plan_env_add(app: str, existing: dict | None, key: str, value: str, current=_DISK) -> Change:
    """Set key=value in the app's override, unless the app's own metadata, the
    user's override or a system override already decides `key`."""
    path = override_path(app)
    before = _read(path) if current is _DISK else current
    entry = f"{key}={value}"
    if existing and existing.get("added") and env_value(before, key) == value:
        return Change(app, path, None, False, existing, f"{app}: {entry} already set.")
    base = {"key": key, "value": value, "override": str(path), "at": time.time()}
    mine = env_value(before, key)
    if mine is not None or env_unset(before, key):
        why = f"your own override sets {key}={mine}" if mine is not None else f"your own override unsets {key}"
        return Change(app, path, None, False, dict(base, added=False, why=why), f"{app}: {why}; left as it is.")
    for where, data in (("its own metadata", [_info("--show-metadata", ref) for ref in branches(app)]),
                        ("a system-wide override", [_read(system_dir() / "overrides" / app)])):
        values = {env_value(d.encode() if isinstance(d, str) else d, key) for d in data if d}
        values.discard(None)
        if values:
            why = f"{where} sets {key}={', '.join(sorted(values))}"
            return Change(app, path, None, False, dict(base, added=False, why=why), f"{app}: {why}; left as it is.")
    after = env_with_flatpak(app, before, key, value)
    try:
        round_trip = remove_env(after, key)
    except ValueError:
        round_trip = b"<missing>"
    if round_trip != before:
        raise HostError(f"{app}: `flatpak override` would also rewrite other parts of {path}, so setting "
                        f"{key} couldn't be undone exactly. Nothing was changed.")
    return Change(app, path, after, True, dict(base, added=True, created_file=before is None),
                  f"{app}: set {entry} (Flatpak override {path}).")


def plan_env_remove(app: str, record: dict, force: bool = False, current=_DISK) -> Change:
    path, key = Path(record["override"]), record["key"]
    if not record.get("added"):
        return Change(app, path, None, False, None, f"{app}: nothing to undo ({record.get('why')}).")
    cur = _read(path) if current is _DISK else current
    now = env_value(cur, key)
    if now != record["value"]:
        what = "no longer sets it" if now is None else f"now sets {key}={now}"
        if not force:
            raise HostError(f"Conflict: {path} {what}, so theme-unifier's {key} entry is gone. Nothing was "
                            "changed; use --force to forget it.")
        return Change(app, path, None, False, None, f"{app}: forgot {key}; {path} {what} and was left alone.")
    after = remove_env(cur, key)
    if after is None and not record.get("created_file"):
        after = b""
    return Change(app, path, after, True, None, f"{app}: removed theme-unifier's {key}={record['value']} from {path}.")
