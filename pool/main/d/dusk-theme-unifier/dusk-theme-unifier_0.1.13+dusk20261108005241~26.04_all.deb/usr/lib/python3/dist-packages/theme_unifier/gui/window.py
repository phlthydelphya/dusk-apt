"""The theme-unifier window (milestone 6). libadwaita 1.5 widgets only, so it
runs on Ubuntu 24.04 as well as newer releases."""

from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import threading

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, Gtk  # noqa: E402

from .. import __version__  # noqa: E402
from . import model, restart  # noqa: E402

KIND_LABEL = {"theme": "", "adjusted": "Adjusted", "derived": "Not in theme", "low": "Low confidence"}


def _swatch(rgba: tuple[float, float, float, float], name: str) -> Gtk.Widget:
    """A color square, composited over a checkerboard so translucent colors show.
    Built as a texture so it needs no cairo bindings."""
    size, cell = 28, 7
    r, g, b, a = rgba
    data = bytearray()
    for y in range(size):
        for x in range(size):
            if x in (0, size - 1) or y in (0, size - 1):
                data += bytes((128, 128, 128))
                continue
            shade = 0.8 if (x // cell + y // cell) % 2 else 0.6
            data += bytes(round(255 * (c * a + shade * (1 - a))) for c in (r, g, b))
    tex = Gdk.MemoryTexture.new(size, size, Gdk.MemoryFormat.R8G8B8, GLib.Bytes.new(bytes(data)), size * 3)
    img = Gtk.Image.new_from_paintable(tex)
    img.set_pixel_size(size)
    img.set_valign(Gtk.Align.CENTER)
    img.update_property([Gtk.AccessibleProperty.LABEL], [f"Swatch for {name}"])
    return img


class Window(Adw.ApplicationWindow):
    def __init__(self, app: Adw.Application):
        super().__init__(application=app, title="Theme Unifier")
        self.set_default_size(860, 760)
        self.busy = False
        self._palette_rows: list[Gtk.Widget] = []
        self._status_rows: list[Gtk.Widget] = []
        self._flatpak_rows: list[Gtk.Widget] = []
        self._app_rows: list[Gtk.Widget] = []
        self._restart_rows: list[Gtk.Widget] = []
        self.restart_targets: list[restart.Target] = []

        self.toasts = Adw.ToastOverlay()
        view = Adw.ToolbarView()
        header = Adw.HeaderBar()
        self.apply_button = Gtk.Button(label="_Apply", use_underline=True)
        self.apply_button.add_css_class("suggested-action")
        self.apply_button.set_tooltip_text("Write the palette for libadwaita and plain GTK4 apps")
        self.apply_button.connect("clicked", lambda *_: self.on_apply())
        self.revert_button = Gtk.Button(label="_Revert", use_underline=True)
        self.revert_button.set_tooltip_text("Remove exactly what theme-unifier added")
        self.revert_button.connect("clicked", lambda *_: self.on_revert())
        header.pack_end(self.apply_button)
        header.pack_start(self.revert_button)

        menu = Gio.Menu()
        menu.append("Check and _Repair", "win.doctor")
        menu.append("_About Theme Unifier", "win.about")
        header.pack_end(Gtk.MenuButton(icon_name="open-menu-symbolic", menu_model=menu,
                                       tooltip_text="Main menu", primary=True))
        for name, cb in (("doctor", self.on_doctor), ("about", self.on_about)):
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", lambda *_a, cb=cb: cb())
            self.add_action(action)
        view.add_top_bar(header)

        # Four short pages instead of one long one: a switcher in the header, and
        # at the bottom when the window is narrow.
        self.stack = Adw.ViewStack()
        switcher = Adw.ViewSwitcher(stack=self.stack, policy=Adw.ViewSwitcherPolicy.WIDE)
        header.set_title_widget(switcher)
        switcher_bar = Adw.ViewSwitcherBar(stack=self.stack)
        view.add_bottom_bar(switcher_bar)
        narrow = Adw.Breakpoint.new(Adw.BreakpointCondition.parse("max-width: 780sp"))
        narrow.add_setter(switcher, "visible", False)
        narrow.add_setter(switcher_bar, "reveal", True)
        self.add_breakpoint(narrow)

        # Theme page ------------------------------------------------------------
        page = Adw.PreferencesPage()
        self.page = page
        summary = Adw.PreferencesGroup()
        self.summary_row = Adw.ActionRow(title="Nothing applied")
        summary.add(self.summary_row)
        page.add(summary)

        self.restart_group = Adw.PreferencesGroup(
            title="Apps to restart",
            description="They started before the theme was applied, so they still show the old look")
        self.restart_all_button = Gtk.Button(label="Restart _All", use_underline=True, valign=Gtk.Align.CENTER)
        self.restart_all_button.connect("clicked", lambda *_: self.on_restart_all())
        self.restart_group.set_header_suffix(self.restart_all_button)
        self.restart_group.set_visible(False)
        page.add(self.restart_group)

        g = Adw.PreferencesGroup(title="Theme", description="The GTK3 theme whose colors other apps should use")
        self.themes = model.theme_names()
        self.theme_row = Adw.ComboRow(title="_GTK3 theme", use_underline=True,
                                      model=Gtk.StringList.new(self.themes))
        self.mode_row = Adw.ComboRow(title="_Mode", use_underline=True,
                                     model=Gtk.StringList.new([model.MODE_LABELS[m] for m in model.MODE_CHOICES]))
        g.add(self.theme_row)
        g.add(self.mode_row)
        page.add(g)

        targets = Adw.PreferencesGroup(title="Apply to")
        self.adwaita_row = Adw.ComboRow(title="_Libadwaita apps", use_underline=True,
                                       model=Gtk.StringList.new([model.ADWAITA_LABELS[c]
                                                                 for c in model.ADWAITA_CHOICES]))
        self.gtk4_row = Adw.ComboRow(title="Plain _GTK4 apps", use_underline=True,
                                     model=Gtk.StringList.new([model.GTK4_LABELS[m] for m in model.GTK4_CHOICES]))
        self.shell_row = Adw.ComboRow(title="GNOME _Shell", use_underline=True,
                                      model=Gtk.StringList.new([model.SHELL_LABELS[m] for m in model.SHELL_CHOICES]))
        self.buttons_row = Adw.ComboRow(title="_Window button layout", use_underline=True,
                                       model=Gtk.StringList.new([model.BUTTONS_LABELS[c]
                                                                 for c in model.BUTTONS_CHOICES]))
        self.accent_row = Adw.ComboRow(title="_Accent color", use_underline=True,
                                       model=Gtk.StringList.new([model.ACCENT_LABELS[c] for c in model.ACCENT_CHOICES]))
        self.apps_row = Adw.ComboRow(title="_Other apps", use_underline=True,
                                     model=Gtk.StringList.new([model.APPS_LABELS[c] for c in model.APPS_CHOICES]))
        choices = model.applied_choices()
        self.accent_row.set_selected(model.ACCENT_CHOICES.index(choices["accent"]))
        self.apps_row.set_selected(model.APPS_CHOICES.index(choices["apps"]))
        found = model.detected_apps()
        # Each row's subtitle says what its current choice does (model.describe).
        for setting, row, options in (("mode", self.mode_row, model.MODE_CHOICES),
                                      ("adwaita", self.adwaita_row, model.ADWAITA_CHOICES),
                                      ("gtk4", self.gtk4_row, model.GTK4_CHOICES),
                                      ("shell", self.shell_row, model.SHELL_CHOICES),
                                      ("buttons", self.buttons_row, model.BUTTONS_CHOICES),
                                      ("accent", self.accent_row, model.ACCENT_CHOICES),
                                      ("apps", self.apps_row, model.APPS_CHOICES)):
            def describe(*_a, setting=setting, row=row, options=options):
                row.set_subtitle(model.describe(setting, options[row.get_selected()], found))
            row.connect("notify::selected", describe)
            describe()
            if row is not self.mode_row:
                targets.add(row)
        if not model.shell_available():
            self.shell_row.set_selected(model.SHELL_CHOICES.index("off"))
            self.shell_row.set_subtitle("Needs the User Themes extension: sudo apt install gnome-shell-extensions, "
                                        "then log out and back in")
            self.shell_row.set_sensitive(False)
        page.add(targets)

        previews = Adw.PreferencesGroup()
        preview = Adw.ActionRow(title="_Preview", use_underline=True, activatable=True,
                                subtitle="Open sample widgets in a separate window without applying the theme")
        preview.add_suffix(Gtk.Image(icon_name="window-new-symbolic"))
        preview.connect("activated", lambda *_: self.on_preview())
        self.preview_extensions = Adw.SwitchRow(
            title="Include blur and dock in preview",
            subtitle="Run copies of enabled extensions with your user permissions and copied settings")
        previews.add(preview)
        previews.add(self.preview_extensions)
        page.add(previews)
        self.stack.add_titled_with_icon(page, "theme", "Theme", "preferences-desktop-appearance-symbolic")

        # Colors page -------------------------------------------------------------
        colors = Adw.PreferencesPage()
        self.palette_group = Adw.PreferencesGroup(title="Palette")
        colors.add(self.palette_group)
        self.stack.add_titled_with_icon(colors, "colors", "Colors", "color-select-symbolic")

        # Apps page ---------------------------------------------------------------
        apps_page = Adw.PreferencesPage()
        self.apps_group = Adw.PreferencesGroup(
            title="Apps with their own theme option",
            description="Set with Other apps on the Theme page. They read the colors when they start.")
        apps_page.add(self.apps_group)
        self.flatpak_group = Adw.PreferencesGroup(
            title="Flatpak apps",
            description="Apply lets every installed app read the theme. Turn an app off here to keep it "
                        "out; revert removes only the read-only permissions theme-unifier added.")
        apps_page.add(self.flatpak_group)
        self.stack.add_titled_with_icon(apps_page, "apps", "Apps", "view-app-grid-symbolic")

        # Status page ---------------------------------------------------------------
        status_page = Adw.PreferencesPage()
        self.status_group = Adw.PreferencesGroup(title="Status")
        status_page.add(self.status_group)
        self.stack.add_titled_with_icon(status_page, "status", "Status", "dialog-information-symbolic")

        view.set_content(self.stack)
        self.toasts.set_child(view)
        self.set_content(self.toasts)

        current = model.applied()
        start = (current[0] if current else None) or model.system_theme()
        if start in self.themes:
            self.theme_row.set_selected(self.themes.index(start))
        self.theme_row.connect("notify::selected", lambda *_: self.refresh_palette())
        self.mode_row.connect("notify::selected", lambda *_: self.refresh_palette())
        self.refresh_palette()
        self.refresh_status()

    # Reading the rows ------------------------------------------------------------

    @property
    def theme(self) -> str:
        return self.themes[self.theme_row.get_selected()] if self.themes else ""

    @property
    def mode_choice(self) -> str:
        return model.MODE_CHOICES[self.mode_row.get_selected()]

    @property
    def gtk4(self) -> str:
        return model.GTK4_CHOICES[self.gtk4_row.get_selected()]

    @property
    def shell(self) -> str:
        return model.SHELL_CHOICES[self.shell_row.get_selected()]

    @property
    def accent(self) -> str:
        return model.ACCENT_CHOICES[self.accent_row.get_selected()]

    @property
    def apps(self) -> str:
        return model.APPS_CHOICES[self.apps_row.get_selected()]

    # Views -------------------------------------------------------------------------

    def _clear(self, group: Adw.PreferencesGroup, rows: list[Gtk.Widget]) -> None:
        for r in rows:
            group.remove(r)
        rows.clear()

    def refresh_palette(self) -> None:
        self._clear(self.palette_group, self._palette_rows)
        if not self.theme:
            return
        mode = model.resolve_mode(self.mode_choice)
        view = model.palette_view(self.theme, mode)
        self.palette_group.set_description(f"{self.theme}, {mode}. Every color that isn't the theme's own "
                                           "value says why.")
        if view.unavailable:
            row = Adw.ActionRow(title="This mode is unavailable", subtitle=view.unavailable)
            row.add_prefix(Gtk.Image(icon_name="dialog-information-symbolic"))
            self._add(self.palette_group, self._palette_rows, row)
            self.apply_button.set_sensitive(False)
            return
        self.apply_button.set_sensitive(not self.busy)
        for msg in view.unresolved:
            row = Adw.ActionRow(title="Still below its contrast target; apply will refuse", subtitle=msg)
            row.add_prefix(Gtk.Image(icon_name="dialog-warning-symbolic"))
            self._add(self.palette_group, self._palette_rows, row)
        for c in view.rows:
            row = Adw.ActionRow(title=c.name, subtitle=f"{c.css}  ·  {c.note}", subtitle_lines=3)
            row.add_prefix(_swatch(c.rgba, c.name))
            if KIND_LABEL[c.kind]:
                tag = Gtk.Label(label=KIND_LABEL[c.kind], valign=Gtk.Align.CENTER)
                tag.add_css_class("caption")
                tag.add_css_class("dim-label")
                row.add_suffix(tag)
            self._add(self.palette_group, self._palette_rows, row)
        if view.left_default:
            row = Adw.ActionRow(title="Left to libadwaita", subtitle=", ".join(view.left_default), subtitle_lines=3)
            self._add(self.palette_group, self._palette_rows, row)

    def refresh_status(self) -> None:
        self._clear(self.status_group, self._status_rows)
        self._clear(self.apps_group, self._app_rows)
        res = model.status()
        title, subtitle = model.summary(res.lines)
        self.summary_row.set_title(title)
        self.summary_row.set_subtitle(subtitle)
        for line in res.lines:
            if line.startswith("  "):
                continue  # detail lines; the summary lines carry the state
            if line.startswith("App: "):  # app adapters live on the Apps page
                name, _, state = line[len("App: "):].partition(": ")
                row = Adw.ActionRow(title=name, subtitle=state, subtitle_lines=3)
                self._add(self.apps_group, self._app_rows, row)
                continue
            row = Adw.ActionRow(title=line, title_lines=4)
            row.add_css_class("property")
            self._add(self.status_group, self._status_rows, row)
        if not self._app_rows:
            self._add(self.apps_group, self._app_rows, Adw.ActionRow(title="No installed app with a theme option"))
        self.revert_button.set_sensitive(not self.busy and model.applied() is not None)
        self.refresh_restart()
        self.refresh_flatpak()

    def refresh_restart(self) -> None:
        self._clear(self.restart_group, self._restart_rows)
        try:
            self.restart_targets = restart.targets(model.restart_needed())
        except GLib.Error:
            self.restart_targets = []
        # One row per app that can be restarted from here; the rest (services,
        # terminals, helpers without a launcher) are named together in one row.
        for t in (t for t in self.restart_targets if t.restartable):
            row = Adw.ActionRow(title=t.name)
            button = Gtk.Button(label="Restart", valign=Gtk.Align.CENTER)
            button.add_css_class("flat")
            button.connect("clicked", lambda _b, t=t: self.on_restart([t]))
            row.add_suffix(button)
            self._add(self.restart_group, self._restart_rows, row)
        others = list(dict.fromkeys(t.name for t in self.restart_targets if not t.restartable))
        if others:
            row = Adw.ActionRow(title="Restart these yourself", subtitle=", ".join(others), subtitle_lines=3)
            row.set_tooltip_text("\n".join(dict.fromkeys(f"{t.name}: {t.reason}" for t in self.restart_targets
                                                         if not t.restartable)))
            self._add(self.restart_group, self._restart_rows, row)
        self.restart_group.set_visible(bool(self.restart_targets))
        self.restart_all_button.set_sensitive(not self.busy and any(t.restartable for t in self.restart_targets))

    def refresh_flatpak(self) -> None:
        self._clear(self.flatpak_group, self._flatpak_rows)
        apps = model.flatpak_apps()
        if not apps:
            self._add(self.flatpak_group, self._flatpak_rows,
                      Adw.ActionRow(title="No Flatpak apps found"))
            return
        nothing_applied = model.applied() is None
        for app, runtime, enabled in apps:
            row = Adw.SwitchRow(title=app, subtitle=runtime, active=enabled)
            row.set_sensitive(not nothing_applied or enabled)
            if nothing_applied and not enabled:
                row.set_subtitle(f"{runtime} · apply a theme first")
            row.connect("notify::active", self.on_flatpak_toggled, app)
            self._add(self.flatpak_group, self._flatpak_rows, row)

    def _add(self, group, rows, row) -> None:
        group.add(row)
        rows.append(row)

    # Actions ------------------------------------------------------------------------

    def _work(self, fn, done) -> None:
        """Run `fn` off the main thread, then `done(result)` on it."""
        self.busy = True
        for b in (self.apply_button, self.revert_button):
            b.set_sensitive(False)

        def run():
            res = fn()
            GLib.idle_add(finish, res)

        def finish(res):
            self.busy = False
            done(res)
            self.refresh_palette()
            self.refresh_status()
            return False

        threading.Thread(target=run, daemon=True).start()

    def _report(self, res: model.Result, title: str, retry=None) -> None:
        if res.ok:
            self.toasts.add_toast(Adw.Toast(title=title, timeout=4))
            if len(res.lines) > 1:
                self._dialog(title, "\n\n".join(res.lines))
            return
        heading = {3: "Mode unavailable", 4: "Contrast check failed", 5: "Conflict: nothing was changed",
                   6: "Unsafe file: nothing was changed", 10: "Not finished"}.get(res.code, "Nothing was changed")
        self._dialog(heading, "\n\n".join(res.lines), retry if res.can_force else None)

    @staticmethod
    def _scroller(text: str) -> Gtk.ScrolledWindow:
        """Long text in a box that scrolls instead of growing past the screen."""
        label = Gtk.Label(label=text, xalign=0, wrap=True, max_width_chars=70, selectable=True)
        scroller = Gtk.ScrolledWindow(propagate_natural_height=True, max_content_height=360,
                                      hscrollbar_policy=Gtk.PolicyType.NEVER)
        scroller.set_child(label)
        return scroller

    def _dialog(self, heading: str, body: str, force=None) -> None:
        """The first paragraph as the dialog's text, the rest (a long apply
        report: Flatpak apps, adjusted colors) in a scrolling box below it."""
        first, _, rest = body.partition("\n\n")
        d = Adw.MessageDialog(transient_for=self, heading=heading, body=first)
        if rest:
            d.set_extra_child(self._scroller(rest))
        d.add_response("close", "_Close")
        if force:
            d.add_response("force", "_Replace Anyway")
            d.set_response_appearance("force", Adw.ResponseAppearance.DESTRUCTIVE)
        d.set_default_response("close")
        d.set_close_response("close")
        d.connect("response", lambda _d, r: force() if r == "force" and force else None)
        self.last_dialog = d
        d.present()

    def on_apply(self, force: bool = False) -> None:
        """First a dry run, shown for confirmation; Apply there makes the changes."""
        theme, mode, gtk4, shell = self.theme, self.mode_choice, self.gtk4, self.shell
        buttons = model.BUTTONS_CHOICES[self.buttons_row.get_selected()]
        adwaita = model.ADWAITA_CHOICES[self.adwaita_row.get_selected()]
        targets = {"accent": self.accent, "apps": self.apps}

        def confirm(res: model.Result) -> None:
            if not res.ok:
                self._report(res, "", lambda: self.on_apply(force=True))
            elif not res.lines or not res.lines[-1].startswith("Revert undoes"):
                self._dialog(f"{theme}", "\n\n".join(res.lines))  # already applied: nothing to confirm
            else:
                self._confirm(f"Apply {theme}?", res.lines,
                              lambda: self._apply_now(theme, mode, gtk4, shell, force, buttons, adwaita, targets))

        self._work(lambda: model.apply(theme, mode, gtk4, force, shell, dry_run=True, buttons=buttons,
                                      adwaita=adwaita, **targets), confirm)

    def _apply_now(self, theme: str, mode: str, gtk4: str, shell: str, force: bool, buttons: str = "auto",
                   adwaita: str = "auto", targets: dict[str, str] | None = None) -> None:
        self._work(lambda: model.apply(theme, mode, gtk4, force, shell, buttons=buttons, adwaita=adwaita,
                                       **(targets or {})),
                   lambda res: self._report(res, f"Applied {theme}", lambda: self.on_apply(force=True)))

    def _confirm(self, heading: str, lines: list[str], go) -> None:
        """The full list of changes, scrollable, with Cancel as the default."""
        start = next(i for i, l in enumerate(lines) if l.startswith("Apply would change"))
        d = Adw.MessageDialog(transient_for=self, heading=heading, body=" ".join(lines[: start + 1]))
        d.set_extra_child(self._scroller("\n".join(f"• {l}" for l in lines[start + 1:-1]) + "\n\n" + lines[-1]))
        d.add_response("cancel", "_Cancel")
        d.add_response("apply", "_Apply")
        d.set_response_appearance("apply", Adw.ResponseAppearance.SUGGESTED)
        d.set_default_response("cancel")
        d.set_close_response("cancel")
        d.connect("response", lambda _d, r: go() if r == "apply" else None)
        self.last_dialog = d
        d.present()

    def on_restart_all(self) -> None:
        targets = [t for t in self.restart_targets if t.restartable]
        if not targets:
            return
        d = Adw.MessageDialog(transient_for=self, heading=f"Restart {len(targets)} apps?",
                              body="Each app is asked to quit, the same as choosing Quit in it, then opened "
                                   "again. An app with unsaved work can ask you first. An app that doesn't quit "
                                   f"within {restart.TIMEOUT:.0f} seconds is left running.")
        d.set_extra_child(self._scroller("\n".join(f"• {t.name}" for t in targets)))
        d.add_response("cancel", "_Cancel")
        d.add_response("restart", "_Restart All")
        d.set_response_appearance("restart", Adw.ResponseAppearance.SUGGESTED)
        d.set_default_response("cancel")
        d.set_close_response("cancel")
        d.connect("response", lambda _d, r: self.on_restart(targets) if r == "restart" else None)
        self.last_dialog = d
        d.present()

    def on_restart(self, targets: list[restart.Target]) -> None:
        """Quit the apps off the main thread, then start the ones that quit again."""
        self.restart_all_button.set_sensitive(False)

        def done(results) -> None:
            context = self.get_display().get_app_launch_context()
            problems = [err for _t, err in results if err]
            started = 0
            for t, err in results:
                if err is None:
                    err = restart.launch(t, context)
                    if err:
                        problems.append(err)
                    else:
                        started += 1
            if started:
                self.toasts.add_toast(Adw.Toast(title=f"Restarted {started} app{'s' if started != 1 else ''}",
                                                timeout=4))
            if problems:
                self._dialog("Not every app was restarted", "\n\n".join(problems))

        self._work(lambda: [(t, restart.quit_and_wait(t)) for t in targets], done)

    def on_revert(self, force: bool = False) -> None:
        self._work(lambda: model.revert(force),
                   lambda res: self._report(res, "Reverted", lambda: self.on_revert(force=True)))

    def on_doctor(self) -> None:
        self._work(model.doctor, lambda res: self._dialog("Check and repair", "\n\n".join(res.lines)))

    def on_flatpak_toggled(self, row, _pspec, app: str, force: bool = False) -> None:
        if self.busy:
            return
        enabled = row.get_active()

        def done(res):
            if not res.ok:
                retry = (lambda: self._flatpak_force(app)) if not enabled and any(
                    "use --force" in line for line in res.lines) else None
                self._report(res, "", retry)
            else:
                self.toasts.add_toast(Adw.Toast(title=f"{app}: {'enabled' if enabled else 'disabled'}",
                                                timeout=3))

        self._work(lambda: model.flatpak_set(app, enabled, force), done)

    def _flatpak_force(self, app: str) -> None:
        self._work(lambda: model.flatpak_set(app, False, force=True),
                   lambda res: self._report(res, f"{app}: forgotten"))

    def on_preview(self) -> None:
        """Sample widgets in a separate process, so this window keeps its own colors."""
        mode = model.resolve_mode(self.mode_choice)
        view = model.palette_view(self.theme, mode)
        if view.unavailable:
            self._dialog("Mode unavailable", view.unavailable)
            return
        path = model.authored_gtk4_css(self.theme, mode) if self.adwaita_row.get_selected() == 0 else None
        authored = path is not None
        if authored:
            path = str(path)
        else:
            from ..generate import generate
            from ..loader import find_theme
            from ..variants import discover
            css = generate(discover(find_theme(self.theme)).palettes[mode], mode).css(
                css_vars=model.ops.gtk4theme.css_variables())
            css = model.ops.t_adwaita.system_accent_palette(css)
            fd, path = tempfile.mkstemp(prefix="theme-unifier-preview-", suffix=".css")
            with os.fdopen(fd, "w") as f:
                f.write(css)
        self.preview_process = subprocess.Popen(
            [sys.executable, "-m", "theme_unifier.gui.preview", path, mode, self.theme,
             os.environ.get("THEME_UNIFIER_PREVIEW_SHELL") or self.shell,
             "extensions" if self.preview_extensions.get_active() else "none",
             "authored" if authored else "palette"],
            env=dict(os.environ, PYTHONPATH=os.pathsep.join(filter(None, [os.path.dirname(os.path.dirname(
                os.path.dirname(os.path.abspath(__file__)))), os.environ.get("PYTHONPATH")]))))

    def on_about(self) -> None:
        about = Adw.AboutWindow(transient_for=self, application_name="Theme Unifier", version=__version__,
                                comments="Unifies supported apps and the Shell with a GTK theme, using its GTK4 "
                                         "styles when available and generated colors where needed. "
                                         "Changes can be reverted.",
                                license_type=Gtk.License.GPL_3_0)
        about.present()
