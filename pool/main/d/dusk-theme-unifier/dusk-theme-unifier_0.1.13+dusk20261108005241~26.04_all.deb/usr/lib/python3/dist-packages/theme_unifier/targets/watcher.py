"""The watcher's systemd user unit."""

from __future__ import annotations

import sys
from pathlib import Path

from ..host import _read, config_home, sha256

UNIT_NAME = "theme-unifier-watch.service"


def unit_path() -> Path:
    return config_home() / "systemd" / "user" / UNIT_NAME


def unit_text(pkg_parent: Path | None = None) -> str:
    """The unit runs the same copy of theme-unifier that wrote it: an
    installed package (no PYTHONPATH needed) or a source checkout. If that
    copy goes away (the package is removed), the unit is skipped quietly
    instead of failing at every login."""
    pkg_parent = pkg_parent or Path(__file__).resolve().parents[2]
    installed = pkg_parent.name in ("dist-packages", "site-packages")
    return ("[Unit]\n"
            "Description=theme-unifier: keep the libadwaita palette out of high contrast and follow light/dark\n"
            "PartOf=graphical-session.target\nAfter=graphical-session.target\n"
            f"ConditionPathExists={pkg_parent / 'theme_unifier' / '__main__.py'}\n\n"
            "[Service]\n"
            f"ExecStart={sys.executable} -m theme_unifier watch\n"
            + ("" if installed else f"Environment=PYTHONPATH={pkg_parent}\n")
            + "Restart=on-failure\n\n"
            "[Install]\nWantedBy=graphical-session.target\n")


def install(out: list[str]) -> tuple[dict, dict[Path, bytes], list[dict]] | None:
    """The watcher unit's record, file and enable action, for Host.commit."""
    path, text = unit_path(), unit_text().encode()
    existing = _read(path)
    if existing is not None and existing != text:
        out.append(f"Warning: {path} exists and was not written by this version; the watcher was not installed.")
        return None
    return {"path": str(path), "sha256": sha256(text)}, {path: text}, [
        {"kind": "unit", "op": "enable", "name": UNIT_NAME, "path": str(path),
         "done": "Watcher enabled (systemd user unit).",
         "failed": f"Watcher unit written to {path}, but systemd --user could not start it. Until it runs, "
                   "turning on high contrast will NOT remove the palette; run `theme-unifier watch` "
                   "in your session, or revert before using high contrast."}]


def remove(unit: dict | None, out: list[str], force: bool) -> tuple[dict[Path, None], list[dict]]:
    """The unit file to delete and the disable action (run before the file goes)."""
    if not unit:
        return {}, []
    path = Path(unit["path"])
    data = _read(path)
    if data is None:
        return {}, []
    if sha256(data) != unit["sha256"] and not force:
        out.append(f"Conflict: {path} was changed after theme-unifier wrote it, so it was left in place.")
        return {}, []
    return {path: None}, [{"kind": "unit", "op": "disable", "name": UNIT_NAME, "path": str(path),
                           "phase": "before",
                           "done": "Watcher stopped and removed."}]


def refresh(unit: dict, out: list[str]) -> tuple[dict, dict[Path, bytes], list[dict]] | None:
    """When the recorded unit runs another copy of theme-unifier (a checkout
    before the package was installed, or the other way round), the new unit
    text and a restart, so the watcher runs the code that applied. None when
    it is current, or was edited by hand (then it's left as it is, D5)."""
    path, text = Path(unit["path"]), unit_text().encode()
    cur = _read(path)
    if cur is None or cur == text:
        return None
    if sha256(cur) != unit["sha256"]:
        out.append(f"Watcher: {path} was changed by hand, so it was left as it is.")
        return None
    return {"path": str(path), "sha256": sha256(text)}, {path: text}, [
        {"kind": "unit", "op": "restart", "name": UNIT_NAME, "path": str(path),
         "done": "Watcher updated to run this copy of theme-unifier, and restarted."}]
