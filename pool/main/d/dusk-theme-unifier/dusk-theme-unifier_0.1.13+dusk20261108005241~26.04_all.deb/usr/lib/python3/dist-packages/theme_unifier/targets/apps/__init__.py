"""App adapters: apps that have their own theme hook get the applied palette.

Each adapter module (see teams.py) has NAME, detect(), plan(), restore() and
status(). It plans whole files that theme-unifier owns, so writing, hashing,
conflicts and removal go through the same path as every other owned file
(targets/gtk4.changes and Host.commit). An adapter never edits a file it
doesn't own, and never changes the desktop itself.
"""

from __future__ import annotations

from pathlib import Path

from ...host import Manifest, _read, sha256
from . import teams

ADAPTERS = [teams]  # in order; tests replace this list


def plan_all(palette: dict, mode: str, old: dict[str, dict], choice: str, out: list[str]
             ) -> tuple[dict[str, dict], dict[Path, bytes], list[dict]]:
    """Plan every detected adapter for `mode`: the new records (adapter name to
    record), the owned files to write, and the actions. With `choice == "off"`,
    or for an app that is gone, an adapter plans no files, so its earlier owned
    files drop out and get removed."""
    records: dict[str, dict] = {}
    files: dict[Path, bytes] = {}
    acts: list[dict] = []
    if choice == "off" and ADAPTERS:
        out.append("App themes: left alone (--apps off).")
    for adapter in ADAPTERS:
        if choice == "off" or not adapter.detect():
            if old.get(adapter.NAME):
                acts += adapter.restore(old[adapter.NAME], False)[1]
            continue
        rec, planned, planned_acts = adapter.plan(palette, mode, old.get(adapter.NAME, {}), out)
        records[adapter.NAME] = rec
        files.update(planned)
        acts += planned_acts
    return records, files, acts


def follow(m: Manifest, palette: dict, mode: str, out: list[str]) -> tuple[dict[Path, bytes], list[dict]]:
    """The watcher's switch to a new mode: the new bytes of every adapter file
    that is still intact, updating m.files and m.apps. A file edited by hand
    (or gone) is left as it is, and said so."""
    files: dict[Path, bytes] = {}
    acts: list[dict] = []
    for adapter in ADAPTERS:
        old = m.apps.get(adapter.NAME)
        if not old or old.get("mode") == mode:
            continue
        rec, planned, planned_acts = adapter.plan(palette, mode, old, out)
        if not rec:
            continue
        skipped = False
        for path, data in planned.items():
            owned = m.files.get(str(path))
            if owned is None or owned == sha256(data):
                continue  # not ours, or already what the new mode needs
            if sha256(_read(path)) != owned:
                out.append(f"App {adapter.NAME}: {path} was edited, so it was not switched.")
                skipped = True
                continue
            files[path] = data
            m.files[str(path)] = sha256(data)
        if not skipped:
            for p in released({adapter.NAME: old}, {adapter.NAME: rec}, m.files):
                del m.files[p]  # the app changed it and the new plan no longer wants it: forget it, keep it
                out.append(f"{adapter.NAME}: {p} was changed by the app after theme-unifier wrote it, so "
                           "theme-unifier no longer manages it (left as it is).")
            m.apps[adapter.NAME] = rec
            acts += planned_acts
    return files, acts


def restore_all(records: dict[str, dict], force: bool) -> tuple[dict[Path, bytes | None], list[dict]]:
    """Files and actions that undo what the adapters did beyond their owned files."""
    files: dict[Path, bytes | None] = {}
    acts: list[dict] = []
    for adapter in ADAPTERS:
        if records.get(adapter.NAME):
            undo_files, undo_acts = adapter.restore(records[adapter.NAME], force)
            files.update(undo_files)
            acts += undo_acts
    return files, acts


def owned_paths(records: dict[str, dict]) -> set[str]:
    """Every file the adapters' records own (they are not generated GTK4 files)."""
    return {p for rec in records.values() for p in rec.get("files", [])}


def owner(path: Path, records: dict[str, dict]) -> str | None:
    """The adapter that owns `path`, if any."""
    return next((name for name, rec in records.items() if str(path) in rec.get("files", [])), None)


def released(old: dict[str, dict], new: dict[str, dict], owned: dict[str, str]) -> list[str]:
    """Paths an old record listed that no new record lists, that exist, and whose
    bytes differ from what we wrote: the app (or the user) changed them and we no
    longer want them. They are forgotten, never deleted or overwritten."""
    kept = owned_paths(new)
    gone = []
    for p in sorted(owned_paths(old) - kept):
        cur = _read(Path(p))
        if cur is not None and p in owned and sha256(cur) != owned[p]:
            gone.append(p)
    return gone


def foreign(records: dict[str, dict], files: dict[Path, bytes], owned: dict[str, str]) -> list[str]:
    """Adapters with a planned file already on disk that theme-unifier didn't write.
    Such an adapter is skipped as a whole, so the app never gets half a theme."""
    return [name for name, rec in records.items()
            if any(Path(p).exists() and p not in owned for p in rec.get("files", []) if Path(p) in files)]


def removed_lines(records: dict[str, dict], removed: set[Path]) -> list[str]:
    """One line per adapter whose owned files revert removed."""
    lines = []
    for name, rec in records.items():
        names = [Path(p).name for p in rec.get("files", []) if Path(p) in removed]
        if names:
            lines.append(f"Removed the {name} theme files ({', '.join(names)}).")
    return lines


def status_lines(records: dict[str, dict], owned: dict[str, str]) -> list[str]:
    """`App: NAME: ...` for each adapter, and any of its files that were edited or removed."""
    lines = []
    for adapter in ADAPTERS:
        rec = records.get(adapter.NAME)
        if rec is None:
            lines.append(f"App: {adapter.NAME}: " + ("installed, not themed" if adapter.detect() else "not detected"))
            continue
        lines.append(f"App: {adapter.NAME}: {adapter.status(rec)}")
        for p in rec.get("files", []):
            cur = _read(Path(p))
            state = "missing" if cur is None else "intact" if sha256(cur) == owned.get(p) else "edited"
            if state != "intact":
                lines.append(f"  {p}: {state}")
    return lines
