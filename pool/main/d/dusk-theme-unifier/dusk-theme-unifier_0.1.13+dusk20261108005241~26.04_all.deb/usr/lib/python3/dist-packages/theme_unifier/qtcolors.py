"""Qt and KDE colors from a generated palette (milestone 11).

Two files, written from the same colors so they agree:

- a qt5ct/qt6ct color scheme: Qt's own palette (QPalette), which every Qt
  widget draws with once the session uses the qt5ct/qt6ct platform theme;
- the [Colors:*] groups of kdeglobals: the KDE color scheme, which KDE apps
  ask for directly (KColorScheme) for views, selections, headers and the
  positive/neutral/negative text colors.

Either one alone mixes palettes: with only kdeglobals, a KDE app on GNOME
draws KDE's colors on Qt's default gray widgets (white text on light gray
buttons, seen with KCalc 23.08). Colors only: the style (Fusion, Breeze)
draws the shapes.
"""

from __future__ import annotations

import colorsys

from .colors import Color, contrast_ratio, mix
from .generate import Generated

# QPalette::ColorRole order, as qt5ct/qt6ct color schemes list them.
QT_ROLES = ("WindowText", "Button", "Light", "Midlight", "Dark", "Mid", "Text", "BrightText", "ButtonText",
            "Base", "Window", "Shadow", "Highlight", "HighlightedText", "Link", "LinkVisited", "AlternateBase",
            "NoRole", "ToolTipBase", "ToolTipText", "PlaceholderText")

BLACK, WHITE = Color(0, 0, 0), Color(1, 1, 1)
DISABLED_TARGET = 3.0  # D4: disabled text, rendered contrast


def _solid(gen: Generated, name: str, on: str | None = None) -> Color:
    """A palette color as opaque RGB, composited over `on` when translucent."""
    c = gen[name].color
    if c.a < 1.0:
        c = c.over(gen[on or "window_bg_color"].color)
    return c


def _value(c: Color, factor: float) -> Color:
    """QColor::lighter/darker: scale HSV value (lighter past 1.0 takes saturation away)."""
    h, s, v = colorsys.rgb_to_hsv(c.r, c.g, c.b)
    v *= factor
    if v > 1.0:
        s = max(0.0, s - (v - 1.0))
        v = 1.0
    return Color(*colorsys.hsv_to_rgb(h, s, v))


def _disabled(fg: Color, bg: Color) -> Color:
    """Half-way between text and background, moved toward the text until it reaches 3:1."""
    for i in range(51):
        c = mix(bg, fg, 0.5 + i / 100)
        if contrast_ratio(c, bg) >= DISABLED_TARGET:
            return c
    return fg


def qt_palette(gen: Generated) -> dict[str, dict[str, Color]]:
    """Active, inactive and disabled colors for each QPalette role."""
    window, window_fg = _solid(gen, "window_bg_color"), _solid(gen, "window_fg_color")
    view, view_fg = _solid(gen, "view_bg_color"), _solid(gen, "view_fg_color", "view_bg_color")
    button = mix(window, window_fg, 0.10)  # libadwaita: currentColor at 10% over the window
    accent_bg, accent_fg = _solid(gen, "accent_bg_color"), _solid(gen, "accent_fg_color", "accent_bg_color")
    link = _solid(gen, "accent_color")
    tip, tip_fg = _solid(gen, "popover_bg_color"), _solid(gen, "popover_fg_color", "popover_bg_color")
    active = {
        "WindowText": window_fg, "Button": button, "Light": _value(button, 1.5), "Midlight": _value(button, 1.15),
        "Dark": _value(button, 0.5), "Mid": _value(button, 0.67), "Text": view_fg,
        "BrightText": WHITE if window.is_dark() else BLACK, "ButtonText": window_fg, "Base": view,
        "Window": window, "Shadow": BLACK, "Highlight": accent_bg, "HighlightedText": accent_fg, "Link": link,
        "LinkVisited": mix(link, window_fg, 0.3), "AlternateBase": mix(view, view_fg, 0.04), "NoRole": BLACK,
        "ToolTipBase": tip, "ToolTipText": tip_fg, "PlaceholderText": _disabled(view_fg, view),
    }
    disabled = dict(active, WindowText=_disabled(window_fg, window), Text=_disabled(view_fg, view),
                    ButtonText=_disabled(window_fg, button), HighlightedText=_disabled(window_fg, window),
                    Highlight=mix(window, accent_bg, 0.5))
    return {"active": active, "inactive": dict(active), "disabled": disabled}


def _argb(c: Color) -> str:
    return "#ff" + c.to_hex()[1:7]


def qtct_scheme(gen: Generated) -> str:
    """A qt5ct/qt6ct color scheme file (both read the same format)."""
    pal = qt_palette(gen)
    lines = ["[ColorScheme]"]
    for group in ("active", "disabled", "inactive"):
        lines.append(f"{group}_colors=" + ", ".join(_argb(pal[group][r]) for r in QT_ROLES))
    return "\n".join(lines) + "\n"


def _rgb(c: Color) -> str:
    return ",".join(str(round(max(0.0, min(1.0, x)) * 255)) for x in (c.r, c.g, c.b))


def kde_colors(gen: Generated) -> dict[str, dict[str, str]]:
    """The kdeglobals color groups (KDE color scheme keys) for this palette."""
    window, window_fg = _solid(gen, "window_bg_color"), _solid(gen, "window_fg_color")
    view, view_fg = _solid(gen, "view_bg_color"), _solid(gen, "view_fg_color", "view_bg_color")
    button = mix(window, window_fg, 0.10)
    accent_bg, accent_fg = _solid(gen, "accent_bg_color"), _solid(gen, "accent_fg_color", "accent_bg_color")
    link = _solid(gen, "accent_color")
    head, head_fg = _solid(gen, "headerbar_bg_color"), _solid(gen, "headerbar_fg_color", "headerbar_bg_color")
    tip, tip_fg = _solid(gen, "popover_bg_color"), _solid(gen, "popover_fg_color", "popover_bg_color")
    side = _solid(gen, "sidebar_bg_color")
    error, warning, success = (_solid(gen, n) for n in ("error_color", "warning_color", "success_color"))

    def group(bg: Color, fg: Color, alt: Color) -> dict[str, str]:
        return {"BackgroundNormal": _rgb(bg), "BackgroundAlternate": _rgb(alt), "ForegroundNormal": _rgb(fg),
                "ForegroundInactive": _rgb(_disabled(fg, bg)), "ForegroundActive": _rgb(link),
                "ForegroundLink": _rgb(link), "ForegroundVisited": _rgb(mix(link, fg, 0.3)),
                "ForegroundNegative": _rgb(error), "ForegroundNeutral": _rgb(warning),
                "ForegroundPositive": _rgb(success), "DecorationFocus": _rgb(accent_bg),
                "DecorationHover": _rgb(accent_bg)}

    selection = group(accent_bg, accent_fg, mix(accent_bg, accent_fg, 0.1))
    selection.update(ForegroundActive=_rgb(accent_fg), ForegroundLink=_rgb(accent_fg))
    return {
        "Colors:Window": group(window, window_fg, side),
        "Colors:View": group(view, view_fg, mix(view, view_fg, 0.04)),
        "Colors:Button": group(button, window_fg, mix(button, window_fg, 0.05)),
        "Colors:Selection": selection,
        "Colors:Tooltip": group(tip, tip_fg, tip),
        "Colors:Complementary": group(head, head_fg, head),
        "Colors:Header": group(head, head_fg, head),
        "Colors:Header][Inactive": group(head, head_fg, head),
        "WM": {"activeBackground": _rgb(head), "activeForeground": _rgb(head_fg),
               "inactiveBackground": _rgb(head), "inactiveForeground": _rgb(_disabled(head_fg, head))},
    }
