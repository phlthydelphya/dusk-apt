"""Sample libadwaita widgets with a generated stylesheet, in their own process.

    python3 -m theme_unifier.gui.preview CSS_FILE light|dark [THEME_NAME [SHELL_CHOICE]]

The CSS is loaded at USER priority into this process only. Nothing is written
to the user's gtk.css, and it is not read either: GTK loads
$XDG_CONFIG_HOME/gtk-4.0/gtk.css into every app, which mixed the applied
theme into the preview of another, so this process gets a config directory
without it (see _without_user_gtk4_css). The temporary CSS file is deleted on
exit.

With a SHELL_CHOICE (auto, generated, off) the window also shows the whole
screen as it would look: the GNOME Shell with that theme and these sample
widgets in a window of their own, rendered by a throwaway headless Shell
(theme_unifier.shellpreview). "none" leaves the Shell out (that is also how
the sample window runs inside the hidden Shell).

With a SHELL_CHOICE it also shows the other kinds of apps Apply reaches:
libadwaita, Flatpak, Snap and Qt sample windows, each drawn the way that kind
of app will draw it (theme_unifier.appspreview, in a hidden Shell of its own).
"none" leaves them out too, since they need a hidden Shell as well.
"""

from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, Gtk  # noqa: E402

SHELL_JOBS: list[subprocess.Popen] = []
SHELL_PNGS: list[str] = []
APP_DIRS: list[str] = []  # the app pictures' folders, removed on exit
REAL_CONFIG_HOME = os.environ.get("XDG_CONFIG_HOME")  # before main() hides gtk.css from this process


PICTURE_HEIGHT = 520  # the screen picture, scaled to fit; "Full Size" opens it 1:1
APP_PICTURE_HEIGHT = 300  # each app picture; clicking it opens it 1:1


def shell_section(theme: str, mode: str, choice: str, css_path: str, extensions: bool = False,
                  authored: bool = False) -> Gtk.Widget:
    """The screen as the Shell would draw it with an app open, filled in when the render is done."""
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
    top = Gtk.Box(spacing=6)
    top.append(Gtk.Label(label="Preview: GNOME Shell and a sample app", xalign=0, hexpand=True,
                         css_classes=["heading"]))
    full = Gtk.Button(label="_Full Size", use_underline=True, sensitive=False, css_classes=["flat"])
    top.append(full)
    box.append(top)
    stack = Gtk.Stack(vhomogeneous=False)
    waiting = Gtk.Box(spacing=8)
    waiting.append(Gtk.Spinner(spinning=True))
    waiting.append(Gtk.Label(label="Starting a hidden GNOME Shell with this theme and a sample window…",
                             xalign=0, css_classes=["dim-label"]))
    stack.add_named(waiting, "waiting")
    picture = Gtk.Picture(can_shrink=True, content_fit=Gtk.ContentFit.CONTAIN, height_request=PICTURE_HEIGHT,
                          hexpand=True, alternative_text=f"The GNOME Shell and a sample app window with {theme}")
    stack.add_named(picture, "picture")
    box.append(stack)
    note = Gtk.Label(xalign=0, wrap=True, css_classes=["dim-label", "caption"])
    box.append(note)

    fd, png = tempfile.mkstemp(prefix="theme-unifier-shell-preview-", suffix=".png")
    os.close(fd)
    SHELL_PNGS.append(png)
    argv = [sys.executable, "-m", "theme_unifier.shellpreview", theme, mode, choice, png, css_path]
    if extensions:
        argv.append("--extensions")
    if authored:
        argv.append("--authored")
    job = subprocess.Popen(argv,
                           stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True,
                           start_new_session=True)
    SHELL_JOBS.append(job)

    def poll() -> bool:
        if job.poll() is None:
            return True
        text = job.stdout.read().strip()
        if job.returncode == 0:
            picture.set_file(Gio.File.new_for_path(png))
            stack.set_visible_child_name("picture")
            full.set_sensitive(True)
            note.set_label(text + " The isolated Shell uses sample widgets and does not connect to your desktop "
                           "services. Other extensions and their effects are not shown.")
        else:
            waiting.get_first_child().set_spinning(False)
            waiting.get_last_child().set_label("No Shell preview.")
            note.set_label(text)
        return False

    def open_full(_button) -> None:
        win = Gtk.Window(title=f"Your screen with {theme} ({mode})", transient_for=box.get_root(),
                         default_width=1280, default_height=800)
        win.set_child(Gtk.Picture(file=Gio.File.new_for_path(png), can_shrink=True,
                                  content_fit=Gtk.ContentFit.CONTAIN))
        win.present()

    full.connect("clicked", open_full)
    GLib.timeout_add(200, poll)
    return box


def _full_size(parent: Gtk.Widget, png: str, title: str) -> None:
    win = Gtk.Window(title=title, transient_for=parent.get_root(), default_width=900, default_height=720)
    win.set_child(Gtk.Picture(file=Gio.File.new_for_path(png), can_shrink=True, content_fit=Gtk.ContentFit.CONTAIN))
    win.present()


def _app_panel(panel: dict, theme: str, mode: str) -> Gtk.Widget:
    card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, valign=Gtk.Align.START)
    card.append(Gtk.Label(label=panel["title"], xalign=0, css_classes=["heading"]))
    if panel.get("png"):
        picture = Gtk.Picture(file=Gio.File.new_for_path(panel["png"]), can_shrink=True,
                              content_fit=Gtk.ContentFit.CONTAIN, height_request=APP_PICTURE_HEIGHT,
                              alternative_text=f"A sample window as {panel['title']} will draw it with {theme}")
        button = Gtk.Button(child=picture, css_classes=["flat"], tooltip_text="Open at full size")
        button.connect("clicked", lambda b: _full_size(b, panel["png"], f"{panel['title']} with {theme} ({mode})"))
        card.append(button)
    card.append(Gtk.Label(label=panel["note"], xalign=0, wrap=True, max_width_chars=60,
                          css_classes=["dim-label", "caption"]))
    return card


def apps_section(theme: str, mode: str, css_path: str, authored: bool = False) -> Gtk.Widget:
    """libadwaita, Flatpak, Snap and Qt sample windows as each will draw them, filled in when rendered."""
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
    box.append(Gtk.Label(label="Preview: libadwaita, Flatpak, Snap and Qt apps", xalign=0,
                         css_classes=["heading"], margin_top=6))
    waiting = Gtk.Box(spacing=8)
    waiting.append(Gtk.Spinner(spinning=True))
    waiting.append(Gtk.Label(label="Opening a sample window for each kind of app in a hidden GNOME Shell…",
                             xalign=0, wrap=True, css_classes=["dim-label"]))
    box.append(waiting)
    # two equal columns: a picture's natural width is the whole window it shows, which would
    # otherwise put one panel on each line
    grid = Gtk.Grid(column_homogeneous=True, column_spacing=18, row_spacing=18, visible=False)
    box.append(grid)

    out = tempfile.mkdtemp(prefix="theme-unifier-apps-preview-")
    APP_DIRS.append(out)
    argv = [sys.executable, "-m", "theme_unifier.appspreview", theme, mode, css_path, out]
    if authored:
        argv.append("--authored")
    # the renderer reads the real config folder (which snaps link to gtk.css, the user's qtNct
    # settings); it never writes there
    env = dict(os.environ)
    env.pop("XDG_CONFIG_HOME", None)
    if REAL_CONFIG_HOME is not None:
        env["XDG_CONFIG_HOME"] = REAL_CONFIG_HOME
    job = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True,
                           start_new_session=True, env=env)
    SHELL_JOBS.append(job)

    def poll() -> bool:
        if job.poll() is None:
            return True
        try:
            panels = json.loads(job.stdout.read())["panels"]
        except (ValueError, KeyError, TypeError):
            panels = None
        if not panels:
            waiting.get_first_child().set_spinning(False)
            waiting.get_last_child().set_label("No app previews.")
            return False
        box.remove(waiting)
        for i, panel in enumerate(panels):
            grid.attach(_app_panel(panel, theme, mode), i % 2, i // 2, 1, 1)
        grid.set_visible(True)
        return False

    GLib.timeout_add(200, poll)
    return box


def stop_shell_jobs() -> None:
    for job in SHELL_JOBS:
        if job.poll() is None:
            try:
                job.send_signal(signal.SIGTERM)  # the renderer stops its hidden Shell itself (shellpreview.py)
                job.wait(20)
            except (OSError, subprocess.TimeoutExpired):
                pass


def build(app: Adw.Application, css_path: str, mode: str, theme: str, shell: str, extensions: bool = False,
          authored: bool = False) -> None:
    Adw.StyleManager.get_default().set_color_scheme(
        Adw.ColorScheme.FORCE_DARK if mode == "dark" else Adw.ColorScheme.FORCE_LIGHT)
    provider = Gtk.CssProvider()
    provider.load_from_path(css_path)
    Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_USER)

    win = Adw.ApplicationWindow(application=app, title=f"Preview: {theme} ({mode})")
    w, _, h = os.environ.get("THEME_UNIFIER_PREVIEW_SIZE", "1100x960").partition("x")
    win.set_default_size(int(w), int(h))
    split = Adw.OverlaySplitView(collapsed=False, show_sidebar=True, min_sidebar_width=180)
    side = Gtk.ListBox(css_classes=["navigation-sidebar"])
    for name in ("Sidebar item", "Another item", "Third item"):
        side.append(Gtk.Label(label=name, xalign=0, margin_top=6, margin_bottom=6))
    side.select_row(side.get_row_at_index(0))
    # The sidebar gets its own header bar: with the sidebar shown, libadwaita
    # puts the window buttons from the start of the layout there, not in the
    # content's header bar (left-hand buttons would otherwise vanish).
    side_view = Adw.ToolbarView()
    side_view.add_top_bar(Adw.HeaderBar(show_title=False))
    side_view.set_content(side)
    split.set_sidebar(side_view)

    # A toolbar view, as real libadwaita apps build their content pane: themes
    # style its content (cards, insets) and the sidebar's selection joins it
    content = Adw.ToolbarView()
    header = Adw.HeaderBar(show_title=True)
    header.set_title_widget(Adw.WindowTitle(title="Preview", subtitle="Nothing here is applied"))
    header.pack_start(Gtk.Button(icon_name="list-add-symbolic", tooltip_text="Header button"))
    content.add_top_bar(header)

    body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin_top=18, margin_bottom=18,
                   margin_start=18, margin_end=18)
    if shell != "none":
        body.append(shell_section(theme, mode, shell, css_path, extensions, authored))
        body.append(apps_section(theme, mode, css_path, authored))
        if authored:
            body.append(Gtk.Label(label="Application preview: the theme's own GTK4 stylesheet.",
                                  xalign=0, wrap=True, css_classes=["dim-label"]))
        body.append(Gtk.Label(label="libadwaita apps (try them)", xalign=0, css_classes=["heading"],
                              margin_top=6))
    body.append(Gtk.Label(label="Window text", xalign=0))
    for cls in ("accent", "error", "warning", "success"):
        body.append(Gtk.Label(label=f"{cls.title()} text", xalign=0, css_classes=[cls]))
    group = Adw.PreferencesGroup(title="A card list")
    group.add(Adw.ActionRow(title="Row", subtitle="Card text"))
    group.add(Adw.SwitchRow(title="A switch", active=True))
    group.add(Adw.EntryRow(title="An entry"))
    body.append(group)
    buttons = Gtk.Box(spacing=8)
    buttons.append(Gtk.Button(label="Suggested", css_classes=["suggested-action"]))
    buttons.append(Gtk.Button(label="Destructive", css_classes=["destructive-action"]))
    buttons.append(Gtk.Button(label="Normal"))
    buttons.append(Gtk.Button(label="Disabled", sensitive=False))
    body.append(buttons)
    body.append(Gtk.CheckButton(label="A check box", active=True))
    scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
    scale.set_value(60)
    body.append(scale)
    scroller = Gtk.ScrolledWindow(vexpand=True)
    scroller.set_child(body)
    content.set_content(scroller)
    split.set_content(content)
    win.set_content(split)
    win.present()


def _without_user_gtk4_css() -> str | None:
    """Point this process at a config directory that mirrors the user's
    (a link to each entry, so dconf, fonts and the rest are unchanged) without
    gtk-4.0, so GTK does not load the user's gtk.css. Must run before GTK
    starts. Returns the directory to remove on exit, or None."""
    real = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    if not os.path.isfile(os.path.join(real, "gtk-4.0", "gtk.css")):
        return None
    tmp = tempfile.mkdtemp(prefix="theme-unifier-preview-config-")
    try:
        for name in os.listdir(real):
            if name != "gtk-4.0":
                os.symlink(os.path.join(real, name), os.path.join(tmp, name))
    except OSError:
        shutil.rmtree(tmp, ignore_errors=True)
        return None
    os.environ["XDG_CONFIG_HOME"] = tmp
    return tmp


def main() -> int:
    config_dir = _without_user_gtk4_css()
    css_path, mode = sys.argv[1], sys.argv[2]
    theme = sys.argv[3] if len(sys.argv) > 3 else "theme"
    shell = sys.argv[4] if len(sys.argv) > 4 else "none"
    app = Adw.Application(application_id="io.github.phlthydelphya.ThemeUnifier.Preview", flags=Gio.ApplicationFlags.NON_UNIQUE)
    extensions = len(sys.argv) > 5 and sys.argv[5] == "extensions"
    authored = len(sys.argv) > 6 and sys.argv[6] == "authored"
    app.connect("activate", lambda a: build(a, css_path, mode, theme, shell, extensions, authored))
    GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGTERM, lambda: app.quit() or False)
    try:
        return app.run([])
    finally:
        stop_shell_jobs()
        if config_dir:
            shutil.rmtree(config_dir, ignore_errors=True)  # links only
        for folder in APP_DIRS:
            shutil.rmtree(folder, ignore_errors=True)
        for path in [css_path, *SHELL_PNGS]:
            if os.path.basename(path).startswith("theme-unifier-"):
                try:
                    os.unlink(path)
                except OSError:
                    pass


if __name__ == "__main__":
    sys.exit(main())
