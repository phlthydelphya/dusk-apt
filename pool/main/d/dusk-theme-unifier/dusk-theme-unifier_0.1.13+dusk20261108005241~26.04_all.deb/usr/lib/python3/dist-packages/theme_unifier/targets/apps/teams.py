"""teams-for-linux (Flatpak): its custom CSS option, filled with the palette.

The app reads `appearance.cssLocation` from its config.json and injects that
CSS file into the Teams page when it starts (theme settings are restart-only).
`appearance.cssName`, a packaged theme, wins over the location. The selectors
below are the ones the app's own packaged themes (compactDark, condensedLight,
...) use for colors; no others are guessed.
"""

from __future__ import annotations

import json
from pathlib import Path

from ...colors import Color, mix
from ...host import _read

NAME = "teams-for-linux"
APP_ID = "com.github.IsmaelMartinez.teams_for_linux"

_THREAD = ".message-list-common:not(.chat-style)"
_CHAT = ".message-list-common.chat-style"
# (selector prefix, palette role): the hover backgrounds of a message's name and time row.
# None is my own messages: the view color tinted with the accent, so they stand out
# from other people's (many themes give window, sidebar and header bar one color).
_ROWS = [(f"{_THREAD} .conversation-start", "window_bg_color"),  # first message of a thread
         (f"{_THREAD} .conversation-reply", "card_bg_color"),  # replies in a thread
         (_CHAT, "view_bg_color"),  # other people's messages in a chat
         (f"{_CHAT} .self", None)]  # my messages in a chat
OWN_TINT = 0.25  # share of the accent in my own messages' background


def app_dir() -> Path:
    return Path.home() / ".var" / "app" / APP_ID


def css_path() -> Path:
    return app_dir() / "config" / "teams-for-linux" / "theme-unifier.css"


def config_path() -> Path:
    return css_path().with_name("config.json")


def detect() -> bool:
    """Whether the Flatpak app has a data folder (it has been installed for this user)."""
    return app_dir().is_dir()


def own_color(colors: dict) -> str:
    """My own messages' background: the view color with a share of the accent."""
    return mix(Color.from_hex(colors["view_bg_color"]), Color.from_hex(colors["accent_bg_color"]), OWN_TINT).to_hex()


def stylesheet(palette: dict) -> bytes:
    """The CSS for the palette's mode. The same palette gives the same bytes."""
    colors = palette["colors"]
    lines = [f"/* Managed by theme-unifier ({palette['theme']}, {palette['mode']}). Revert removes this file. */"]
    for prefix, role in _ROWS:
        row = f"{prefix} .ts-message-thread-body:hover .message-body-top-row"
        color = colors[role] if role else own_color(colors)
        lines.append(f"{row},\n{row} .timestamp-column {{\n  background: {color} !important;\n}}")
    return ("\n".join(lines) + "\n").encode()


def config_text() -> bytes:
    """A config.json that only points the app at the CSS file."""
    return (json.dumps({"appearance": {"cssLocation": str(css_path())}}, indent=2) + "\n").encode()


def _setting(config: dict, nested: str, legacy: str):
    """A theme setting from a parsed config.json: the nested key, or its deprecated flat alias."""
    appearance = config.get("appearance")
    value = appearance.get(nested) if isinstance(appearance, dict) else None
    return value or config.get(legacy)


def _parsed(data: bytes) -> dict:
    try:
        config = json.loads(data)
    except ValueError:
        return {}
    return config if isinstance(config, dict) else {}


def plan(palette: dict, mode: str, old_rec: dict, out: list[str]) -> tuple[dict, dict[Path, bytes], list[dict]]:
    """Own the CSS file, and a config.json that points at it when there is none.
    An existing config.json is never edited: if it already points at the CSS
    file only the CSS is written, otherwise nothing is and the user is told
    what to add. A config.json we created is ours only while its bytes are
    still what we wrote; once the app saves its own choice into it, it is
    treated like any other user config."""
    css, config = css_path(), config_path()
    cur = _read(config)
    if cur is None or (str(config) in old_rec.get("files", []) and cur == config_text()):
        files = {css: stylesheet(palette), config: config_text()}
        rec = {"files": [str(p) for p in files], "mode": mode, "config": "created"}
    else:
        settings = _parsed(cur)
        if _setting(settings, "cssName", "customCSSName"):
            out.append(f"{NAME}: config.json exists and picks a packaged theme (appearance.cssName), which wins "
                       "over a CSS file; no colors were written.")
            return {}, {}, []
        if _setting(settings, "cssLocation", "customCSSLocation") != str(css):
            out.append(f'{NAME}: config.json exists; add "appearance": {{"cssLocation": "{css}"}} '
                       "yourself to use the colors.")
            return {}, {}, []
        files = {css: stylesheet(palette)}
        rec = {"files": [str(css)], "mode": mode, "config": "yours"}
    out.append(f"{NAME}: restart it to see the colors (it reads its theme only at start).")
    return rec, files, []


def restore(rec: dict, force: bool) -> tuple[dict[Path, bytes | None], list[dict]]:
    """Nothing beyond the owned files, which revert removes."""
    return {}, []


def status(rec: dict) -> str:
    if not rec:
        return "config.json is yours and does not point at the theme-unifier CSS, so no colors were written"
    how = "config.json created by theme-unifier" if rec.get("config") == "created" else "your config.json points at it"
    return f"{rec['mode']} colors in {css_path()} ({how}); restart the app after a change"
