"""What the GUI shows and does, without GTK, so it can be tested directly.

Every change goes through ops.py, the same code the CLI runs, so the GUI has
the same safety rules (journal, conflict checks, D2/D3/D5/D7). Nothing here
writes a file itself.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .. import flatpak as fp
from .. import ops, session
from ..targets import apps as t_apps
from ..generate import generate
from ..host import EXIT_CONFLICT, Host, HostError
from ..loader import find_theme, list_themes
from ..variants import discover

MODE_CHOICES = ("system", "light", "dark")
MODE_LABELS = {"system": "Follow the system", "light": "Light", "dark": "Dark"}
GTK4_CHOICES = ("auto", "generated", "off")
GTK4_LABELS = {"auto": "Automatic", "generated": "Always generate", "off": "Leave alone"}
SHELL_CHOICES = GTK4_CHOICES
SHELL_LABELS = GTK4_LABELS
ADWAITA_CHOICES = ("auto", "palette")
ADWAITA_LABELS = {"auto": "Follow theme", "palette": "Colors only"}
BUTTONS_CHOICES = ("auto", "off")
BUTTONS_LABELS = {"auto": "Follow theme", "off": "Leave alone"}
ACCENT_CHOICES = ("off", "set")  # off first: the accent is often owned by something else
ACCENT_LABELS = {"off": "Leave alone", "set": "Follow theme"}
APPS_CHOICES = ("auto", "off")
APPS_LABELS = {"auto": "Follow theme", "off": "Leave alone"}


@dataclass
class ColorRow:
    name: str
    css: str
    rgba: tuple[float, float, float, float]
    kind: str  # "theme", "adjusted", "derived" or "low"
    note: str  # where it came from, and why it isn't the theme's value


@dataclass
class PaletteView:
    theme: str
    mode: str
    rows: list[ColorRow] = field(default_factory=list)
    unavailable: str | None = None  # D2 explanation when the theme has no palette for the mode
    unresolved: list[str] = field(default_factory=list)  # pairs still below target (apply refuses)
    left_default: list[str] = field(default_factory=list)  # names left to libadwaita


def _sentence(text: str) -> str:
    return text[:1].upper() + text[1:]


def theme_names() -> list[str]:
    return [t.name for t in list_themes()]


def system_theme() -> str | None:
    return session.gtk_theme()


def authored_gtk4_css(theme: str, mode: str):
    """The theme's own GTK4 CSS for comparison, never generated output."""
    folder = ops.gtk4theme.own_gtk4_dir(theme)
    if folder is None:
        return None
    dark = folder / "gtk-dark.css"
    return dark if mode == "dark" and dark.is_file() else folder / "gtk.css"


def resolve_mode(choice: str) -> str:
    if choice == "system":
        return session.color_scheme() or "light"
    return choice


def palette_view(theme_name: str, mode: str) -> PaletteView:
    vs = discover(find_theme(theme_name))
    view = PaletteView(theme_name, mode)
    if mode not in vs.palettes:
        view.unavailable = vs.missing_mode_message(mode)
        return view
    gen = generate(vs.palettes[mode], mode)
    for i in gen.items:
        if i.adjusted_from is not None:
            kind = "adjusted"
            note = f"Adjusted for contrast: the theme has {i.adjusted_from.to_css()}. {_sentence(i.reason)}"
        elif i.derived:
            kind, note = "derived", f"Not in the theme: {i.reason}"
        elif i.confidence == "low":
            kind, note = "low", f"Low confidence: {i.source}"
        else:
            kind, note = "theme", f"From the theme: {i.source}"
        c = i.color
        view.rows.append(ColorRow(i.name, c.to_css(), (c.r, c.g, c.b, c.a), kind, note))
    view.unresolved = [f"{fg} on {bg}: {r}:1, needs {need}:1" for fg, bg, r, need in gen.unresolved]
    view.left_default = sorted(gen.not_overridden)
    return view


def modes_of(theme_name: str) -> list[str]:
    return discover(find_theme(theme_name)).modes


# --- Actions (run off the main thread by the window) ---------------------------


@dataclass
class Result:
    ok: bool
    lines: list[str]
    code: int = 0
    can_force: bool = False  # a conflict that --force would override


def _run(fn, *args, **kw) -> Result:
    try:
        return Result(True, fn(*args, host=Host(), **kw))
    except HostError as e:
        return Result(False, [str(e)], e.code, e.code == EXIT_CONFLICT)


def apply(theme: str, mode_choice: str, gtk4: str, force: bool = False, shell: str = "auto",
          dry_run: bool = False, buttons: str = "auto", adwaita: str = "auto", accent: str = "off",
          apps: str = "auto") -> Result:
    mode = None if mode_choice == "system" else mode_choice
    return _run(ops.apply, theme, mode, force=force, gtk4=gtk4, shell=shell, dry_run=dry_run, buttons=buttons,
                adwaita=adwaita, accent=accent, apps=apps)


def shell_available() -> bool:
    """Whether the User Themes extension's settings exist (it is installed)."""
    return session.user_theme_name() is not None


def revert(force: bool = False) -> Result:
    return _run(ops.revert, force=force)


def doctor() -> Result:
    return _run(ops.doctor)


def status() -> Result:
    return _run(ops.status)


def flatpak_set(app: str, enabled: bool, force: bool = False) -> Result:
    if enabled:
        return _run(ops.flatpak_add, [app])
    return _run(ops.flatpak_remove, [app], force=force)


def flatpak_apps() -> list[tuple[str, str, bool]]:
    """(app ID, runtime, enabled) for installed Flatpak apps."""
    try:
        m, _ = Host().load()
    except HostError:
        m = None
    enabled = m.flatpak if m else {}
    try:
        rows = fp.installed_apps()
    except HostError:
        rows = []
    return [(app, runtime, app in enabled) for app, runtime in rows]


# What each choice does, shown under its row and kept short enough that the
# row's value isn't cut off. {apps} is the list of installed apps with an adapter.
DESCRIPTIONS = {
    "mode": {"system": "Light or dark like the system, and switch with it",
             "light": "Always the theme's light colors",
             "dark": "Always the theme's dark colors"},
    "adwaita": {"auto": "The theme's own GTK4 styles, or its colors if it has none",
                "palette": "libadwaita's own look in the theme's colors"},
    "gtk4": {"auto": "A GTK4 theme from the colors only if the theme has none",
             "generated": "A GTK4 theme from the colors, replacing the theme's own",
             "off": "Plain GTK4 apps keep their current look"},
    "shell": {"auto": "The theme's own Shell theme, or one built from its colors",
              "generated": "A Shell theme built from the colors, always",
              "off": "The top bar and menus keep their current look"},
    "buttons": {"auto": "The theme's window-button layout, if it has one",
                "off": "Window buttons stay where they are"},
    "accent": {"off": "Left as it is, e.g. when the wallpaper sets it",
               "set": "Set to the system accent closest to the theme's"},
    "apps": {"auto": "{apps} get the colors (restart them after applying)",
             "off": "{apps} keep their own look"},
}


def describe(setting: str, choice: str, apps: list[str] | None = None) -> str:
    """The subtitle for a setting's row: what its current choice does."""
    if setting == "apps" and not apps:
        return "No installed app with a theme option"
    return DESCRIPTIONS[setting][choice].format(apps=", ".join(apps or []))


def summary(status_lines: list[str]) -> tuple[str, str]:
    """The Theme page's one-line state, from `status` output: what is applied,
    when, and whether the watcher runs."""
    applied = next((l for l in status_lines if l.startswith("Applied: ")), None)
    if applied is None:
        return "Nothing applied", "Pick a theme and press Apply"
    what, _, when = applied[len("Applied: "):].partition(" at ")
    watcher = next((l for l in status_lines if l.startswith("Watcher: ")), "")
    state = watcher[len("Watcher: "):].split(" (")[0].rstrip(".")
    return what, f"Applied {when}" + (f" · watcher {state}" if state else "")


def detected_apps() -> list[str]:
    """Installed apps that have an adapter (their own theme option)."""
    return [a.NAME for a in t_apps.ADAPTERS if a.detect()]


def applied_choices() -> dict[str, str]:
    """The accent and app choices of what is applied, so the window starts on
    them and a re-apply from the GUI doesn't undo a choice made with the CLI.
    Defaults when nothing is applied."""
    try:
        m, _ = Host().load()
    except HostError:
        m = None
    if m is None:
        return {"accent": "off", "apps": "auto"}
    # --apps off leaves no adapter record at all; auto records every detected app.
    apps_off = not m.apps and bool(detected_apps())
    return {"accent": "set" if m.accent else "off", "apps": "off" if apps_off else "auto"}


def restart_needed() -> list[dict]:
    """Apps (pid, start, name) that started before the applied theme and still run."""
    try:
        m, _ = Host().load()
    except HostError:
        return []
    return session.still_running(m.restart_needed) if m else []


def applied() -> tuple[str, str] | None:
    """(theme, mode) currently applied, if any."""
    try:
        m, _ = Host().load()
    except HostError:
        return None
    return (m.theme, m.mode) if m else None
