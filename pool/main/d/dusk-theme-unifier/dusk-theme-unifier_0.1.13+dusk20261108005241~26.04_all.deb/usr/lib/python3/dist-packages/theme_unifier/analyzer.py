"""Turn a GTK3 theme's stylesheet into a neutral Palette.

Colors are taken, in order of preference, from:
  1. @define-color names (the standard GTK3 theme_* names and common aliases),
  2. background/color declarations on well-known selectors such as headerbar,
  3. values derived from colors already found, marked "derived" in the output.

Every color carries a confidence (high/medium/low), its origin stylesheet,
and notes explaining anything that lowered confidence. See docs/PLAN.md,
"Analyzer limitations".
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from . import cssparse
from .colors import Color, contrast_ratio, evaluate, mix, shade, try_evaluate
from .loader import Theme
from .palette import ROLES, Entry, Palette

# Role -> @define-color names to try, best first. Names in STANDARD_NAMES
# are GTK3's documented public colors; the rest are conventions some theme
# families use, so they get medium confidence.
DEFINE_NAMES: dict[str, list[str]] = {
    "window_bg": ["theme_bg_color", "bg_color", "window_bg_color"],
    "window_fg": ["theme_fg_color", "fg_color", "window_fg_color"],
    "view_bg": ["theme_base_color", "base_color", "view_bg_color", "content_view_bg"],
    "view_fg": ["theme_text_color", "text_color", "view_fg_color"],
    "accent_bg": ["theme_selected_bg_color", "selected_bg_color", "accent_bg_color"],
    "accent_fg": ["theme_selected_fg_color", "selected_fg_color", "accent_fg_color"],
    "accent": ["accent_color", "link_color", "theme_selected_bg_color", "selected_bg_color"],
    "headerbar_bg": ["headerbar_bg_color", "header_bg_color", "titlebar_bg_color", "wm_bg"],
    # wm_title is deliberately absent: it styles window-manager titles, and
    # GTK3 headerbar labels inherit the window text color instead.
    "headerbar_fg": ["headerbar_fg_color", "header_fg_color", "titlebar_fg_color"],
    "headerbar_backdrop": ["headerbar_backdrop_color", "wm_unfocused_bg", "wm_bg_unfocused"],
    "sidebar_bg": ["sidebar_bg_color", "sidebar_bg"],
    "sidebar_fg": ["sidebar_fg_color"],
    "card_bg": ["card_bg_color"],
    "popover_bg": ["popover_bg_color", "menu_bg_color"],
    "dialog_bg": ["dialog_bg_color"],
    "borders": ["borders", "border_color", "theme_border_color"],
    "destructive_bg": ["destructive_bg_color", "destructive_color", "error_color"],
    "success": ["success_color"],
    "warning": ["warning_color"],
    "error": ["error_color"],
}

STANDARD_NAMES = {
    "theme_bg_color", "theme_fg_color", "theme_base_color", "theme_text_color",
    "theme_selected_bg_color", "theme_selected_fg_color", "borders",
    "success_color", "warning_color", "error_color", "link_color",
    # libadwaita-style names, used by themes that target both toolkits
    "window_bg_color", "window_fg_color", "view_bg_color", "view_fg_color",
    "accent_bg_color", "accent_fg_color", "accent_color", "headerbar_bg_color",
    "headerbar_fg_color", "headerbar_backdrop_color", "sidebar_bg_color",
    "sidebar_fg_color", "card_bg_color", "popover_bg_color", "dialog_bg_color",
    "destructive_bg_color",
}

# Name-based sources that a matching rule block should replace, because the
# rule is what GTK actually paints (wm_* colors are for window managers).
WEAK_DEFINE_PREFIXES = ("@wm_", "@menu_", "@titlebar_")

# Role -> (selectors, properties) to read from rule blocks, best first.
RULE_SOURCES: dict[str, tuple[list[str], list[str]]] = {
    "headerbar_bg": (["headerbar", ".titlebar:not(headerbar)", ".titlebar", "headerbar.titlebar"],
                     ["background-image", "background", "background-color"]),
    "headerbar_fg": (["headerbar", ".titlebar:not(headerbar)", ".titlebar"], ["color"]),
    "headerbar_border": (["headerbar", ".titlebar:not(headerbar)", ".titlebar"],
                         ["border-bottom-color", "border-color", "border-bottom", "border"]),
    "headerbar_backdrop": (["headerbar:backdrop", ".titlebar:backdrop:not(headerbar)",
                            ".titlebar:backdrop"],
                           ["background-image", "background", "background-color"]),
    "sidebar_bg": ([".sidebar", "placessidebar", "stacksidebar", ".navigation-sidebar",
                    "placessidebar list", "stacksidebar list", ".sidebar list"],
                   ["background-image", "background", "background-color"]),
    "popover_bg": (["popover", "popover.background", "popover.menu", "menu", ".menu"],
                   ["background-image", "background", "background-color"]),
    "dialog_bg": (["messagedialog", "dialog", "messagedialog.background"],
                  ["background-image", "background", "background-color"]),
    "borders": (["frame > border", "separator"], ["border-color", "color", "background-color"]),
}

BACKGROUND_ROLES = ("window_bg", "view_bg", "headerbar_bg", "headerbar_backdrop",
                    "sidebar_bg", "card_bg", "popover_bg", "dialog_bg", "accent_bg")

# (text role, background role, minimum contrast) checked on the result.
TEXT_PAIRS = (
    ("window_fg", "window_bg", 4.5), ("view_fg", "view_bg", 4.5),
    ("headerbar_fg", "headerbar_bg", 4.5), ("sidebar_fg", "sidebar_bg", 4.5),
    ("accent_fg", "accent_bg", 3.0),
)

_GRADIENTS = ("linear-gradient(", "radial-gradient(", "-gtk-gradient(", "image(")


@dataclass
class _Value:
    color: Color
    gradient_stops: list[Color] | None = None  # set when taken from a gradient


def _gradient_stops(token: str, defines: dict[str, str]) -> list[Color]:
    inner = token[token.index("(") + 1 : -1]
    stops = []
    for stop in cssparse.split_top_level(inner, ","):
        v = _visible_color(stop, defines)
        if v is not None:
            stops.append(v.color)
    return stops


def _visible_color(value: str, defines: dict[str, str]) -> _Value | None:
    """The visible color of a CSS value.

    In a `background` shorthand a gradient is painted over the plain color,
    so a gradient wins over a bare color token. A gradient is approximated by
    the average of its color stops, which is what a two-stop linear gradient
    shows at its midpoint; the caller marks that as low confidence.
    """
    value = value.replace("!important", "")
    plain: Color | None = None
    for part in cssparse.split_top_level(value, ","):
        for token in cssparse.split_top_level(part.replace("\t", " "), " "):
            if token.startswith(_GRADIENTS):
                stops = _gradient_stops(token, defines)
                if stops:
                    n = len(stops)
                    avg = Color(sum(c.r for c in stops) / n, sum(c.g for c in stops) / n,
                                sum(c.b for c in stops) / n, sum(c.a for c in stops) / n)
                    return _Value(avg, stops)
                continue
            if plain is None:
                plain = try_evaluate(token, defines)
    return _Value(plain) if plain is not None else None


def _from_rules(sheet: cssparse.Stylesheet, selectors: Iterable[str], props: Iterable[str]) -> Entry | None:
    """Color from the last rule (cascade order) for the most preferred selector.

    Only exact selector matches count; more specific selectors elsewhere in
    the theme are not considered, which is noted on the entry.
    """
    props = list(props)
    for sel in (cssparse.normalize_selector(s) for s in selectors):
        hits: list[tuple[cssparse.Rule, str, _Value]] = []
        for rule in sheet.rules:
            if sel not in rule.selectors:
                continue
            for prop in props:
                if prop not in rule.declarations:
                    continue
                v = _visible_color(rule.declarations[prop], sheet.defines)
                if v is not None and v.color.a > 0:
                    hits.append((rule, prop, v))
                    break
        if not hits:
            continue
        rule, prop, v = hits[-1]
        notes = ["read from a fixed selector list; more specific selectors were not evaluated"]
        distinct = {h[2].color.to_css() for h in hits}
        if len(distinct) > 1:
            notes.append(f"{len(hits)} rules for '{sel}' disagree ({', '.join(sorted(distinct))}); used the last")
        confidence = "medium"
        if v.gradient_stops is not None:
            confidence = "low"
            stops = ", ".join(c.to_css() for c in v.gradient_stops)
            notes.append(f"gradient approximated by the average of its color stops ({stops})")
        return Entry(v.color, f"rule: {sel} {{ {prop} }}", confidence, rule.origin, notes)
    return None


def analyze(theme: Theme, dark: bool = False) -> Palette:
    sheet = theme.stylesheet(dark=dark)
    variant = "dark" if dark and theme.has_dark_variant else "light"
    pal = Palette(theme.name, variant, stylesheet=theme.stylesheet_path(dark), files=list(sheet.files))
    found: dict[str, Entry] = {}

    for m in sheet.missing:
        pal.source_problems.append(f"Could not read imported stylesheet {m}; colors from it are missing.")
    for c in sheet.cycles:
        pal.source_problems.append(f"Import cycle skipped: {c}.")
    pal.warnings.extend(pal.source_problems)
    if not sheet.defines:
        pal.warnings.append("No @define-color declarations found; most colors are guesses.")

    for role, names in DEFINE_NAMES.items():
        for name in names:
            if name not in sheet.defines:
                continue
            c = try_evaluate(f"@{name}", sheet.defines)
            if c is None:
                problem = f"@{name} could not be evaluated: {sheet.defines[name]!r}"
                pal.warnings.append(problem)
                pal.source_problems.append(problem)
                continue
            origins = sheet.define_origins.get(name, [""])
            notes = []
            confidence = "high"
            if name not in STANDARD_NAMES:
                confidence = "medium"
                notes.append(f"@{name} is a theme-family convention, not a GTK3 standard name")
            if len(origins) > 1:
                notes.append(f"@{name} is defined {len(origins)} times; the last definition wins")
            found[role] = Entry(c, f"@{name}", confidence, origins[-1], notes)
            break

    # Rule blocks give the real headerbar etc. and beat the wm_* fallbacks.
    for role, (selectors, props) in RULE_SOURCES.items():
        if role in found and not found[role].source.startswith(WEAK_DEFINE_PREFIXES):
            continue
        hit = _from_rules(sheet, selectors, props)
        if hit:
            found[role] = hit

    def derive(role: str, color: Color, how: str) -> None:
        if role not in found:
            found[role] = Entry(color, f"derived: {how}", "low", "", ["not found in the theme"])

    def inherit(role: str, parent: str) -> None:
        """Text color with no rule of its own: CSS `color` inherits."""
        if role not in found:
            p = found[parent]
            found[role] = Entry(p.color, f"inherited: {parent}", "medium", p.origin,
                                [f"no color of its own; inherits {parent} as CSS color does"])

    # Fallbacks for the core roles, so output is always complete.
    if "window_bg" not in found:
        found["window_bg"] = Entry(evaluate("#1e1e1e" if dark else "#fafafa"), "default", "low",
                                   "", ["no window background found; using a neutral default"])
    win = found["window_bg"].color
    derive("window_fg", Color(1, 1, 1) if win.is_dark() else Color(0, 0, 0, 0.8), "contrast with window_bg")
    derive("view_bg", shade(win, 1.08 if win.is_dark() else 1.03), "window_bg lightened")
    inherit("view_fg", "window_fg")
    derive("accent_bg", evaluate("#3584e4"), "GNOME blue")
    acc = found["accent_bg"].color
    derive("accent_fg", Color(0, 0, 0) if acc.luminance() > 0.4 else Color(1, 1, 1), "contrast with accent_bg")
    derive("accent", acc, "accent_bg")
    derive("headerbar_bg", shade(win, 1.1 if win.is_dark() else 0.95), "window_bg shaded")
    inherit("headerbar_fg", "window_fg")
    derive("headerbar_backdrop", found["headerbar_bg"].color, "headerbar_bg")
    derive("borders", mix(win, found["window_fg"].color.over(win), 0.18), "mix of window colors")
    derive("headerbar_border", found["borders"].color, "borders")
    derive("sidebar_bg", shade(win, 0.97 if not win.is_dark() else 1.05), "window_bg shaded")
    # Sidebars are lists, and GTK3 list rows use the view text color.
    inherit("sidebar_fg", "view_fg")
    derive("card_bg", found["view_bg"].color, "view_bg")
    derive("popover_bg", found["view_bg"].color, "view_bg")
    derive("dialog_bg", win, "window_bg")
    derive("error", evaluate("#c01c28"), "GNOME red")
    derive("warning", evaluate("#e5a50a"), "GNOME yellow")
    derive("success", evaluate("#2ec27e"), "GNOME green")
    derive("destructive_bg", found["error"].color, "error")

    # Backgrounds must be opaque to be usable as libadwaita surface colors.
    # Text colors keep their alpha.
    for role in BACKGROUND_ROLES:
        e = found[role]
        if e.color.a < 1.0:
            base = win if role != "window_bg" else Color(1, 1, 1)
            e.notes.append(f"had alpha {round(e.color.a, 3)}; flattened over "
                           f"{'window_bg' if role != 'window_bg' else 'white'}")
            e.color = e.color.over(base)
            if e.confidence == "high":
                e.confidence = "medium"

    # Report contrast, but never change the theme's colors here: judging
    # legibility belongs to the CSS generation step.
    for fg, bg, minimum in TEXT_PAIRS:
        ratio = contrast_ratio(found[fg].color.over(found[bg].color), found[bg].color)
        if ratio < minimum:
            msg = f"{fg} on {bg} has contrast {ratio:.2f}:1 (below {minimum}:1)"
            found[fg].notes.append(msg)
            pal.warnings.append(msg + " in the theme as extracted.")

    if dark and not theme.has_dark_variant:
        sib = theme.dark_sibling()
        hint = f" A separate dark theme is installed: {sib.name}." if sib else ""
        pal.warnings.append("Theme has no gtk-dark.css; analyzed its only stylesheet." + hint)

    pal.colors = {role: found[role] for role in ROLES}
    return pal
