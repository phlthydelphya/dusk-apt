"""`theme-unifier-gui` / `python3 -m theme_unifier.gui`."""

from __future__ import annotations

import sys


def main() -> int:
    import gi

    gi.require_version("Gtk", "4.0")
    gi.require_version("Adw", "1")
    from gi.repository import Adw, Gio, Gtk

    from .window import Window

    Gtk.Window.set_default_icon_name("io.github.phlthydelphya.ThemeUnifier")

    app = Adw.Application(application_id="io.github.phlthydelphya.ThemeUnifier",
                          flags=Gio.ApplicationFlags.DEFAULT_FLAGS)

    def activate(app):
        win = app.get_active_window() or Window(app)
        win.present()

    app.connect("activate", activate)
    return app.run(sys.argv[:1])


if __name__ == "__main__":
    sys.exit(main())
