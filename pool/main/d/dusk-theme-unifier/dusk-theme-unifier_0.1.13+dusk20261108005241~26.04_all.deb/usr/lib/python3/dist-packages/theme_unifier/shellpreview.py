"""Render the GNOME Shell as it would look with a theme, without applying it.

    python3 -m theme_unifier.shellpreview THEME light|dark auto|generated|off OUT.png [APP_CSS]

Starts a throwaway `gnome-shell --headless` (its own HOME, GSettings keyfile
backend and D-Bus buses, the same recipe as tools/m7_shell_check.py) with the
User Themes extension pointed at the theme the apply would use: the theme's
own Shell theme for "auto" when it ships one (D9), the generated one
otherwise, or the current Shell theme for "off" when it can be read. With APP_CSS, a sample app window (the
preview's own widgets with that stylesheet) opens inside the hidden Shell
first, so the picture shows the Shell and an app together. An automation
script then opens the quick settings menu and takes a screenshot of the whole
screen. Nothing in the real HOME or session is touched.
"""

from __future__ import annotations

import ast
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

from . import session, shelltheme
from .host import Paths

PROBE = r"""
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Shell from 'gi://Shell';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as QuickSettings from 'resource:///org/gnome/shell/ui/quickSettings.js';
import * as Scripting from 'resource:///org/gnome/shell/ui/scripting.js';
export var METRICS = {};
// The preview asks for an early stop by creating TU_STOP; returning from run()
// lets the Shell exit normally (a signal while it starts makes it abort).
const stopped = () => GLib.file_test(GLib.getenv('TU_STOP'), GLib.FileTest.EXISTS);
async function wait(ms) {
    for (let t = 0; t < ms; t += 100) {
        if (stopped())
            return false;
        await Scripting.sleep(100);
    }
    return !stopped();
}
export async function run() {
    if (!await wait(1000))
        return;
    const app = GLib.getenv('TU_APP');  // the sample window's command line, as JSON
    if (app) {
        GLib.spawn_async(null, JSON.parse(app), GLib.get_environ(), GLib.SpawnFlags.SEARCH_PATH, null);
        for (let t = 0; t < 20000 && global.get_window_actors().length === 0; t += 100) {
            if (!await wait(100))
                return;
        }
        if (!await wait(1500))  // let it draw its first frames
            return;
    }
    Main.overview.hide();
    if (!await wait(1000))
        return;
    // A headless Shell without GDM greets with a "Screen Lock disabled" banner.
    for (const source of Main.messageTray.getSources())
        source.destroy();
    // These actors are visual examples only; no desktop services are connected.
    const samples = [];
    try {
        const menu = Main.panel.statusArea.quickSettings.menu;
        const volume = new QuickSettings.QuickSlider({iconName: 'audio-volume-high-symbolic'});
        volume.slider.value = 0.6;
        menu.addItem(volume, 2);
        samples.push('volume');
        for (const [title, icon] of [['Sample Wi-Fi', 'network-wireless-signal-excellent-symbolic'],
                                     ['Sample Bluetooth', 'bluetooth-active-symbolic']]) {
            const item = new QuickSettings.QuickToggle({title, iconName: icon,
                toggle_mode: true, checked: true, reactive: false, can_focus: false});
            menu.addItem(item);
            samples.push(title);
        }
    } catch (e) {
        logError(e, 'Unable to add sample quick settings');
    }
    GLib.file_set_contents(GLib.getenv('TU_SAMPLES'), JSON.stringify(samples));
    const extensions = JSON.parse(GLib.getenv('TU_EXTENSIONS'));
    const states = Object.fromEntries(extensions.map(uuid => {
        const ext = Main.extensionManager.lookup(uuid);
        return [uuid, {state: ext?.state ?? null, error: ext?.error ?? null}];
    }));
    GLib.file_set_contents(GLib.getenv('TU_EXTENSION_STATES'), JSON.stringify(states));
    Main.panel.statusArea.quickSettings.menu.open(false);
    if (!await wait(800))
        return;
    const stream = Gio.File.new_for_path(GLib.getenv('TU_SHOT')).replace(null, false, Gio.FileCreateFlags.NONE, null);
    await new Shell.Screenshot().screenshot_area(0, 0, global.stage.width, global.stage.height, stream);
    stream.close(null);
}
export function finish() {}
"""


@dataclass
class Result:
    png: Path | None
    note: str  # what the picture shows, or why there is none


SAMPLE_SIZE = "900x640"  # the sample window inside the 1280x800 screen, so the desktop shows around it
SOCKET_PATH_MAX = 100  # sun_path is 108 bytes; leave room for "wayland-0.lock" and the like
BACKGROUND_KEYS = ("picture-uri", "picture-uri-dark", "picture-options", "primary-color")
APPEARANCE_KEYS = {
    "org.gnome.desktop.interface": ("accent-color", "icon-theme", "cursor-theme", "font-name",
                                    "document-font-name", "monospace-font-name"),
    "org.gnome.desktop.wm.preferences": ("button-layout",),
}
PREVIEW_EXTENSIONS = {
    "blur-my-shell@aunetx": ("Blur My Shell", "blur-my-shell"),
    "dash-to-dock@micxgx.gmail.com": ("Dash to Dock", "dash-to-dock"),
}


def _preview_extensions(home: Path, version: str | None) -> tuple[list[str], str, list[str]]:
    """Copy supported active extensions and their dconf settings into the temporary home."""
    enabled = session.enabled_extensions()
    if enabled is None or session.user_extensions_disabled():
        return [], "", ["Active extensions could not be read or are disabled."]
    roots = [Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local/share")]
    roots += [Path(p) for p in (os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share").split(":") if p]
    selected, settings, notes = [], [], []
    for uuid, (label, key) in PREVIEW_EXTENSIONS.items():
        if uuid not in enabled:
            notes.append(f"{label} is not enabled in the current session.")
            continue
        src = next((root / "gnome-shell/extensions" / uuid for root in roots
                    if (root / "gnome-shell/extensions" / uuid / "metadata.json").is_file()), None)
        try:
            if src is None:
                raise ValueError("extension files not found")
            metadata = json.loads((src / "metadata.json").read_text())
            if metadata.get("uuid") != uuid or version not in metadata.get("shell-version", []):
                raise ValueError("not compatible with this Shell version")
            dump = subprocess.run(["dconf", "dump", f"/org/gnome/shell/extensions/{key}/"],
                                  capture_output=True, text=True, timeout=5, check=True).stdout
            dest = home / ".local/share/gnome-shell/extensions" / uuid
            shutil.copytree(src, dest)
            prefix = f"org/gnome/shell/extensions/{key}"
            for line in dump.splitlines(keepends=True):
                if line.startswith("[") and line.rstrip().endswith("]"):
                    group = line.strip()[1:-1].strip("/")
                    line = f"[{prefix}{'/' + group if group else ''}]\n"
                settings.append(line)
            settings.append("\n")
            selected.append(uuid)
        except (OSError, ValueError, TypeError, subprocess.SubprocessError) as e:
            notes.append(f"{label} was not copied: {e}.")
    return selected, "".join(settings), notes


def _favorites() -> str:
    """Copy the Shell's favorite application IDs for a preview dock."""
    value = session._gsettings_get(session.SHELL_SCHEMA, "favorite-apps")
    try:
        apps = ast.literal_eval(value.removeprefix("@as ").strip()) if value is not None else None
    except (ValueError, SyntaxError):
        return ""
    if not isinstance(apps, list) or not all(isinstance(app, str) for app in apps):
        return ""
    return "favorite-apps=[" + ", ".join(session._gvariant_str(app) for app in apps) + "]\n"


def _appearance(scheme: str) -> str:
    """Copy selected string settings, omitting keys unavailable on older GNOME."""
    groups = []
    for schema, keys in APPEARANCE_KEYS.items():
        lines = [f"color-scheme='{scheme}'\n"] if schema == session.SCHEME_SCHEMA else []
        for key in keys:
            value = session._gsettings_get(schema, key)
            if value is None:
                continue
            try:
                value = ast.literal_eval(value)
            except (ValueError, SyntaxError):
                continue
            if isinstance(value, str):
                lines.append(f"{key}={session._gvariant_str(value)}\n")
        if lines:
            groups.append(f"[{schema.replace('.', '/')}]\n" + "".join(lines) + "\n")
    return "".join(groups)


def _recorded_difference(theme: str, kind: str) -> str:
    """Describe a different last-applied Shell selection without changing host state."""
    try:
        data = json.loads(Paths.default().manifest.read_text())
        rec = data.get("shell", {})
        if rec.get("state") not in ("active", "suspended") or not rec.get("name"):
            return ""
        recorded = "generated" if rec.get("file") else "authored"
        if rec["name"] != theme or recorded != kind:
            return (f" Last recorded application: {rec['name']} ({recorded} Shell theme); "
                    "the preview selection differs.")
    except (OSError, ValueError, TypeError, AttributeError):
        pass
    return ""


def _background() -> str:
    """The user's own wallpaper settings, so the preview sits on their desktop."""
    lines = []
    for key in BACKGROUND_KEYS:
        try:
            r = subprocess.run(["gsettings", "get", "org.gnome.desktop.background", key], capture_output=True,
                               text=True, timeout=5)
        except (OSError, subprocess.TimeoutExpired):
            continue
        if r.returncode == 0 and r.stdout.strip():
            lines.append(f"{key}={r.stdout.strip()}\n")
    return "[org/gnome/desktop/background]\n" + "".join(lines) + "\n" if lines else ""


def _theme_root(css: Path) -> Path:
    return css.parent.parent  # <theme>/gnome-shell/gnome-shell.css


def render(theme: str, mode: str, choice: str, out: Path, size: str = "1280x800",
           app_css: Path | None = None, extensions: bool = False, authored: bool = False) -> Result:
    for tool in ("gnome-shell", "dbus-run-session", "dbus-daemon"):
        if not shutil.which(tool):
            return Result(None, f"The Shell preview needs `{tool}`.")
    version = shelltheme.shell_version()
    tmp = Path(tempfile.mkdtemp(prefix="theme-unifier-shell-preview-"))
    # The Shell's sockets (Wayland, D-Bus) need a short path: Unix socket paths
    # stop at 108 bytes, and a long TMPDIR (pytest's on stonking) made the
    # Shell abort at startup. So the runtime folder is always under /tmp.
    sockets = Path(tempfile.mkdtemp(prefix="tu-sock-", dir="/tmp" if os.access("/tmp", os.W_OK) else None))
    daemon = None
    try:
        home, run = tmp / "home", sockets / "run"
        settings = home / ".config" / "glib-2.0" / "settings"
        settings.mkdir(parents=True)
        run.mkdir(mode=0o700)
        if len(str(run / "wayland-0")) > SOCKET_PATH_MAX:
            return Result(None, f"The temporary folder path {sockets} is too long for the Shell's sockets.")
        name = ""
        if choice == "off":
            name = session.user_theme_name() or ""
            exts = session.enabled_extensions()
            current = next((d / name / "gnome-shell" / "gnome-shell.css" for d in shelltheme.theme_dirs()
                            if name and (d / name / "gnome-shell" / "gnome-shell.css").is_file()), None)
            if current and exts is not None and shelltheme.EXTENSION in exts and not session.user_extensions_disabled():
                (home / ".themes").mkdir()
                (home / ".themes" / name).symlink_to(_theme_root(current))
                note = f"Shell left alone: previewing the current User Themes stylesheet ({current})."
            else:
                name = ""
                note = "Shell left alone: previewing the default Shell stylesheet."
        else:
            own = shelltheme.own_shell_css(theme) if choice == "auto" else None
            if own:
                (home / ".themes").mkdir()
                (home / ".themes" / theme).symlink_to(_theme_root(own))
                note = f"Shell selection: Automatic; {theme}'s own Shell theme ({own.parent})."
                note += _recorded_difference(theme, "authored")
            else:
                if version is None:
                    return Result(None, "GNOME Shell isn't installed.")
                from .generate import generate
                from .loader import find_theme
                from .variants import discover
                palettes = discover(find_theme(theme)).palettes
                if mode not in palettes:
                    return Result(None, f"{theme} has no {mode} palette.")
                try:
                    css = shelltheme.compile_css(generate(palettes[mode], mode), version)
                except shelltheme.ShellError as e:
                    return Result(None, str(e))
                target = home / ".local" / "share" / "themes" / theme / "gnome-shell" / "gnome-shell.css"
                target.parent.mkdir(parents=True)
                target.write_text(css)
                label = "Always generate" if choice == "generated" else "Automatic"
                note = f"Shell selection: {label}; generated from Shell {version} with {theme}'s {mode} colors."
                note += _recorded_difference(theme, "generated")
            name = theme
        scheme = "prefer-dark" if mode == "dark" else "default"
        selected, extension_settings, extension_notes = _preview_extensions(home, version) if extensions else ([], "", [])
        enabled = [shelltheme.EXTENSION, *selected]
        (settings / "keyfile").write_text(
            _background() + _appearance(scheme) +
            "[org/gnome/shell]\n" +
            f"enabled-extensions=[{', '.join(session._gvariant_str(e) for e in enabled)}]\n" +
            (_favorites() if selected else "") + "\n" +
            f"[org/gnome/shell/extensions/user-theme]\nname={session._gvariant_str(name)}\n\n" + extension_settings)
        (tmp / "probe.js").write_text(PROBE)
        app = ""
        if app_css is not None:
            if authored:
                shutil.copytree(app_css.parent, tmp / "app-theme")
                sample_css = tmp / "app-theme" / app_css.name
            else:
                shutil.copyfile(app_css, tmp / "app.css")
                sample_css = tmp / "app.css"
            # its errors go to a file, read back when no window showed up
            app = json.dumps(["sh", "-c", 'exec "$@" 2>"$0"', str(tmp / "app.log"), sys.executable, "-m",
                              "theme_unifier.gui.preview", str(sample_css), mode, theme, "none"])
        sysbus = sockets / "bus"
        daemon = subprocess.Popen(["dbus-daemon", "--session", f"--address=unix:path={sysbus}", "--nofork"],
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        out.unlink(missing_ok=True)
        env = dict(os.environ, HOME=str(home), XDG_CONFIG_HOME=str(home / ".config"),
                   XDG_DATA_HOME=str(home / ".local" / "share"), XDG_STATE_HOME=str(home / ".local" / "state"),
                   XDG_CACHE_HOME=str(home / ".cache"), XDG_RUNTIME_DIR=str(run), GSETTINGS_BACKEND="keyfile",
                   DBUS_SYSTEM_BUS_ADDRESS=f"unix:path={sysbus}", TU_SHOT=str(out), TU_STOP=str(tmp / "stop"),
                   TU_SAMPLES=str(tmp / "samples.json"),
                   TU_EXTENSIONS=json.dumps(selected), TU_EXTENSION_STATES=str(tmp / "extension-states.json"),
                   TU_APP=app, GDK_BACKEND="wayland", THEME_UNIFIER_PREVIEW_SIZE=SAMPLE_SIZE)
        for k in ("WAYLAND_DISPLAY", "DISPLAY", "DBUS_SESSION_BUS_ADDRESS"):
            env.pop(k, None)
        env.update(NO_SIDE_SERVICES)
        # the sample window runs this same copy of theme-unifier, whatever the caller's working folder
        pkg_parent = str(Path(__file__).resolve().parent.parent)
        env["PYTHONPATH"] = os.pathsep.join([pkg_parent, *filter(None, [env.get("PYTHONPATH")])])
        flags = ["--headless", "--wayland", "--no-x11", "--virtual-monitor", size]
        while True:
            stderr = _run_shell(["dbus-run-session", "--", "gnome-shell", *flags,
                                 f"--automation-script={tmp / 'probe.js'}"], env, tmp / "stop")
            unknown = next((f for f in ("--no-x11", "--wayland") if f in flags and "Unknown option " + f in stderr),
                           None)
            if unknown is None:
                break
            flags.remove(unknown)  # newer Shells are Wayland-only and dropped these
        if app and os.environ.get("THEME_UNIFIER_DEBUG") and (tmp / "app.log").exists():
            sys.stderr.write((tmp / "app.log").read_text(errors="replace"))
        if not out.is_file():
            return Result(None, "The headless Shell didn't produce a picture: "
                          + (stderr.strip().splitlines() or ["no output"])[-1])
        try:
            samples = json.loads((tmp / "samples.json").read_text())
        except (OSError, ValueError):
            samples = []
        if samples == ["volume", "Sample Wi-Fi", "Sample Bluetooth"]:
            note += " Quick settings includes sample volume, Wi-Fi and Bluetooth controls."
        else:
            note += " Some sample quick settings could not be displayed on this Shell version."
        if extensions:
            try:
                states = json.loads((tmp / "extension-states.json").read_text())
            except (OSError, ValueError):
                states = {}
            for uuid in selected:
                state = states.get(uuid) or {}
                label = PREVIEW_EXTENSIONS[uuid][0]
                if state.get("state") == 1:
                    extension_notes.append(f"{label} loaded in the preview.")
                    if uuid == "dash-to-dock@micxgx.gmail.com":
                        extension_notes.append("The dock may be hidden by its settings or unavailable applications.")
                else:
                    extension_notes.append(f"{label} did not load in the preview" +
                                           (f": {state['error']}" if state.get("error") else "."))
            note += " " + " ".join(extension_notes)
        return Result(out, note)
    finally:
        if daemon is not None:
            daemon.send_signal(signal.SIGTERM)
            daemon.wait(5)
        _unmount_below(sockets)
        for _ in range(50):  # a Shell that is still stopping may write a last file or two
            shutil.rmtree(tmp, ignore_errors=True)
            shutil.rmtree(sockets, ignore_errors=True)
            if not tmp.exists() and not sockets.exists():
                break
            time.sleep(0.1)


# Keep the hidden session from starting desktop services. gvfs in particular
# mounts a FUSE file system in $XDG_RUNTIME_DIR/gvfs; if the session dies, that
# mount stays and the folder can't be removed (seen on stonking).
NO_SIDE_SERVICES = {"GIO_USE_VFS": "local", "GVFS_DISABLE_FUSE": "1", "GVFS_REMOTE_VOLUME_MONITOR_IGNORE": "1",
                    "GTK_A11Y": "none", "NO_AT_BRIDGE": "1"}


def _unmount_below(folder: Path, table: str = "/proc/mounts") -> None:
    """Lazily unmount anything still mounted inside `folder` (a stale gvfs mount)."""
    try:
        mounts = Path(table).read_text().splitlines()
    except OSError:
        return
    prefix = str(folder) + "/"
    for line in mounts:
        fields = line.split()
        if len(fields) > 1:
            point = fields[1].replace("\\040", " ")
            if point.startswith(prefix):
                for tool in ("fusermount3", "fusermount"):
                    if shutil.which(tool) and subprocess.run([tool, "-u", "-z", point],
                                                             capture_output=True).returncode == 0:
                        break


class Stop(Exception):
    pass


def _run_shell(argv: list[str], env: dict, stop: Path, timeout: float = 90) -> str:
    """Run the hidden Shell to the end of its script. On a stop request (SIGTERM
    to this process) or a timeout, ask it to finish (the stop file), and only
    if it doesn't, SIGKILL its process group. Never SIGTERM: GNOME Shell 51
    aborts on that while starting up, which leaves a crash report (apport)."""
    with tempfile.TemporaryFile() as err:
        p = subprocess.Popen(argv, env=env, stdout=subprocess.DEVNULL, stderr=err, start_new_session=True)
        try:
            p.wait(timeout)
        except (Stop, subprocess.TimeoutExpired):
            stop.touch()
            try:
                p.wait(10)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)  # SIGKILL leaves no core and no crash report
                p.wait()
            raise Stop() from None
        finally:
            try:
                os.killpg(p.pid, signal.SIGKILL)  # anything the session left behind (dbus-run-session's bus)
            except ProcessLookupError:
                pass
        err.seek(0)
        return err.read().decode(errors="replace")


def _on_term(*_) -> None:
    raise Stop()


def main() -> int:
    # The preview stops a render it no longer needs with SIGTERM to this process only.
    signal.signal(signal.SIGTERM, _on_term)
    theme, mode, choice, out = sys.argv[1:5]
    app_css = Path(sys.argv[5]) if len(sys.argv) > 5 else None
    try:
        r = render(theme, mode, choice, Path(out), app_css=app_css,
                   extensions="--extensions" in sys.argv[6:], authored="--authored" in sys.argv[6:])
    except Stop:
        return 1
    print(r.note)
    return 0 if r.png else 1


if __name__ == "__main__":
    sys.exit(main())
