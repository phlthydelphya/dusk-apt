"""Links and files AppHub opens in place of GNOME Software.

  appstream://org.gnome.Maps  appstream:org.gnome.Maps   the app's page (catalog)
  apt://gimp  apt:gimp  apt:gimp?refresh=yes            the APT package's page
  snap://spotify                                         the snap's page
  a .flatpakref file                                     the app's page, when the catalog has it;
                                                         otherwise an offer to install from the file
  a .flatpakrepo file                                    Sources: remotes are added there by address
  an app's .desktop file                                 the page of the package that installed it
                                                         (dpkg's owner, the snap, or the Flatpak app):
                                                         the start menu's Uninstall opens AppHub this way

Nothing here installs: every target opens a page or a question, and installing
still takes the person's click (and polkit, where the source needs it).
"""

from __future__ import annotations

import os
import re
import subprocess
from dataclasses import dataclass
from typing import Optional
from urllib.parse import unquote, urlsplit

from gi.repository import GLib

# AppStream ids: reverse-DNS with an optional .desktop; Debian package names; snap names.
_APP_ID = re.compile(r"[A-Za-z0-9_][A-Za-z0-9_.+-]{0,254}")
_DEB_NAME = re.compile(r"[a-z0-9][a-z0-9+.-]{0,99}")
_SNAP_NAME = re.compile(r"[a-z0-9](?:-?[a-z0-9]){0,39}")
# A .flatpakref is small; anything bigger is not one.
MAX_REF_BYTES = 64 * 1024


@dataclass(frozen=True)
class FlatpakRef:
    """A parsed .flatpakref file, kept whole for Transaction.add_install_flatpakref."""
    name: str
    title: str
    url: str  # the repository it installs from
    has_key: bool  # carries a GPGKey
    data: bytes  # the file as read


@dataclass(frozen=True)
class Target:
    kind: str  # "app" (catalog id), "apt", "snap", "sources", "unsupported"
    value: str  # the id or name; for "unsupported", what to tell the person
    title: str = ""  # a display name, when the link carries one
    ref: Optional[FlatpakRef] = None  # for a .flatpakref file: the file itself


def _same_url(a: str, b: str) -> bool:
    return a.strip().rstrip("/").lower() == b.strip().rstrip("/").lower()


def ref_source_problem(ref: FlatpakRef, remote_urls) -> Optional[str]:
    """Why AppHub will not install from `ref`, or None when it may.

    The repository must be https. A file without a GPGKey is accepted only when a
    remote with its address is already set up (that remote's own key verifies it);
    otherwise nothing would check what is downloaded.
    """
    if urlsplit(ref.url).scheme.lower() != "https" or not urlsplit(ref.url).hostname:
        return "That .flatpakref does not use a secure (https) address"
    if not ref.has_key and not any(_same_url(ref.url, u) for u in remote_urls if u):
        return ("That .flatpakref has no signing key, and its source is not set up "
                "for you, so nothing could check what it installs")
    return None


def ref_host(ref: FlatpakRef) -> str:
    return urlsplit(ref.url).hostname or ref.url


def _path_part(uri: str, scheme: str) -> str:
    """'apt://gimp/', 'apt:gimp?x=y' -> 'gimp'."""
    rest = uri[len(scheme) + 1:]
    if rest.startswith("//"):
        rest = rest[2:]
    rest = rest.split("?", 1)[0].split("#", 1)[0]
    return unquote(rest).strip("/").strip()


def parse(uri: str) -> Target:
    """A target for a URI as Gio hands it to do_open (file:// for local files)."""
    scheme = (urlsplit(uri).scheme or "").lower()
    if scheme == "appstream":
        app_id = _path_part(uri, scheme)
        if _APP_ID.fullmatch(app_id):
            return Target("app", app_id)
        return Target("unsupported", "That AppStream link has no app id")
    if scheme == "apt":
        # apt:pkg1,pkg2 is allowed by apturl; AppHub shows the first one.
        name = _path_part(uri, scheme).split(",", 1)[0].strip()
        if _DEB_NAME.fullmatch(name):
            return Target("apt", name)
        return Target("unsupported", "That APT link names no package")
    if scheme == "snap":
        name = _path_part(uri, scheme)
        if _SNAP_NAME.fullmatch(name):
            return Target("snap", name)
        return Target("unsupported", "That Snap link names no snap")
    if scheme == "file":
        try:
            path = GLib.filename_from_uri(uri)[0]
        except GLib.Error:
            return Target("unsupported", "AppHub cannot read that file")
        return parse_file(path)
    return Target("unsupported", f"AppHub does not open {scheme or 'these'} links")


# Where installed apps' launchers live, by who installed them
_FLATPAK_EXPORTS = ("/var/lib/flatpak/exports/share/applications/",
                    "/.local/share/flatpak/exports/share/applications/")
_SNAP_DESKTOP = "/var/lib/snapd/desktop/applications/"


def dpkg_owner(path: str) -> Optional[str]:
    """The Debian package that installed `path`, or None."""
    try:
        out = subprocess.run(["dpkg-query", "-S", path], capture_output=True, text=True,
                             timeout=10, check=False).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    for line in out.splitlines():
        # "pkg1, pkg2: /path" (diversions start "diversion by"); the first owner is enough
        head, sep, tail = line.partition(": ")
        if sep and tail.strip() == path and not head.startswith("diversion"):
            name = head.split(",", 1)[0].strip().split(":", 1)[0]
            if _DEB_NAME.fullmatch(name):
                return name
    return None


def desktop_name(path: str) -> str:
    key = GLib.KeyFile()
    try:
        key.load_from_file(path, GLib.KeyFileFlags.NONE)
        return key.get_locale_string("Desktop Entry", "Name", None).strip()
    except GLib.Error:
        return ""


def _shadowed(path: str, data_dirs=None) -> list[str]:
    """The same-named launchers in the system data dirs that `path` hides.

    Some installers copy their package's launchers to /usr/local/share/applications
    (FreeOffice does), which comes first in XDG_DATA_DIRS, so the shell hands over
    the unowned copy; the package's own launcher sits under /usr/share.
    """
    base = os.path.basename(path)
    dirs = GLib.get_system_data_dirs() if data_dirs is None else data_dirs
    found = []
    for d in dirs:
        other = os.path.join(d, "applications", base)
        if os.path.realpath(other) != os.path.realpath(path) and os.path.isfile(other):
            found.append(other)
    return found


def parse_desktop(path: str, owner=dpkg_owner, data_dirs=None) -> Target:
    """The package page for an installed app's launcher (its .desktop file)."""
    stem = os.path.basename(path).removesuffix(".desktop")
    title = desktop_name(path)
    if any(d in path for d in _FLATPAK_EXPORTS):
        if _APP_ID.fullmatch(stem):
            return Target("app", stem, title)
    elif path.startswith(_SNAP_DESKTOP):
        name = stem.split("_", 1)[0]
        if _SNAP_NAME.fullmatch(name):
            return Target("snap", name, title)
    else:
        candidates = (path, os.path.realpath(path), *_shadowed(path, data_dirs))
        for candidate in dict.fromkeys(candidates):
            name = owner(candidate)
            if name:
                return Target("apt", name, title)
    what = title or stem
    return Target("unsupported", f"{what} was not installed by APT, Flatpak or Snap, "
                                 "so AppHub cannot remove it. Remove it the way it was installed")


def parse_file(path: str) -> Target:
    lower = path.lower()
    if lower.endswith(".desktop"):
        return parse_desktop(path)
    if lower.endswith(".flatpakrepo"):
        return Target("sources", "To add this Flatpak remote, choose Add in Sources and give the address the file was downloaded from")
    if not lower.endswith(".flatpakref"):
        return Target("unsupported", "AppHub opens .flatpakref and .flatpakrepo files only")
    key = GLib.KeyFile()
    try:
        with open(path, "rb") as f:
            data = f.read(MAX_REF_BYTES + 1)
        if len(data) > MAX_REF_BYTES:
            raise ValueError("too big")
        text = data.decode("utf-8")
        key.load_from_data(text, len(text.encode("utf-8")), GLib.KeyFileFlags.NONE)
        name = key.get_string("Flatpak Ref", "Name").strip()
    except (OSError, ValueError, UnicodeDecodeError, GLib.Error):
        return Target("unsupported", "That is not a readable .flatpakref file")
    try:
        if key.get_boolean("Flatpak Ref", "IsRuntime"):
            return Target("unsupported", "That .flatpakref is a runtime, not an app")
    except GLib.Error:
        pass
    try:
        title = key.get_string("Flatpak Ref", "Title").strip()
    except GLib.Error:
        title = ""
    if not _APP_ID.fullmatch(name):
        return Target("unsupported", "That .flatpakref names no app")
    try:
        url = key.get_string("Flatpak Ref", "Url").strip()
    except GLib.Error:
        url = ""
    try:
        has_key = bool(key.get_string("Flatpak Ref", "GPGKey").strip())
    except GLib.Error:
        has_key = False
    return Target("app", name, title, FlatpakRef(name, title or name, url, has_key, data))
