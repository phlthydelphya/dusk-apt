"""Sources: where apps come from. One section per kind (Flatpak, APT, AppImage):
what is configured, an Add for anything custom, and well-known sources as cards.

Adding is check first, then confirm: the person sees what the source is, whether
it has anything for this system, and its caveat, before any password prompt.
"""

from __future__ import annotations

from typing import Callable, Optional

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, GLib, Gtk, Pango  # noqa: E402

from ..backend import BackendError, Source  # noqa: E402
from ..sources import SourceEntry, SourceManager, SourcePlugin, SpecCheck  # noqa: E402
from .common import Shell, error_text, icon_button  # noqa: E402

KIND_ORDER = (Source.FLATPAK, Source.APT, Source.APPIMAGE)
KIND_TEXT = {
    Source.FLATPAK: ("Flatpak", "Sandboxed apps from Flatpak repositories. New repositories are "
                                "added for your account only, so no password is needed."),
    Source.APT: ("APT and PPAs", "System packages from Ubuntu and from PPAs. Adding or changing "
                                 "one asks for your password."),
    Source.APPIMAGE: ("AppImage pools", "Folders AppHub scans for AppImages, and catalogs it can "
                                        "download them from."),
}
ADD_HINT = {
    Source.FLATPAK: ("Add Flatpak repository", "https://example.org/repo.flatpakrepo"),
    Source.APT: ("Add PPA", "ppa:owner/name"),
    Source.APPIMAGE: ("Add AppImage pool", "~/Applications/Games or https://…/feed.json"),
}


class PluginCard(Gtk.FlowBoxChild):
    """A well-known source: name, what it is, and Add (or Added)."""

    def __init__(self, plugin: SourcePlugin, on_add: Callable[[SourcePlugin], None]):
        super().__init__()
        self.plugin = plugin
        self.update_property([Gtk.AccessibleProperty.LABEL], [f"{plugin.name}: {plugin.description}"])
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        card.add_css_class("source-card")
        head = Gtk.Box(spacing=8)
        name = Gtk.Label(label=plugin.name, xalign=0, hexpand=True, ellipsize=Pango.EllipsizeMode.END)
        name.add_css_class("heading")
        head.append(name)
        self.button = Gtk.Button(label="Add", valign=Gtk.Align.CENTER,
                                 tooltip_text=f"Add {plugin.name}")
        self.button.add_css_class("pill")
        self.button.add_css_class("suggested-action")
        self.button.connect("clicked", lambda *_: on_add(plugin))
        head.append(self.button)
        card.append(head)
        desc = Gtk.Label(label=plugin.description, xalign=0, wrap=True, lines=3,
                         ellipsize=Pango.EllipsizeMode.END, wrap_mode=Pango.WrapMode.WORD_CHAR,
                         width_chars=16, max_width_chars=40)
        desc.add_css_class("dim-label")
        card.append(desc)
        spec = Gtk.Label(label=plugin.spec, xalign=0, ellipsize=Pango.EllipsizeMode.MIDDLE,
                         selectable=True, max_width_chars=34)
        spec.add_css_class("caption")
        spec.add_css_class("monospace")
        spec.add_css_class("dim-label")
        card.append(spec)
        self.set_child(card)

    def set_added(self, added: bool) -> None:
        self.button.set_label("Added" if added else "Add")
        self.button.set_sensitive(not added)
        if added:
            self.button.remove_css_class("suggested-action")
        else:
            self.button.add_css_class("suggested-action")


class EntryRow(Adw.ActionRow):
    """One configured source: on/off, a warning if any, remove."""

    def __init__(self, entry: SourceEntry, on_toggle, on_remove):
        super().__init__(title=entry.name, subtitle=entry.detail, use_markup=False,
                         subtitle_selectable=True)
        self.entry = entry
        if entry.scope:
            scope = Gtk.Label(label="For you" if entry.scope == "user" else "Everyone",
                              valign=Gtk.Align.CENTER)
            scope.add_css_class("caption")
            scope.add_css_class("dim-label")
            self.add_suffix(scope)
        if entry.warning:
            warn = Gtk.Image(icon_name="dialog-warning-symbolic", tooltip_text=entry.warning,
                             valign=Gtk.Align.CENTER)
            warn.add_css_class("warning")
            warn.update_property([Gtk.AccessibleProperty.LABEL], [entry.warning])
            self.add_suffix(warn)
        self.switch: Optional[Gtk.Switch] = None
        if entry.can_disable:
            self.switch = Gtk.Switch(active=entry.enabled, valign=Gtk.Align.CENTER,
                                     tooltip_text=f"Use {entry.name}")
            self.switch.update_property([Gtk.AccessibleProperty.LABEL], [f"Use {entry.name}"])
            self.switch.connect("state-set", lambda _s, state: on_toggle(self, state))
            self.add_suffix(self.switch)
        self.remove_button: Optional[Gtk.Button] = None
        if entry.removable or entry.remove_note:
            self.remove_button = icon_button("user-trash-symbolic", f"Remove {entry.name}",
                                             lambda: on_remove(self))
            self.remove_button.add_css_class("flat")
            if not entry.removable:
                # Shown but off, so the tooltip can say why (GTK 4 shows it on insensitive widgets)
                note = f"Cannot remove: {entry.remove_note}"
                self.remove_button.set_sensitive(False)
                self.remove_button.set_tooltip_text(note)
                self.remove_button.update_property([Gtk.AccessibleProperty.DESCRIPTION], [note])
            self.add_suffix(self.remove_button)


class KindSection(Gtk.Box):
    """Everything about one kind of source."""

    def __init__(self, page: "SourcesPage", manager: SourceManager, plugins: list[SourcePlugin]):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.page = page
        self.manager = manager
        self.kind = manager.kind
        self.entries: list[SourceEntry] = []
        self.rows: dict[str, EntryRow] = {}
        self.cards: dict[str, PluginCard] = {}

        title, blurb = KIND_TEXT[self.kind]
        # Title and blurb, then the Add button; on narrow windows the button wraps below.
        head = Adw.WrapBox(child_spacing=12, line_spacing=8, justify=Adw.JustifyMode.NONE)
        names = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, hexpand=True, width_request=200)
        heading = Gtk.Label(label=title, xalign=0)
        heading.add_css_class("shelf-title")
        sub = Gtk.Label(label=blurb, xalign=0, wrap=True)
        sub.add_css_class("dim-label")
        names.append(heading)
        names.append(sub)
        head.append(names)
        add_label, _hint = ADD_HINT[self.kind]
        self.add_button = Gtk.Button(label=add_label, valign=Gtk.Align.CENTER)
        self.add_button.add_css_class("pill")
        self.add_button.connect("clicked", lambda *_: self.page.ask_custom(self))
        head.append(self.add_button)
        self.append(head)

        self.list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        self.list.add_css_class("boxed-list")
        self.list.update_property([Gtk.AccessibleProperty.LABEL], [f"{title} sources"])
        self.spinner = Adw.Spinner(halign=Gtk.Align.CENTER, height_request=32)
        self.append(self.spinner)
        self.append(self.list)
        self.error = Gtk.Label(xalign=0, wrap=True, visible=False)
        self.error.add_css_class("error")
        self.append(self.error)

        groups: dict[str, list[SourcePlugin]] = {}
        for p in plugins:
            groups.setdefault(p.group or "Suggested", []).append(p)
        for group, members in groups.items():
            label = Gtk.Label(label=group, xalign=0, margin_top=8)
            label.add_css_class("caption-heading")
            label.add_css_class("dim-label")
            self.append(label)
            grid = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, homogeneous=True,
                               min_children_per_line=1, max_children_per_line=3,
                               column_spacing=12, row_spacing=12)
            grid.update_property([Gtk.AccessibleProperty.LABEL], [group])
            for p in members:
                card = PluginCard(p, self.page.ask_plugin)
                grid.append(card)
                self.cards[p.id] = card
            self.append(grid)

    def load(self) -> None:
        self.spinner.set_visible(True)
        self.error.set_visible(False)
        prefetch = getattr(self.manager, "prefetch", None)
        if prefetch and not getattr(self, "_prefetched", False):
            # Some managers need to read plugin files to match them (Flatpak's
            # .flatpakrepo declares the real URL); list once that is known.
            self._prefetched = True
            plugins = [c.plugin for c in self.cards.values()]
            prefetch(plugins, lambda _r, _e: self.manager.list(self._listed))
            return
        self.manager.list(self._listed)

    def _listed(self, entries: Optional[list[SourceEntry]], err: Optional[BackendError]) -> None:
        self.spinner.set_visible(False)
        self.list.remove_all()
        self.rows = {}
        if err:
            self.error.set_label(f"Could not read these sources: {error_text(err)}")
            self.error.set_visible(True)
            self.list.set_visible(False)
            return
        self.entries = entries or []
        for e in self.entries:
            row = EntryRow(e, self.page.toggle, self.page.ask_remove)
            self.list.append(row)
            self.rows[e.id] = row
        self.list.set_visible(bool(self.entries))
        for card in self.cards.values():
            card.set_added(any(self.manager.matches(card.plugin, e) for e in self.entries))


class SourcesPage(Gtk.Box):
    def __init__(self, shell: Shell, managers: list[SourceManager], plugins: list[SourcePlugin]):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.add_css_class("sources")
        self.shell = shell
        self.busy = False
        by_kind = {}
        for m in managers:
            try:
                if m.available():
                    by_kind[m.kind] = m
            except Exception:  # noqa: BLE001 - a broken probe means "not here"
                pass
        self.sections: dict[Source, KindSection] = {}

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=28,
                      margin_top=12, margin_bottom=28, margin_start=12, margin_end=12)
        # The "Sources" title lives on the tabbed page around this one.
        sub = Gtk.Label(label="Where your apps come from", xalign=0)
        sub.add_css_class("dim-label")
        box.append(sub)
        for kind in KIND_ORDER:
            if kind in by_kind:
                section = KindSection(self, by_kind[kind], [p for p in plugins if p.kind == kind])
                self.sections[kind] = section
                box.append(section)
        if not self.sections:
            box.append(Adw.StatusPage(icon_name="network-server-symbolic",
                                      title="No Sources Can Be Managed Here",
                                      description="None of APT, Flatpak or AppImage is available."))
        clamp = Adw.Clamp(maximum_size=1240, tightening_threshold=1240, child=box)
        self.append(Gtk.ScrolledWindow(child=clamp,
                                       hscrollbar_policy=Gtk.PolicyType.NEVER, vexpand=True))

    def load(self) -> None:
        for section in self.sections.values():
            section.load()

    # -- adding ---------------------------------------------------------

    def ask_plugin(self, plugin: SourcePlugin) -> None:
        section = self.sections.get(plugin.kind)
        if section:
            self._check_then_confirm(section, plugin.spec, plugin.remote_name, plugin.name,
                                     plugin.caveat)

    def ask_custom(self, section: KindSection) -> None:
        title, hint = ADD_HINT[section.kind]
        dialog = Adw.AlertDialog(heading=title,
                                 body="AppHub checks it before adding anything.")
        entry = Gtk.Entry(placeholder_text=hint, activates_default=True)
        entry.update_property([Gtk.AccessibleProperty.LABEL], [title])
        name: Optional[Gtk.Entry] = None
        extra = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        extra.append(entry)
        if section.kind == Source.FLATPAK:
            name = Gtk.Entry(placeholder_text="Name (needed for oci+https:// registries)")
            name.update_property([Gtk.AccessibleProperty.LABEL], ["Remote name"])
            extra.append(name)
        dialog.set_extra_child(extra)
        dialog.add_response("cancel", "Cancel")
        dialog.add_response("check", "Check")
        dialog.set_response_appearance("check", Adw.ResponseAppearance.SUGGESTED)
        dialog.set_default_response("check")
        dialog.set_close_response("cancel")

        def respond(_d, response):
            spec = entry.get_text().strip()
            if response == "check" and spec:
                remote = name.get_text().strip() if name else ""
                self._check_then_confirm(section, spec, remote or None, None, None)

        dialog.connect("response", respond)
        dialog.present(self)
        self.custom_dialog = dialog

    def _check_then_confirm(self, section: KindSection, spec: str, remote_name: Optional[str],
                            display: Optional[str], caveat: Optional[str]) -> None:
        self.shell.toast(f"Checking {display or spec}…")

        def checked(result: Optional[SpecCheck], err: Optional[BackendError]) -> None:
            if err:
                self.shell.toast(f"Could not check {display or spec}: {error_text(err)}")
                return
            self._confirm(section, spec, remote_name, display or result.name or spec, caveat, result)

        section.manager.check(spec, checked)

    def _confirm(self, section: KindSection, spec: str, remote_name: Optional[str], display: str,
                 caveat: Optional[str], result: SpecCheck) -> None:
        body = result.message
        if caveat:
            body += "\n\n" + caveat
        dialog = Adw.AlertDialog(heading=f"Add {display}?" if result.ok else f"Cannot add {display}",
                                 body=body)
        if result.ok:
            dialog.add_response("cancel", "Cancel")
            dialog.add_response("add", "Add")
            dialog.set_response_appearance("add", Adw.ResponseAppearance.SUGGESTED)
            dialog.set_default_response("add")
            dialog.set_close_response("cancel")
            dialog.connect("response", lambda _d, r: r == "add" and self.add(section, spec,
                                                                             remote_name, display))
        else:
            dialog.add_response("close", "Close")
            dialog.set_close_response("close")
        dialog.present(self)
        self.confirm_dialog = dialog

    def add(self, section: KindSection, spec: str, remote_name: Optional[str], display: str) -> None:
        self._set_busy(True)

        def added(entry: Optional[SourceEntry], err: Optional[BackendError]) -> None:
            self._set_busy(False)
            if err:
                self.shell.toast(f"Could not add {display}: {error_text(err)}")
                return
            note = f" ({entry.warning})" if entry and entry.warning else ""
            self.shell.toast(f"Added {display}{note}")
            section.load()
            self.shell.sources_changed()

        section.manager.add(spec, added, name=remote_name)

    # -- changing -------------------------------------------------------

    def toggle(self, row: EntryRow, enabled: bool) -> bool:
        section = self.sections[row.entry.kind]

        def done(entry: Optional[SourceEntry], err: Optional[BackendError]) -> None:
            if err:
                self.shell.toast(f"Could not change {row.entry.name}: {error_text(err)}")
                section.load()  # put the switch back to the truth
                return
            self.shell.sources_changed()

        section.manager.set_enabled(row.entry, enabled, done)
        return False  # let the switch move; a failure reloads it

    def ask_remove(self, row: EntryRow) -> None:
        dialog = Adw.AlertDialog(heading=f"Remove {row.entry.name}?",
                                 body="Apps already installed from it stay installed, but stop "
                                      "getting updates from it.")
        dialog.add_response("cancel", "Cancel")
        dialog.add_response("remove", "Remove")
        dialog.set_response_appearance("remove", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_close_response("cancel")
        dialog.connect("response", lambda _d, r: r == "remove" and self.remove(row))
        dialog.present(self)
        self.confirm_dialog = dialog

    def remove(self, row: EntryRow) -> None:
        section = self.sections[row.entry.kind]

        def done(ok: Optional[bool], err: Optional[BackendError]) -> None:
            if err:
                self.shell.toast(f"Could not remove {row.entry.name}: {error_text(err)}")
                return
            self.shell.toast(f"Removed {row.entry.name}")
            section.load()
            self.shell.sources_changed()

        section.manager.remove(row.entry, done)

    def _set_busy(self, busy: bool) -> None:
        self.busy = busy
        for section in self.sections.values():
            section.add_button.set_sensitive(not busy)
            for card in section.cards.values():
                if card.button.get_label() == "Add":
                    card.button.set_sensitive(not busy)
