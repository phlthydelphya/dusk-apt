"""The store: Home, Apps, a category, and search results, as views of one page.

Laid out like the Microsoft Store crossed with Linux Mint's Software Manager:
- Home opens on a spotlight banner (the app's screenshot fills it, the name sits
  on top), then Made for Dusk, rows of plain tiles, and Mint-style category buttons.
- Apps is every category as a button; a category is a grid of app cards.
- Tiles show stars with a rating count and a checkmark when the app is installed.
Each app's tile, banner and page wear its own palette from Dusk's seed engine.
The search entry lives in the window's title bar; this page owns it.
"""

from __future__ import annotations

from typing import Callable, Optional

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, Gtk, Pango  # noqa: E402

from ..backend import AppInfo, BackendError, Catalog, Package, Rating, Source  # noqa: E402
from ..hub import Hub  # noqa: E402
from .. import dusk, policy  # noqa: E402
from ..seed import Seeder, css_class, live_palette  # noqa: E402
from .common import (  # noqa: E402
    Shell,
    SourceBanners,
    StateStack,
    app_icon,
    error_text,
    source_label,
    stars_text,
)

HERO_COUNT = 6
HERO_SECONDS = 7
SHELF_COUNT = 14
HOME_CATEGORIES = 8  # category buttons on Home; Apps shows them all
CATEGORY_LIMIT = 60  # cards are widgets; a category can hold hundreds of apps
TOP_RATED_MIN = 25  # ratings needed before an app can be "Top Rated"
FEATURED = "Featured"  # select_category(FEATURED) goes back to Home

# Friendly names and icons for freedesktop main categories.
CATEGORY_LABELS = {
    "AudioVideo": "Audio & Video", "Audio": "Audio", "Video": "Video",
    "Development": "Developer Tools", "Education": "Education", "Game": "Games",
    "Graphics": "Graphics & Photography", "Network": "Internet", "Office": "Productivity",
    "Science": "Science", "Settings": "Settings", "System": "System", "Utility": "Utilities",
}
CATEGORY_ICONS = {
    "AudioVideo": "applications-multimedia-symbolic", "Audio": "applications-multimedia-symbolic",
    "Video": "applications-multimedia-symbolic", "Development": "applications-engineering-symbolic",
    "Education": "accessories-dictionary-symbolic", "Game": "applications-games-symbolic",
    "Graphics": "applications-graphics-symbolic", "Network": "web-browser-symbolic",
    "Office": "x-office-document-symbolic", "Science": "applications-science-symbolic",
    "Settings": "preferences-system-symbolic", "System": "applications-system-symbolic",
    "Utility": "applications-utilities-symbolic",
}


def category_label(name: str) -> str:
    return CATEGORY_LABELS.get(name, name)


def group_packages(packages: list[Package]) -> list[list[Package]]:
    """Group search hits that are the same app in several sources, best source first."""
    groups: dict[str, list[Package]] = {}
    for p in packages:
        groups.setdefault(p.app_id or f"{p.source}:{p.name}", []).append(p)
    return [sorted(g, key=lambda p: policy.rank(p.source)) for g in groups.values()]


def _score(r: Rating) -> float:
    # A fixed, middling prior: an app must earn its place with many ratings, so a
    # catalog full of high averages cannot pull every small sample up with it.
    prior, weight = 3.5, 50
    return (r.average * r.count + prior * weight) / (r.count + weight)


def top_rated(apps: list[AppInfo], ratings: dict[str, Rating], limit: int) -> list[AppInfo]:
    """Best apps by a Bayesian average, so 5 stars from 3 people does not beat 4.6 from 900."""
    rated = [(a, ratings[a.app_id]) for a in apps
             if a.app_id in ratings and ratings[a.app_id].count >= TOP_RATED_MIN]
    return [a for a, _ in sorted(rated, key=lambda item: _score(item[1]), reverse=True)[:limit]]


def rating_text(r: Rating) -> str:
    return f"★ {r.average:.1f}  ({r.count:,})"


def _sources_text(info: AppInfo) -> str:
    return " · ".join(str(s) for s in policy.ordered(info.candidates))


def _subtitle(info: AppInfo) -> str:
    return category_label(info.categories[0]) if info.categories else info.summary


def _rating_a11y(r: Rating) -> str:
    return f"Rated {r.average:.1f} out of 5 from {r.count} ratings"


def _activate_on_click(widget: Gtk.Widget, callback: Callable[[], None]) -> None:
    click = Gtk.GestureClick()
    click.connect("released", lambda *_: callback())
    widget.add_controller(click)


def _installed_mark() -> Gtk.Image:
    mark = Gtk.Image(icon_name="object-select-symbolic", pixel_size=12, visible=False,
                     halign=Gtk.Align.END, valign=Gtk.Align.START, tooltip_text="Installed")
    mark.add_css_class("installed-mark")
    mark.update_property([Gtk.AccessibleProperty.LABEL], ["Installed"])
    return mark


# -- spotlight ---------------------------------------------------------------

class HeroSlide(Gtk.Overlay):
    """A spotlight banner: the screenshot fills it, the app's name and a button sit on top."""

    def __init__(self, info: AppInfo, on_open: Callable[[AppInfo], None], cancel: Gio.Cancellable):
        super().__init__(hexpand=True)
        self.info = info
        self.add_css_class("spotlight")
        self.set_overflow(Gtk.Overflow.HIDDEN)
        self.set_cursor(Gdk.Cursor.new_from_name("pointer"))
        self.update_property([Gtk.AccessibleProperty.LABEL], [f"Spotlight: {info.title}"])
        _activate_on_click(self, lambda: on_open(info))

        base = Gtk.Box(height_request=340, hexpand=True)
        base.add_css_class("spotlight-base")
        base.add_css_class("seed-glow")
        self.set_child(base)

        self.picture = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True,
                                   visible=False, hexpand=True, vexpand=True)
        self.picture.add_css_class("spotlight-shot")
        self.picture.update_property([Gtk.AccessibleProperty.LABEL], [f"{info.title} screenshot"])
        self.add_overlay(self.picture)
        # Without a screenshot, the icon stands in on the right.
        self.big_icon = app_icon(info.icon, 176)
        self.big_icon.set_halign(Gtk.Align.END)
        self.big_icon.set_valign(Gtk.Align.CENTER)
        self.big_icon.set_margin_end(64)
        self.big_icon.add_css_class("spotlight-icon")
        self.add_overlay(self.big_icon)
        scrim = Gtk.Box(hexpand=True, vexpand=True, can_target=False)
        scrim.add_css_class("spotlight-scrim")
        self.add_overlay(scrim)

        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, halign=Gtk.Align.START,
                       valign=Gtk.Align.END, margin_start=28, margin_bottom=24, margin_end=28)
        badge = Gtk.Label(label=(category_label(info.categories[0]) if info.categories
                                 else "Spotlight").upper(), xalign=0)
        badge.add_css_class("spotlight-badge")
        row = Gtk.Box(spacing=16)
        icon = app_icon(info.icon, 56)
        row.append(icon)
        title = Gtk.Label(label=info.title, xalign=0, wrap=True, lines=2,
                          ellipsize=Pango.EllipsizeMode.END, max_width_chars=24)
        title.add_css_class("spotlight-title")
        row.append(title)
        tagline = Gtk.Label(label=info.summary, xalign=0, wrap=True, lines=2,
                            ellipsize=Pango.EllipsizeMode.END, max_width_chars=48)
        tagline.add_css_class("spotlight-tagline")
        actions = Gtk.Box(spacing=14, margin_top=6)
        self.explore = Gtk.Button(label="See details")
        self.explore.add_css_class("pill")
        self.explore.add_css_class("suggested-action")
        self.explore.connect("clicked", lambda *_: on_open(info))
        self.meta = Gtk.Label(label=_sources_text(info), xalign=0, valign=Gtk.Align.CENTER)
        self.meta.add_css_class("spotlight-meta")
        actions.append(self.explore)
        actions.append(self.meta)
        for w in (badge, row, tagline, actions):
            text.append(w)
        self.add_overlay(text)

        if info.screenshots:
            Gio.File.new_for_uri(info.screenshots[0]).load_bytes_async(cancel, self._on_screenshot)

    def _on_screenshot(self, gfile: Gio.File, result: Gio.AsyncResult) -> None:
        try:
            data, _etag = gfile.load_bytes_finish(result)
            texture = Gdk.Texture.new_from_bytes(data)
        except GLib.Error:
            return  # the icon stays; a screenshot is decoration
        self.picture.set_paintable(texture)
        self.picture.set_visible(not self.has_css_class("compact"))
        self.big_icon.set_visible(False)

    def set_rating(self, rating: Rating) -> None:
        if rating.count > 0:
            self.meta.set_label(f"{rating_text(rating)}   ·   {_sources_text(self.info)}")

    def set_compact(self, compact: bool) -> None:
        """Narrow windows: text only; the slide's colours still say which app it is."""
        if compact:
            self.add_css_class("compact")
        else:
            self.remove_css_class("compact")
        has_shot = self.picture.get_paintable() is not None
        self.picture.set_visible(has_shot and not compact)
        self.big_icon.set_visible(not has_shot and not compact)


class Hero(Gtk.Box):
    """Carousel of spotlights that advances on its own and stops while you are on it."""

    def __init__(self, on_change: Callable[[AppInfo], None]):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.on_change = on_change
        self.slides: list[HeroSlide] = []
        self.compact = False
        self._timer = 0
        self._paused = False

        # Spacing clears the shadow room around each slide (style.css .hero-carousel), so
        # the next slide never peeks into it.
        self.carousel = Adw.Carousel(allow_long_swipes=False, spacing=56, hexpand=True)
        self.carousel.add_css_class("hero-carousel")
        self.carousel.update_property([Gtk.AccessibleProperty.LABEL], ["Spotlight"])
        self.carousel.connect("page-changed", self._on_page_changed)
        self.append(self.carousel)
        controls = Gtk.Box(spacing=8, halign=Gtk.Align.CENTER)
        self.prev_button = self._nav_button("go-previous-symbolic", "Previous app", -1)
        self.next_button = self._nav_button("go-next-symbolic", "Next app", 1)
        self.dots = Adw.CarouselIndicatorLines(carousel=self.carousel)
        for w in (self.prev_button, self.dots, self.next_button):
            controls.append(w)
        self.append(controls)

        hover = Gtk.EventControllerMotion()
        hover.connect("enter", lambda *_: self._pause(True))
        hover.connect("leave", lambda *_: self._pause(False))
        self.add_controller(hover)
        focus = Gtk.EventControllerFocus()
        focus.connect("enter", lambda *_: self._pause(True))
        focus.connect("leave", lambda *_: self._pause(False))
        self.add_controller(focus)
        self.connect("unmap", lambda *_: self._stop())
        self.connect("map", lambda *_: self._start())

    def _nav_button(self, icon: str, tip: str, step: int) -> Gtk.Button:
        b = Gtk.Button(icon_name=icon, tooltip_text=tip, valign=Gtk.Align.CENTER)
        b.add_css_class("circular")
        b.add_css_class("flat")
        b.update_property([Gtk.AccessibleProperty.LABEL], [tip])
        b.connect("clicked", lambda *_: self.step(step))
        return b

    def set_apps(self, apps: list[AppInfo], on_open, cancel, seeder: Seeder) -> None:
        for s in self.slides:
            self.carousel.remove(s)
        self.slides = [HeroSlide(a, on_open, cancel) for a in apps]
        for s in self.slides:
            self.carousel.append(s)
            s.set_compact(self.compact)
            seeder.seed(s, s.info.app_id, s.info.icon)
        many = len(self.slides) > 1
        for w in (self.prev_button, self.next_button, self.dots):
            w.set_visible(many)
        self.set_visible(bool(self.slides))
        if self.slides:
            self.on_change(self.slides[0].info)
        self._start()

    def step(self, delta: int) -> None:
        if not self.slides:
            return
        i = (round(self.carousel.get_position()) + delta) % len(self.slides)
        self.carousel.scroll_to(self.slides[i], True)

    def current(self) -> Optional[AppInfo]:
        if not self.slides:
            return None
        return self.slides[round(self.carousel.get_position()) % len(self.slides)].info

    def set_compact(self, compact: bool) -> None:
        self.compact = compact
        for s in self.slides:
            s.set_compact(compact)

    @staticmethod
    def animations_enabled() -> bool:
        settings = Gtk.Settings.get_default()
        return bool(settings and settings.props.gtk_enable_animations)

    def _start(self) -> None:
        self._stop()
        if len(self.slides) > 1 and self.animations_enabled():
            self._timer = GLib.timeout_add_seconds(HERO_SECONDS, self._tick)

    def _stop(self) -> None:
        if self._timer:
            GLib.source_remove(self._timer)
            self._timer = 0

    def _tick(self) -> bool:
        if not self._paused and self.get_mapped():
            self.step(1)
        return True

    def _pause(self, paused: bool) -> None:
        self._paused = paused

    def _on_page_changed(self, _carousel, index: int) -> None:
        if 0 <= index < len(self.slides):
            self.on_change(self.slides[index].info)


# -- tiles and cards ---------------------------------------------------------

class AppTile(Gtk.Button):
    """Store tile: icon, name, category, stars. Tinted by the app's own palette."""

    def __init__(self, info: AppInfo, on_open: Callable[[AppInfo], None]):
        super().__init__()
        self.info = info
        self.add_css_class("store-tile")
        self.update_property([Gtk.AccessibleProperty.LABEL], [f"{info.title}: {info.summary}"])
        self.connect("clicked", lambda *_: on_open(info))

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        top = Gtk.Overlay()
        icon = app_icon(info.icon, 64)
        icon.set_halign(Gtk.Align.START)
        icon.set_margin_bottom(10)
        top.set_child(icon)
        self.mark = _installed_mark()
        top.add_overlay(self.mark)
        box.append(top)
        title = Gtk.Label(label=info.title, xalign=0, ellipsize=Pango.EllipsizeMode.END)
        title.add_css_class("heading")
        sub = Gtk.Label(label=_subtitle(info), xalign=0, ellipsize=Pango.EllipsizeMode.END)
        sub.add_css_class("caption")
        sub.add_css_class("dim-label")
        self.stars = Gtk.Label(xalign=0, visible=False)
        self.stars.add_css_class("tile-stars")
        for w in (title, sub, self.stars):
            box.append(w)
        self.set_child(box)

    def set_rating(self, rating: Rating) -> None:
        if rating.count <= 0:
            return
        self.stars.set_label(rating_text(rating))
        self.stars.update_property([Gtk.AccessibleProperty.LABEL], [_rating_a11y(rating)])
        self.stars.set_visible(True)

    def set_installed(self, installed: bool) -> None:
        self.mark.set_visible(installed)


class Shelf(Gtk.Box):
    """A titled, horizontally scrolling row of AppTiles with page buttons."""

    def __init__(self, title: str, subtitle: str):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.tiles: dict[str, AppTile] = {}
        head = Gtk.Box(spacing=8)
        names = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, hexpand=True)
        heading = Gtk.Label(label=title, xalign=0)
        heading.add_css_class("shelf-title")
        sub = Gtk.Label(label=subtitle, xalign=0)
        sub.add_css_class("dim-label")
        names.append(heading)
        names.append(sub)
        head.append(names)
        self.scroller = Gtk.ScrolledWindow(vscrollbar_policy=Gtk.PolicyType.NEVER,
                                           hscrollbar_policy=Gtk.PolicyType.EXTERNAL)
        for icon, tip, direction in (("go-previous-symbolic", f"Scroll {title} back", -1),
                                     ("go-next-symbolic", f"Scroll {title} forward", 1)):
            b = Gtk.Button(icon_name=icon, tooltip_text=tip, valign=Gtk.Align.CENTER)
            b.add_css_class("circular")
            b.add_css_class("flat")
            b.update_property([Gtk.AccessibleProperty.LABEL], [tip])
            b.connect("clicked", lambda *_a, d=direction: self.page(d))
            head.append(b)
        self.append(head)
        self.row = Gtk.Box(spacing=12)
        self.row.update_property([Gtk.AccessibleProperty.LABEL], [title])
        self.scroller.set_child(self.row)
        self.append(self.scroller)
        self.set_visible(False)

    def set_apps(self, apps: list[AppInfo], on_open, seeder: Seeder) -> None:
        child = self.row.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.row.remove(child)
            child = nxt
        self.tiles = {}
        for info in apps:
            tile = AppTile(info, on_open)
            self.row.append(tile)
            self.tiles[info.app_id] = tile
            seeder.seed(tile, info.app_id, info.icon)
        self.set_visible(bool(apps))

    def page(self, direction: int) -> None:
        adj = self.scroller.get_hadjustment()
        target = adj.get_value() + direction * adj.get_page_size() * 0.85
        adj.set_value(max(adj.get_lower(), min(target, adj.get_upper() - adj.get_page_size())))


class AppCard(Gtk.FlowBoxChild):
    """Category grid card, Mint style: icon, name, summary, stars, installed mark."""

    def __init__(self, info: AppInfo):
        super().__init__()
        self.info = info
        self.update_property([Gtk.AccessibleProperty.LABEL], [f"{info.title}: {info.summary}"])
        overlay = Gtk.Overlay()
        overlay.add_css_class("app-card")
        box = Gtk.Box(spacing=14)
        box.append(app_icon(info.icon, 56))
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3,
                       valign=Gtk.Align.CENTER, hexpand=True)
        title = Gtk.Label(label=info.title, xalign=0, ellipsize=Pango.EllipsizeMode.END)
        title.add_css_class("heading")
        summary = Gtk.Label(label=info.summary, xalign=0, wrap=True, lines=2,
                            ellipsize=Pango.EllipsizeMode.END,
                            wrap_mode=Pango.WrapMode.WORD_CHAR, width_chars=18, max_width_chars=30)
        summary.add_css_class("dim-label")
        summary.add_css_class("caption")
        self.stars = Gtk.Label(xalign=0, visible=False)
        self.stars.add_css_class("tile-stars")
        for w in (title, summary, self.stars):
            text.append(w)
        box.append(text)
        overlay.set_child(box)
        self.mark = _installed_mark()
        overlay.add_overlay(self.mark)
        self.set_child(overlay)

    set_rating = AppTile.set_rating
    set_installed = AppTile.set_installed


class CategoryButton(Gtk.FlowBoxChild):
    """Mint-style category button: a symbolic icon in a tinted square, the name, a count."""

    def __init__(self, name: str, count: int):
        super().__init__()
        self.name = name
        label = category_label(name)
        self.update_property([Gtk.AccessibleProperty.LABEL], [f"{label}, {count} apps"])
        box = Gtk.Box(spacing=14)
        box.add_css_class("category-button")
        icon = Gtk.Image(icon_name=CATEGORY_ICONS.get(name, "applications-other-symbolic"),
                         pixel_size=22, valign=Gtk.Align.CENTER)
        icon.add_css_class("category-icon")
        box.append(icon)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
        name_label = Gtk.Label(label=label, xalign=0, ellipsize=Pango.EllipsizeMode.END)
        name_label.add_css_class("heading")
        count_label = Gtk.Label(label=f"{count:,} apps", xalign=0)
        count_label.add_css_class("caption")
        count_label.add_css_class("dim-label")
        text.append(name_label)
        text.append(count_label)
        box.append(text)
        self.set_child(box)


def category_grid(on_select: Callable[[str], None]) -> Gtk.FlowBox:
    grid = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, homogeneous=True,
                       min_children_per_line=1, max_children_per_line=4,
                       column_spacing=12, row_spacing=12, activate_on_single_click=True,
                       valign=Gtk.Align.START)
    grid.update_property([Gtk.AccessibleProperty.LABEL], ["Categories"])
    grid.connect("child-activated", lambda _g, child: on_select(child.name))
    return grid


# -- Made for Dusk -----------------------------------------------------------

class DuskTile(Gtk.FlowBoxChild):
    """One Dusk app: icon, name, what it is, and Open when it is here."""

    def __init__(self, app: "dusk.DuskApp", on_launch: Callable[["dusk.DuskApp"], None]):
        super().__init__()
        self.app = app
        self.update_property([Gtk.AccessibleProperty.LABEL], [f"{app.title}: {app.summary}"])
        card = Gtk.Box(spacing=14)
        card.add_css_class("dusk-tile")
        card.append(app_icon(app.icon, 56))
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3, hexpand=True,
                       valign=Gtk.Align.CENTER)
        title = Gtk.Label(label=app.title, xalign=0, ellipsize=Pango.EllipsizeMode.END)
        title.add_css_class("heading")
        summary = Gtk.Label(label=app.summary, xalign=0, wrap=True, lines=2,
                            ellipsize=Pango.EllipsizeMode.END, wrap_mode=Pango.WrapMode.WORD_CHAR,
                            width_chars=8, max_width_chars=28)
        summary.add_css_class("caption")
        summary.add_css_class("dim-label")
        text.append(title)
        text.append(summary)
        if app.replaces:
            tag = Gtk.Label(label=f"Dusk’s {app.replaces}", xalign=0,
                            ellipsize=Pango.EllipsizeMode.END)
            tag.add_css_class("dusk-tag")
            text.append(tag)
        card.append(text)
        self.installed = app.installed
        if self.installed:
            self.action = Gtk.Button(label="Open", valign=Gtk.Align.CENTER,
                                     tooltip_text=f"Open {app.title}")
            self.action.add_css_class("pill")
            self.action.add_css_class("suggested-action")
            self.action.connect("clicked", lambda *_: on_launch(app))
        else:
            self.action = Gtk.Label(label="Coming", valign=Gtk.Align.CENTER,
                                    tooltip_text="Ships with Dusk Desktop; not installed here yet")
            self.action.add_css_class("dusk-soon")
        card.append(self.action)
        self.set_child(card)


class DuskSection(Gtk.Box):
    """Made for Dusk: the desktop's own apps, in the desktop's own live colours."""

    def __init__(self, on_open: Callable[["dusk.DuskApp"], None],
                 on_launch: Callable[["dusk.DuskApp"], None]):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        self.add_css_class("dusk-collection")
        self.add_css_class("seed-glow")
        self.tiles: dict[str, DuskTile] = {}
        badge = Gtk.Label(label="DUSK DESKTOP", xalign=0)
        badge.add_css_class("spotlight-badge")
        title = Gtk.Label(label="Made for Dusk", xalign=0)
        title.add_css_class("dusk-title")
        sub = Gtk.Label(label="Built for this desktop and styled to match it, down to the colours "
                              "of your wallpaper.", xalign=0, wrap=True)
        sub.add_css_class("dim-label")
        head = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        for w in (badge, title, sub):
            head.append(w)
        self.append(head)
        self.grid = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, homogeneous=True,
                                min_children_per_line=1, max_children_per_line=3,
                                column_spacing=12, row_spacing=12, activate_on_single_click=True)
        self.grid.update_property([Gtk.AccessibleProperty.LABEL], ["Made for Dusk"])
        self.grid.connect("child-activated", lambda _g, tile: on_open(tile.app))
        self.append(self.grid)
        self._on_launch = on_launch
        self.set_visible(False)

    def set_apps(self, apps: list["dusk.DuskApp"], seeder: Seeder) -> None:
        self.grid.remove_all()
        self.tiles = {}
        # Installed first: what you can open now leads.
        for app in sorted(apps, key=lambda a: not a.installed):
            tile = DuskTile(app, self._on_launch)
            self.grid.append(tile)
            self.tiles[app.id] = tile
        self.set_visible(bool(apps))
        if apps:
            # Wear the desktop's own live palette; re-seed from the wallpaper outside Dusk.
            live = live_palette()
            if live:
                seeder.apply(self, dusk.WALLPAPER_KEY, live)
            else:
                seeder.seed(self, dusk.WALLPAPER_KEY, dusk.wallpaper_file())


# -- page --------------------------------------------------------------------

def _scrolled(child: Gtk.Widget, width: int) -> Gtk.ScrolledWindow:
    return Gtk.ScrolledWindow(child=Adw.Clamp(maximum_size=width, tightening_threshold=width,
                                                 child=child),
                              hscrollbar_policy=Gtk.PolicyType.NEVER)


PAGE_MARGIN, PAGE_MARGIN_COMPACT = 12, 8


def _page_box(spacing: int = 24) -> Gtk.Box:
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=spacing,
                  margin_top=12, margin_bottom=28, margin_start=PAGE_MARGIN, margin_end=PAGE_MARGIN)
    box.add_css_class("store-page")
    return box


def _find_page_box(widget: Optional[Gtk.Widget]) -> Optional[Gtk.Box]:
    while widget is not None and not widget.has_css_class("store-page"):
        widget = widget.get_first_child()
    return widget


class DiscoverPage(Gtk.Box):
    def __init__(self, shell: Shell, hub: Hub, catalog: Optional[Catalog],
                 seeder: Optional[Seeder] = None, dusk_apps: Optional[list] = None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.add_css_class("discover")
        self.add_css_class("seed-wash")
        self.shell = shell
        self.hub = hub
        self.catalog = catalog
        self.seeder = seeder or Seeder()
        self.dusk_apps = list(dusk_apps or [])
        self.catalog_ready = False
        # Called once when the catalog has loaded, or failed to (links wait for it)
        self.on_catalog_ready: list[Callable[[], None]] = []
        self.catalog_loading = False
        self.category: str = FEATURED
        self.view = "home"
        self.cards: dict[str, AppCard] = {}
        self.result_rows: list[Adw.ActionRow] = []
        self.ratings: dict[str, Rating] = {}
        self.installed_keys: set[tuple[Source, str]] = set()
        self.category_buttons: dict[str, CategoryButton] = {}
        self.on_view_changed: Callable[[str, Optional[str]], None] = lambda view, cat: None
        self._ambient: Optional[str] = None
        self._search_gen = 0
        self._cancel = Gio.Cancellable()

        self.banners = SourceBanners(self.retry)
        self.append(self.banners)

        # Owned here, shown in the window's title bar.
        self.search_entry = Gtk.SearchEntry(placeholder_text="Search apps, games and more",
                                            hexpand=True)
        self.search_entry.add_css_class("store-search")
        self.search_entry.update_property([Gtk.AccessibleProperty.LABEL], ["Search apps"])
        self.search_entry.connect("search-changed", self._on_search_changed)
        self.search_entry.connect("activate", self._on_search_activate)
        self.search_entry.connect("stop-search", lambda e: e.set_text(""))

        self.views = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, vexpand=True)
        self.views.add_named(self._build_home(), "home")
        self.views.add_named(self._build_apps(), "apps")
        self.views.add_named(self._build_category(), "category")
        self.views.add_named(self._build_results(), "results")
        self.idle_page = Adw.StatusPage(
            icon_name="system-search-symbolic", title="Search for Apps",
            description="Find apps from " + ", ".join(str(s) for s in policy.ordered(hub.sources))
            if hub.sources else "No software sources are available on this computer")
        self.views.add_named(self.idle_page, "idle")

        self.state = StateStack(self.views, self.retry)
        self.append(self.state)

    # -- layout ---------------------------------------------------------

    def _build_home(self) -> Gtk.Widget:
        box = _page_box()
        self.hero = Hero(self._on_hero_changed)
        box.append(self.hero)
        self.dusk_section = DuskSection(self._open_dusk_app, self._launch_dusk_app)
        box.append(self.dusk_section)
        self.top_shelf = Shelf("Top rated", "Loved by the people who use them")
        self.picks_shelf = Shelf("Editor’s picks", "Hand-picked for Dusk")
        box.append(self.top_shelf)
        box.append(self.picks_shelf)

        cats = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        head = Gtk.Box()
        heading = Gtk.Label(label="Categories", xalign=0, hexpand=True)
        heading.add_css_class("shelf-title")
        head.append(heading)
        see_all = Gtk.Button(label="See all", valign=Gtk.Align.CENTER)
        see_all.add_css_class("flat")
        see_all.connect("clicked", lambda *_: self.show_apps())
        head.append(see_all)
        cats.append(head)
        self.home_categories = category_grid(self.select_category)
        cats.append(self.home_categories)
        self.categories_box = cats
        box.append(cats)

        self.browse_scroller = _scrolled(box, 1240)
        return self.browse_scroller

    def _build_apps(self) -> Gtk.Widget:
        box = _page_box(18)
        title = Gtk.Label(label="Apps", xalign=0)
        title.add_css_class("store-title")
        sub = Gtk.Label(label="Browse by category", xalign=0)
        sub.add_css_class("dim-label")
        head = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        head.append(title)
        head.append(sub)
        box.append(head)
        self.category_tiles = category_grid(self.select_category)
        box.append(self.category_tiles)
        return _scrolled(box, 1240)

    def _build_category(self) -> Gtk.Widget:
        box = _page_box(18)
        head = Gtk.Box(spacing=12)
        back = Gtk.Button(icon_name="go-previous-symbolic", tooltip_text="All categories",
                          valign=Gtk.Align.CENTER)
        back.add_css_class("circular")
        back.update_property([Gtk.AccessibleProperty.LABEL], ["Back to categories"])
        back.connect("clicked", lambda *_: self.show_apps())
        self.category_back = back
        head.append(back)
        self.browse_title = Gtk.Label(label="", xalign=0)
        self.browse_title.add_css_class("store-title")
        head.append(self.browse_title)
        box.append(head)
        self.grid = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, homogeneous=True,
                                min_children_per_line=1, max_children_per_line=3,
                                column_spacing=12, row_spacing=12,
                                activate_on_single_click=True, valign=Gtk.Align.START)
        self.grid.connect("child-activated", lambda _g, card: self.shell.open_app(card.info))
        box.append(self.grid)
        self.category_scroller = _scrolled(box, 1240)
        return self.category_scroller

    def _build_results(self) -> Gtk.Widget:
        box = _page_box(12)
        self.results_title = Gtk.Label(label="Results", xalign=0)
        self.results_title.add_css_class("shelf-title")
        box.append(self.results_title)
        self.results = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE, valign=Gtk.Align.START)
        self.results.add_css_class("boxed-list")
        self.results.update_property([Gtk.AccessibleProperty.LABEL], ["Search results"])
        box.append(self.results)
        return _scrolled(box, 860)

    def set_compact(self, compact: bool) -> None:
        """Narrow windows: tighter margins and padding, text-only spotlights."""
        self.hero.set_compact(compact)
        margin = PAGE_MARGIN_COMPACT if compact else PAGE_MARGIN
        for view in ("home", "apps", "category", "results"):
            box = _find_page_box(self.views.get_child_by_name(view))
            if box is not None:
                box.set_margin_start(margin)
                box.set_margin_end(margin)
        if compact:
            self.add_css_class("compact")
        else:
            self.remove_css_class("compact")

    # -- loading --------------------------------------------------------

    def load(self) -> None:
        self.dusk_section.set_apps(self.dusk_apps, self.seeder)
        if self.catalog is None:
            self._show(self.view)
            return
        self.state.loading()
        self.catalog_loading = True
        self.catalog.load(self._on_catalog_loaded)

    # -- Flathub verification (as Linux Mint) -------------------------------

    @property
    def show_unverified(self) -> bool:
        settings = getattr(self.shell, "settings", None)
        return bool(settings and settings.show_unverified_flatpaks)

    def _visible(self, apps: list[AppInfo]) -> list[AppInfo]:
        """Apps as they may be offered: unverified Flathub Flatpaks removed unless shown."""
        show = self.show_unverified
        return [v for v in (policy.visible(a, show) for a in apps) if v is not None]

    def _package_allowed(self, pkg: Package) -> bool:
        """A Flatpak search hit, judged by the catalog's verification of its app."""
        if pkg.source != Source.FLATPAK or self.show_unverified or pkg.installed:
            return True
        info = self.catalog.get(pkg.app_id or pkg.name) if self.catalog_ready else None
        if info is not None and info.flatpak_verified is not None:
            return info.flatpak_verified
        # Not in the catalog: a Flathub hit cannot be checked, so it stays hidden.
        return not (pkg.origin or "").lower().startswith("flathub")

    def refilter(self) -> None:
        """Re-apply what may be shown (a preference changed) without re-reading the catalog."""
        if self.catalog_ready:
            self._fill_storefront()
            self.refresh_installed()
            self._show(self.view if self.view != "results" else "home")

    def reload(self) -> None:
        """Re-read the catalog (a source changed); keeps the current view."""
        if self.catalog is not None:
            self.catalog_loading = True
            self.catalog.load(self._on_catalog_loaded)

    def retry(self) -> None:
        if self.search_entry.get_text().strip():
            self._search(self.search_entry.get_text().strip())
        elif self.catalog is not None and not self.catalog_ready:
            self.load()
        else:
            self._show(self.view)

    def _on_catalog_loaded(self, ok: Optional[bool], err: Optional[BackendError]) -> None:
        self.catalog_loading = False
        if err or not ok:
            self.catalog_ready = False
            self.state.error("Could not load the app catalog",
                             (error_text(err) if err else "No app metadata was found")
                             + ". Searching still works.")
            self._run_catalog_ready()
            return
        self.catalog_ready = True
        self._run_catalog_ready()
        self._fill_storefront()
        self.refresh_installed()
        if not self.search_entry.get_text().strip():
            self._show(self.view)

    def _run_catalog_ready(self) -> None:
        waiting, self.on_catalog_ready = self.on_catalog_ready, []
        for then in waiting:
            then()

    def _fill_storefront(self) -> None:
        # Ask for extra: unverified Flatpaks drop out when they are hidden.
        featured = self._visible(self.catalog.featured(2 * (HERO_COUNT + SHELF_COUNT)))
        featured = featured[:HERO_COUNT + SHELF_COUNT]
        self.hero.set_apps(featured[:HERO_COUNT], self.shell.open_app, self._cancel, self.seeder)
        self.picks_shelf.set_apps(featured[HERO_COUNT:], self.shell.open_app, self.seeder)

        names = self.catalog.categories()
        counts = {n: len(self._visible(self.catalog.in_category(n))) for n in names}
        by_size = sorted(names, key=lambda n: -counts[n])
        self.home_categories.remove_all()
        self.category_tiles.remove_all()
        self.category_buttons = {}
        for name in by_size[:HOME_CATEGORIES]:
            self.home_categories.append(CategoryButton(name, counts[name]))
        for name in names:
            button = CategoryButton(name, counts[name])
            self.category_tiles.append(button)
            self.category_buttons[name] = button
        self.categories_box.set_visible(bool(names))

        # One ratings call for the whole catalog: Top rated needs them all.
        everyone = {a.app_id: a for name in names
                    for a in self._visible(self.catalog.in_category(name))}
        for a in featured:
            everyone.setdefault(a.app_id, a)
        self.catalog.ratings(list(everyone), lambda r, e: self._on_ratings(everyone, r, e))

    def _on_ratings(self, everyone: dict[str, AppInfo], ratings: Optional[dict[str, Rating]],
                    err: Optional[BackendError]) -> None:
        if err or not ratings:
            return  # ratings are decoration; without them Top rated stays hidden
        self.ratings = ratings
        self.top_shelf.set_apps(top_rated(list(everyone.values()), ratings, SHELF_COUNT),
                                self.shell.open_app, self.seeder)
        self._decorate()

    def refresh_installed(self) -> None:
        """Ask every source what is installed, then mark tiles and cards."""
        def done(packages: list[Package], _errors) -> None:
            self.installed_keys = {(p.source, p.name) for p in packages}
            self._decorate()

        self.hub.list_installed(done)

    def is_installed(self, info: AppInfo) -> bool:
        return any((s, n) in self.installed_keys for s, n in info.candidates.items())

    def _decorate(self) -> None:
        """Apply ratings and installed marks to everything on screen."""
        for slide in self.hero.slides:
            if r := self.ratings.get(slide.info.app_id):
                slide.set_rating(r)
        for widgets in (self.top_shelf.tiles, self.picks_shelf.tiles, self.cards):
            for app_id, w in widgets.items():
                if r := self.ratings.get(app_id):
                    w.set_rating(r)
                w.set_installed(self.is_installed(w.info))

    # -- views ----------------------------------------------------------

    def _show(self, view: str) -> None:
        self.banners.show_errors([])
        if not self.catalog_ready:
            self.view = view
            self.views.set_visible_child_name("idle")
            self.state.content()
            self.on_view_changed("idle", None)
            return
        if view == "category":
            self.browse_title.set_label(category_label(self.category))
            apps = self._visible(self.catalog.in_category(self.category))
            if self.ratings:
                apps = sorted(apps, key=lambda a: -_score(self.ratings[a.app_id])
                              if a.app_id in self.ratings else 0)
            self._fill_grid(apps[:CATEGORY_LIMIT])
            self.category_scroller.get_vadjustment().set_value(0)
        self.view = view
        self.views.set_visible_child_name(view)
        self.state.content()
        self.on_view_changed(view, self.category if view == "category" else None)

    def show_home(self) -> None:
        self.category = FEATURED
        self._clear_search()
        self._show("home")

    def show_apps(self) -> None:
        self._clear_search()
        self._show("apps")

    def select_category(self, name: str) -> None:
        if name == FEATURED:
            self.show_home()
            return
        self.category = name
        self._clear_search()
        self._show("category")

    def _clear_search(self) -> None:
        if self.search_entry.get_text():
            self._search_gen += 1
            self.search_entry.set_text("")

    def _fill_grid(self, apps: list[AppInfo]) -> None:
        self.grid.remove_all()
        self.cards = {}
        for info in apps:
            card = AppCard(info)
            self.grid.append(card)
            self.cards[info.app_id] = card
        self._decorate()

    def _on_hero_changed(self, info: AppInfo) -> None:
        """The page takes the palette of the spotlight on screen."""
        def apply(pal) -> None:
            if self.hero.current() is not info:
                return  # the carousel moved on while the palette was computed
            if self._ambient:
                self.remove_css_class(self._ambient)
            self._ambient = css_class(info.app_id) if pal else None
            if self._ambient:
                self.add_css_class(self._ambient)

        # Seed a throwaway widget: the palette lands in the shared provider either way.
        self.seeder.seed(Gtk.Box(), info.app_id, info.icon, then=apply)

    def _open_dusk_app(self, app) -> None:
        if opener := getattr(self.shell, "open_dusk_app", None):
            opener(app)

    def _launch_dusk_app(self, app) -> None:
        if not dusk.launch(app, self):
            self.shell.toast(f"Could not open {app.title}")

    # -- search ---------------------------------------------------------

    def focus_search(self) -> None:
        self.search_entry.grab_focus()
        self.search_entry.select_region(0, -1)

    def _on_search_changed(self, entry: Gtk.SearchEntry) -> None:
        query = entry.get_text().strip()
        if query:
            self._search(query)
        else:
            self._search_gen += 1
            self._show(self.view if self.view not in ("results",) else "home")

    def _on_search_activate(self, _entry) -> None:
        if self.result_rows:
            self.result_rows[0].activate()

    def _search(self, query: str) -> None:
        self._search_gen += 1
        gen = self._search_gen
        apps = self._visible(self.catalog.search(query)) if self.catalog_ready else []
        self.results.remove_all()
        self.result_rows = []
        for info in apps:
            self._add_app_row(info)
        self.results_title.set_label(f"Results for “{query}”")
        if apps:
            self.views.set_visible_child_name("results")
            self.state.content()
        else:
            self.state.loading()
        self.on_view_changed("results", None)
        known = {a.app_id for a in apps} | {(s, n) for a in apps for s, n in a.candidates.items()}
        self.hub.search(query, lambda pkgs, errs: self._on_hub_results(gen, query, known, pkgs, errs))

    def _on_hub_results(self, gen: int, query: str, known: set,
                        packages: list[Package], errors: list[BackendError]) -> None:
        if gen != self._search_gen:
            return  # the user typed something newer
        packages = [p for p in packages if self._package_allowed(p)]
        for group in group_packages(packages):
            if group[0].app_id in known or any((p.source, p.name) in known for p in group):
                continue  # already shown from the catalog
            self._add_package_row(group)
        if self.result_rows:
            self.banners.show_errors(errors)
            self.views.set_visible_child_name("results")
            self.state.content()
        elif errors and len(errors) >= len(self.hub.sources):
            self.banners.show_errors([])
            self.state.error("Search failed", "; ".join(error_text(e) for e in errors))
        else:
            self.banners.show_errors(errors)
            self.state.empty("No Apps Found", f"Nothing matches “{query}”. Try another word.",
                             "system-search-symbolic")

    def _add_app_row(self, info: AppInfo) -> None:
        tags = ["Installed"] if self.is_installed(info) else []
        sources = ", ".join(str(s) for s in policy.ordered(info.candidates))
        if sources:
            tags.append(sources)
        row = self._row(info.title, info.summary, info.icon, tags)
        row.connect("activated", lambda *_: self.shell.open_app(info))

    def _add_package_row(self, group: list[Package]) -> None:
        pkg = group[0]
        tags = ["Installed"] if any(p.installed for p in group) else []
        tags.append(", ".join(str(p.source) for p in group))
        row = self._row(pkg.display_name, pkg.summary, pkg.icon, tags)
        row.connect("activated", lambda *_: self.shell.open_package(pkg, group))

    def _row(self, title: str, summary: str, icon: Optional[str], tags: list[str]) -> Adw.ActionRow:
        row = Adw.ActionRow(title=title, subtitle=summary, activatable=True, use_markup=False,
                            subtitle_lines=2)
        row.add_prefix(app_icon(icon, 48))
        for tag in tags:
            row.add_suffix(source_label(tag))
        row.add_suffix(Gtk.Image(icon_name="go-next-symbolic",
                                 accessible_role=Gtk.AccessibleRole.PRESENTATION))
        self.results.append(row)
        self.result_rows.append(row)
        return row
