"""Install-source policy: which source AppHub offers first when an app has several."""

from __future__ import annotations

from dataclasses import replace
from typing import Iterable, Optional, TypeVar

from .backend import AppInfo, Source

# Flatpak first: sandboxed and updated often by the app's own developers.
# APT next: signed distribution packages that update with the system.
# Snap and AppImage last: Snap is confined but slower to start; AppImage has no sandbox or updates.
SOURCE_PREFERENCE: list[Source] = [Source.FLATPAK, Source.APT, Source.SNAP, Source.APPIMAGE]

SOURCE_REASON: dict[Source, str] = {
    Source.FLATPAK: "Sandboxed and updated often",
    Source.APT: "Part of the system, updated with it",
    Source.SNAP: "Confined, updated automatically",
    Source.APPIMAGE: "Single file, no sandbox or automatic updates",
}

T = TypeVar("T")


def rank(source: Source) -> int:
    """Position of a source in SOURCE_PREFERENCE; unknown sources sort last."""
    try:
        return SOURCE_PREFERENCE.index(source)
    except ValueError:
        return len(SOURCE_PREFERENCE)


def ordered(sources: Iterable[Source]) -> list[Source]:
    """Sources sorted by preference, best first."""
    return sorted(sources, key=rank)


def preferred(sources: Iterable[Source]) -> Source | None:
    """The source to offer as the default install, or None when there is none."""
    best = ordered(sources)
    return best[0] if best else None


UNVERIFIED_WARNING = (
    "This Flatpak is not maintained by the app's own developer. Someone else packages it on "
    "Flathub, so you must trust that maintainer as well as the developer. Flathub publishes "
    "updates immediately; nobody else reviews them.")


def flatpak_allowed(info: AppInfo, show_unverified: bool) -> bool:
    """Whether the Flatpak candidate may be offered (Mint: unverified hidden by default)."""
    return show_unverified or info.flatpak_verified is not False


def visible(info: AppInfo, show_unverified: bool) -> Optional[AppInfo]:
    """`info` with the Flatpak candidate removed when it may not be offered; None when
    nothing is left to install it from."""
    if Source.FLATPAK in info.candidates and not flatpak_allowed(info, show_unverified):
        rest = {s: n for s, n in info.candidates.items() if s != Source.FLATPAK}
        return replace(info, candidates=rest) if rest else None
    return info
