"""Installed: every installed app, grouped by source, with Remove."""

from __future__ import annotations

from typing import Optional

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gtk  # noqa: E402

from ..backend import BackendError, Package, Progress, Source  # noqa: E402
from ..hub import Hub  # noqa: E402
from .. import policy  # noqa: E402
from .common import (
    widen,  # noqa: E402
    ProgressRow,
    Shell,
    SourceBanners,
    StateStack,
    app_icon,
    confirm_remove,
    error_text,
    icon_button,
    report_failure,
    size_text,
    source_label,
)


class InstalledRow(Adw.ActionRow):
    def __init__(self, pkg: Package, on_open, on_remove):
        super().__init__(title=pkg.display_name, use_markup=False, activatable=True,
                         subtitle=f"{pkg.version} · {size_text(pkg)}")
        self.pkg = pkg
        self.add_prefix(app_icon(pkg.icon, 40))
        self.add_suffix(source_label(str(pkg.source)))
        self.remove_button: Optional[Gtk.Button] = None
        if pkg.essential:
            self.add_suffix(source_label("System"))
        else:
            self.remove_button = icon_button("user-trash-symbolic", f"Remove {pkg.display_name}",
                                             lambda: on_remove(pkg))
            self.remove_button.add_css_class("flat")
            self.add_suffix(self.remove_button)
        self.connect("activated", lambda *_: on_open(pkg))


class InstalledPage(Gtk.Box):
    def __init__(self, shell: Shell, hub: Hub):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.shell = shell
        self.hub = hub
        self.busy = False
        self.loading = False
        self.reload_pending = False
        self.rows: dict[str, InstalledRow] = {}
        self.groups: list[Adw.PreferencesGroup] = []

        self.banners = SourceBanners(self.load)
        self.append(self.banners)

        self.prefs = widen(Adw.PreferencesPage())
        self.progress_group = Adw.PreferencesGroup(visible=False)
        self.progress_row = ProgressRow()
        self.progress_group.add(self.progress_row)
        self.prefs.add(self.progress_group)

        self.state = StateStack(self.prefs, self.load)
        self.append(self.state)

    def load(self) -> None:
        if self.loading:
            self.reload_pending = True  # answer the newest state once this load ends
            return
        self.loading = True
        self.state.loading()
        self.hub.list_installed(self._on_loaded)

    def _on_loaded(self, packages: list[Package], errors: list[BackendError]) -> None:
        self.loading = False
        if self.reload_pending:
            self.reload_pending = False
            self.load()
            return
        for group in self.groups:
            self.prefs.remove(group)
        self.groups = []
        self.rows = {}

        if not packages and errors:
            self.banners.show_errors([])
            self.state.error("Could not list installed apps",
                             "; ".join(f"{e.source}: {error_text(e)}" for e in errors))
            return
        self.banners.show_errors(errors)
        if not packages:
            self.state.empty("No Apps Installed", "Apps you install appear here.",
                             "view-grid-symbolic")
            return

        by_source: dict[Source, list[Package]] = {}
        for p in packages:
            by_source.setdefault(p.source, []).append(p)
        for source in policy.ordered(by_source):
            pkgs = sorted(by_source[source], key=lambda p: p.display_name.casefold())
            group = Adw.PreferencesGroup(title=str(source),
                                         description=f"{len(pkgs)} installed")
            for pkg in pkgs:
                row = InstalledRow(pkg, self._open, self._ask_remove)
                group.add(row)
                self.rows[pkg.id] = row
            self.prefs.add(group)
            self.groups.append(group)
        self.state.content()

    def _open(self, pkg: Package) -> None:
        self.shell.open_package(pkg, [pkg])

    def _ask_remove(self, pkg: Package) -> None:
        if self.busy or pkg.essential:
            return
        confirm_remove(self, pkg, lambda: self.remove(pkg))

    def remove(self, pkg: Package) -> None:
        """Remove without asking; the confirmation dialog calls this."""
        if self.busy or pkg.essential:
            return
        self._set_busy(True)
        self.hub.remove(pkg, self._on_progress,
                        lambda result, err: self._on_removed(pkg, result, err))

    def _set_busy(self, busy: bool) -> None:
        self.busy = busy
        for group in self.groups:
            group.set_sensitive(not busy)
        self.progress_group.set_visible(busy)
        if busy:
            self.progress_row.start()
        else:
            self.progress_row.stop()

    def _on_progress(self, p: Progress) -> None:
        self.progress_row.update(p)

    def _on_removed(self, pkg: Package, result: Optional[Package],
                    err: Optional[BackendError]) -> None:
        self._set_busy(False)
        name = pkg.display_name
        if err:
            report_failure(self.shell, f"remove {name}", err)
            return
        self.shell._notify(f"{name} removed", f"{name} {pkg.version} from {pkg.source}")
        self.shell.package_changed()
