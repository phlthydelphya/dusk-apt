"""Dusk Desktop's own apps: a curated list (data/dusk-apps.json) plus their state here.

These apps do not come from APT, Flatpak or Snap yet: they are installed by
Dusk's installer (for example under /usr/local) or by their own packages. So
"installed" means "a launcher for it exists". When an app ships in a package
source, its manifest entry gains `packages` and the normal install flow takes over.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gio, GLib, Gtk  # noqa: E402

try:
    gi.require_version("GioUnix", "2.0")
    from gi.repository import GioUnix  # noqa: E402
    DesktopAppInfo = GioUnix.DesktopAppInfo
except (ValueError, ImportError):  # GLib older than 2.86
    DesktopAppInfo = Gio.DesktopAppInfo

from .backend import AppInfo, Source  # noqa: E402

log = logging.getLogger("apphub.dusk")

MANIFEST = Path(__file__).resolve().parent.parent.parent / "data" / "dusk-apps.json"
WALLPAPER_KEY = "dusk:wallpaper"  # Seeder key for the desktop wallpaper's palette


@dataclass(frozen=True)
class DuskApp:
    id: str  # desktop file ID without ".desktop"
    title: str
    summary: str
    description: str = ""
    icon: Optional[str] = None  # icon name or absolute path
    replaces: Optional[str] = None  # stock app this build stands in for
    packages: dict[Source, str] = field(default_factory=dict)

    def launcher(self):
        try:
            return DesktopAppInfo.new(f"{self.id}.desktop")
        except TypeError:
            return None

    @property
    def installed(self) -> bool:
        return self.launcher() is not None

    def info(self) -> AppInfo:
        return AppInfo(app_id=self.id, title=self.title, summary=self.summary,
                       description=self.description, developer="Dusk Desktop",
                       icon=self.icon, candidates=dict(self.packages))


def load(path: Path = MANIFEST) -> list[DuskApp]:
    """The curated list. A missing or broken manifest means no Dusk section, not a crash."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        log.warning("no Dusk app list at %s: %s", path, e)
        return []
    apps = []
    for entry in data.get("apps", []):
        try:
            packages = {Source(k): v for k, v in (entry.get("packages") or {}).items()}
            apps.append(DuskApp(id=entry["id"], title=entry["title"], summary=entry["summary"],
                                description=entry.get("description", ""),
                                icon=entry.get("icon"), replaces=entry.get("replaces"),
                                packages=packages))
        except (KeyError, ValueError) as e:
            log.warning("skipping Dusk app entry %r: %s", entry.get("id"), e)
    return apps


def wallpaper_file() -> Optional[str]:
    """The desktop's dark-style wallpaper (Dusk is dark only), else the light one."""
    try:
        settings = Gio.Settings.new("org.gnome.desktop.background")
    except Exception:  # noqa: BLE001 - schema missing outside GNOME
        return None
    for key in ("picture-uri-dark", "picture-uri"):
        uri = settings.get_string(key)
        if uri:
            path = Gio.File.new_for_uri(uri).get_path() if "://" in uri else uri
            if path and os.path.isfile(path):
                return path
    return None


def launch(app: DuskApp, widget: Optional[Gtk.Widget] = None) -> bool:
    launcher = app.launcher()
    if launcher is None:
        return False
    ctx = widget.get_display().get_app_launch_context() if widget else None
    try:
        return launcher.launch([], ctx)
    except GLib.Error as e:
        log.warning("could not open %s: %s", app.id, e.message)
        return False
