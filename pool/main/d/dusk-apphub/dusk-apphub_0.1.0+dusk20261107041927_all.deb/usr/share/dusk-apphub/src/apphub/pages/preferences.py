"""Preferences: software shown (Flathub verification), the Downloads watcher,
the top bar icon and automatic updates."""

from __future__ import annotations

from datetime import datetime
from typing import Callable, Optional

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gio, Gtk  # noqa: E402

from ..backend import BackendError  # noqa: E402
from ..settings import Settings  # noqa: E402
from ..system import Automation, AutomationState  # noqa: E402
from .common import error_text  # noqa: E402

SUBTITLE = ("Runs daily. Security updates and Flatpak apps only, never kernels. "
            "A Timeshift restore point is made first when Timeshift is set up.")


def last_run_text(state: Optional[AutomationState]) -> str:
    if state is None:
        return "Checking…"
    if not state.last_run:
        return "Has not run yet"
    try:
        when = datetime.fromisoformat(state.last_run).astimezone().strftime("%-d %b %Y, %H:%M")
    except ValueError:
        when = state.last_run
    return f"{when}: {state.last_result}" if state.last_result else when


UNVERIFIED_SUBTITLE = ("Flathub apps not maintained by their own developer are hidden, as in "
                       "Linux Mint. Showing them means trusting a third-party maintainer too; "
                       "installing one asks you first.")


WATCH_SUBTITLE = ("When an AppImage finishes downloading, offer to add it to the app drawer")

TRAY_SUBTITLE = "An icon in the top bar for updates"
# (settings value, label), in Settings.TRAY_MODES order
TRAY_CHOICES = (("updates", "While Updates Wait"), ("always", "Always"), ("never", "Never"))


class PreferencesDialog(Adw.PreferencesDialog):
    def __init__(self, automation: Optional[Automation] = None,
                 settings: Optional[Settings] = None,
                 on_settings_changed: Optional[Callable[[], None]] = None):
        super().__init__(title="Preferences")
        self._automation = automation
        self._settings = settings
        self._on_settings_changed = on_settings_changed or (lambda: None)
        # The state systemd last reported. A switch change that matches it came from code
        # (GTK may deliver notify::active late, so a "busy" flag is not reliable).
        self._confirmed = False
        page = Adw.PreferencesPage(title="General", icon_name="emblem-system-symbolic")

        self.unverified_switch: Optional[Adw.SwitchRow] = None
        self.watch_switch: Optional[Adw.SwitchRow] = None
        self.tray_row: Optional[Adw.ComboRow] = None
        if settings is not None:
            self.unverified_switch = Adw.SwitchRow(
                title="Show unverified Flatpaks", subtitle=UNVERIFIED_SUBTITLE,
                active=settings.show_unverified_flatpaks)
            self.unverified_switch.connect("notify::active", self._on_unverified_toggled)
            # Read by the watcher for every download, so it applies at once
            self.watch_switch = Adw.SwitchRow(
                title="Watch Downloads for AppImages", subtitle=WATCH_SUBTITLE,
                active=settings.watch_downloads)
            self.watch_switch.connect("notify::active", self._on_watch_toggled)
            self.tray_row = Adw.ComboRow(
                title="Show Updates in the Top Bar", subtitle=TRAY_SUBTITLE,
                model=Gtk.StringList.new([label for _v, label in TRAY_CHOICES]))
            modes = [v for v, _l in TRAY_CHOICES]
            self.tray_row.set_selected(modes.index(settings.tray_icon))
            self.tray_row.connect("notify::selected", self._on_tray_selected)
            software = Adw.PreferencesGroup(title="Software")
            software.add(self.unverified_switch)
            software.add(self.watch_switch)
            software.add(self.tray_row)
            page.add(software)

        self.switch = Adw.SwitchRow(title="Install security updates automatically",
                                    subtitle=SUBTITLE, sensitive=False)
        self.last_run = Adw.ActionRow(title="Last run", subtitle=last_run_text(None),
                                      subtitle_selectable=True)
        if automation is not None:
            group = Adw.PreferencesGroup(title="Automatic updates")
            group.add(self.switch)
            group.add(self.last_run)
            page.add(group)
        self.add(page)

        self.switch.connect("notify::active", self._on_toggled)
        if automation is not None:
            automation.state(self._on_state)

    def _on_unverified_toggled(self, row, _pspec) -> None:
        if row.get_active() != self._settings.show_unverified_flatpaks:
            self._settings.set("show_unverified_flatpaks", row.get_active())
            self._on_settings_changed()

    def _on_watch_toggled(self, row, _pspec) -> None:
        if row.get_active() == self._settings.watch_downloads:
            return
        self._settings.set("watch_downloads", row.get_active())
        if row.get_active():
            # This AppHub may have started without --watch (autostart off):
            # start the watcher here too; it does nothing when already running
            app = Gio.Application.get_default()
            if app is not None and app.lookup_action("watch-downloads") is not None:
                app.activate_action("watch-downloads", None)

    def _on_tray_selected(self, row, _pspec) -> None:
        index = row.get_selected()
        if not 0 <= index < len(TRAY_CHOICES):
            return
        mode = TRAY_CHOICES[index][0]
        if mode == self._settings.tray_icon:
            return
        self._settings.set("tray_icon", mode)
        app = Gio.Application.get_default()
        if app is not None and hasattr(app, "tray_setting_changed"):
            app.tray_setting_changed()

    def _show(self, state: AutomationState) -> None:
        self._confirmed = state.enabled
        self.switch.set_active(state.enabled)
        self.last_run.set_subtitle(last_run_text(state))

    def _on_state(self, state: Optional[AutomationState], error: Optional[BackendError]) -> None:
        if state is not None:
            self._show(state)
        else:
            self.last_run.set_subtitle("Could not read the state")
        self.switch.set_sensitive(state is not None)

    def _on_toggled(self, *_args) -> None:
        wanted = self.switch.get_active()
        if wanted == self._confirmed:
            return
        self.switch.set_sensitive(False)  # one request at a time; the helper may ask for a password

        def finished(state: Optional[AutomationState], error: Optional[BackendError]) -> None:
            self.switch.set_sensitive(True)
            if state is not None and state.enabled == wanted:
                self._show(state)
                return
            # Failed, or systemd did not end up as asked: put the switch back to the truth.
            self._confirmed = state.enabled if state is not None else not wanted
            self.switch.set_active(self._confirmed)
            if state is not None:
                self.last_run.set_subtitle(last_run_text(state))
            what = "turn on" if wanted else "turn off"
            reason = error_text(error) if error else "The timer did not change"
            self.add_toast(Adw.Toast(title=f"Could not {what} automatic updates. {reason}",
                                     use_markup=False, timeout=5))

        self._automation.set_enabled(wanted, finished)
