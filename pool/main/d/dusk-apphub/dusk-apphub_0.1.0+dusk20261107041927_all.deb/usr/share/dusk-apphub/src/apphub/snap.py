"""Snap backend over snapd-glib.

snapd is the privileged side: it owns the REST API, polkit authentication and
the change queue, so AppHub runs unprivileged. All calls use the library's
`_async` APIs, which complete on the GLib main loop, so no extra thread is
needed and every callback already runs on the main thread.
"""

from __future__ import annotations

import dataclasses
import os
from typing import Callable, Optional

import gi

try:
    gi.require_version("Snapd", "2")
    from gi.repository import Snapd
except (ValueError, ImportError):  # typelib missing: available() reports False
    Snapd = None

from gi.repository import Gio, GLib  # noqa: E402

from .backend import (  # noqa: E402
    BackendError,
    Done,
    ErrorKind,
    OnProgress,
    Once,
    on_main,
    Package,
    Progress,
    Source,
)

if Snapd is not None:
    _SNAPD_KINDS = {
        Snapd.Error.AUTH_CANCELLED: ErrorKind.AUTH,
        Snapd.Error.AUTH_DATA_REQUIRED: ErrorKind.AUTH,
        Snapd.Error.AUTH_DATA_INVALID: ErrorKind.AUTH,
        Snapd.Error.TWO_FACTOR_REQUIRED: ErrorKind.AUTH,
        Snapd.Error.TWO_FACTOR_INVALID: ErrorKind.AUTH,
        Snapd.Error.PERMISSION_DENIED: ErrorKind.AUTH,
        Snapd.Error.CHANGE_CONFLICT: ErrorKind.BUSY,
        Snapd.Error.DNS_FAILURE: ErrorKind.NETWORK,
        Snapd.Error.NETWORK_TIMEOUT: ErrorKind.NETWORK,
        Snapd.Error.NOT_FOUND: ErrorKind.NOT_FOUND,
        Snapd.Error.NOT_IN_STORE: ErrorKind.NOT_FOUND,
        Snapd.Error.NOT_INSTALLED: ErrorKind.NOT_FOUND,
        Snapd.Error.APP_NOT_FOUND: ErrorKind.NOT_FOUND,
        # This snap cannot be installed here as asked: nothing the user can retry.
        Snapd.Error.NEEDS_DEVMODE: ErrorKind.UNSUPPORTED,
        Snapd.Error.NEEDS_CLASSIC: ErrorKind.UNSUPPORTED,
        Snapd.Error.NEEDS_CLASSIC_SYSTEM: ErrorKind.UNSUPPORTED,
        Snapd.Error.NOT_CLASSIC: ErrorKind.UNSUPPORTED,
        Snapd.Error.ARCHITECTURE_NOT_AVAILABLE: ErrorKind.UNSUPPORTED,
        Snapd.Error.CHANNEL_NOT_AVAILABLE: ErrorKind.UNSUPPORTED,
        Snapd.Error.REVISION_NOT_AVAILABLE: ErrorKind.UNSUPPORTED,
        # CONNECTION_FAILED, ALREADY_INSTALLED, NO_UPDATE_AVAILABLE and the rest: FAILED.
    }
else:
    _SNAPD_KINDS = {}

# Where snapd mounts snaps: /snap on Debian-like systems, the other on Fedora-like ones.
_SNAP_ROOTS = ("/snap", "/var/lib/snapd/snap")


def map_error(err: GLib.Error) -> BackendError:
    """Turn a snapd-glib GLib.Error into the shared error contract.

    The raw Snapd.Error code is kept on the result as `snapd_code` (None for
    errors from other domains) for callers that must tell, say, NO_UPDATE_AVAILABLE apart.
    """
    kind = ErrorKind.FAILED
    code = None
    if Snapd is not None and err.domain == GLib.quark_to_string(Snapd.Error.quark()):
        code = err.code
        try:
            kind = _SNAPD_KINDS.get(Snapd.Error(err.code), ErrorKind.FAILED)
        except ValueError:
            pass
    elif err.matches(Gio.io_error_quark(), Gio.IOErrorEnum.CANCELLED):
        kind = ErrorKind.CANCELLED
    out = BackendError(kind, err.message, Source.SNAP)
    out.snapd_code = code
    return out


def _fail(e: Exception) -> BackendError:
    return BackendError(ErrorKind.FAILED, str(e) or e.__class__.__name__, Source.SNAP)


def _app_id(snap) -> Optional[str]:
    """First AppStream common ID, without a ".desktop" suffix."""
    ids = list(snap.get_common_ids() or [])
    if not ids:  # installed snaps carry the ID on their apps instead
        ids = [a.get_common_id() for a in (snap.get_apps() or []) if a.get_common_id()]
    if not ids:
        return None
    first = ids[0]
    return first[: -len(".desktop")] if first.endswith(".desktop") else first


def _desktop_icon(snap) -> Optional[str]:
    """Icon= of the snap's generated .desktop file: an absolute path that exists, or an icon name."""
    for app in snap.get_apps() or []:
        path = app.get_desktop_file()
        if not path:
            continue
        try:
            with open(path, encoding="utf-8") as f:
                for line in f:
                    if line.startswith("Icon="):
                        icon = line[5:].strip()
                        if not icon:
                            break
                        if not icon.startswith("/"):
                            return icon  # theme icon name
                        if os.path.isfile(icon):
                            return icon
                        break
        except OSError:
            continue
    return None


def _local_icon(snap) -> Optional[str]:
    """Local icon for an installed snap. snapd's own /v2/icons URL is not a file."""
    found = _desktop_icon(snap)
    if found:
        return found
    name = snap.get_name()
    for root in _SNAP_ROOTS:
        for fname in ("icon.png", "icon.svg", f"{name}.png", f"{name}.svg"):
            path = os.path.join(root, name, "current", "meta", "gui", fname)
            if os.path.isfile(path):
                return path
    return None


def _is_app(snap) -> bool:
    """A user-facing app: type APP and at least one app inside.

    snapd files content snaps (GNOME platform, GTK themes, Mesa) under type APP
    too, but they have no apps and are not something a user launches or manages.
    """
    return snap.get_snap_type() == Snapd.SnapType.APP and bool(snap.get_apps())


def _change_progress(change) -> Progress:
    """Map a snapd change to Progress.

    Percent is the mean of per-task completion (done/total of each task's
    progress; a finished task counts 1). A plain sum of done/total would be
    all download bytes and hit ~100% before the install steps even start.
    """
    tasks = list(change.get_tasks() or [])
    fractions = []
    for t in tasks:
        if t.get_ready():
            fractions.append(1.0)
            continue
        total = t.get_progress_total()
        fractions.append(min(max(t.get_progress_done() / total, 0.0), 1.0) if total > 0 else 0.0)
    percent = int(100 * sum(fractions) / len(fractions)) if fractions else None
    running = next((t for t in tasks if t.get_status() == "Doing"), None)
    status = (running.get_summary() if running else None) or change.get_summary() or "Working"
    return Progress(percent=percent, status=status)


def _progress_adapter(cb: Optional[OnProgress], lo: float = 0.0, hi: float = 1.0):
    """snapd progress callback -> Progress. [lo, hi] rescales one step of a multi-step job."""
    def on_progress(_client, change, *_):
        if cb is None:
            return
        try:
            p = _change_progress(change)
            if p.percent is not None and (lo, hi) != (0.0, 1.0):
                p = Progress(int(100 * (lo + (hi - lo) * p.percent / 100)), p.status)
            cb(p)
        except Exception:  # noqa: BLE001 - a progress bug must not break the change
            pass

    return on_progress


class SnapBackend:
    source = Source.SNAP

    def __init__(self) -> None:
        self._client = Snapd.Client() if Snapd is not None else None
        if self._client is not None:
            self._client.set_allow_interaction(True)  # allow the polkit prompt

    def available(self) -> bool:
        """Typelib imported and snapd's socket answers (local socket, a few ms)."""
        if self._client is None:
            return False
        try:
            self._client.get_system_information_sync(None)
        except Exception:  # noqa: BLE001 - any failure means "not here"
            return False
        return True

    # -- queries --------------------------------------------------------

    def lookup(self, name: str, done: Done[Package]) -> None:
        done = Once(done)

        def not_installed(err: BackendError) -> None:
            if err.kind is ErrorKind.NOT_FOUND:
                self._store_exact(name, lambda s: done(self._to_package(s, False), None), done)
            else:
                done(None, err)

        self._run("get_snap", (name,), lambda s: done(self._to_package(s, True), None),
                  done, not_installed)

    def search(self, query: str, done: Done[list[Package]]) -> None:
        done = Once(done)
        if not query.strip():
            on_main(done)([], None)  # never call done before the call returns
            return

        def found(result) -> None:
            hits = [s for s in _snaps(result) if s.get_snap_type() == Snapd.SnapType.APP]
            if not hits:
                done([], None)
                return

            def merged(installed) -> None:
                have = {s.get_name(): s for s in installed}
                done([self._to_package(have.get(s.get_name(), s), s.get_name() in have)
                      for s in hits], None)

            # Mark what is already installed. Failing here still returns the hits.
            self._run("get_snaps", (Snapd.GetSnapsFlags.NONE, [s.get_name() for s in hits]),
                      merged, done, lambda _e: merged([]))

        self._run("find", (Snapd.FindFlags.NONE, query), found, done)

    def list_installed(self, done: Done[list[Package]]) -> None:
        done = Once(done)
        self._run("get_snaps", (Snapd.GetSnapsFlags.NONE, None),
                  lambda snaps: done([self._to_package(s, True) for s in snaps if _is_app(s)], None),
                  done)

    def get_updates(self, done: Done[list[Package]]) -> None:
        done = Once(done)

        def refreshable(result) -> None:
            news = {s.get_name(): s for s in _snaps(result)}
            if not news:
                done([], None)
                return

            def installed(snaps) -> None:
                out = []
                for s in snaps:
                    if not _is_app(s):
                        continue  # runtimes and bases refresh on their own
                    new = news[s.get_name()]
                    out.append(dataclasses.replace(
                        self._to_package(s, True),
                        update_version=new.get_version() or None,
                        download_size=new.get_download_size() or None))
                done(out, None)

            self._run("get_snaps", (Snapd.GetSnapsFlags.NONE, list(news)), installed, done)

        self._run("find_refreshable", (), refreshable, done)

    # -- changes --------------------------------------------------------

    # snapd has no dry run. For simulate=True we never send a change: we only
    # check that the snap exists (store for install, local for remove and
    # update) and is in the right install state, then return the package
    # unchanged. Whether snapd would accept the real change (auth, conflicts,
    # confinement, disk space) is NOT checked.

    def install(self, pkg: Package, progress: OnProgress, done: Done[Package],
                simulate: bool = False) -> None:
        done = Once(done)

        def checked(installed) -> None:
            if installed is not None:
                done(None, BackendError(ErrorKind.FAILED,
                                        f"{pkg.name} is already installed", Source.SNAP))
            elif simulate:
                self._store_exact(pkg.name, lambda _s: done(pkg, None), done)
            else:
                self._store_exact(pkg.name, lambda s: self._install_real(s, pkg, progress, done),
                                  done)

        self._installed_or_none(pkg.name, checked, done)

    def _install_real(self, store_snap, pkg: Package, progress: OnProgress, done) -> None:
        # Classic snaps need an explicit flag; picking the snap implies consent.
        flags = (Snapd.InstallFlags.CLASSIC
                 if store_snap.get_confinement() == Snapd.Confinement.CLASSIC
                 else Snapd.InstallFlags.NONE)
        self._run("install2", (flags, pkg.name, None, None, _progress_adapter(progress), None),
                  lambda _ok: self._reread(pkg, True, done), done)

    def remove(self, pkg: Package, progress: OnProgress, done: Done[Package],
               simulate: bool = False) -> None:
        done = Once(done)

        def checked(installed) -> None:
            if installed is None:
                done(None, BackendError(ErrorKind.NOT_FOUND,
                                        f"{pkg.name} is not installed", Source.SNAP))
            elif simulate:
                done(pkg, None)
            else:
                self._run("remove2", (Snapd.RemoveFlags.NONE, pkg.name,
                                      _progress_adapter(progress), None),
                          lambda _ok: self._reread(pkg, False, done), done)

        self._installed_or_none(pkg.name, checked, done)

    def update(self, pkgs: list[Package], progress: OnProgress, done: Done[list[Package]],
               simulate: bool = False) -> None:
        done = Once(done)
        if not pkgs:
            on_main(done)([], None)
            return

        def checked(installed) -> None:
            have = {s.get_name() for s in installed}
            missing = [p.name for p in pkgs if p.name not in have]
            if missing:
                done(None, BackendError(ErrorKind.NOT_FOUND,
                                        f"not installed: {', '.join(missing)}", Source.SNAP))
            elif simulate:
                done(list(pkgs), None)
            else:
                self._refresh_next(pkgs, 0, progress, done)

        self._run("get_snaps", (Snapd.GetSnapsFlags.NONE, [p.name for p in pkgs]), checked, done)

    def _refresh_next(self, pkgs: list[Package], i: int, progress: OnProgress, done) -> None:
        """Refresh pkgs[i:] one after another; a snap job per snapd change."""
        if i == len(pkgs):
            self._reread_all(pkgs, done)
            return
        n = len(pkgs)

        def after(_ok=None) -> None:
            self._refresh_next(pkgs, i + 1, progress, done)

        def failed(err: BackendError) -> None:
            if getattr(err, "snapd_code", None) == int(Snapd.Error.NO_UPDATE_AVAILABLE):
                after()  # already current: not a failure
            else:
                done(None, err)

        self._run("refresh", (pkgs[i].name, None, _progress_adapter(progress, i / n, (i + 1) / n),
                              None),
                  after, done, failed)

    # -- plumbing -------------------------------------------------------

    def _to_package(self, snap, installed: bool) -> Package:
        name = snap.get_name()
        return Package(
            id=name,
            name=name,
            version=snap.get_version() or "",
            summary=snap.get_summary() or "",
            source=self.source,
            installed=installed,
            title=snap.get_title() or None,
            app_id=_app_id(snap),
            origin=(snap.get_tracking_channel() if installed else snap.get_channel()) or None,
            icon=_local_icon(snap) if installed else None,
            installed_size=snap.get_installed_size() or None,
            download_size=snap.get_download_size() or None,
            essential=snap.get_snap_type() != Snapd.SnapType.APP,
        )

    def _installed_or_none(self, name: str, on_result, done) -> None:
        """Call on_result(installed snap) or on_result(None) when it is not installed."""
        self._run("get_snap", (name,), on_result, done,
                  lambda err: on_result(None) if err.kind is ErrorKind.NOT_FOUND
                  else done(None, err))

    def _store_exact(self, name: str, on_snap, done) -> None:
        """Call on_snap(store snap named exactly `name`), or done(NOT_FOUND)."""
        def found(result) -> None:
            hits = [s for s in _snaps(result) if s.get_name() == name]
            if hits:
                on_snap(hits[0])
            else:
                done(None, BackendError(ErrorKind.NOT_FOUND,
                                        f"{name} is not in the Snap Store", Source.SNAP))

        self._run("find", (Snapd.FindFlags.MATCH_NAME, name), found, done)

    def _reread(self, pkg: Package, installed: bool, done) -> None:
        """Re-read state from snapd after a change instead of assuming it landed."""
        fallback = dataclasses.replace(pkg, installed=installed, update_version=None)
        if installed:
            self._run("get_snap", (pkg.name,), lambda s: done(self._to_package(s, True), None),
                      done, lambda _e: done(fallback, None))
        else:
            # The snap is gone locally; show its store entry if the store answers.
            self._store_exact(pkg.name, lambda s: done(self._to_package(s, False), None),
                              lambda _r, _e: done(fallback, None))

    def _reread_all(self, pkgs: list[Package], done) -> None:
        def got(snaps) -> None:
            have = {s.get_name(): self._to_package(s, True) for s in snaps}
            done([have.get(p.name, dataclasses.replace(p, update_version=None)) for p in pkgs],
                 None)

        self._run("get_snaps", (Snapd.GetSnapsFlags.NONE, [p.name for p in pkgs]), got,
                  lambda _r, _e: done([dataclasses.replace(p, update_version=None)
                                       for p in pkgs], None))

    def _run(self, method: str, args: tuple, on_ok: Callable, done,
             on_err: Optional[Callable[[BackendError], None]] = None) -> None:
        """Start `<method>_async`; route the result to on_ok, a failure to on_err or done.

        Every path ends in exactly one call to `done` (directly or via on_ok /
        on_err), so a bug here shows as an error in the UI, not a stuck spinner.
        """
        def fail(err: BackendError) -> None:
            try:
                (on_err or (lambda e: done(None, e)))(err)
            except Exception as e:  # noqa: BLE001
                done(None, _fail(e))

        def ready(client, res, *_):
            try:
                result = getattr(client, f"{method}_finish")(res)
            except GLib.Error as e:
                err = map_error(e)
                fail(err)
                return
            except Exception as e:  # noqa: BLE001 - never leave the caller waiting
                done(None, _fail(e))
                return
            try:
                on_ok(result)
            except Exception as e:  # noqa: BLE001
                done(None, _fail(e))

        try:
            if self._client is None:
                raise RuntimeError("snapd-glib typelib is not installed")
            getattr(self._client, f"{method}_async")(*args, None, ready)
        except Exception as e:  # noqa: BLE001
            done(None, _fail(e))


def _snaps(result) -> list:
    """find_finish returns (snaps, suggested_currency); the other list calls a bare list."""
    return list(result[0] if isinstance(result, tuple) else result)
