"""Widgets and rules shared by every page: error text, state stack, icons, changes."""

from __future__ import annotations

import os
from typing import Callable, Optional, Protocol

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, GLib, Gtk  # noqa: E402

from ..backend import AppInfo, BackendError, ErrorKind, Package, Progress  # noqa: E402
from ..hub import Hub  # noqa: E402

# The user stopping the polkit prompt is not a failure worth a notification.
QUIET_KINDS = {ErrorKind.AUTH, ErrorKind.CANCELLED}

_ERROR_TEXT = {
    ErrorKind.AUTH: "Authentication was not given",
    ErrorKind.BUSY: "Another package manager is running. Try again when it finishes",
    ErrorKind.NETWORK: "No network connection",
    ErrorKind.NOT_FOUND: "The package was not found",
    ErrorKind.CANCELLED: "Cancelled",
}

FALLBACK_ICON = "application-x-executable"


def error_text(err: BackendError) -> str:
    return _ERROR_TEXT.get(err.kind, err.message)


def source_error_text(err: BackendError) -> str:
    """One line naming the failed source, for banners."""
    where = f"{err.source}: " if err.source else ""
    return f"{where}{error_text(err)}"


class Shell(Protocol):
    """What a page needs from the window."""

    hub: Hub

    def toast(self, text: str) -> None: ...

    def _notify(self, title: str, body: str) -> None: ...

    def open_app(self, info: AppInfo) -> None: ...

    def open_package(self, pkg: Package, group: Optional[list[Package]] = None) -> None: ...

    def package_changed(self) -> None: ...

    def sources_changed(self) -> None: ...

    def set_update_count(self, count: int) -> None: ...


def report_failure(shell: Shell, what: str, err: BackendError) -> None:
    """Step 1 rules: always a toast; a notification unless the user cancelled."""
    shell.toast(error_text(err))
    if err.kind not in QUIET_KINDS:
        shell._notify(f"Could not {what}", error_text(err))


# -- icons and labels --------------------------------------------------------

def widen(page: Gtk.Widget, width: int = 1240) -> Gtk.Widget:
    """Adw.PreferencesPage caps its content at 600px; AppHub's lists fill the card like
    the rest of the store. Returns the page."""
    stack = [page]
    while stack:
        w = stack.pop()
        if isinstance(w, Adw.Clamp):
            w.set_maximum_size(width)
            w.set_tightening_threshold(width)
        c = w.get_first_child()
        while c:
            stack.append(c)
            c = c.get_next_sibling()
    return page


def _theme_has(name: str) -> bool:
    display = Gdk.Display.get_default()
    return display is None or Gtk.IconTheme.get_for_display(display).has_icon(name)


def app_icon(icon: Optional[str], size: int) -> Gtk.Image:
    image = Gtk.Image(pixel_size=size)
    image.add_css_class("icon-dropshadow")
    if icon and os.path.isabs(icon) and os.path.exists(icon):
        image.set_from_file(icon)
    elif icon and not os.path.isabs(icon) and _theme_has(icon):
        image.set_from_icon_name(icon)
    else:
        image.set_from_icon_name(FALLBACK_ICON)
    image.update_property([Gtk.AccessibleProperty.LABEL], [""])
    return image


def source_label(text: str) -> Gtk.Label:
    label = Gtk.Label(label=text, valign=Gtk.Align.CENTER)
    label.add_css_class("caption")
    label.add_css_class("dim-label")
    return label


def size_text(pkg: Package) -> str:
    if pkg.installed:
        return GLib.format_size(pkg.installed_size) if pkg.installed_size else "Unknown size"
    parts = []
    if pkg.download_size:
        parts.append(f"{GLib.format_size(pkg.download_size)} download")
    if pkg.installed_size:
        parts.append(f"{GLib.format_size(pkg.installed_size)} installed")
    return ", ".join(parts) or "Unknown size"


def stars_text(average: float) -> str:
    full = max(0, min(5, round(average)))
    return "★" * full + "☆" * (5 - full)


def icon_button(icon: str, tooltip: str, on_click: Callable[[], None]) -> Gtk.Button:
    """Icon-only button with a tooltip and an accessible label."""
    button = Gtk.Button(icon_name=icon, tooltip_text=tooltip, valign=Gtk.Align.CENTER)
    button.update_property([Gtk.AccessibleProperty.LABEL], [tooltip])
    button.connect("clicked", lambda *_: on_click())
    return button


def confirm_remove(parent: Gtk.Widget, pkg: Package, on_confirm: Callable[[], None]) -> Adw.AlertDialog:
    dialog = Adw.AlertDialog(
        heading=f"Remove {pkg.display_name}?",
        body="It will be uninstalled from this computer. Its settings in your home folder are kept.",
    )
    dialog.add_response("cancel", "Cancel")
    dialog.add_response("remove", "Remove")
    dialog.set_response_appearance("remove", Adw.ResponseAppearance.DESTRUCTIVE)
    dialog.set_default_response("cancel")
    dialog.set_close_response("cancel")
    dialog.connect("response", lambda _d, r: r == "remove" and on_confirm())
    dialog.present(parent)
    return dialog


# -- state stack -------------------------------------------------------------

class StateStack(Gtk.Stack):
    """loading / empty / error / content, with Try Again on the error page."""

    def __init__(self, content: Gtk.Widget, retry: Callable[[], None]):
        super().__init__(transition_type=Gtk.StackTransitionType.CROSSFADE, vexpand=True)

        spinner = Adw.Spinner(width_request=48, height_request=48,
                              halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER)
        self.add_named(spinner, "loading")

        self.empty_page = Adw.StatusPage()
        self.add_named(self.empty_page, "empty")

        self.error_page = Adw.StatusPage(icon_name="dialog-error-symbolic")
        self.retry_button = Gtk.Button(label="Try Again", halign=Gtk.Align.CENTER)
        self.retry_button.add_css_class("pill")
        self.retry_button.connect("clicked", lambda *_: retry())
        self.error_page.set_child(self.retry_button)
        self.add_named(self.error_page, "error")

        self.add_named(content, "content")

    def loading(self) -> None:
        self.set_visible_child_name("loading")

    def content(self) -> None:
        self.set_visible_child_name("content")

    def empty(self, title: str, description: str, icon: str,
              child: Optional[Gtk.Widget] = None) -> None:
        self.empty_page.set_title(title)
        self.empty_page.set_description(description)
        self.empty_page.set_icon_name(icon)
        self.empty_page.set_child(child)
        self.set_visible_child_name("empty")

    def error(self, title: str, description: str) -> None:
        self.error_page.set_title(title)
        self.error_page.set_description(description)
        self.set_visible_child_name("error")


class SourceBanners(Gtk.Box):
    """One Adw.Banner per failed source, shown while other sources still answered."""

    def __init__(self, retry: Callable[[], None]):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self._retry = retry
        self.banners: list[Adw.Banner] = []

    def show_errors(self, errors: list[BackendError]) -> None:
        for banner in self.banners:
            self.remove(banner)
        self.banners = []
        for err in errors:
            banner = Adw.Banner(title=GLib.markup_escape_text(source_error_text(err)),
                                button_label="Try Again", revealed=True)
            banner.connect("button-clicked", lambda *_: self._retry())
            self.append(banner)
            self.banners.append(banner)


class ProgressRow(Adw.ActionRow):
    """One progress row for a running change."""

    def __init__(self):
        super().__init__(visible=False, title="Starting", use_markup=False)
        self.bar = Gtk.ProgressBar(valign=Gtk.Align.CENTER, hexpand=True)
        self.add_suffix(self.bar)

    def start(self, title: str = "Starting") -> None:
        self.set_title(title)
        self.bar.set_fraction(0)
        self.set_visible(True)

    def update(self, p: Progress) -> None:
        self.set_title(p.status or "Working")
        if p.percent is None:
            self.bar.pulse()
        else:
            self.bar.set_fraction(max(0, min(100, p.percent)) / 100)

    def stop(self) -> None:
        self.set_visible(False)


def clear(container: Gtk.Widget) -> None:
    """Remove every child of a Gtk.Box, Gtk.ListBox or Gtk.FlowBox."""
    if isinstance(container, (Gtk.ListBox, Gtk.FlowBox)):
        container.remove_all()
        return
    child = container.get_first_child()
    while child:
        nxt = child.get_next_sibling()
        container.remove(child)
        child = nxt
