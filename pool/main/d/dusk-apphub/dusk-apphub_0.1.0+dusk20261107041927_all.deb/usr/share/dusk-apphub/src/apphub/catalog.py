"""AppStream catalog: the app data behind the Discover page, plus ODRS ratings.

libappstream reads the APT DEP-11 catalog (/var/lib/swcatalog) and the Flatpak
appstream data of the system and user installations. Components that share an
app ID merge into one AppInfo with a candidate per source, so the UI shows one
app and lets the user pick where to install it from.

The pool is loaded in a worker thread and turned into plain Python objects;
no AppStream object outlives load(), so the sync queries never touch gi.
"""

from __future__ import annotations

import html
import json
import os
import re
import threading
import time
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import replace, dataclass, field
from pathlib import Path
from typing import Callable, Optional

import gi

gi.require_version("AppStream", "1.0")
from gi.repository import AppStream as AS, GLib  # noqa: E402

from .verification import flathub_verification as _flathub_verification  # noqa: E402
from .backend import (  # noqa: E402
    AppInfo,
    BackendError,
    Done,
    ErrorKind,
    Once,
    Rating,
    Source,
    on_main,
    run_blocking,
)

ODRS_URL = "https://odrs.gnome.org/1.0/reviews/api/ratings"
ODRS_TTL = 24 * 60 * 60  # seconds
ODRS_TIMEOUT = 30  # seconds per socket operation

DEFAULT_FEATURED = Path(__file__).resolve().parents[2] / "data" / "featured.txt"

# freedesktop main categories, in the order the UI lists them.
MAIN_CATEGORIES = (
    "AudioVideo", "Development", "Education", "Game", "Graphics", "Network",
    "Office", "Science", "Settings", "System", "Utility",
)
_CATEGORY_ALIASES = {"Audio": "AudioVideo", "Video": "AudioVideo"}

_APP_KINDS = (AS.ComponentKind.DESKTOP_APP, AS.ComponentKind.CONSOLE_APP)
_MAX_ICON = 128  # pixels


def normalize_id(app_id: str) -> str:
    return app_id.removesuffix(".desktop")


# -- text -----------------------------------------------------------------

def _ws(text: str) -> str:
    return " ".join(text.split())


def markup_to_text(markup: Optional[str]) -> str:
    """AppStream description markup to plain text.

    Paragraphs are joined with a blank line; list items become "• " lines.
    """
    if not markup:
        return ""
    try:
        root = ET.fromstring(f"<root>{markup}</root>")
    except ET.ParseError:
        # Not well-formed (stray entity, broken tag): strip tags instead.
        text = re.sub(r"</(p|ul|ol)>", "\n\n", markup)
        text = re.sub(r"<li[^>]*>", "\n• ", text)
        text = html.unescape(re.sub(r"<[^>]+>", "", text))
        blocks = ("\n".join(_ws(line) for line in b.split("\n") if line.strip())
                  for b in text.split("\n\n"))
        return "\n\n".join(b for b in blocks if b)

    blocks: list[str] = []
    if root.text and root.text.strip():
        blocks.append(_ws(root.text))
    for el in root:
        if el.tag in ("ul", "ol"):
            items = [_ws("".join(li.itertext())) for li in el if li.tag == "li"]
            items = ["• " + i for i in items if i]
            if items:
                blocks.append("\n".join(items))
        else:
            text = _ws("".join(el.itertext()))
            if text:
                blocks.append(text)
        if el.tail and el.tail.strip():
            blocks.append(_ws(el.tail))
    return "\n\n".join(blocks)


# -- component readers ---------------------------------------------------

def _flatpak_name(ref: str) -> Optional[str]:
    """'app/org.foo.Bar/x86_64/stable' -> 'org.foo.Bar'; runtimes -> None."""
    parts = ref.split("/")
    if len(parts) >= 2 and parts[0] == "app":
        return parts[1] or None
    if len(parts) == 1 and parts[0]:
        return parts[0]
    return None


def _icon_choice(comps) -> Optional[str]:
    """Largest cached/local icon file at or below 128px, else a stock name."""
    files: list[tuple[tuple[int, bool], str]] = []
    stock = None
    for c in comps:
        for ic in c.get_icons() or []:
            kind = ic.get_kind()
            if kind in (AS.IconKind.CACHED, AS.IconKind.LOCAL):
                path = ic.get_filename()
                if not path or not os.path.isabs(path):
                    continue
                scale = max(ic.get_scale() or 1, 1)
                size = (ic.get_width() or 0) * scale
                if size <= _MAX_ICON:
                    files.append(((size, scale == 1), path))
            elif kind == AS.IconKind.STOCK and stock is None:
                stock = ic.get_name() or None
    for _key, path in sorted(files, key=lambda f: f[0], reverse=True):
        if os.path.isfile(path):
            return path
    return stock


def _screenshot_urls(c) -> tuple[str, ...]:
    shots = list(c.get_screenshots_all() or [])
    shots.sort(key=lambda s: s.get_kind() != AS.ScreenshotKind.DEFAULT)  # stable
    urls: list[str] = []
    for s in shots:
        if s.get_media_kind() != AS.ScreenshotMediaKind.IMAGE:
            continue
        imgs = [i for i in s.get_images_all() or [] if i.get_url()]
        thumbs = [i for i in imgs if i.get_kind() == AS.ImageKind.THUMBNAIL
                  and (i.get_scale() or 1) == 1]
        sources = [i for i in imgs if i.get_kind() == AS.ImageKind.SOURCE]
        if thumbs:
            pick = max(thumbs, key=lambda i: i.get_width() or 0)
        elif sources:
            pick = sources[0]
        elif imgs:
            pick = imgs[0]
        else:
            continue
        if pick.get_url() not in urls:
            urls.append(pick.get_url())
    return tuple(urls)


def _main_categories(cats) -> list[str]:
    found = {_CATEGORY_ALIASES.get(c, c) for c in cats or []}
    return [c for c in MAIN_CATEGORIES if c in found]


def _kudos(c) -> int:
    getter = getattr(c, "get_kudos", None)  # dropped from libappstream 1.x
    return len(getter() or []) if getter else 0


@dataclass
class _Part:
    """What one AppStream component contributes to a merged app."""
    comp: object
    flatpak: bool
    description: str


def _merge(app_id: str, parts: list[_Part]) -> tuple[AppInfo, int, str]:
    """Merge components that share an app ID. Returns (info, kudos, keywords)."""
    # Richest description wins; on a tie prefer Flathub (upstream metadata).
    ordered = sorted(parts, key=lambda p: (len(p.description), p.flatpak), reverse=True)
    comps = [p.comp for p in ordered]

    def first(getter):
        for c in comps:
            value = getter(c)
            if value:
                return value
        return None

    candidates: dict[Source, str] = {}
    for p in parts:  # pool order, so the choice is stable
        c = p.comp
        pkg = c.get_pkgname()
        if pkg and Source.APT not in candidates:
            candidates[Source.APT] = pkg
        for b in c.get_bundles() or []:
            if b.get_kind() == AS.BundleKind.FLATPAK and Source.FLATPAK not in candidates:
                name = _flatpak_name(b.get_id() or "")
                if name:
                    candidates[Source.FLATPAK] = name

    cats: list[str] = []
    for c in comps:
        cats.extend(c.get_categories() or [])

    shots = max((_screenshot_urls(c) for c in comps), key=len)

    def developer(c):
        d = c.get_developer()
        return d.get_name() if d else None

    keywords: list[str] = []
    for c in comps:
        keywords.extend(c.get_keywords() or [])

    info = AppInfo(
        app_id=app_id,
        title=first(lambda c: c.get_name()) or app_id,
        summary=first(lambda c: c.get_summary()) or "",
        description=ordered[0].description,
        developer=first(developer),
        icon=_icon_choice(comps),
        categories=tuple(_main_categories(cats)),
        screenshots=shots,
        homepage=first(lambda c: c.get_url(AS.UrlKind.HOMEPAGE)),
        license=first(lambda c: c.get_project_license()),
        candidates=candidates,
    )
    return info, max(_kudos(c) for c in comps), " ".join(keywords)


# -- in-memory index -----------------------------------------------------

@dataclass
class _Row:
    app: AppInfo
    title: str  # casefolded
    terms: str  # app ID, package names, keywords; casefolded
    summary: str
    description: str


@dataclass
class _State:
    apps: dict[str, AppInfo] = field(default_factory=dict)
    rows: list[_Row] = field(default_factory=list)
    by_category: dict[str, list[AppInfo]] = field(default_factory=dict)
    kudos: dict[str, int] = field(default_factory=dict)
    featured_ids: list[str] = field(default_factory=list)
    components: int = 0  # AppStream components seen, before filtering


def _sort_key(app: AppInfo):
    return (app.icon is None, app.title.casefold(), app.app_id)


def read_featured(path: Path) -> list[str]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    ids: list[str] = []
    for line in lines:
        line = line.split("#", 1)[0].strip()
        if line:
            app_id = normalize_id(line)
            if app_id not in ids:
                ids.append(app_id)
    return ids


def _search_tier(row: _Row, query: str, tokens: list[str]) -> Optional[int]:
    t = row.title
    if t == query:
        return 0
    if t.startswith(query):
        return 1
    if query in t:
        return 2 if re.search(r"\b" + re.escape(query), t) else 3
    if all(tok in t for tok in tokens):
        return 4
    named = f"{t} {row.terms}"
    if all(tok in named for tok in tokens):
        return 5
    if all(tok in f"{named} {row.summary}" for tok in tokens):
        return 6
    if all(tok in f"{named} {row.summary} {row.description}" for tok in tokens):
        return 7
    return None


# -- ODRS ------------------------------------------------------------------

def odrs_request() -> urllib.request.Request:
    """The only request sent: a plain GET, no user, machine or email identifiers."""
    return urllib.request.Request(ODRS_URL, headers={"User-Agent": "AppHub"})


def fetch_odrs() -> bytes:
    with urllib.request.urlopen(odrs_request(), timeout=ODRS_TIMEOUT) as resp:
        return resp.read()


def _parse_ratings(raw: bytes) -> dict:
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError("ODRS ratings are not a JSON object")
    return data


def rating_for(data: dict, app_id: str) -> Optional[Rating]:
    """Sum the histograms stored under the ID with and without ".desktop"."""
    app_id = normalize_id(app_id)
    stars = [0] * 6
    for key in (app_id, app_id + ".desktop"):
        entry = data.get(key)
        if not isinstance(entry, dict):
            continue
        for n in range(1, 6):  # star0 is "no rating", not zero stars
            value = entry.get(f"star{n}")
            if isinstance(value, int) and value > 0:
                stars[n] += value
    count = sum(stars)
    if count == 0:
        return None
    average = sum(n * stars[n] for n in range(1, 6)) / count
    return Rating(app_id=app_id, average=round(average, 2), count=count)


def _map_exc(e: Exception) -> BackendError:
    if isinstance(e, BackendError):
        return e
    if isinstance(e, GLib.Error):
        return BackendError(ErrorKind.FAILED, e.message)
    return BackendError(ErrorKind.FAILED, str(e))


# -- catalog -------------------------------------------------------------

class AppStreamCatalog:
    """Catalog over libappstream. Call load() once before the sync queries."""

    def __init__(self, featured_path: Optional[Path] = None,
                 cache_dir: Optional[Path] = None,
                 fetch: Optional[Callable[[], bytes]] = None,
                 verification: Optional[Callable[[], dict]] = None) -> None:
        self._featured_path = Path(featured_path) if featured_path else DEFAULT_FEATURED
        self._cache_dir = (Path(cache_dir) if cache_dir
                           else Path(GLib.get_user_cache_dir()) / "apphub")
        self._fetch = fetch or fetch_odrs
        self._verification = verification or _flathub_verification
        self._state = _State()
        self._ratings_lock = threading.Lock()
        self._ratings_mem: Optional[tuple[float, dict]] = None  # (cache mtime, data)

    # -- load -----------------------------------------------------------

    def load(self, done: Done[bool]) -> None:
        once = Once(done)

        def finished(state: Optional[_State], error: Optional[BackendError]) -> None:
            if error is not None:
                once(None, error)
                return
            self._state = state
            once(True, None)

        run_blocking(self._build, finished, _map_exc)

    def _build(self) -> _State:
        pool = AS.Pool()
        # OS catalog = APT DEP-11; LOAD_FLATPAK reads both the system
        # (/var/lib/flatpak) and user (~/.local/share/flatpak) appstream data.
        pool.set_flags(AS.PoolFlags.LOAD_OS_CATALOG | AS.PoolFlags.LOAD_FLATPAK)
        pool.load(None)
        comps = pool.get_components().as_array()

        groups: dict[str, list[_Part]] = {}
        for c in comps:
            if c.get_kind() not in _APP_KINDS:
                continue
            is_flatpak = any(b.get_kind() == AS.BundleKind.FLATPAK
                             for b in c.get_bundles() or [])
            if not c.get_pkgname() and not is_flatpak:
                continue  # nothing to install it from (web apps, local metainfo)
            app_id = normalize_id(c.get_id() or "")
            if not app_id:
                continue
            groups.setdefault(app_id, []).append(
                _Part(c, is_flatpak, markup_to_text(c.get_description())))

        state = _State(components=len(comps), featured_ids=read_featured(self._featured_path))
        verified = self._verification()
        for app_id, parts in groups.items():
            info, kudos, keywords = _merge(app_id, parts)
            if not info.candidates:
                continue
            if Source.FLATPAK in info.candidates and app_id in verified:
                # Only Flathub verifies developers; Flatpaks from other remotes the person
                # added themselves keep None (trusted because they chose the remote).
                v = verified[app_id]
                info = replace(info, flatpak_verified=v.verified, flatpak_verified_by=v.by)
            state.apps[app_id] = info
            state.kudos[app_id] = kudos
            terms = " ".join([app_id, *info.candidates.values(), keywords])
            state.rows.append(_Row(info, info.title.casefold(), terms.casefold(),
                                   info.summary.casefold(), info.description.casefold()))
            for cat in info.categories:
                state.by_category.setdefault(cat, []).append(info)
        for apps in state.by_category.values():
            apps.sort(key=_sort_key)
        return state

    # -- queries --------------------------------------------------------

    def categories(self) -> list[str]:
        return [c for c in MAIN_CATEGORIES if self._state.by_category.get(c)]

    def in_category(self, category: str) -> list[AppInfo]:
        category = _CATEGORY_ALIASES.get(category, category)
        return list(self._state.by_category.get(category, []))

    def get(self, app_id: str) -> Optional[AppInfo]:
        return self._state.apps.get(normalize_id(app_id))

    def search(self, query: str, limit: int = 50) -> list[AppInfo]:
        # Own index instead of AS.Pool.search(): that took 0.3-0.5 s per query
        # here, too slow for a synchronous call on the main thread.
        query = _ws(query).casefold()
        if not query or limit <= 0:
            return []
        tokens = query.split()
        hits = []
        for row in self._state.rows:
            tier = _search_tier(row, query, tokens)
            if tier is not None:
                a = row.app
                # Within a tier: has an icon, offered by more sources, has
                # screenshots (signs of a maintained app), then by title.
                hits.append((tier, (a.icon is None, -len(a.candidates), not a.screenshots,
                                    a.title.casefold(), a.app_id), a))
        hits.sort(key=lambda h: (h[0], h[1]))
        return [h[2] for h in hits[:limit]]

    def featured(self, limit: int = 12) -> list[AppInfo]:
        state = self._state
        if limit <= 0:
            return []
        picked = [state.apps[i] for i in state.featured_ids if i in state.apps][:limit]
        if len(picked) < limit:
            seen = {a.app_id for a in picked}
            pad = [a for a in state.apps.values()
                   if a.app_id not in seen and a.screenshots and a.icon]
            pad.sort(key=lambda a: (-state.kudos.get(a.app_id, 0),
                                    a.title.casefold(), a.app_id))
            picked.extend(pad[:limit - len(picked)])
        return picked

    # -- ratings --------------------------------------------------------

    @property
    def ratings_cache_path(self) -> Path:
        return self._cache_dir / "odrs-ratings.json"

    def ratings(self, app_ids: list[str], done: Done[dict[str, Rating]]) -> None:
        ids = list(dict.fromkeys(normalize_id(a) for a in app_ids))
        if not ids:
            on_main(Once(done))({}, None)
            return

        def work() -> dict[str, Rating]:
            data = self._ratings_data()
            out: dict[str, Rating] = {}
            for app_id in ids:
                rating = rating_for(data, app_id)
                if rating is not None:
                    out[app_id] = rating
            return out

        run_blocking(work, Once(done), _map_exc)

    def _ratings_data(self) -> dict:
        """Fresh cache, else download, else stale cache, else NETWORK error."""
        with self._ratings_lock:
            path = self.ratings_cache_path
            try:
                mtime: Optional[float] = path.stat().st_mtime
            except OSError:
                mtime = None
            if mtime is not None and time.time() - mtime < ODRS_TTL:
                data = self._read_cache(path, mtime)
                if data is not None:
                    return data

            try:
                raw = self._fetch()
                data = _parse_ratings(raw)
            except (OSError, ValueError) as e:  # URLError and timeouts are OSError
                stale = self._read_cache(path, mtime) if mtime is not None else None
                if stale is not None:
                    return stale
                if isinstance(e, OSError):
                    raise BackendError(ErrorKind.NETWORK,
                                       f"Could not download ratings: {e}") from e
                raise BackendError(ErrorKind.FAILED, f"Bad ratings data: {e}") from e

            self._write_cache(path, raw)
            try:
                self._ratings_mem = (path.stat().st_mtime, data)
            except OSError:
                self._ratings_mem = None
            return data

    def _read_cache(self, path: Path, mtime: float) -> Optional[dict]:
        if self._ratings_mem is not None and self._ratings_mem[0] == mtime:
            return self._ratings_mem[1]
        try:
            data = _parse_ratings(path.read_bytes())
        except (OSError, ValueError):
            return None
        self._ratings_mem = (mtime, data)
        return data

    @staticmethod
    def _write_cache(path: Path, raw: bytes) -> None:
        """Atomic replace; a cache that cannot be written is not an error."""
        tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp.write_bytes(raw)
            os.replace(tmp, path)
        except OSError:
            try:
                tmp.unlink()
            except OSError:
                pass
