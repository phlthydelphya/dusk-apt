"""apphub-cli: check for updates and install the automatic ones, without a window.

  apphub-cli check [--json]
      Print the updates grouped by tier. Exit 0 none, 100 some, 1 error.
  apphub-cli update --policy security [--snapshot] [--dry-run]
      Install only the updates in system.AUTOMATIC_TIERS (Security and Flatpak).
      Never kernels, never other tiers. Run by apphub-autoupdate.service as root.

Nothing here can prompt: PackageKit is set non-interactive and Flatpak never asks.
Every outside dependency (hub, snapshots, state file, root check, timeshift) is a
parameter of main(), so tests never touch the real system.
"""

from __future__ import annotations

import argparse
import importlib
import json
import logging
import os
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from typing import Callable, Optional, TextIO

from gi.repository import GLib

from .backend import BackendError, Package, Progress
from .hub import Hub
from .system import AUTOMATIC_TIERS, TIER_ORDER, Tier, is_kernel_package, tier_of

EXIT_OK = 0
EXIT_ERROR = 1
EXIT_UPDATES = 100  # `check` found updates (apt's own convention for "updates available")

SNAPSHOT_COMMENT = "AppHub automatic updates"
ROOT_STATE_PATH = "/var/lib/apphub/autoupdate.json"

# Same sources as app.make_sources, without the window and catalog it also loads.
_BACKENDS = [
    ("apt", "AptBackend"),
    ("flatpak", "FlatpakBackend"),
    ("snap", "SnapBackend"),
    ("appimage", "AppImageBackend"),
]

log = logging.getLogger("apphub-cli")


# -- defaults for the injectable parts ------------------------------------------------


def default_state_path(is_root: bool) -> str:
    if is_root:
        return ROOT_STATE_PATH
    base = os.environ.get("XDG_STATE_HOME") or os.path.join(os.path.expanduser("~"), ".local", "state")
    return os.path.join(base, "apphub", "autoupdate.json")


def make_hub() -> Hub:
    backends = []
    for module, cls in _BACKENDS:
        try:
            backends.append(getattr(importlib.import_module(f".{module}", __package__), cls)())
        except (ImportError, ValueError) as e:  # ValueError: gi typelib missing
            log.warning("%s unavailable: %s", cls, e)
    return Hub(backends)


def make_snapshots():
    """Timeshift from snapshots.py, or None when that module is absent."""
    try:
        from .snapshots import Timeshift
    except ImportError:
        return None
    return Timeshift()


def make_non_interactive(hub: Hub) -> None:
    """No polkit prompt can be answered in a service. Backends that can prompt
    (APT through PackageKit) offer set_interactive(); Flatpak never asks."""
    for backend in hub.backends.values():
        if hasattr(backend, "set_interactive"):
            backend.set_interactive(False)


# -- running async backend calls to the end -----------------------------------------


def run_async(start: Callable[[Callable], None]) -> tuple:
    """Call start(finish); run the GLib main loop until finish(*args). Returns args.

    No timeout of its own: apphub-autoupdate.service has TimeoutStartSec.
    """
    box: list[tuple] = []
    loop = GLib.MainLoop()

    def finish(*args) -> None:
        if not box:
            box.append(args)
            loop.quit()

    start(finish)
    if not box:  # a synchronous answer has nothing to wait for
        loop.run()
    return box[0]


# -- state file ---------------------------------------------------------------------


def write_state(path: str, result: str, installed: list[str], errors: list[str],
                now: Optional[datetime] = None) -> None:
    """Atomic: write a temp file in the same directory, fsync, rename over the old one."""
    data = {
        "last_run": (now or datetime.now(timezone.utc)).replace(microsecond=0).isoformat(),
        "result": result,
        "installed": installed,
        "errors": errors,
    }
    directory = os.path.dirname(path) or "."
    os.makedirs(directory, mode=0o755, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".autoupdate-", suffix=".tmp", dir=directory)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, 0o644)  # the unprivileged Preferences dialog reads it
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


# -- logging ---------------------------------------------------------------------------

# journald reads a "<N>" prefix on stdout lines as the syslog priority.
_PRIORITY = {"error": "<3>", "warn": "<4>", "info": "<6>"}


class Out:
    def __init__(self, stream: TextIO, journal: bool):
        self.stream, self.journal = stream, journal

    def line(self, text: str, level: str = "info") -> None:
        prefix = _PRIORITY[level] if self.journal else ""
        print(f"{prefix}{text}", file=self.stream, flush=True)


def _is_journal(stream: TextIO) -> bool:
    """systemd sets JOURNAL_STREAM to "device:inode" of the journal pipe it gave us."""
    try:
        dev, ino = os.environ["JOURNAL_STREAM"].split(":")
        st = os.fstat(stream.fileno())
        return (st.st_dev, st.st_ino) == (int(dev), int(ino))
    except (KeyError, ValueError, OSError, AttributeError):
        return False


# -- check -----------------------------------------------------------------------------


def gather_updates(hub: Hub) -> tuple[list[Package], list[BackendError]]:
    found, errors = run_async(lambda finish: hub.get_updates(finish))
    return found, errors


def group_by_tier(pkgs: list[Package]) -> dict[Tier, list[Package]]:
    groups: dict[Tier, list[Package]] = {}
    for p in sorted(pkgs, key=lambda p: p.name):
        groups.setdefault(tier_of(p), []).append(p)
    return {t: groups[t] for t in TIER_ORDER if t in groups}


def _error_line(e: BackendError) -> str:
    return f"{e.source}: {e.message}" if e.source else e.message


def cmd_check(hub_factory, out: Out, as_json: bool) -> int:
    hub = hub_factory()
    make_non_interactive(hub)
    found, errors = gather_updates(hub)
    groups = group_by_tier(found)
    if as_json:
        out.stream.write(json.dumps({
            "count": len(found),
            "updates": {t.value: [{"name": p.name, "source": str(p.source), "version": p.version,
                                   "update_version": p.update_version, "phased": p.phased} for p in pkgs]
                        for t, pkgs in groups.items()},
            "errors": [_error_line(e) for e in errors],
        }, indent=2) + "\n")
        out.stream.flush()
    else:
        for tier, pkgs in groups.items():
            out.line(f"{tier.value.capitalize()} ({len(pkgs)})")
            for p in pkgs:
                change = f"{p.version} -> {p.update_version}" if p.update_version else p.version
                note = "  (rolling out gradually, not yet for this computer)" if p.phased else ""
                out.line(f"  {p.name}  {change}  [{p.source}]{note}")
        if not found:
            out.line("No updates")
        for e in errors:
            out.line(f"{_error_line(e)}", "error")
    if errors and not found:
        return EXIT_ERROR
    return EXIT_UPDATES if found else EXIT_OK


# -- update ----------------------------------------------------------------------------


def automatic_updates(pkgs: list[Package]) -> list[Package]:
    """Only the automatic tiers. A kernel package is refused even if mislabelled;
    a phased package is skipped because apt defers it on this machine."""
    return [p for p in pkgs if tier_of(p) in AUTOMATIC_TIERS and not is_kernel_package(p.name)
            and not p.phased]


def take_snapshot(snapshots, is_root: bool, runner, out: Out) -> Optional[str]:
    """Make a restore point if Timeshift is set up. Returns an error text, or None.

    None also covers "nothing to do": Timeshift missing or not configured.
    """
    if snapshots is None:
        out.line("Timeshift is not available; no restore point", "warn")
        return None
    try:
        if not snapshots.configured():
            out.line("Timeshift is not set up; no restore point")
            return None
    except Exception as e:  # noqa: BLE001
        return f"Could not check Timeshift: {e}"
    out.line("Creating a restore point")
    if is_root:
        # Already root: no pkexec, call timeshift itself (what the system helper does).
        try:
            proc = runner(["timeshift", "--create", "--scripted", "--comments", SNAPSHOT_COMMENT,
                           "--tags", "O"], capture_output=True, text=True, timeout=3600)
        except (OSError, subprocess.SubprocessError) as e:
            return f"Restore point failed: {e}"
        if proc.returncode != 0:
            tail = ((proc.stderr or proc.stdout or "").strip().splitlines() or [""])[-1]
            return f"Restore point failed (timeshift exit {proc.returncode}) {tail}".strip()
        return None
    try:
        _snap, err = run_async(lambda finish: snapshots.create(SNAPSHOT_COMMENT, finish))
    except Exception as e:  # noqa: BLE001
        return f"Restore point failed: {e}"
    return f"Restore point failed: {err.message}" if err else None


def _progress_logger(out: Out) -> Callable[[Progress], None]:
    last = {"text": None}

    def on_progress(p: Progress) -> None:
        pct = f" {p.percent // 25 * 25}%" if p.percent is not None else ""
        text = f"{p.status}{pct}"
        if text != last["text"]:  # a line per change, not per tick
            last["text"] = text
            out.line(text)

    return on_progress


def cmd_update(hub_factory, snapshots_factory, state_path: str, out: Out, *, snapshot: bool,
               dry_run: bool, is_root: bool, runner) -> int:
    def finish(result: str, installed: list[str], errors: list[str], code: int) -> int:
        out.line(result, "error" if code else "info")
        if not dry_run:  # a rehearsal must not overwrite the record of the last real run
            try:
                write_state(state_path, result, installed, errors)
            except OSError as e:
                out.line(f"Could not write {state_path}: {e}", "error")
                return EXIT_ERROR
        return code

    hub = hub_factory()
    make_non_interactive(hub)
    found, query_errors = gather_updates(hub)
    errors = [_error_line(e) for e in query_errors]
    for line in errors:
        out.line(f"Could not check for updates: {line}", "error")
    todo = automatic_updates(found)
    skipped = len(found) - len(todo)
    if skipped:
        out.line(f"Leaving {skipped} other updates for the person to choose")
    if not todo:
        if errors:
            return finish("Could not check for updates", [], errors, EXIT_ERROR)
        return finish("No automatic updates to install", [], [], EXIT_OK)
    out.line(f"{len(todo)} automatic updates: " + ", ".join(p.name for p in todo))

    if snapshot and not dry_run:
        snap_error = take_snapshot(snapshots_factory(), is_root, runner, out)
        if snap_error:
            errors.append(snap_error)
            return finish("Restore point failed; updates skipped", [], errors, EXIT_ERROR)

    updated, update_errors = run_async(
        lambda done: hub.update(todo, _progress_logger(out), done, simulate=dry_run))
    errors += [_error_line(e) for e in update_errors]
    names = sorted(p.name for p in updated)
    for e in update_errors:
        out.line(_error_line(e), "error")
    prefix = "Would install" if dry_run else "Installed"
    result = f"{prefix} {len(names)} updates" if names else "Nothing installed"
    if errors:
        result += f", {len(update_errors)} failed" if update_errors else ""
    return finish(result, names, errors, EXIT_ERROR if errors else EXIT_OK)


# -- entry point -----------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="apphub-cli", description="AppHub updates without a window")
    sub = p.add_subparsers(dest="command", required=True)
    c = sub.add_parser("check", help="list available updates (exit 100 when there are some)")
    c.add_argument("--json", action="store_true", help="machine-readable output")
    u = sub.add_parser("update", help="install the automatic updates")
    u.add_argument("--policy", choices=["security"], default="security",
                   help="what may be installed (security: Security tier and Flatpak apps)")
    u.add_argument("--snapshot", action="store_true",
                   help="take a Timeshift restore point first, when Timeshift is set up")
    u.add_argument("--dry-run", action="store_true", help="simulate; change nothing")
    return p


def main(argv: Optional[list[str]] = None, *, hub_factory=make_hub, snapshots_factory=make_snapshots,
         state_path: Optional[str] = None, stdout: Optional[TextIO] = None,
         is_root: Optional[bool] = None, runner=subprocess.run) -> int:
    try:
        args = build_parser().parse_args(argv)
    except SystemExit as e:  # argparse: 2 for a usage error, 0 for --help
        return EXIT_ERROR if e.code else EXIT_OK
    stream = stdout or sys.stdout
    out = Out(stream, journal=_is_journal(stream))
    root = (os.geteuid() == 0) if is_root is None else is_root
    path = state_path or default_state_path(root)
    try:
        if args.command == "check":
            return cmd_check(hub_factory, out, args.json)
        return cmd_update(hub_factory, snapshots_factory, path, out, snapshot=args.snapshot,
                          dry_run=args.dry_run, is_root=root, runner=runner)
    except Exception as e:  # noqa: BLE001 - a service must end with a line, not a traceback
        out.line(f"apphub-cli failed: {e}", "error")
        return EXIT_ERROR


if __name__ == "__main__":
    sys.exit(main())
