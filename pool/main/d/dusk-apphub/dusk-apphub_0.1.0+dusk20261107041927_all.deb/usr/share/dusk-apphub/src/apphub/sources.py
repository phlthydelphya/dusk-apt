"""Software sources contract: where apps come from, per source kind. FROZEN: change
only through its owner, as backend.py.

Three managers implement SourceManager:
  APT       PPAs ("ppa:owner/name"), plus the repositories already configured
  Flatpak   remotes: a .flatpakrepo URL, or an OCI registry ("oci+https://...")
  AppImage  pools: a local folder AppHub scans, or a feed of AppImages to download

Plugins (data/source-plugins.json) are well-known sources offered as one-click
adds; the UI shows a plugin as added when SourceManager.matches() says so.

Completion and threading rules are backend.py's: every call ends in exactly one
done(result, error) on the GLib main thread.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Protocol

from .backend import Done, Source

log = logging.getLogger("apphub.sources")

PLUGINS = Path(__file__).resolve().parent.parent.parent / "data" / "source-plugins.json"


@dataclass(frozen=True)
class SourceEntry:
    """One configured source."""
    id: str  # opaque; only the manager that made it may parse it
    kind: Source
    name: str  # human name: "UbuntuHandbook Apps", "Flathub", "Games folder"
    detail: str  # what it points at: "ppa:ubuntuhandbook1/apps", a URL, a folder
    enabled: bool
    removable: bool = True  # False for sources the system depends on (ubuntu.sources)
    remove_note: Optional[str] = None  # why it cannot be removed now, shown on the button
    can_disable: bool = True
    scope: Optional[str] = None  # Flatpak: "user" or "system"
    warning: Optional[str] = None  # e.g. "No packages for Ubuntu 26.10 yet"


@dataclass(frozen=True)
class SourcePlugin:
    """A well-known source, offered as a one-click add."""
    id: str
    kind: Source
    name: str
    description: str
    spec: str  # what SourceManager.add() takes
    remote_name: Optional[str] = None  # Flatpak OCI remotes need a name; others derive one
    group: Optional[str] = None  # shown as a heading, e.g. "UbuntuHandbook"
    homepage: Optional[str] = None
    caveat: Optional[str] = None  # said before adding, e.g. "Nightly builds can break"


@dataclass(frozen=True)
class SpecCheck:
    """What adding a spec would do, found out before asking for a password."""
    ok: bool  # False: adding would fail or do nothing useful
    message: str  # one line for the person, e.g. "Has packages for Ubuntu 26.10"
    name: Optional[str] = None  # the source's own human name, when it says


class SourceManager(Protocol):
    kind: Source

    def available(self) -> bool:
        """Cheap synchronous check that this kind of source can be managed here."""

    def list(self, done: Done[list[SourceEntry]]) -> None:
        """Every configured source of this kind, enabled or not."""

    def check(self, spec: str, done: Done[SpecCheck]) -> None:
        """Validate a spec without changing anything. May use the network (read only)."""

    def add(self, spec: str, done: Done[SourceEntry], name: Optional[str] = None) -> None:
        """Add the source and refresh its metadata, so its apps show up afterwards."""

    def set_enabled(self, entry: SourceEntry, enabled: bool, done: Done[SourceEntry]) -> None: ...

    def remove(self, entry: SourceEntry, done: Done[bool]) -> None:
        """Remove (or, for APT files, disable reversibly) the source."""

    def matches(self, plugin: SourcePlugin, entry: SourceEntry) -> bool:
        """True when `entry` is the source `plugin` would add."""


def load_plugins(path: Path = PLUGINS) -> list[SourcePlugin]:
    """The curated plugin list. A missing or broken file means no plugins, not a crash."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        log.warning("no source plugins at %s: %s", path, e)
        return []
    out = []
    for entry in data.get("plugins", []):
        try:
            out.append(SourcePlugin(
                id=entry["id"], kind=Source(entry["kind"]), name=entry["name"],
                description=entry["description"], spec=entry["spec"],
                remote_name=entry.get("remote_name"), group=entry.get("group"),
                homepage=entry.get("homepage"), caveat=entry.get("caveat")))
        except (KeyError, ValueError) as e:
            log.warning("skipping source plugin %r: %s", entry.get("id"), e)
    return out
