"""Maintenance tools, after Linux Mint's Software Sources > Maintenance.

Each tool implements system.MaintenanceTool: scan() only reads and reports
Findings; fix() changes exactly the findings the person picked. Root work goes
through the two pkexec helpers (apphub-system-helper for dpkg and the apt lists,
apphub-sources-helper for .sources files); package changes go through PackageKit.

Every outside dependency (dpkg-query, apt's cache, PackageKit, the helpers, the
network, gpg) is a constructor argument, so tests run on fakes and never touch
the system. Scans run off the main thread; every callback lands on the GLib main
loop, as backend.py requires.
"""

from __future__ import annotations

import logging
import os
import re
import subprocess
import tempfile
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Callable, Iterable, Optional

from . import ppa, repos
from .backend import BackendError, Done, ErrorKind, OnProgress, Once, Progress, Source, run_blocking
from .package_story import Story, StoryReader, held_packages, size_text
from .system import (Fact, Finding, HelperResult, REMEDY_FIX, REMEDY_HOLD, REMEDY_KEEP,
                     REMEDY_OPEN, REMEDY_SWITCH, Remedy, is_kernel_package, run_system_helper)

log = logging.getLogger("apphub.maintenance")

LISTS_DIR = Path("/var/lib/apt/lists")
DPKG_QUERY = "/usr/bin/dpkg-query"
PKG_RE = re.compile(r"[a-z0-9][a-z0-9+.-]+\Z")  # same rule the system helper enforces
MAX_PURGE = 200  # the helper's cap per call
OWN_MAINTAINER = "phlthydelphya"  # locally built Dusk debs; never "foreign"

Helper = Callable[[list[str], Done[HelperResult]], None]  # system.run_system_helper
Query = Callable[[list[str]], str]  # dpkg-query arguments -> stdout


# -- small plumbing ---------------------------------------------------------------

def _map_exc(e: Exception) -> BackendError:
    if isinstance(e, BackendError):
        return e
    if isinstance(e, FileNotFoundError):
        return BackendError(ErrorKind.NOT_FOUND, str(e), Source.APT)
    return BackendError(ErrorKind.FAILED, str(e) or type(e).__name__, Source.APT)


def _guard(done: Done, fn: Callable, *args) -> None:
    """Call fn(*args[:-1], cb); an error (raised or reported) goes to done, success to args[-1]."""
    *call_args, on_ok = args

    def cb(result, error) -> None:
        if error is not None:
            done(None, error)
            return
        try:
            on_ok(result)
        except Exception as e:  # noqa: BLE001 - contract: always reach done
            done(None, _map_exc(e))

    try:
        fn(*call_args, cb)
    except Exception as e:  # noqa: BLE001
        done(None, _map_exc(e))


def _chain(items: list, step: Callable, done: Done[int]) -> None:
    """Run step(item, cb) for each item in order; done(number that succeeded).

    A failure stops nothing: later items still run. If none succeeded, the first
    error is the result.
    """
    state = {"ok": 0, "err": None}

    def next_item(i: int) -> None:
        if i >= len(items):
            if state["ok"] == 0 and state["err"] is not None:
                done(None, state["err"])
            else:
                done(state["ok"], None)
            return

        def cb(_result, error) -> None:
            if error is None:
                state["ok"] += 1
            else:
                log.warning("maintenance step failed: %s", error.message)
                state["err"] = state["err"] or error
            next_item(i + 1)

        try:
            step(items[i], cb)
        except Exception as e:  # noqa: BLE001
            cb(None, _map_exc(e))

    next_item(0)


def run_dpkg_query(args: list[str]) -> str:
    """dpkg-query with a plain environment. Exit 1 (some name unknown) is not an error."""
    env = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"}
    proc = subprocess.run([DPKG_QUERY, *args], capture_output=True, text=True, env=env,
                          timeout=60, check=False)
    if proc.returncode not in (0, 1):
        raise BackendError(ErrorKind.FAILED, f"dpkg-query failed: {proc.stderr.strip()}",
                           Source.APT)
    return proc.stdout


# -- PackageKit ---------------------------------------------------------------------

_pending: set = set()  # keep clients alive while their call runs


def _pk_run(method: str, args: tuple, progress: Optional[OnProgress], done: Done) -> None:
    """Start PackageKit `<method>_async`; done(results, None) or done(None, error)."""
    try:
        import gi
        gi.require_version("PackageKitGlib", "1.0")
        from gi.repository import GLib, PackageKitGlib as Pk
        from .apt import _progress_adapter, map_error
    except Exception as e:  # noqa: BLE001 - no PackageKit: report, never hang
        done(None, BackendError(ErrorKind.UNSUPPORTED, f"PackageKit unavailable: {e}", Source.APT))
        return
    done = Once(done)
    client = Pk.Client()
    client.set_interactive(True)
    _pending.add(client)

    def ready(c, res, *_):
        _pending.discard(c)
        try:
            results = c.generic_finish(res)
        except GLib.Error as e:
            done(None, map_error(e))
            return
        except Exception as e:  # noqa: BLE001
            done(None, BackendError(ErrorKind.FAILED, str(e), Source.APT))
            return
        code = results.get_error_code() if results is not None else None
        if code is not None:
            done(None, BackendError(ErrorKind.FAILED, code.get_details() or "PackageKit failed",
                                    Source.APT))
            return
        done(results, None)

    try:
        getattr(client, f"{method}_async")(*args, None, _progress_adapter(progress), (), ready)
    except Exception as e:  # noqa: BLE001
        _pending.discard(client)
        done(None, BackendError(ErrorKind.FAILED, str(e), Source.APT))


def _pk_flags(names: str) -> int:
    from gi.repository import PackageKitGlib as Pk
    return Pk.transaction_flag_bitfield_from_string(names)


def packagekit_refresh(force: bool, done: Done[bool]) -> None:
    """Refresh APT's package lists through PackageKit."""
    _pk_run("refresh_cache", (force,), None, lambda r, e: done(None if e else True, e))


def packagekit_install(ids: list[str], allow_downgrade: bool, progress: OnProgress,
                       done: Done[bool]) -> None:
    """Install exact package IDs (name;version;arch;data). Only trusted packages."""
    try:
        flags = _pk_flags("only-trusted;allow-downgrade" if allow_downgrade else "only-trusted")
    except Exception as e:  # noqa: BLE001
        done(None, _map_exc(e))
        return
    _pk_run("install_packages", (flags, ids), progress, lambda r, e: done(None if e else True, e))


def packagekit_remove(pkgs: list[tuple[str, str, str]], progress: OnProgress,
                      done: Done[bool]) -> None:
    """Remove installed (name, version, arch) packages; dependents are never taken along."""
    try:
        from gi.repository import PackageKitGlib as Pk
        installed = Pk.filter_bitfield_from_string("installed")
        flags = _pk_flags("only-trusted")
    except Exception as e:  # noqa: BLE001
        done(None, _map_exc(e))
        return
    want = {(n, v, a) for n, v, a in pkgs}

    def resolved(results, error) -> None:
        if error is not None:
            done(None, error)
            return
        ids = [p.get_id() for p in results.get_package_array()
               if (p.get_name(), p.get_version(), p.get_arch()) in want]
        if not ids:
            done(None, BackendError(ErrorKind.NOT_FOUND, "None of these packages is installed",
                                    Source.APT))
            return
        # allow_deps=False: refuse rather than take dependents; autoremove=False.
        _pk_run("remove_packages", (flags, ids, False, False), progress,
                lambda r, e: done(None if e else True, e))

    _pk_run("resolve", (installed, sorted({n for n, _v, _a in pkgs})), None, resolved)


class RefreshProbe:
    """Runs a PackageKit refresh and remembers what went wrong, for the scans to read.

    A refresh that fails with a plain failure is still a result: its text is what
    the MergeList and missing-key scans look for. Network, lock and auth failures
    are errors, because then nothing was learned.
    """

    def __init__(self, refresh: Callable[[bool, Done[bool]], None] = packagekit_refresh):
        self._refresh = refresh
        self.last_error: Optional[str] = None

    def run(self, done: Done[str]) -> None:
        """done(error text, "" when the refresh was clean)."""
        def refreshed(_ok, error: Optional[BackendError]) -> None:
            if error is None:
                self.last_error = None
                done("", None)
            elif error.kind == ErrorKind.FAILED:
                self.last_error = error.message
                done(error.message, None)
            else:
                done(None, error)

        try:
            self._refresh(False, refreshed)
        except Exception as e:  # noqa: BLE001
            done(None, _map_exc(e))


# -- 1. MergeList ---------------------------------------------------------------------

MERGELIST_ERRORS = ("MergeList", "Hash Sum mismatch", "Hashsum mismatch", "Problem parsing",
                    "Encountered a section with no Package")
_COMPRESSED = (".gz", ".xz", ".lz4", ".zst", ".bz2", ".lzma")
_EDGE = 4096


def _head_tail(path: Path, size: int) -> tuple[bytes, bytes]:
    with open(path, "rb") as f:
        head = f.read(_EDGE)
        if size > _EDGE:
            f.seek(-_EDGE, os.SEEK_END)
        tail = f.read(_EDGE) if size > _EDGE else head
    return head, tail


def damaged_lists(lists_dir: Path) -> list[str]:
    """Names of package-list files that are empty or visibly cut short. Cheap: sizes,
    the first and last 4 KiB, and the Release files' shape."""
    bad = []
    try:
        entries = sorted(os.scandir(lists_dir), key=lambda e: e.name)
    except OSError:
        return bad
    for e in entries:
        if e.name == "lock" or not e.is_file(follow_symlinks=False):
            continue
        try:
            size = e.stat(follow_symlinks=False).st_size
            if size == 0:
                bad.append(e.name)
                continue
            if e.name.endswith(_COMPRESSED):
                continue
            head, tail = _head_tail(Path(e.path), size)
        except OSError:
            continue
        if e.name.endswith("_InRelease"):
            if (not head.startswith(b"-----BEGIN PGP SIGNED MESSAGE-----")
                    or b"-----END PGP SIGNATURE-----" not in tail):
                bad.append(e.name)
        elif e.name.endswith("_Release"):
            if not re.search(rb"^(Suite|Codename):", head, re.M):
                bad.append(e.name)
        elif e.name.endswith(".gpg"):
            continue
        elif not tail.endswith(b"\n"):  # Packages, Sources, Translation, Contents...
            bad.append(e.name)
    return bad


class MergeListTool:
    id = "mergelist"
    title = "Fix MergeList problems"
    description = ("Damaged package lists stop APT from reading what is available. "
                   "This deletes the downloaded lists and fetches them again.")
    needs_password = True

    def __init__(self, lists_dir: Path = LISTS_DIR, probe: Optional[RefreshProbe] = None,
                 helper: Helper = run_system_helper,
                 refresh: Callable[[bool, Done[bool]], None] = packagekit_refresh):
        self._dir = Path(lists_dir)
        self._probe = probe or RefreshProbe()
        self._helper = helper
        self._refresh = refresh

    def scan(self, done: Done[list[Finding]]) -> None:
        def work() -> list[Finding]:
            bad = damaged_lists(self._dir)
            last = self._probe.last_error or ""
            hit = next((m for m in MERGELIST_ERRORS if m.lower() in last.lower()), None)
            if bad or hit:
                why = []
                if bad:
                    names = ", ".join(bad[:5]) + (f" and {len(bad) - 5} more" if len(bad) > 5 else "")
                    why.append(f"{len(bad)} damaged list files: {names}.")
                if hit:
                    why.append(f"The last refresh reported: {ppa._one_line(last, 200)}")
                why.append("Fixing deletes every downloaded list and downloads them again.")
                facts = [Fact("Damaged files", ", ".join(bad[:5]) + (f" and {len(bad) - 5} more"
                                                                    if len(bad) > 5 else ""))] if bad else []
                if hit:
                    facts.append(Fact("Last refresh said", ppa._one_line(last, 160)))
                return [Finding(
                    id="mergelist", key="mergelist", title="Package lists are damaged",
                    detail=" ".join(why),
                    summary="APT cannot read some of its downloaded package lists, so it may miss "
                            "updates or refuse to install. Downloading them again fixes it.",
                    facts=tuple(facts),
                    remedies=(Remedy(REMEDY_FIX, "Download the lists again",
                                     "Deletes the damaged lists and fetches fresh ones from your "
                                     "mirror. Takes a minute on a normal connection.", True),))]
            return [Finding(id="mergelist", key="mergelist", title="Package lists look healthy",
                            detail="No damage found. Only needed if APT reports MergeList or "
                                   "Hash Sum errors.", selected=False,
                            summary="Nothing is wrong. Re-downloading is only worth it if an "
                                    "update fails with a MergeList or Hash Sum error.",
                            remedies=(Remedy(REMEDY_FIX, "Download the lists anyway",
                                             "Deletes the lists and fetches them again. Harmless, "
                                             "just slow."),))]

        run_blocking(work, done, _map_exc)

    def fix(self, findings: list[Finding], progress: OnProgress, done: Done[int]) -> None:
        done = Once(done)
        if not any(f.id == "mergelist" for f in findings):
            done(0, None)
            return
        progress(Progress(None, "Deleting package lists"))

        def cleared(_result: HelperResult) -> None:
            progress(Progress(None, "Downloading package lists"))
            _guard(done, self._refresh, True, lambda _ok: self._refreshed(done))

        _guard(done, self._helper, ["fix-mergelist"], cleared)

    def _refreshed(self, done: Done[int]) -> None:
        self._probe.last_error = None
        done(1, None)


# -- 2. residual configuration ----------------------------------------------------------

@dataclass(frozen=True)
class Residual:
    name: str
    conffiles: tuple[str, ...]


def parse_residual(out: str) -> list[Residual]:
    """dpkg-query records "<abbrev>\\x1f<name>\\x1f<conffiles>\\x1e" -> packages in "rc"."""
    found = []
    for rec in out.split("\x1e"):
        parts = rec.lstrip("\n").split("\x1f")
        if len(parts) != 3 or not parts[0].startswith("rc"):
            continue
        name = parts[1].strip()
        if not PKG_RE.match(name):
            continue
        files = tuple(w for line in parts[2].splitlines() for w in line.split()[:1]
                      if w.startswith("/"))
        found.append(Residual(name, files))
    return sorted(found, key=lambda r: r.name)


class ResidualConfigTool:
    id = "residual-config"
    title = "Purge residual configuration"
    description = ("Removed packages can leave their system configuration behind. "
                   "Purging deletes those leftover files.")
    needs_password = True

    def __init__(self, query: Query = run_dpkg_query, helper: Helper = run_system_helper,
                 exists: Callable[[str], bool] = os.path.exists,
                 stories: Optional[Callable[[], StoryReader]] = None):
        self._query = query
        self._helper = helper
        self._exists = exists
        self._stories = stories or StoryReader

    def read(self) -> list[Residual]:
        return parse_residual(self._query(
            ["-W", "-f", "${db:Status-Abbrev}\x1f${Package}\x1f${Conffiles}\x1e"]))

    def scan(self, done: Done[list[Finding]]) -> None:
        def work() -> list[Finding]:
            out = []
            reader = self._stories()
            for r in self.read():
                left = [f for f in r.conffiles if self._exists(f)]
                story = reader.read(r.name)
                when = (f"on {story.removed_on.strftime('%-d %b %Y')}" if story.removed_on
                        else "some time ago")
                facts = [Fact("Removed", when.removeprefix("on ").capitalize()
                              if story.removed_on else "Date unknown")]
                if left:
                    shown = ", ".join(left[:4]) + (f" and {len(left) - 4} more" if len(left) > 4 else "")
                    detail = f"Leftover: {shown}"
                    facts.append(Fact("Left behind", shown))
                    summary = (f"{r.name} was removed {when}, but {len(left)} of its system "
                               f"settings files are still in /etc. They do nothing unless you "
                               f"install it again.")
                else:
                    detail = "No files left; only dpkg's record of it"
                    summary = (f"{r.name} was removed {when}. Its files are already gone; only "
                               "the package system's note about it remains.")
                out.append(Finding(
                    id=r.name, key=r.name, title=r.name, detail=detail, summary=summary,
                    facts=tuple(facts),
                    remedies=(Remedy(REMEDY_FIX, "Clean it up",
                                     "Deletes the leftover files and the record. If you install "
                                     "it again later, it starts with default settings.", True),
                              Remedy(REMEDY_KEEP, "Keep the settings",
                                     "Worth it only if you plan to reinstall it and want its old "
                                     "settings back."))))
            return out

        run_blocking(work, done, _map_exc)

    def fix(self, findings: list[Finding], progress: OnProgress, done: Done[int]) -> None:
        done = Once(done)
        names = sorted({f.id for f in findings if PKG_RE.match(f.id)})
        if not names:
            done(0, None)
            return
        progress(Progress(None, "Purging configuration"))
        batches = [names[i:i + MAX_PURGE] for i in range(0, len(names), MAX_PURGE)]
        counted = {"n": 0}

        def step(batch, cb) -> None:
            def ran(result, error) -> None:
                if error is None:
                    counted["n"] += len(batch)
                cb(result, error)
            self._helper(["purge-residual", *batch], ran)

        _chain(batches, step, lambda _ok, err: done(None, err) if err else done(counted["n"], None))


# -- 3. duplicate entries -----------------------------------------------------------------

def _norm_uri(uri: str) -> str:
    return uri.rstrip("/")


def _tuples(r: repos.Repo) -> set[tuple[str, str, str, str]]:
    return {(t, _norm_uri(u), s, c) for t in r.types for u in r.uris for s in r.suites
            for c in (r.components or ("",))}


def find_duplicates(all_repos: Iterable[repos.Repo]) -> list[tuple[repos.Repo, repos.Repo]]:
    """(duplicate, the entry it repeats). A stanza or line is a duplicate when every
    (type, uri, suite, component) it names is already named by an earlier enabled
    entry. .sources stanzas come first, so a legacy line is the one called the copy."""
    enabled = [r for r in all_repos if r.enabled]
    order = [r for r in enabled if not r.legacy] + [r for r in enabled if r.legacy]
    seen: dict[tuple, repos.Repo] = {}
    dups = []
    for r in order:
        ts = _tuples(r)
        if ts and all(t in seen for t in ts):
            dups.append((r, seen[min(ts)]))
            continue
        for t in ts:
            seen.setdefault(t, r)
    return dups


def _repo_id(r: repos.Repo) -> str:
    return f"{r.file}#{r.index}"


def remove_stanzas(text: str, indices: Iterable[int]) -> str:
    """New .sources text without the given stanzas; comments and the rest untouched."""
    file = repos._parse(text)
    paragraphs = list(file)
    for i in sorted(set(indices), reverse=True):
        if not 0 <= i < len(paragraphs):
            raise repos.ValidationError(f"no stanza {i}")
        file.remove(paragraphs[i])
    return file.dump()


class DuplicatesTool:
    id = "duplicates"
    title = "Remove duplicate entries"
    description = ("A repository listed twice makes APT warn on every update. "
                   "This removes the repeated entries from .sources files.")
    needs_password = True

    def __init__(self, list_repos: Callable[[], list[repos.Repo]] = repos.list_repos,
                 write: Callable[[str, str, Done[bool]], None] = repos.add_repo_async,
                 disable: Callable[[str, Done[bool]], None] = repos.disable_file_async,
                 sources_dir: Path = repos.SOURCES_DIR):
        self._list = list_repos
        self._write = write
        self._disable = disable
        self._dir = Path(sources_dir)

    def _fixable(self, r: repos.Repo) -> bool:
        return (not r.legacy and r.file.suffix == ".sources" and r.file.parent == self._dir
                and bool(repos.BASENAME_RE.match(r.file.name)))

    def scan(self, done: Done[list[Finding]]) -> None:
        def work() -> list[Finding]:
            out = []
            for dup, orig in find_duplicates(self._list()):
                where = f"{dup.file.name}" + ("" if dup.legacy else f", entry {dup.index + 1}")
                first = f"{orig.file.name}" + ("" if orig.legacy else f", entry {orig.index + 1}")
                what = " ".join([*dup.uris[:1], *dup.suites])
                facts = (Fact("Listed in", f"{first} and {where}"), Fact("Repository", what))
                summary = (f"{dup.name} is set up twice, so APT downloads its lists twice and "
                           "warns about it on every update. One copy is enough.")
                if self._fixable(dup):
                    out.append(Finding(
                        id=_repo_id(dup), key=_repo_id(dup), title=f"{dup.name} ({where})",
                        detail=f"{what} is already listed in {first}. Fixing removes this copy.",
                        summary=summary, facts=facts,
                        remedies=(Remedy(REMEDY_FIX, f"Remove the copy in {dup.file.name}",
                                         f"Keeps the entry in {orig.file.name}; nothing you "
                                         "installed changes.", True),
                                  Remedy(REMEDY_KEEP, "Leave both",
                                         "Harmless apart from the warning and the extra download."))))
                else:
                    out.append(Finding(
                        id=_repo_id(dup), key=_repo_id(dup), title=f"{dup.name} ({where})",
                        detail=f"{what} is already listed in {first}. {ppa.LEGACY_WARNING}.",
                        selected=False, summary=summary + f" The copy in {dup.file.name} is an "
                        "old-style list file that AppHub does not edit.", facts=facts,
                        remedies=(Remedy(REMEDY_KEEP, "Leave it",
                                         f"Delete the line from {dup.file} yourself if the "
                                         "warning bothers you."),)))
            return out

        run_blocking(work, done, _map_exc)

    def fix(self, findings: list[Finding], progress: OnProgress, done: Done[int]) -> None:
        done = Once(done)
        wanted = {f.id for f in findings}

        def prepare() -> list[tuple[str, Optional[str], int]]:
            # Re-read: only entries that are still duplicates now are removed.
            by_file: dict[Path, list[int]] = {}
            for dup, _orig in find_duplicates(self._list()):
                if _repo_id(dup) in wanted and self._fixable(dup):
                    by_file.setdefault(dup.file, []).append(dup.index)
            plans = []
            for file, indices in sorted(by_file.items()):
                new = remove_stanzas(file.read_text(encoding="utf-8"), indices)
                if list(repos._parse(new)):
                    repos.validate(new)
                    plans.append((file.name, new, len(indices)))
                else:
                    plans.append((file.name, None, len(indices)))  # nothing left: disable it
            return plans

        def prepared(plans, error) -> None:
            if error is not None:
                done(None, error)
                return
            if not plans:
                done(0, None)
                return
            progress(Progress(None, "Saving sources"))
            counted = {"n": 0}

            def step(plan, cb) -> None:
                basename, text, n = plan

                def ran(result, err) -> None:
                    if err is None:
                        counted["n"] += n
                    cb(result, err)

                if text is None:
                    self._disable(basename, ran)
                else:
                    self._write(basename, text, ran)

            _chain(plans, step,
                   lambda _ok, err: done(None, err) if err else done(counted["n"], None))

        run_blocking(prepare, prepared, _map_exc)


# -- 4. missing keys ---------------------------------------------------------------------

_GPG_ERROR = re.compile(r"GPG error:\s*(\S+)\s+(\S+)\s+(?:In)?Release:")
_KEY = re.compile(r"\b(NO_PUBKEY|EXPKEYSIG)\s+([0-9A-Fa-f]{40}|[0-9A-Fa-f]{16})\b")
_KEYID = re.compile(r"[0-9A-F]{16}")


@dataclass(frozen=True)
class KeyProblem:
    uri: str
    suite: str
    kind: str  # "NO_PUBKEY" or "EXPKEYSIG"
    key_id: str  # 16 upper-case hex digits


def parse_key_errors(text: str) -> list[KeyProblem]:
    """NO_PUBKEY / EXPKEYSIG key IDs from APT's "GPG error: URI SUITE InRelease: ..." text."""
    out: list[KeyProblem] = []
    marks = list(_GPG_ERROR.finditer(text or ""))
    for i, m in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(text)
        for k in _KEY.finditer(text, m.end(), end):
            p = KeyProblem(m.group(1), m.group(2), k.group(1), k.group(2).upper()[-16:])
            if p not in out:
                out.append(p)
    return out


def key_fingerprint(armored: str, gpg: str = "gpg") -> str:
    """The fingerprint of the one primary key in armored. ppa.verify_key's rules:
    a throwaway GNUPGHOME, exactly one key, no secret material, not revoked or expired."""
    with tempfile.TemporaryDirectory(prefix="apphub-gpg-") as home:
        os.chmod(home, 0o700)
        env = {k: v for k, v in os.environ.items() if k in ("PATH", "LANG", "LC_ALL")}
        env["GNUPGHOME"] = home
        try:
            proc = subprocess.run(
                [gpg, "--batch", "--no-tty", "--no-options", "--no-autostart",
                 "--homedir", home, "--with-colons", "--show-keys"],
                input=armored, capture_output=True, text=True, env=env, timeout=30, check=False)
        except (OSError, subprocess.SubprocessError) as e:
            raise ValueError(f"cannot run gpg to check the key: {e}") from None
    if proc.returncode != 0:
        raise ValueError("gpg could not read the key")
    records = [ln.split(":") for ln in proc.stdout.splitlines()]
    if any(r[0] in ("sec", "ssb") for r in records):
        raise ValueError("key data contains secret key material")
    pubs = [i for i, r in enumerate(records) if r[0] == "pub"]
    if len(pubs) != 1:
        raise ValueError(f"expected exactly one key, got {len(pubs)}")
    i = pubs[0]
    if records[i][1] in ("r", "e"):
        raise ValueError("the key is revoked or expired")
    nxt = records[i + 1] if i + 1 < len(records) else []
    fpr = nxt[9].upper() if len(nxt) > 9 and nxt[0] == "fpr" else ""
    if not re.fullmatch(r"[0-9A-F]{40}", fpr):
        raise ValueError("gpg did not report a fingerprint")
    return fpr


def set_signed_by(text: str, stanza_index: int, armored: str) -> str:
    """New .sources text with one stanza's Signed-By replaced by an inline key."""
    file = repos._parse(text)
    paragraphs = list(file)
    if not 0 <= stanza_index < len(paragraphs):
        raise repos.ValidationError(f"no stanza {stanza_index}")
    paragraphs[stanza_index]["Signed-By"] = repos._format_signed_by(armored)
    out = file.dump()
    repos.validate(out)
    return out


def _uri_match(a: str, b: str) -> bool:
    return _norm_uri(a.removeprefix("mirror+")) == _norm_uri(b.removeprefix("mirror+"))


class MissingKeysTool:
    id = "missing-keys"
    title = "Add missing keys"
    description = ("APT refuses updates from a repository whose signing key is missing or "
                   "expired. This fetches the key from keyserver.ubuntu.com.")
    needs_password = True

    def __init__(self, probe: Optional[RefreshProbe] = None,
                 list_repos: Callable[[], list[repos.Repo]] = repos.list_repos,
                 fetch: ppa.Fetch = ppa.urllib_fetch,
                 write: Callable[[str, str, Done[bool]], None] = repos.add_repo_async,
                 fingerprint: Callable[[str], str] = key_fingerprint,
                 sources_dir: Path = repos.SOURCES_DIR):
        self._probe = probe or RefreshProbe()
        self._list = list_repos
        self._fetch = fetch
        self._write = write
        self._fingerprint = fingerprint
        self._dir = Path(sources_dir)

    def _fixable(self, r: repos.Repo) -> bool:
        return (not r.legacy and r.file.suffix == ".sources" and r.file.parent == self._dir
                and bool(repos.BASENAME_RE.match(r.file.name)))

    def _findings(self, text: str) -> list[Finding]:
        problems = parse_key_errors(text)
        if not problems:
            return []
        all_repos = [r for r in self._list() if r.enabled]
        out = []
        for p in problems:
            owners = [r for r in all_repos
                      if p.suite in r.suites and any(_uri_match(u, p.uri) for u in r.uris)]
            what = "missing" if p.kind == "NO_PUBKEY" else "expired"
            base = (f"APT reports the {what} key {p.key_id} ({p.kind}) for {p.uri} {p.suite}. "
                    f"Fixing downloads key {p.key_id} from keyserver.ubuntu.com and checks only "
                    "that its fingerprint ends with this 16-digit key ID; nothing proves the key "
                    "belongs to the publisher. The key replaces this repository's Signed-By.")
            summary_for = lambda name: (
                f"Updates from {name} are blocked because APT cannot check them: its signing key "
                f"is {what}. Until that is fixed, apps from it get no updates.")
            facts = (Fact("Key", f"{p.key_id} ({p.kind})"), Fact("Repository", f"{p.uri} {p.suite}"))
            keep = Remedy(REMEDY_KEEP, "Leave it blocked",
                          "Nothing changes; apps from this repository stay on their current "
                          "versions. Turn the repository off in Repositories if you no longer use it.")
            if not owners:
                out.append(Finding(id=f"{p.key_id}|?", key=f"{p.key_id}|?",
                                   title=f"{p.uri} (key {p.key_id})",
                                   detail=base + " AppHub cannot find this repository's file.",
                                   selected=False, risky=True, summary=summary_for(p.uri),
                                   facts=facts, remedies=(keep,)))
            for r in owners:
                fixable = self._fixable(r)
                fetch = Remedy(REMEDY_FIX, f"Fetch key {p.key_id[-8:]}",
                               f"Downloads the key from keyserver.ubuntu.com. AppHub can only check "
                               f"that it matches the ID APT asked for ({p.key_id}), so do this only "
                               f"for a repository you trust, like {r.name}.", True)
                out.append(Finding(
                    id=f"{p.key_id}|{_repo_id(r)}", key=f"{p.key_id}|{_repo_id(r)}",
                    title=f"{r.name} (key {p.key_id})",
                    detail=base if fixable else base + f" {ppa.LEGACY_WARNING}.",
                    selected=fixable, risky=True, summary=summary_for(r.name), facts=facts,
                    remedies=(fetch, keep) if fixable else (keep,)))
        return out

    def scan(self, done: Done[list[Finding]]) -> None:
        done = Once(done)

        def probed(text: Optional[str], error: Optional[BackendError]) -> None:
            if error is not None:
                done(None, error)
                return
            if text and not parse_key_errors(text) and not any(
                    m.lower() in text.lower() for m in MERGELIST_ERRORS):
                # The refresh failed for some other reason; say so rather than "all fine".
                done(None, BackendError(ErrorKind.FAILED, text, Source.APT))
                return
            run_blocking(lambda: self._findings(text or ""), done, _map_exc)

        self._probe.run(probed)

    def _fetch_key(self, key_id: str) -> str:
        if not _KEYID.fullmatch(key_id):
            raise ValueError(f"not a key ID: {key_id!r}")
        try:
            raw = self._fetch(ppa.KEYSERVER + key_id, ppa.MAX_KEY)
        except ppa.HttpError as e:
            raise BackendError(ErrorKind.NETWORK,
                               f"The key server did not return key {key_id} (HTTP {e.status})",
                               Source.APT) from None
        except OSError as e:
            raise BackendError(ErrorKind.NETWORK, f"Cannot reach the key server: {e}",
                               Source.APT) from None
        armored = ppa.normalize_armor(raw.decode("ascii"))
        fpr = self._fingerprint(armored)
        if not fpr.endswith(key_id):
            raise ValueError(f"key server returned {fpr}, which does not end with {key_id}")
        return armored

    def fix(self, findings: list[Finding], progress: OnProgress, done: Done[int]) -> None:
        done = Once(done)
        wanted: dict[str, str] = {}  # repo id -> key id (the last one asked for wins)
        for f in findings:
            key_id, _, rid = f.id.partition("|")
            if rid and rid != "?":
                wanted[rid] = key_id

        def prepare() -> tuple[list[tuple[str, str, int]], list[str]]:
            repos_now = {_repo_id(r): r for r in self._list()}
            keys: dict[str, str] = {}
            edits: dict[Path, list[tuple[int, str]]] = {}
            errors = []
            for rid, key_id in sorted(wanted.items()):
                r = repos_now.get(rid)
                if r is None or not self._fixable(r):
                    errors.append(f"{rid}: not an editable .sources entry")
                    continue
                try:
                    if key_id not in keys:
                        keys[key_id] = self._fetch_key(key_id)
                except (ValueError, UnicodeError, BackendError) as e:
                    errors.append(f"key {key_id}: {getattr(e, 'message', None) or e}")
                    continue
                edits.setdefault(r.file, []).append((r.index, keys[key_id]))
            plans = []
            for file, changes in sorted(edits.items()):
                text = file.read_text(encoding="utf-8")
                for index, armored in changes:
                    text = set_signed_by(text, index, armored)
                plans.append((file.name, text, len(changes)))
            return plans, errors

        def prepared(result, error) -> None:
            if error is not None:
                done(None, error)
                return
            plans, errors = result
            if not plans:
                if errors:
                    done(None, BackendError(ErrorKind.FAILED, "; ".join(errors), Source.APT))
                else:
                    done(0, None)
                return
            progress(Progress(None, "Saving sources"))
            counted = {"n": 0}

            def step(plan, cb) -> None:
                basename, text, n = plan

                def ran(res, err) -> None:
                    if err is None:
                        counted["n"] += n
                    cb(res, err)

                self._write(basename, text, ran)

            _chain(plans, step,
                   lambda _ok, err: done(None, err) if err else done(counted["n"], None))

        progress(Progress(None, "Downloading keys"))
        run_blocking(prepare, prepared, _map_exc)


# -- 5 and 6. foreign packages ------------------------------------------------------------

@dataclass(frozen=True)
class Origin:
    origin: str  # Release "Origin:", e.g. "Ubuntu", "LP-PPA-owner-name"
    label: str
    archive: str  # suite, e.g. "stonking-updates"
    component: str
    site: str  # host

    @property
    def official(self) -> bool:
        # Ubuntu's archive, security pocket and its mirrors all say Origin/Label "Ubuntu".
        return self.origin == "Ubuntu" and self.label == "Ubuntu"

    @property
    def text(self) -> str:
        if self.origin.startswith("LP-PPA-"):
            parts = self.origin[len("LP-PPA-"):]
            return f"ppa:{parts}" if parts else self.origin
        return self.origin or self.site or "unknown origin"

    @property
    def packagekit_data(self) -> str:
        """PackageKit's apt data field for a version from this origin: origin-suite-component."""
        return f"{self.origin}-{self.archive}-{self.component}".lower().replace(" ", "_")


@dataclass(frozen=True)
class PkgVersion:
    version: str
    origins: tuple[Origin, ...]  # repositories offering it now; dpkg's status file excluded


@dataclass(frozen=True)
class InstalledPkg:
    name: str
    arch: str
    installed: str  # installed version
    maintainer: str
    versions: tuple[PkgVersion, ...]  # every version APT knows, installed one included
    essential: bool = False  # Essential, or priority required/important

    def version(self, ver: str) -> Optional[PkgVersion]:
        return next((v for v in self.versions if v.version == ver), None)


def _version_compare(a: str, b: str) -> int:
    try:
        import apt_pkg
        apt_pkg.init_system()
        return apt_pkg.version_compare(a, b)
    except Exception:  # noqa: BLE001 - python3-apt missing: plain comparison
        return (a > b) - (a < b)


# The owner's own apps, recognised by the app IDs their launchers use: packages that
# install such a launcher are never "foreign", whoever is named as Maintainer.
OWN_APP_PREFIXES = ("io.github.phlthydelphya.", "io.github.themeunifier.")
APPLICATIONS_DIR = "/usr/share/applications"
_own_cache: Optional[frozenset] = None


def own_app_packages(apps_dir: str = APPLICATIONS_DIR, runner=subprocess.run) -> frozenset:
    """Package names that ship a launcher with one of OWN_APP_PREFIXES (dpkg -S, read only)."""
    try:
        paths = [os.path.join(apps_dir, f) for f in sorted(os.listdir(apps_dir))
                 if f.startswith(OWN_APP_PREFIXES) and f.endswith(".desktop")]
    except OSError:
        return frozenset()
    if not paths:
        return frozenset()
    try:
        out = runner(["dpkg-query", "-S", *paths], capture_output=True, text=True,
                     timeout=30, check=False).stdout
    except (OSError, subprocess.SubprocessError):
        return frozenset()
    names = set()
    for line in out.splitlines():
        owners, _, _path = line.partition(": ")
        names.update(o.strip().split(":")[0] for o in owners.split(",") if o.strip())
    return frozenset(names)


def _own(p: InstalledPkg) -> bool:
    global _own_cache
    if p.name.startswith("dusk-") or OWN_MAINTAINER in p.maintainer.lower():
        return True
    if _own_cache is None:
        _own_cache = own_app_packages()
    return p.name in _own_cache


def foreign_downgrades(pkgs: Iterable[InstalledPkg],
                       compare: Callable[[str, str], int] = _version_compare
                       ) -> list[tuple[InstalledPkg, PkgVersion, PkgVersion]]:
    """(package, installed version, best official version) for packages whose installed
    version no official origin offers while some official version exists."""
    out = []
    for p in pkgs:
        if _own(p):
            continue
        cur = p.version(p.installed) or PkgVersion(p.installed, ())
        if any(o.official for o in cur.origins):
            continue
        official = [v for v in p.versions
                    if v.version != p.installed and any(o.official for o in v.origins)]
        if not official:
            continue
        best = official[0]
        for v in official[1:]:
            if compare(v.version, best.version) > 0:
                best = v
        out.append((p, cur, best))
    return sorted(out, key=lambda t: t[0].name)


def foreign_orphans(pkgs: Iterable[InstalledPkg]) -> list[InstalledPkg]:
    """Installed packages that no enabled repository offers in any version."""
    out = []
    for p in pkgs:
        if _own(p) or p.essential or is_kernel_package(p.name):
            continue
        if any(v.origins for v in p.versions):
            continue
        out.append(p)
    return sorted(out, key=lambda p: p.name)


def read_apt_packages() -> list[InstalledPkg]:
    """Installed packages and where APT can get each version, from apt's own cache
    (python3-apt). Read only: as a normal user apt builds the cache in memory."""
    try:
        import apt_pkg
    except ImportError:
        raise BackendError(ErrorKind.UNSUPPORTED,
                           "python3-apt is not installed, so APT's policy cannot be read",
                           Source.APT) from None
    apt_pkg.init_config()
    apt_pkg.init_system()
    cache = apt_pkg.Cache(None)
    records = apt_pkg.PackageRecords(cache)
    out = []
    for pkg in cache.packages:
        cur = pkg.current_ver
        if cur is None:
            continue
        versions = []
        for v in pkg.version_list:
            origins = tuple(
                Origin(pf.origin or "", pf.label or "", pf.archive or "", pf.component or "",
                       pf.site or "")
                for pf, _i in v.file_list
                if not pf.not_source and pf.archive != "now"
                and pf.index_type != "Debian dpkg status file")
            versions.append(PkgVersion(v.ver_str, origins))
        maintainer = ""
        if cur.file_list:
            try:
                records.lookup(cur.file_list[0])
                maintainer = records.maintainer or ""
            except Exception:  # noqa: BLE001 - a missing record only loses the name
                pass
        essential = bool(getattr(pkg, "essential", False)) or cur.priority in (1, 2)
        out.append(InstalledPkg(pkg.name, pkg.architecture, cur.ver_str, maintainer,
                                tuple(versions), essential))
    return out


def _pkg_id(name: str, arch: str, ver: str) -> str:
    return f"{name}|{arch}|{ver}"


def _split_id(fid: str) -> Optional[tuple[str, str, str]]:
    parts = fid.split("|")
    if len(parts) != 3 or not PKG_RE.match(parts[0]) or not parts[1] or not parts[2]:
        return None
    return parts[0], parts[1], parts[2]


@dataclass(frozen=True)
class Alternative:
    """Another source for the same app, e.g. its Flatpak."""
    source: str  # "Flatpak", "Snap"
    name: str  # what Hub.lookup takes
    title: str
    verified: Optional[bool] = None  # Flathub verification, when known


def foreign_finding(p: "InstalledPkg", story: Story, alts: list[Alternative]) -> Finding:
    """Turn what is known about a package no repository offers into a plain explanation and
    a clear way forward, best option first."""
    name = p.name
    app = story.app_names[0] if story.app_names else name
    facts = [Fact("What it is", story.summary or "No description")]
    facts.append(Fact("Installed", story.installed_text()))
    if story.size_kb:
        facts.append(Fact("Size", size_text(story.size_kb)))
    if story.maker:
        facts.append(Fact("Made by", story.maker))
    if story.homepage:
        facts.append(Fact("Website", story.homepage))
    if story.needed_by:
        facts.append(Fact("Needed by", ", ".join(story.needed_by[:5])))
    if story.extensions:
        facts.append(Fact("Used by", ", ".join(e.split("@")[0] for e in story.extensions)
                          + " (GNOME Shell extension, turned on)"))
    remove = Remedy(REMEDY_FIX, "Remove it",
                    f"Uninstalls {name}. Your own files and settings in your home folder stay.",
                    destructive=True)

    def keep(recommended: bool, why: str) -> Remedy:
        return Remedy(REMEDY_KEEP, "Keep it", why + " AppHub stops listing it here.", recommended)

    freeze = Remedy(REMEDY_HOLD + name, "Freeze this version",
                    f"Holds {name} at {p.installed} (apt-mark hold) so no update or clean-up "
                    "changes or removes it by accident. Undo any time with apt-mark unhold.")

    if story.how == "dusk":
        summary = ("Dusk's setup installed this and updates it itself, so it is meant to be "
                   "here. Nothing to do.")
        remedies = (keep(True, "Leave it to Dusk's setup."),)
    elif story.extensions:
        ext = story.extensions[0].split("@")[0]
        summary = (f"The {ext} extension you have turned on needs this, so it belongs here. "
                   "Freezing it keeps it exactly as it is, the way a system component should be.")
        remedies = [replace(freeze, recommended=True),
                    keep(False, f"The {ext} extension keeps working.")]
        if story.homepage:
            remedies.append(Remedy(REMEDY_OPEN + story.homepage, "Check for a newer version",
                                   f"Opens {story.homepage}."))
        remedies.append(remove)
        remedies = tuple(remedies)
    elif story.needed_by:
        others = ", ".join(story.needed_by[:3])
        summary = (f"{others} {'needs' if len(story.needed_by) == 1 else 'need'} it, so it has to "
                   "stay while they are installed. It does not update itself.")
        remedies = (keep(True, f"{others} keep working."), freeze, remove)
    elif alts:
        best = alts[0]
        trust = "" if best.verified is not False else (
            " Its Flathub version is packaged by a third party, not the developer.")
        summary = (f"No repository updates {app}, so it misses fixes. {best.source} has "
                   f"{best.title}, which updates itself.{trust}")
        remedies = (Remedy(REMEDY_SWITCH + f"{best.source}:{best.name}",
                           f"Switch to the {best.source} version",
                           f"Installs {best.title} from {best.source} first; only when that "
                           f"works is this copy removed. Settings in your home folder stay.", True),
                    keep(False, "It keeps working as it is."), remove)
    elif story.homepage:
        host = re.sub(r"^https?://(www\.)?", "", story.homepage).split("/")[0]
        summary = (f"No repository updates {app}. It keeps working, but new versions and "
                   f"security fixes only come from {host}.")
        remedies = (Remedy(REMEDY_OPEN + story.homepage, f"Get updates from {host}",
                           f"Opens {story.homepage}. Install the new .deb there the same way you "
                           "installed this one.", True),
                    keep(False, "It keeps working as it is."), remove)
    else:
        frees = f" frees {size_text(story.size_kb)}" if story.size_kb else " tidies it away"
        summary = (f"No repository updates {app}. It keeps working, but fixes will not arrive "
                   f"automatically. If you no longer use it, removing it{frees}.")
        remedies = (keep(True, "It keeps working as it is."), remove)
    return Finding(id=_pkg_id(p.name, p.arch, p.installed), key=name,
                   title=f"{app} ({name} {p.installed})" if app != name else f"{name} {p.installed}",
                   detail=summary, selected=False, risky=True, summary=summary,
                   facts=tuple(facts), remedies=remedies)


class ForeignDowngradeTool:
    id = "foreign-downgrade"
    title = "Downgrade foreign packages"
    description = ("Packages installed from a PPA or another repository that Ubuntu also "
                   "ships. This goes back to Ubuntu's version.")
    needs_password = True

    def __init__(self, read: Callable[[], list[InstalledPkg]] = read_apt_packages,
                 install: Callable[[list[str], bool, OnProgress, Done[bool]], None]
                 = packagekit_install):
        self._read = read
        self._install = install

    def scan(self, done: Done[list[Finding]]) -> None:
        def work() -> list[Finding]:
            out = []
            held = held_packages()
            for p, cur, best in foreign_downgrades(self._read()):
                if p.name in held:
                    continue  # frozen at this version on purpose
                came = ", ".join(sorted({o.text for o in cur.origins})) or "a local file"
                still = bool(cur.origins)
                summary = (f"You have {p.installed} from {came}; Ubuntu ships {best.version}. "
                           + (f"It still gets updates from {came}, so nothing is wrong unless "
                              "it misbehaves." if still else
                              "Nothing offers updates for your version any more, so going back to "
                              "Ubuntu's keeps it updated."))
                out.append(Finding(
                    id=_pkg_id(p.name, p.arch, best.version), key=p.name,
                    title=f"{p.name} {p.installed} (from {came})",
                    detail=f"Ubuntu has {best.version}. Fixing installs Ubuntu's version, which "
                           "may be older and lose features or fixes the other version had.",
                    risky=True, summary=summary,
                    facts=(Fact("Installed", f"{p.installed} from {came}"),
                           Fact("Ubuntu's version", best.version)),
                    remedies=(Remedy(REMEDY_KEEP, f"Stay on {came}'s version",
                                     "Keeps the newer build and its updates.", still),
                              Remedy(REMEDY_FIX, "Go back to Ubuntu's version",
                                     f"Installs {best.version} from Ubuntu. Useful if the newer "
                                     "build causes problems; features added since may go.",
                                     not still, destructive=True))))
            return out

        run_blocking(work, done, _map_exc)

    def fix(self, findings: list[Finding], progress: OnProgress, done: Done[int]) -> None:
        done = Once(done)
        wanted = {s for s in (_split_id(f.id) for f in findings) if s}
        if not wanted:
            done(0, None)
            return

        def prepare() -> list[str]:
            # Re-read: install only versions an official origin still offers.
            ids = []
            for p, _cur, best in foreign_downgrades(self._read()):
                if (p.name, p.arch, best.version) in wanted:
                    origin = next(o for o in best.origins if o.official)
                    ids.append(f"{p.name};{best.version};{p.arch};{origin.packagekit_data}")
            return ids

        def prepared(ids, error) -> None:
            if error is not None:
                done(None, error)
                return
            if not ids:
                done(0, None)
                return
            self._install(ids, True, progress,
                          lambda _ok, err: done(None, err) if err else done(len(ids), None))

        run_blocking(prepare, prepared, _map_exc)


class ForeignRemoveTool:
    id = "foreign-remove"
    title = "Remove foreign packages"
    description = ("Installed packages no repository offers, so nothing updates them. Each one "
                   "says where it came from, whether something needs it, and the best way to "
                   "keep it current.")
    needs_password = True

    def __init__(self, read: Callable[[], list[InstalledPkg]] = read_apt_packages,
                 remove: Callable[[list[tuple[str, str, str]], OnProgress, Done[bool]], None]
                 = packagekit_remove,
                 stories: Optional[Callable[[], StoryReader]] = None):
        self._read = read
        self._remove = remove
        self._stories = stories or StoryReader
        # Set by the window: (story) -> [Alternative], other sources of the same app.
        self.alternatives: Optional[Callable[[Story], list["Alternative"]]] = None
        self.frozen: list[str] = []  # held or pinned packages the last scan left out

    def scan(self, done: Done[list[Finding]]) -> None:
        def work() -> list[Finding]:
            reader = self._stories()
            out = []
            self.frozen = []
            for p in foreign_orphans(self._read()):
                story = reader.read(p.name)
                if story.frozen:
                    # Held or pinned on purpose (e.g. a component Dusk ships as part of the
                    # system): not a problem to report.
                    self.frozen.append(f"{p.name} {story.pinned or p.installed}")
                    continue
                alts = []
                if self.alternatives is not None:
                    try:
                        alts = self.alternatives(story)
                    except Exception:  # noqa: BLE001 - no catalog: just no suggestion
                        alts = []
                out.append(foreign_finding(p, story, alts))
            return out

        run_blocking(work, done, _map_exc)

    def fix(self, findings: list[Finding], progress: OnProgress, done: Done[int]) -> None:
        done = Once(done)
        wanted = {s for s in (_split_id(f.id) for f in findings) if s}
        if not wanted:
            done(0, None)
            return

        def prepare() -> list[tuple[str, str, str]]:
            return [(p.name, p.installed, p.arch) for p in foreign_orphans(self._read())
                    if (p.name, p.arch, p.installed) in wanted]

        def prepared(pkgs, error) -> None:
            if error is not None:
                done(None, error)
                return
            if not pkgs:
                done(0, None)
                return
            self._remove(pkgs, progress,
                         lambda _ok, err: done(None, err) if err else done(len(pkgs), None))

        run_blocking(prepare, prepared, _map_exc)


# -- factory ----------------------------------------------------------------------------

def default_tools() -> list:
    """The six tools, in the order the page shows them. The refresh probe is shared, so
    the missing-key scan's refresh also informs the MergeList scan."""
    probe = RefreshProbe()
    return [
        MergeListTool(probe=probe),
        ResidualConfigTool(),
        DuplicatesTool(),
        MissingKeysTool(probe=probe),
        ForeignDowngradeTool(),
        ForeignRemoveTool(),
    ]
