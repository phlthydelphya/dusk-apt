"""What the system knows about an installed package, read only: when and how it was
installed, what it is for, who makes it, what needs it, and the apps it provides.

Used by the maintenance tools to explain a finding in plain terms and to suggest a
real way forward, instead of a bare "no repository offers it".
"""

from __future__ import annotations

import glob
import gzip
import os
import re
import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable, Optional

Runner = Callable[..., subprocess.CompletedProcess]

DUSK_CACHE = "/var/cache/dusk/"  # where Dusk's own installer keeps the debs it installs


@dataclass(frozen=True)
class Story:
    name: str
    summary: str = ""  # the package's own one-line description
    maker: str = ""  # Maintainer, without the email
    homepage: str = ""
    size_kb: Optional[int] = None
    installed_on: Optional[datetime] = None
    how: str = "unknown"  # file | dusk | installer | apt | unknown
    file: str = ""  # the .deb's file name, when installed from one
    needed_by: tuple[str, ...] = ()  # installed packages that depend on it
    extensions: tuple[str, ...] = ()  # enabled GNOME Shell extensions that use it
    app_ids: tuple[str, ...] = ()  # desktop file IDs it ships, without ".desktop"
    app_names: tuple[str, ...] = ()  # their Name=
    removed_on: Optional[datetime] = None  # for packages already removed (rc)
    config_files: tuple[str, ...] = ()  # conffiles left behind (rc)
    held: bool = False  # apt-mark hold: frozen at this version on purpose
    pinned: str = ""  # the version an apt preferences pin locks it to, if any

    @property
    def frozen(self) -> bool:
        return self.held or bool(self.pinned)

    def installed_text(self) -> str:
        when = self.installed_on.strftime("%-d %b %Y") if self.installed_on else "Unknown date"
        how = {
            "file": f"from {self.file}, a file you downloaded" if self.file else "from a downloaded file",
            "dusk": "by Dusk's setup",
            "installer": "with a package installer app (opening a .deb file)",
            "apt": "from a repository that is no longer set up",
        }.get(self.how, "")
        return f"{when}, {how}" if how else when


def _run(runner: Runner, args: list[str]) -> str:
    try:
        return runner(args, capture_output=True, text=True, timeout=30, check=False).stdout
    except (OSError, subprocess.SubprocessError):
        return ""


def _read_logs(pattern: str) -> list[str]:
    """Lines of every rotated copy, oldest first."""
    paths = sorted(glob.glob(pattern), key=lambda p: (_rot(p)), reverse=True)
    lines: list[str] = []
    for p in paths:
        try:
            opener = gzip.open if p.endswith(".gz") else open
            with opener(p, "rt", errors="replace") as f:
                lines.extend(f.read().splitlines())
        except OSError:
            continue  # not readable for this user (adm group): fewer facts, not an error
    return lines


def _rot(path: str) -> int:
    m = re.search(r"\.(\d+)(?:\.gz)?$", path)
    return int(m.group(1)) if m else 0


def _strip_email(who: str) -> str:
    return re.sub(r"\s*<[^>]*>", "", who).strip()


class StoryReader:
    """Reads stories, sharing the log files between packages of one scan."""

    def __init__(self, runner: Runner = subprocess.run,
                 dpkg_logs: str = "/var/log/dpkg.log*",
                 apt_history: str = "/var/log/apt/history.log*",
                 extensions: Optional[Callable[[], list[str]]] = None):
        self._runner = runner
        self._dpkg_logs = dpkg_logs
        self._apt_history = apt_history
        self._extensions_fn = extensions or enabled_extensions
        self._dpkg_lines: Optional[list[str]] = None
        self._history: Optional[list[dict]] = None
        self._extensions: Optional[list[str]] = None

    # -- shared reads -------------------------------------------------------

    def _dpkg(self) -> list[str]:
        if self._dpkg_lines is None:
            self._dpkg_lines = _read_logs(self._dpkg_logs)
        return self._dpkg_lines

    def _hist(self) -> list[dict]:
        if self._history is None:
            blocks, cur = [], {}
            for line in _read_logs(self._apt_history):
                if not line.strip():
                    if cur:
                        blocks.append(cur)
                    cur = {}
                    continue
                key, _, value = line.partition(": ")
                cur[key] = value
            if cur:
                blocks.append(cur)
            self._history = blocks
        return self._history

    def _exts(self) -> list[str]:
        if self._extensions is None:
            try:
                self._extensions = self._extensions_fn()
            except Exception:  # noqa: BLE001 - no GNOME settings: no extension facts
                self._extensions = []
        return self._extensions

    # -- one package --------------------------------------------------------

    def read(self, name: str) -> Story:
        fields = _run(self._runner, ["dpkg-query", "-W", "-f",
                                     "${Installed-Size}\t${Homepage}\t${binary:Summary}\t${Maintainer}",
                                     name]).split("\t")
        size = int(fields[0]) if fields and fields[0].strip().isdigit() else None
        homepage = fields[1].strip() if len(fields) > 1 else ""
        summary = fields[2].strip() if len(fields) > 2 else ""
        maker = _strip_email(fields[3]) if len(fields) > 3 else ""

        installed_on = removed_on = None
        for line in self._dpkg():
            parts = line.split()
            if len(parts) >= 4 and parts[3].split(":")[0] == name:
                when = _parse_time(parts[0], parts[1])
                if parts[2] in ("install", "upgrade"):
                    installed_on = when
                elif parts[2] == "remove":
                    removed_on = when

        how, deb = "unknown", ""
        for block in reversed(self._hist()):
            touched = " ".join(block.get(k, "") for k in ("Install", "Upgrade", "Reinstall"))
            if not re.search(rf"(^|[ ,]){re.escape(name)}:", touched):
                continue
            cmd = block.get("Commandline", "")
            debs = re.findall(r"(\S+\.deb)\b", cmd)
            if any(DUSK_CACHE in d for d in debs):
                how = "dusk"
            elif debs:
                how, deb = "file", os.path.basename(next((d for d in debs if name.split("-")[0] in
                                                          os.path.basename(d)), debs[0]))
            elif "install-files" in cmd:
                how = "installer"
            elif cmd:
                how = "apt"
            break

        needed = []
        out = _run(self._runner, ["apt-cache", "rdepends", "--installed", "--no-recommends",
                                  "--no-suggests", "--no-enhances", name])
        started = False
        for line in out.splitlines():
            if line.strip() == "Reverse Depends:":
                started = True
                continue
            if started:
                dep = line.strip().lstrip("|").strip()
                if dep and dep != name and dep not in needed:
                    needed.append(dep)

        stem = name.lower()
        for suffix in ("-daemon", "-client", "-console", "-desktop-app"):
            stem = stem[: -len(suffix)] if stem.endswith(suffix) else stem
        exts = tuple(u for u in self._exts() if stem and stem in u.split("@")[0].lower())

        app_ids, app_names = [], []
        for path in _run(self._runner, ["dpkg-query", "-L", name]).splitlines():
            if path.startswith("/usr/share/applications/") and path.endswith(".desktop"):
                app_ids.append(os.path.basename(path)[: -len(".desktop")])
                n = _desktop_name(path)
                if n:
                    app_names.append(n)

        held = _run(self._runner, ["dpkg-query", "-W", "-f", "${db:Status-Want}", name]).strip() == "hold"
        pinned = pin_of(_run(self._runner, ["apt-cache", "policy", name]))

        conf = tuple(_run(self._runner, ["dpkg-query", "-W", "-f", "${Conffiles}", name]).split())
        conf = tuple(c for c in conf if c.startswith("/"))

        return Story(name=name, summary=summary, maker=maker, homepage=homepage, size_kb=size,
                     installed_on=installed_on, how=how, file=deb, needed_by=tuple(needed),
                     extensions=exts, app_ids=tuple(app_ids), app_names=tuple(app_names),
                     removed_on=removed_on, config_files=conf, held=held, pinned=pinned)


def _parse_time(day: str, clock: str) -> Optional[datetime]:
    try:
        return datetime.strptime(f"{day} {clock}", "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None


def _desktop_name(path: str) -> str:
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            for line in f:
                if line.startswith("Name="):
                    return line[5:].strip()
    except OSError:
        pass
    return ""


def enabled_extensions() -> list[str]:
    from gi.repository import Gio
    return list(Gio.Settings.new("org.gnome.shell").get_strv("enabled-extensions"))


def size_text(kb: Optional[int]) -> str:
    if not kb:
        return "Unknown"
    if kb >= 1024 * 1024:
        return f"{kb / 1024 / 1024:.1f} GB"
    if kb >= 1024:
        return f"{kb / 1024:.0f} MB"
    return f"{kb} kB"


def pin_of(policy_out: str) -> str:
    """The version `apt-cache policy` says a preferences pin locks the package to, or ""."""
    m = re.search(r"^\s*Package pin:\s*(\S+)", policy_out, re.M)
    return m.group(1) if m else ""


def held_packages(runner: Runner = subprocess.run) -> frozenset:
    """Names of every package marked hold (apt-mark hold), from one dpkg-query call."""
    out = _run(runner, ["dpkg-query", "-W", "-f", "${Package}\t${db:Status-Want}\n"])
    return frozenset(line.split("\t")[0] for line in out.splitlines()
                     if line.endswith("\thold"))


PHASING_HEADER = "The following upgrades have been deferred due to phasing:"


def parse_phased(text: str) -> list[str]:
    """Package names under apt-get's "deferred due to phasing" heading."""
    names, inside = [], False
    for line in text.splitlines():
        if line.startswith(PHASING_HEADER):
            inside = True
            continue
        if inside:
            if line.startswith(" ") and line.strip():
                names.extend(line.split())
            else:
                inside = False
    return names


def phased_packages(runner: Runner = subprocess.run) -> frozenset:
    """Names apt defers on this machine because the distribution is rolling the
    new version out gradually (Ubuntu phased updates). PackageKit still lists
    them as updates but refuses to install them. Empty on any failure: this
    check must never block updates."""
    argv = ["apt-get", "-s", "-o", "Debug::NoLocking=1", "upgrade"]
    try:
        proc = runner(argv, capture_output=True, text=True, timeout=60, check=False,
                      env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C.UTF-8"})
    except (OSError, subprocess.SubprocessError):
        return frozenset()
    if proc.returncode != 0:
        return frozenset()
    return frozenset(parse_phased(proc.stdout or ""))
