"""AppImage backend: "best effort" management of AppImages kept in a few fixed folders.

Strategy
--------
AppImages are not installed by a package manager, so this backend mostly *finds*
them. It scans the configured pool folders (DEFAULT_DIRS until the person changes
them, see pools.py), one level deep, and recognises an AppImage by its magic
bytes, never by its extension. It can also search AppImageHub-format feeds and
download an AppImage from one into the first pool folder (see "feeds" below).

SECURITY: an AppImage is never executed, not even with --appimage-extract,
because that runs untrusted code. Metadata is read straight out of the embedded
squashfs with /usr/bin/unsquashfs (listing and `-cat`, which streams one file to
stdout and writes nothing to disk). The squashfs payload starts right after the
ELF section header table. Only the top-level *.desktop file and one icon are
read; they are copied into a private cache under ~/.cache/apphub/appimage/.
Symlinks inside the squashfs are never followed except for the single
.DirIcon -> sibling-file hop, which is resolved by this module, not by the OS.
If anything about that fails, the scan falls back to metadata from the file name.

Feeds: a feed is a feed.json catalog (https only, cached 24 hours). Installing
from one resolves a download (GitHub latest release asset, or a direct
.AppImage link), saves it to a temp name in the target folder, checks the ELF
and AppImage magic BEFORE making it executable, then renames it into place. The
downloaded file is never executed.
"""

from __future__ import annotations

import contextlib
import dataclasses
import hashlib
import http.client
import json
import logging
import os
import re
import shutil
import stat
import struct
import subprocess
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable, Optional

from gi.repository import Gio, GLib

from .backend import (
    BackendError,
    Done,
    ErrorKind,
    OnProgress,
    Once,
    Package,
    Progress,
    Source,
    on_main,
    run_blocking,
)

if TYPE_CHECKING:
    from .pools import FeedPool, PoolConfig

log = logging.getLogger("apphub.appimage")

# The defined management strategy: AppImages live in one of these folders.
# "~/Applications" is where the install message tells people to put them;
# "~/AppImages" is a common alternative and "~/.local/bin" is where many
# launchers and tools drop a single binary. Missing folders are fine. Nothing
# below the first level is scanned and symlinks are ignored.
DEFAULT_DIRS = ("~/Applications", "~/AppImages", "~/.local/bin")

# Never scan anything under these (rclone mounts: crawling them can freeze the machine).
_FORBIDDEN_ROOTS = ("~/GoogleDrive", "~/OneDrive")


def is_forbidden_dir(directory: str) -> bool:
    """True for a path under a forbidden root. The text check comes first and touches
    no file system, so a mount is never even stat-ed; symlinks are resolved after."""
    plain = os.path.abspath(os.path.expanduser(directory))
    roots = [os.path.abspath(os.path.expanduser(r)) for r in _FORBIDDEN_ROOTS]
    if any(plain == r or plain.startswith(r + os.sep) for r in roots):
        return True
    real = os.path.realpath(plain)
    for root in roots:
        root = os.path.realpath(root)
        if real == root or real.startswith(root + os.sep):
            return True
    return False

UNSQUASHFS = "/usr/bin/unsquashfs"
_EXTRACT_TIMEOUT = 20  # seconds per unsquashfs call
_MAX_DESKTOP_BYTES = 256 * 1024
_MAX_ICON_BYTES = 4 * 1024 * 1024
_HEADER_BYTES = 64
_SQUASHFS_MAGIC = b"hsqs"
_ICON_EXTS = ("", ".png", ".svg", ".xpm")

_LISTING_LINE = re.compile(
    r"^(?P<kind>[-dlcbps])\S+\s+\S+\s+(?P<size>\d+)\s+"
    r"\d{4}-\d{2}-\d{2} \d{2}:\d{2} /(?P<rest>.*)$")
_FILENAME_VERSION = re.compile(r"(?:^|[-_ vV])(\d+(?:\.\d+)+)")
_SUFFIX = re.compile(r"\.appimage$", re.IGNORECASE)
_SAFE_NAME = re.compile(r"[^A-Za-z0-9._+-]")

# Downloads in progress live in the pool folder under this name; scans skip them.
_PART_PREFIX, _PART_SUFFIX = ".apphub-", ".part"


# -- detection --------------------------------------------------------------

def _read_header(path: str) -> Optional[bytes]:
    """First bytes of a regular, non-symlink file; None for anything else."""
    try:
        # O_NOFOLLOW: never follow a symlink. O_NONBLOCK: a FIFO must not hang the scan.
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    except OSError:
        return None
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            return None
        return os.read(fd, _HEADER_BYTES)
    except OSError:
        return None
    finally:
        os.close(fd)


def header_type(header: bytes) -> Optional[int]:
    """AppImage type (1 or 2) from the first bytes of a file, else None."""
    if len(header) < 11 or header[:4] != b"\x7fELF":
        return None
    marker = header[8:11]
    if marker == b"AI\x02":
        return 2
    if marker == b"AI\x01":
        return 1
    return None


def appimage_type(path: str) -> Optional[int]:
    header = _read_header(path)
    return None if header is None else header_type(header)


def payload_offset(header: bytes) -> Optional[int]:
    """Where the squashfs starts: the end of the ELF section header table.

    e_shoff + e_shentsize * e_shnum, for ELF64 and ELF32 in either byte order.
    """
    if len(header) < 52 or header[:4] != b"\x7fELF":
        return None
    cls, data = header[4], header[5]
    order = {1: "<", 2: ">"}.get(data)
    if order is None:
        return None
    if cls == 2 and len(header) >= 64:
        (shoff,) = struct.unpack_from(order + "Q", header, 0x28)
        shentsize, shnum = struct.unpack_from(order + "HH", header, 0x3A)
    elif cls == 1:
        (shoff,) = struct.unpack_from(order + "I", header, 0x20)
        shentsize, shnum = struct.unpack_from(order + "HH", header, 0x2E)
    else:
        return None
    if shoff == 0 or shentsize == 0 or shnum == 0:
        return None
    return shoff + shentsize * shnum


def _squashfs_offset(path: str, header: bytes) -> Optional[int]:
    """payload_offset(), but only if a squashfs superblock really sits there."""
    off = payload_offset(header)
    if off is None:
        return None
    try:
        if off + 4 > os.stat(path).st_size:
            return None
        with open(path, "rb") as f:
            f.seek(off)
            return off if f.read(4) == _SQUASHFS_MAGIC else None
    except OSError:
        return None


# -- squashfs reading (never runs the AppImage) -----------------------------

def _unsquashfs(args: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(
        [UNSQUASHFS, "-p", "1", "-mem", "128M", *args],
        stdin=subprocess.DEVNULL, capture_output=True, timeout=_EXTRACT_TIMEOUT,
        env={"PATH": "/usr/bin:/bin", "LC_ALL": "C"}, check=False)


def _list_top_level(image: str, offset: int) -> dict[str, tuple[str, int, str]]:
    """Top-level squashfs entries: name -> (kind, size, symlink target)."""
    proc = _unsquashfs(["-o", str(offset), "-ll", "-max-depth", "1", "-d", "", image])
    if proc.returncode != 0:
        raise ValueError("unsquashfs could not list the image")
    entries: dict[str, tuple[str, int, str]] = {}
    for line in proc.stdout.decode("utf-8", "replace").splitlines():
        m = _LISTING_LINE.match(line)
        if not m or not m["rest"]:
            continue
        name, target = m["rest"], ""
        if m["kind"] == "l" and " -> " in name:
            name, target = name.split(" -> ", 1)
        if "/" in name or name in (".", ".."):
            continue  # only plain top-level names are ever used
        entries[name] = (m["kind"], int(m["size"]), target)
    return entries


def _cat(image: str, offset: int, name: str, size: int) -> bytes:
    """Contents of one regular top-level file, streamed to memory."""
    proc = _unsquashfs(["-o", str(offset), "-cat", "-no-wildcards", image, "/" + name])
    if proc.returncode != 0 or len(proc.stdout) != size:
        raise ValueError(f"unsquashfs could not read {name!r}")
    return proc.stdout


def _resolve_icon_entry(entries: dict[str, tuple[str, int, str]], name: str) -> Optional[str]:
    """Follow a top-level symlink chain, only through plain sibling names."""
    for _ in range(4):
        entry = entries.get(name)
        if entry is None:
            return None
        kind, _size, target = entry
        if kind == "-":
            return name
        if kind != "l":
            return None
        target = target[2:] if target.startswith("./") else target
        if not target or "/" in target or target in (".", ".."):
            return None  # absolute or traversing link: refuse
        name = target
    return None


def _icon_ext(data: bytes) -> Optional[str]:
    """File extension from the icon's content; None when it is not a known image."""
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if data.startswith(b"/* XPM */"):
        return ".xpm"
    head = data[:2048].lstrip().lower()
    if head.startswith(b"<") and b"<svg" in head:
        return ".svg"
    return None


def _clean(text: Optional[str], limit: int) -> Optional[str]:
    if not text:
        return None
    text = "".join(c for c in text if c.isprintable()).strip()
    return text[:limit] or None


def parse_desktop(data: bytes) -> dict[str, Optional[str]]:
    """Name, Comment, Icon and X-AppImage-Version of a desktop file (localised where it applies)."""
    kf = GLib.KeyFile()
    text = data.decode("utf-8", "replace")
    kf.load_from_data(text, len(text.encode("utf-8")), GLib.KeyFileFlags.NONE)
    group = "Desktop Entry"

    def get(key: str, localised: bool = False) -> Optional[str]:
        try:
            return (kf.get_locale_string(group, key, None) if localised
                    else kf.get_string(group, key))
        except GLib.Error:
            return None

    return {
        "name": _clean(get("Name", True), 200),
        "comment": _clean(get("Comment", True), 500),
        "icon": get("Icon"),
        "version": _clean(get("X-AppImage-Version"), 64),
    }


# -- metadata cache ---------------------------------------------------------

@dataclass(frozen=True)
class _Meta:
    desktop_name: Optional[str] = None  # basename of the desktop file inside the image
    name: Optional[str] = None
    comment: Optional[str] = None
    version: Optional[str] = None
    icon: Optional[str] = None  # absolute path in the cache


def _cache_key(path: str, st: os.stat_result) -> str:
    raw = f"{path}\0{st.st_size}\0{st.st_mtime_ns}".encode()
    return hashlib.sha256(raw).hexdigest()[:32]


def _extract(path: str, offset: int, entry_dir: str) -> None:
    """Read the desktop file and icon into entry_dir (a fresh, private directory)."""
    entries = _list_top_level(path, offset)
    meta: dict[str, Optional[str]] = {}

    desktops = sorted(n for n, (k, s, _t) in entries.items()
                      if k == "-" and n.endswith(".desktop") and len(n) > len(".desktop")
                      and 0 < s <= _MAX_DESKTOP_BYTES)
    parsed: dict[str, Optional[str]] = {}
    if desktops:
        chosen = desktops[0]
        data = _cat(path, offset, chosen, entries[chosen][1])
        parsed = parse_desktop(data)
        meta.update(desktop=chosen, name=parsed["name"], comment=parsed["comment"],
                    version=parsed["version"])

    # Icon: the Icon= name first, then the .DirIcon the AppImage spec asks for.
    candidates: list[str] = []
    icon_name = parsed.get("icon")
    if icon_name and "/" not in icon_name and icon_name not in (".", ".."):
        candidates += [icon_name + ext for ext in _ICON_EXTS]
    candidates.append(".DirIcon")
    for cand in candidates:
        real = _resolve_icon_entry(entries, cand)
        if real is None or not 0 < entries[real][1] <= _MAX_ICON_BYTES:
            continue
        data = _cat(path, offset, real, entries[real][1])
        ext = _icon_ext(data)
        if ext is None:
            continue
        with open(os.path.join(entry_dir, "icon" + ext), "wb") as f:
            f.write(data)
        meta["icon"] = "icon" + ext
        break

    with open(os.path.join(entry_dir, "meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f)


def _load_entry(entry_dir: str) -> _Meta:
    with open(os.path.join(entry_dir, "meta.json"), encoding="utf-8") as f:
        raw = json.load(f)
    icon = raw.get("icon")
    # The cache is ours, but keep the same rule: a bare file name inside entry_dir.
    if not isinstance(icon, str) or "/" in icon or not icon.startswith("icon."):
        icon = None
    elif not os.path.isfile(os.path.join(entry_dir, icon)):
        icon = None
    return _Meta(
        desktop_name=raw.get("desktop") if isinstance(raw.get("desktop"), str) else None,
        name=raw.get("name"), comment=raw.get("comment"), version=raw.get("version"),
        icon=os.path.join(entry_dir, icon) if icon else None)


def _metadata(cache_root: str, path: str, st: os.stat_result, offset: int) -> _Meta:
    """Cached or freshly read metadata. Any failure gives an empty _Meta, never an error."""
    entry = os.path.join(cache_root, _cache_key(path, st))
    try:
        if os.path.isfile(os.path.join(entry, "meta.json")):
            return _load_entry(entry)
        os.makedirs(cache_root, mode=0o700, exist_ok=True)
        tmp = tempfile.mkdtemp(prefix=".tmp-", dir=cache_root)
        try:
            _extract(path, offset, tmp)
            try:
                os.rename(tmp, entry)
            except OSError:
                shutil.rmtree(tmp, ignore_errors=True)  # another scan won the race
            tmp = ""
        finally:
            if tmp:
                shutil.rmtree(tmp, ignore_errors=True)
        return _load_entry(entry)
    except Exception:  # noqa: BLE001 - contract: a bad image must not fail the scan
        return _Meta()


# -- naming -----------------------------------------------------------------

def _stem(filename: str) -> str:
    return _SUFFIX.sub("", filename) or filename


def _version_from_filename(stem: str) -> Optional[str]:
    m = _FILENAME_VERSION.search(stem)
    return m.group(1) if m else None


def _map_exc(e: Exception) -> BackendError:
    if isinstance(e, BackendError):
        return e
    return BackendError(ErrorKind.FAILED, str(e) or type(e).__name__, Source.APPIMAGE)


def _error(kind: ErrorKind, message: str) -> BackendError:
    return BackendError(kind, message, Source.APPIMAGE)


# -- feeds ------------------------------------------------------------------

FEED_PREFIX = "feed:"
FEED_TTL = 24 * 3600  # seconds a cached feed counts as fresh
_NET_TIMEOUT = 20  # seconds, per socket operation
_MAX_FEED_BYTES = 32 * 1024 * 1024
_MAX_API_BYTES = 8 * 1024 * 1024
_MAX_DOWNLOAD_BYTES = 4 * 1024 ** 3
_FEED_RESULT_LIMIT = 100  # search hits taken from one feed
_GITHUB_RELEASE = "https://api.github.com/repos/{}/releases/latest"
_GITHUB_REPO = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")
# Architectures we refuse. "x86_64" must not match "x86" or "i386"-style names.
_BAD_ARCH = re.compile(
    r"(?<![a-z0-9])(aarch64|arm64|armhf|armv\d+l?|arm|i[3-6]86|x86(?![_-]?64)|ia32|"
    r"riscv64|ppc64(le)?|s390x|win32)(?![a-z0-9])")
_GOOD_ARCH = re.compile(r"(?<![a-z0-9])(x86[_-]?64|amd64|x64)(?![a-z0-9])")
_KNOWN_FEEDS = {"appimage.github.io": "AppImageHub"}

# A fetcher is fetcher(url, accept) -> response with read(n) and headers.get(name),
# closed by the caller. Tests inject their own; the default is urllib over https.
Fetcher = Callable[[str, Optional[str]], Any]


class _HttpsOnlyRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not newurl.lower().startswith("https://"):
            raise urllib.error.URLError(f"refusing a redirect to {newurl}")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


_OPENER = urllib.request.build_opener(_HttpsOnlyRedirects)


def default_fetcher(url: str, accept: Optional[str] = None):
    """urllib over https only; sends nothing but a fixed User-Agent."""
    if not url.lower().startswith("https://"):
        raise urllib.error.URLError(f"refusing a non-https URL: {url}")
    req = urllib.request.Request(url, headers={"User-Agent": "AppHub", "Accept": accept or "*/*"})
    return _OPENER.open(req, timeout=_NET_TIMEOUT)


def net_error(e: Exception, what: str) -> BackendError:
    """Map a failed request to a BackendError."""
    if isinstance(e, BackendError):
        return e
    if isinstance(e, urllib.error.HTTPError):
        if e.code == 404:
            return _error(ErrorKind.NOT_FOUND, f"{what}: not found (HTTP 404)")
        if e.code in (403, 429):
            return _error(ErrorKind.NETWORK,
                          f"{what}: the server refused the request or is rate limiting "
                          f"(HTTP {e.code}); try again later")
        return _error(ErrorKind.NETWORK, f"{what}: HTTP {e.code}")
    reason = getattr(e, "reason", None) or str(e) or type(e).__name__
    return _error(ErrorKind.NETWORK, f"{what}: {reason}")


def _get(fetcher: Fetcher, url: str, what: str, limit: int,
         accept: Optional[str] = None) -> bytes:
    try:
        with contextlib.closing(fetcher(url, accept)) as r:
            data = r.read(limit + 1)
    except (OSError, http.client.HTTPException) as e:  # URLError, HTTPError, timeouts
        raise net_error(e, what) from e
    if len(data) > limit:
        raise _error(ErrorKind.FAILED, f"{what}: the response is too large")
    return data


def feed_id(feed_url: str, item_name: str) -> str:
    return f"{FEED_PREFIX}{feed_url}#{item_name}"


def split_feed_id(pkg_id: str) -> Optional[tuple[str, str]]:
    if not pkg_id.startswith(FEED_PREFIX) or "#" not in pkg_id:
        return None
    url, name = pkg_id[len(FEED_PREFIX):].split("#", 1)
    return (url, name) if url and name else None


def default_feed_name(url: str, title: Optional[str] = None) -> str:
    host = (urllib.parse.urlsplit(url).hostname or url).lower()
    return _clean(title, 100) or _KNOWN_FEEDS.get(host) or host


@dataclass(frozen=True)
class Feed:
    url: str
    title: Optional[str]
    items: tuple[dict, ...]
    stale: bool = False  # served from an out-of-date cache because the network failed

    def find(self, name: str) -> Optional[dict]:
        for item in self.items:
            if item["name"] == name:
                return item
        low = name.lower()
        for item in self.items:
            if item["name"].lower() == low:
                return item
        return None


def parse_feed(data: bytes, url: str, stale: bool = False) -> Feed:
    try:
        raw = json.loads(data.decode("utf-8"))
    except ValueError as e:
        raise _error(ErrorKind.FAILED, f"{url} is not a valid feed: {e}") from e
    if not isinstance(raw, dict) or not isinstance(raw.get("items"), list):
        raise _error(ErrorKind.FAILED, f"{url} is not an AppImage feed (no list of items)")
    items = tuple(i for i in raw["items"]
                  if isinstance(i, dict) and isinstance(i.get("name"), str) and i["name"])
    title = raw.get("title") if isinstance(raw.get("title"), str) else None
    return Feed(url, title, items, stale)


class FeedStore:
    """Feeds fetched over https, cached on disk for FEED_TTL, stale cache when offline."""

    def __init__(self, cache_dir: Optional[str] = None, fetcher: Optional[Fetcher] = None,
                 ttl: float = FEED_TTL, clock: Callable[[], float] = time.time) -> None:
        self._dir = cache_dir or os.path.join(GLib.get_user_cache_dir(), "apphub",
                                              "appimage-feeds")
        self._fetch = fetcher or default_fetcher
        self._ttl = ttl
        self._clock = clock

    def _path(self, url: str) -> str:
        return os.path.join(self._dir, hashlib.sha256(url.encode()).hexdigest() + ".json")

    def _read_cache(self, url: str) -> tuple[Optional[Feed], bool]:
        """(feed, fresh); (None, False) when there is no usable cache."""
        path = self._path(url)
        try:
            age = self._clock() - os.stat(path).st_mtime
            with open(path, "rb") as f:
                return parse_feed(f.read(_MAX_FEED_BYTES), url), 0 <= age < self._ttl
        except (OSError, BackendError):
            return None, False

    def _write_cache(self, url: str, data: bytes) -> None:
        try:
            os.makedirs(self._dir, mode=0o700, exist_ok=True)
            fd, tmp = tempfile.mkstemp(prefix=".tmp-", dir=self._dir)
            try:
                with os.fdopen(fd, "wb") as f:
                    f.write(data)
                os.replace(tmp, self._path(url))
            except BaseException:
                with contextlib.suppress(OSError):
                    os.unlink(tmp)
                raise
        except OSError as e:
            log.warning("could not cache feed %s: %s", url, e)

    def load(self, url: str) -> Feed:
        if not url.lower().startswith("https://"):
            raise _error(ErrorKind.FAILED, "Feeds must use https")
        cached, fresh = self._read_cache(url)
        if cached is not None and fresh:
            return cached
        try:
            data = _get(self._fetch, url, "Could not read the feed", _MAX_FEED_BYTES,
                        "application/json")
            feed = parse_feed(data, url)
        except BackendError:
            if cached is not None:
                return dataclasses.replace(cached, stale=True)
            raise
        self._write_cache(url, data)
        return feed


def feed_icon(feed_url: str, item: dict) -> Optional[str]:
    """The item's first icon as an https URL, or None. AppImageHub gives relative paths
    that live under /database/ next to feed.json."""
    icons = item.get("icons")
    if not isinstance(icons, list) or not icons or not isinstance(icons[0], str):
        return None
    icon = icons[0].strip()
    if icon.lower().startswith("https://"):
        return icon
    if not icon or ":" in icon.split("/", 1)[0] or icon.startswith(("/", "..")) or "/../" in icon:
        return None
    return urllib.parse.urljoin(feed_url, "database/" + urllib.parse.quote(icon, safe="/+"))


def feed_package(feed_url: str, origin: str, item: dict) -> Package:
    name = item["name"]
    return Package(
        id=feed_id(feed_url, name), name=name, version="latest",
        summary=_clean(item.get("description") if isinstance(item.get("description"), str)
                       else None, 500) or "",
        source=Source.APPIMAGE, installed=False, title=name, origin=origin,
        icon=feed_icon(feed_url, item))


def search_feed(feed: Feed, origin: str, words: list[str]) -> list[Package]:
    """Items containing every word, best matches first (name before description)."""
    scored = []
    for item in feed.items:
        name = item["name"].lower()
        desc = item.get("description") if isinstance(item.get("description"), str) else ""
        cats = item.get("categories")
        extra = " ".join(c for c in cats if isinstance(c, str)) if isinstance(cats, list) else ""
        hay = f"{name} {desc} {extra}".lower()
        if not all(w in hay for w in words):
            continue
        rank = 0 if name == " ".join(words) else 1 if all(w in name for w in words) else 2
        scored.append((rank, name, item))
    scored.sort(key=lambda t: (t[0], t[1]))
    return [feed_package(feed.url, origin, item) for _r, _n, item in scored[:_FEED_RESULT_LIMIT]]


# -- resolving a download ---------------------------------------------------

@dataclass(frozen=True)
class Download:
    url: str
    filename: str
    size: Optional[int] = None


def arch_rank(filename: str) -> Optional[int]:
    """0 for an explicit x86_64/amd64 name, 1 for a name with no architecture,
    None for anything built for another architecture."""
    low = filename.lower()
    if _BAD_ARCH.search(low):
        return None
    return 0 if _GOOD_ARCH.search(low) else 1


def pick_github_asset(release: Any) -> Optional[Download]:
    """The best x86_64 *.AppImage asset of a GitHub release JSON object, if any."""
    assets = release.get("assets") if isinstance(release, dict) else None
    if not isinstance(assets, list):
        return None
    best: Optional[tuple[int, Download]] = None
    for a in assets:
        if not isinstance(a, dict):
            continue
        name, url = a.get("name"), a.get("browser_download_url")
        if not (isinstance(name, str) and isinstance(url, str)):
            continue
        if not name.lower().endswith(".appimage") or not url.lower().startswith("https://"):
            continue
        rank = arch_rank(name)
        if rank is None:
            continue
        size = a.get("size") if isinstance(a.get("size"), int) else None
        if best is None or rank < best[0]:
            best = (rank, Download(url, name, size))
    return None if best is None else best[1]


def resolve_download(item: dict, fetcher: Fetcher) -> Download:
    """Where to get this feed item: its GitHub latest release, else a direct .AppImage link.

    NOT_FOUND when nothing resolves; a NETWORK error when the only obstacle was the network.
    """
    links = [lk for lk in (item.get("links") or []) if isinstance(lk, dict)
             and isinstance(lk.get("type"), str) and isinstance(lk.get("url"), str)]
    last: Optional[BackendError] = None
    for lk in links:
        if lk["type"] != "GitHub" or not _GITHUB_REPO.match(lk["url"]):
            continue
        what = f"Could not read the latest release of {lk['url']}"
        try:
            data = _get(fetcher, _GITHUB_RELEASE.format(lk["url"]), what, _MAX_API_BYTES,
                        "application/vnd.github+json")
            found = pick_github_asset(json.loads(data.decode("utf-8")))
        except BackendError as e:
            last = e
            continue
        except ValueError as e:
            last = _error(ErrorKind.FAILED, f"{what}: unreadable answer ({e})")
            continue
        if found is not None:
            return found
    for lk in links:
        if lk["type"] != "Download":
            continue
        parts = urllib.parse.urlsplit(lk["url"])
        base = urllib.parse.unquote(parts.path.rsplit("/", 1)[-1])
        if (parts.scheme == "https" and base.lower().endswith(".appimage")
                and arch_rank(base) is not None):
            return Download(lk["url"], base)
    if last is not None and last.kind in (ErrorKind.NETWORK, ErrorKind.FAILED):
        raise last
    raise _error(ErrorKind.NOT_FOUND,
                 f"No x86_64 AppImage download was found for {item['name']}. Its latest "
                 "release has no AppImage file for this computer, or its link points to "
                 "a web page.")


def safe_filename(name: str, fallback: str) -> str:
    """A plain file name that ends in .AppImage, safe to create in a pool folder."""
    base = os.path.basename(name.replace("\\", "/"))
    base = _SAFE_NAME.sub("_", base).lstrip(".")
    stem = _SUFFIX.sub("", base)[:150]
    if not stem:
        stem = _SAFE_NAME.sub("_", fallback).lstrip(".")[:150] or "app"
    return stem + ".AppImage"


# -- backend ----------------------------------------------------------------

class AppImageBackend:
    source = Source.APPIMAGE

    def __init__(self, dirs: Optional[list[str]] = None, cache_dir: Optional[str] = None,
                 config: Optional["PoolConfig"] = None, feeds: Optional[FeedStore] = None,
                 fetcher: Optional[Fetcher] = None) -> None:
        """`dirs` overrides the configured folders (tests); with it and no `config`
        the pool config file is not read at all and there are no feeds."""
        self._fixed_dirs = (None if dirs is None
                            else [os.path.abspath(os.path.expanduser(d)) for d in dirs])
        if config is None and dirs is None:
            from .pools import PoolConfig  # pools imports this module
            config = PoolConfig()
        self._config = config
        self._cache = cache_dir or os.path.join(GLib.get_user_cache_dir(), "apphub", "appimage")
        self._fetch: Fetcher = fetcher or default_fetcher
        self._feeds = feeds if feeds is not None else FeedStore(fetcher=self._fetch)

    @property
    def _dirs(self) -> list[str]:
        """Folders to scan, in order: the override, else the enabled pool folders."""
        if self._fixed_dirs is not None:
            return list(self._fixed_dirs)
        return self._config.enabled_folders() if self._config else []

    def _feed_pools(self) -> list["FeedPool"]:
        return [f for f in self._config.feeds() if f.enabled] if self._config else []

    def available(self) -> bool:
        return True  # nothing to install; a missing folder just means no AppImages

    # -- scanning -------------------------------------------------------

    def _dir_allowed(self, directory: str) -> bool:
        return not is_forbidden_dir(directory)

    def scan(self) -> list[Package]:
        """Blocking scan of every directory. Never raises for a bad entry."""
        found: dict[tuple[int, int], Package] = {}
        for directory in self._dirs:
            if not self._dir_allowed(directory):
                continue
            try:
                names = sorted(os.listdir(directory))
            except OSError:
                continue  # missing or unreadable: fine
            for filename in names:
                if filename.startswith(_PART_PREFIX) and filename.endswith(_PART_SUFFIX):
                    continue  # a download in progress
                path = os.path.join(directory, filename)
                try:
                    pkg, ident = self._inspect(directory, filename, path)
                except Exception:  # noqa: BLE001 - one bad file must not hide the rest
                    continue
                if pkg is not None and ident not in found:
                    found[ident] = pkg
        return sorted(found.values(), key=lambda p: (p.display_name.lower(), p.id))

    def _inspect(self, directory: str, filename: str, path: str):
        st = os.lstat(path)
        if not stat.S_ISREG(st.st_mode):
            return None, None  # symlinks, directories (no recursion) and specials
        header = _read_header(path)
        kind = None if header is None else header_type(header)
        if kind is None:
            return None, None
        meta = _Meta()
        if kind == 2:
            offset = _squashfs_offset(path, header)
            if offset is not None:
                meta = _metadata(self._cache, path, st, offset)
        stem = _stem(filename)
        app_id = None
        if meta.desktop_name:
            app_id = meta.desktop_name[:-len(".desktop")]
        pkg = Package(
            id=path,
            name=stem,
            version=meta.version or _version_from_filename(stem) or "unknown",
            summary=meta.comment or "",
            source=self.source,
            installed=True,
            title=meta.name,
            app_id=app_id,
            origin=directory,
            icon=meta.icon,
            installed_size=st.st_size,
        )
        return pkg, (st.st_dev, st.st_ino)

    def _run(self, work, done) -> None:
        run_blocking(work, Once(done), _map_exc)

    # -- queries --------------------------------------------------------

    def list_installed(self, done: Done[list[Package]]) -> None:
        self._run(self.scan, done)

    def search(self, query: str, done: Done[list[Package]]) -> None:
        words = query.lower().split()

        def work() -> list[Package]:
            if not words:
                return []
            result = []
            for p in self.scan():
                hay = " ".join((p.name, p.title or "", p.summary)).lower()
                if all(w in hay for w in words):
                    result.append(p)
            for pool in self._feed_pools():
                try:
                    feed = self._feeds.load(pool.url)
                except BackendError as e:  # an unreachable feed must not hide the rest
                    log.warning("feed %s unavailable: %s", pool.url, e.message)
                    continue
                result += search_feed(feed, pool.name, words)
            return result

        self._run(work, done)

    def lookup(self, name: str, done: Done[Package]) -> None:
        def work() -> Package:
            for p in self.scan():
                if p.name == name:
                    return p
            wanted = split_feed_id(name)
            failure: Optional[BackendError] = None
            for pool in self._feed_pools():
                if wanted is not None and normalize_url(wanted[0]) != normalize_url(pool.url):
                    continue
                try:
                    feed = self._feeds.load(pool.url)
                except BackendError as e:
                    failure = e
                    continue
                item = feed.find(wanted[1] if wanted else name)
                if item is not None:
                    return feed_package(pool.url, pool.name, item)
            if failure is not None:
                raise failure
            raise _error(ErrorKind.NOT_FOUND, f"No AppImage named {name} was found")

        self._run(work, done)

    def get_updates(self, done: Done[list[Package]]) -> None:
        # Update info (zsync / AppImageUpdate) is out of scope for now: report none.
        on_main(Once(done))([], None)

    # -- changes --------------------------------------------------------

    def install(self, pkg: Package, progress: OnProgress, done: Done[Package],
                simulate: bool = False) -> None:
        if split_feed_id(pkg.id) is None:
            on_main(Once(done))(None, _error(
                ErrorKind.UNSUPPORTED,
                "AppImages cannot be installed here. To add one, place the file in "
                "~/Applications and it will show up in the list."))
            return
        self._run(lambda: self._install_from_feed(pkg, progress, simulate), done)

    def _install_from_feed(self, pkg: Package, progress: OnProgress, simulate: bool) -> Package:
        """Blocking. Resolve, download, verify, then rename into the first pool folder."""
        def say(percent: Optional[int], status: str) -> None:
            try:
                on_main(progress)(Progress(percent, status))
            except Exception:  # noqa: BLE001 - a bad progress callback must not stop the install
                pass

        feed_url, item_name = split_feed_id(pkg.id)  # type: ignore[misc]
        pool = next((f for f in (self._config.feeds() if self._config else [])
                     if normalize_url(f.url) == normalize_url(feed_url)), None)
        if pool is None:
            raise _error(ErrorKind.NOT_FOUND, f"{feed_url} is not one of your AppImage feeds")
        say(None, "Looking up the download")
        item = self._feeds.load(pool.url).find(item_name)
        if item is None:
            raise _error(ErrorKind.NOT_FOUND, f"{item_name} is no longer in the feed")
        download = resolve_download(item, self._fetch)
        if simulate:
            return pkg

        folders = self._dirs
        if not folders:
            raise _error(ErrorKind.FAILED, "No AppImage folder is turned on to install into")
        folder = folders[0]
        if is_forbidden_dir(folder):
            raise _error(ErrorKind.FAILED, f"{folder} is a cloud drive folder; refusing to use it")
        filename = safe_filename(download.filename, item_name)
        final = os.path.join(folder, filename)
        if os.path.lexists(final):
            raise _error(ErrorKind.FAILED,
                         f"{filename} already exists in {folder}. Remove it first to install again.")
        try:
            os.makedirs(folder, exist_ok=True)
        except OSError as e:
            raise _error(ErrorKind.FAILED, f"Could not create {folder}: {e.strerror or e}") from e

        tmp = ""
        try:
            try:
                response = self._fetch(download.url, None)
            except (OSError, http.client.HTTPException) as e:
                raise net_error(e, f"Could not download {download.url}") from e
            with contextlib.closing(response):
                total = _content_length(response)
                if total is not None and total > _MAX_DOWNLOAD_BYTES:
                    raise _error(ErrorKind.FAILED, "The download is too large")
                try:
                    fd, tmp = tempfile.mkstemp(prefix=_PART_PREFIX, suffix=_PART_SUFFIX, dir=folder)
                except OSError as e:
                    raise _error(ErrorKind.FAILED,
                                 f"Cannot write to {folder}: {e.strerror or e}") from e
                got, last_pct = 0, -1
                with os.fdopen(fd, "wb") as out:
                    while True:
                        try:
                            chunk = response.read(1 << 16)
                        except (OSError, http.client.HTTPException) as e:
                            raise net_error(e, "The download was interrupted") from e
                        if not chunk:
                            break
                        got += len(chunk)
                        if got > _MAX_DOWNLOAD_BYTES:
                            raise _error(ErrorKind.FAILED, "The download is too large")
                        out.write(chunk)
                        if total:
                            pct = min(100, got * 100 // total)
                            if pct != last_pct:
                                last_pct = pct
                                say(pct, "Downloading")
                        elif last_pct < 0:
                            last_pct = 0
                            say(None, "Downloading")
            if total is not None and got != total:
                raise _error(ErrorKind.NETWORK, "The download was cut short")
            say(None, "Checking the file")
            # Magic check first: nothing is made executable until it passes.
            if appimage_type(tmp) is None:
                raise _error(ErrorKind.FAILED,
                             f"{filename} is not an AppImage; it was deleted")
            os.chmod(tmp, 0o755)
            if os.path.lexists(final):
                raise _error(ErrorKind.FAILED, f"{filename} already exists in {folder}")
            os.rename(tmp, final)
            tmp = ""
        except OSError as e:
            raise _error(ErrorKind.FAILED, f"Could not save {filename}: {e.strerror or e}") from e
        finally:
            if tmp:
                with contextlib.suppress(OSError):
                    os.unlink(tmp)

        installed, _ident = self._inspect(folder, filename, final)
        if installed is None:
            raise _error(ErrorKind.FAILED, f"{filename} was saved but could not be read")
        return installed

    def update(self, pkgs: list[Package], progress: OnProgress, done: Done[list[Package]],
               simulate: bool = False) -> None:
        on_main(Once(done))(None, _error(
            ErrorKind.UNSUPPORTED, "AppImages cannot be updated from AppHub."))

    def remove(self, pkg: Package, progress: OnProgress, done: Done[Package],
               simulate: bool = False) -> None:
        if not simulate:
            try:
                progress(Progress(None, "Moving to the trash"))
            except Exception:  # noqa: BLE001 - a bad progress callback must not block removal
                pass

        def work() -> Package:
            path = self._checked_path(pkg)
            if simulate:
                directory = os.path.dirname(path)
                if not (os.access(path, os.W_OK) and os.access(directory, os.W_OK | os.X_OK)):
                    raise _error(ErrorKind.FAILED, f"{path} cannot be removed: not writable")
                return pkg
            try:
                # Trash, never unlink: the user can restore it.
                Gio.File.new_for_path(path).trash(None)
            except GLib.Error as e:
                raise _trash_error(path, e) from e
            return dataclasses.replace(pkg, installed=False)

        self._run(work, done)

    def _checked_path(self, pkg: Package) -> str:
        """pkg.id as a path, only if it still is an AppImage directly inside a scanned folder."""
        path = pkg.id
        if not os.path.isabs(path) or os.path.normpath(path) != path:
            raise _error(ErrorKind.FAILED, "Not a valid AppImage path")
        if os.path.dirname(path) not in self._dirs:
            raise _error(ErrorKind.FAILED, f"{path} is not in an AppImage folder; refusing to remove it")
        try:
            st = os.lstat(path)
        except FileNotFoundError:
            raise _error(ErrorKind.NOT_FOUND, f"{path} no longer exists") from None
        if not stat.S_ISREG(st.st_mode) or appimage_type(path) is None:
            raise _error(ErrorKind.NOT_FOUND, f"{path} is no longer an AppImage")
        return path


def _content_length(response: Any) -> Optional[int]:
    try:
        n = int(response.headers.get("Content-Length"))
    except (AttributeError, TypeError, ValueError):
        return None
    return n if n >= 0 else None


def normalize_url(url: str) -> str:
    """Lower-case scheme and host, no default port, no fragment, no trailing slash."""
    parts = urllib.parse.urlsplit(url.strip())
    host = (parts.hostname or "").lower()
    if ":" in host:
        host = f"[{host}]"
    try:
        port = parts.port
    except ValueError:
        port = None
    if port and not (parts.scheme.lower(), port) in (("https", 443), ("http", 80)):
        host = f"{host}:{port}"
    return urllib.parse.urlunsplit((parts.scheme.lower(), host, parts.path.rstrip("/"),
                                    parts.query, ""))


def _trash_error(path: str, e: GLib.Error) -> BackendError:
    if e.matches(Gio.io_error_quark(), Gio.IOErrorEnum.NOT_FOUND):
        return _error(ErrorKind.NOT_FOUND, f"{path} no longer exists")
    if e.matches(Gio.io_error_quark(), Gio.IOErrorEnum.CANCELLED):
        return _error(ErrorKind.CANCELLED, e.message)
    if e.matches(Gio.io_error_quark(), Gio.IOErrorEnum.NOT_SUPPORTED):
        return _error(ErrorKind.FAILED,
                      f"The trash is not supported for {path}; the file was left in place")
    return _error(ErrorKind.FAILED, f"Could not move {path} to the trash: {e.message}")
