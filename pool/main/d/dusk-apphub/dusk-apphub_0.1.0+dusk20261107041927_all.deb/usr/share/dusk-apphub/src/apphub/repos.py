"""APT repository management (DEB822): the unprivileged model and the read side.

Everything here is pure or read-only. Changes go through the root helper
(helpers/apphub-sources-helper) run by pkexec; the async wrappers at the bottom
do that. The pure functions return NEW file text and never touch the disk.

Round-trip rule: edits use debian._deb822_repro, which keeps comments, field
order, blank lines and unknown fields byte for byte. Only the edited field
changes.

validate() is duplicated in the helper (the helper is installed outside the
package and must not import from user-writable paths). tests/test_repos.py
checks that both copies agree. Keep them in sync.
"""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional
from urllib.parse import urlparse

from debian._deb822_repro import parse_deb822_file

from .backend import BackendError, Done, ErrorKind, Source, run_blocking

SOURCES_DIR = Path("/etc/apt/sources.list.d")
MAIN_LIST = Path("/etc/apt/sources.list")
HELPER_PATH = "/usr/libexec/apphub/apphub-sources-helper"
ACTION_ID = "io.github.phlthydelphya.DuskAppHub.manage-sources"

BASENAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*\.sources\Z")
URI_PREFIXES = ("http://", "https://", "file:", "cdrom:", "mirror+")
KEY_MARKER = "-----BEGIN PGP PUBLIC KEY BLOCK-----"
INLINE_KEY = "inline key"
_BOOL_TRUE = {"yes", "true", "1", "on"}
_BOOL_FALSE = {"no", "false", "0", "off"}


class ValidationError(ValueError):
    pass


@dataclass(frozen=True)
class Repo:
    file: Path
    index: int  # stanza index in a .sources file; entry index in a legacy .list
    name: str
    types: tuple[str, ...]
    uris: tuple[str, ...]
    suites: tuple[str, ...]
    components: tuple[str, ...]
    enabled: bool = True
    signed_by: Optional[str] = None  # key path, INLINE_KEY, or None
    legacy: bool = False  # .list entry: shown only, never edited


# -- parsing / validation (pure) -------------------------------------------

def _parse(text: str):
    try:
        return parse_deb822_file(text.splitlines(keepends=True))
    except Exception as e:  # noqa: BLE001 - parser raises several types
        raise ValidationError(f"cannot parse: {e}") from None


def _words(value: Optional[str]) -> tuple[str, ...]:
    return tuple(value.split()) if value else ()


def _parse_bool(value: Optional[str]) -> bool:
    return value is None or value.strip().lower() not in _BOOL_FALSE


def validate(text: str, require_signed: bool = True) -> None:
    """Raise ValidationError unless text is a sane DEB822 sources file."""
    if "\0" in text:
        raise ValidationError("NUL byte in text")
    paragraphs = list(_parse(text))
    if not paragraphs:
        raise ValidationError("no stanzas")
    problems: list[str] = []
    for i, p in enumerate(paragraphs):
        for field in ("Types", "URIs", "Suites"):
            if not _words(p.get(field)):
                problems.append(f"stanza {i}: missing {field}")
        for t in _words(p.get("Types")):
            if t not in ("deb", "deb-src"):
                problems.append(f"stanza {i}: bad type {t!r}")
        for u in _words(p.get("URIs")):
            if not u.startswith(URI_PREFIXES):
                problems.append(f"stanza {i}: URI scheme not allowed: {u}")
        enabled = p.get("Enabled")
        if enabled is not None and enabled.strip().lower() not in _BOOL_TRUE | _BOOL_FALSE:
            problems.append(f"stanza {i}: bad Enabled value {enabled.strip()!r}")
        if require_signed and not (p.get("Signed-By") or "").strip():
            problems.append(f"stanza {i}: missing Signed-By (unsigned repositories refused)")
    if problems:
        raise ValidationError("; ".join(problems))


def _signed_by(p) -> Optional[str]:
    value = (p.get("Signed-By") or "").strip()
    if not value:
        return None
    return INLINE_KEY if value.startswith("-----BEGIN") else value.split()[0]


def _host_name(uris: tuple[str, ...]) -> str:
    if not uris:
        return "Unknown repository"
    u = urlparse(uris[0].removeprefix("mirror+"))
    host = u.hostname or uris[0]
    parts = [s for s in u.path.split("/") if s]
    if host == "ppa.launchpadcontent.net" and len(parts) >= 2:
        return f"ppa:{parts[0]}/{parts[1]}"
    return host


def parse_repos(text: str, file: Path) -> list[Repo]:
    """Repos of one .sources text. Raises ValidationError when it cannot parse."""
    repos = []
    for i, p in enumerate(_parse(text)):
        uris = _words(p.get("URIs"))
        name = (p.get("X-Repolib-Name") or p.get("Name") or "").strip() or _host_name(uris)
        repos.append(Repo(
            file=file, index=i, name=name,
            types=_words(p.get("Types")), uris=uris,
            suites=_words(p.get("Suites")), components=_words(p.get("Components")),
            enabled=_parse_bool(p.get("Enabled")), signed_by=_signed_by(p),
        ))
    return repos


_LEGACY_OPT = re.compile(r"\[([^\]]*)\]")


def parse_legacy(text: str, file: Path) -> list[Repo]:
    """One-line-style entries (.list). Comments and unrecognised lines are skipped."""
    repos = []
    for line in text.splitlines():
        line = line.split("#", 1)[0].strip()
        if not line:
            continue
        m = _LEGACY_OPT.search(line)
        opts: dict[str, str] = {}
        if m:
            for kv in m.group(1).split():
                k, _, v = kv.partition("=")
                opts[k.lower()] = v
            line = (line[:m.start()] + " " + line[m.end():]).strip()
        words = line.split()
        if len(words) < 3 or words[0] not in ("deb", "deb-src"):
            continue
        uris = (words[1],)
        repos.append(Repo(
            file=file, index=len(repos), name=_host_name(uris), types=(words[0],),
            uris=uris, suites=(words[2],), components=tuple(words[3:]),
            enabled=True, signed_by=opts.get("signed-by"), legacy=True,
        ))
    return repos


# -- read side -------------------------------------------------------------

def list_repos(root: Path = SOURCES_DIR, main_list: Optional[Path] = MAIN_LIST) -> list[Repo]:
    """Every repo apt reads: *.sources (editable) and *.list (legacy, read-only).

    Backups (.save, .orig, .curtin.orig, .disabled, ...) are ignored. An
    unreadable or unparsable file is skipped, not fatal.
    """
    files = sorted(p for p in Path(root).iterdir()
                   if p.is_file() and p.suffix in (".sources", ".list"))
    if main_list is not None and Path(main_list).is_file():
        files.append(Path(main_list))
    repos: list[Repo] = []
    for f in files:
        try:
            text = f.read_text(encoding="utf-8")
            repos += (parse_repos(text, f) if f.suffix == ".sources" else parse_legacy(text, f))
        except (OSError, UnicodeError, ValidationError):
            continue
    return repos


# -- pure edits: return new text -------------------------------------------

def set_enabled(text: str, stanza_index: int, enabled: bool) -> str:
    """New text with one stanza's Enabled field changed; everything else untouched.

    Enabling a stanza without an Enabled field is a no-op (the default is yes).
    """
    file = _parse(text)
    paragraphs = list(file)
    if not 0 <= stanza_index < len(paragraphs):
        raise ValidationError(f"no stanza {stanza_index}")
    p = paragraphs[stanza_index]
    if "Enabled" not in p and enabled:
        return text
    p["Enabled"] = "yes" if enabled else "no"
    return file.dump()


def _clean(label: str, values: Iterable[str]) -> str:
    vals = [v.strip() for v in values if v and v.strip()]
    if not vals:
        raise ValidationError(f"{label} is required")
    if any(re.search(r"\s", v) for v in vals):
        raise ValidationError(f"{label} must not contain whitespace")
    return " ".join(vals)


def _format_signed_by(value: str) -> str:
    value = value.strip()
    if KEY_MARKER in value:
        lines = [ln.rstrip() for ln in value.splitlines()]
        return lines[0] + "".join("\n " + (ln if ln else ".") for ln in lines[1:])
    if "\n" in value or not value.startswith("/"):
        raise ValidationError("Signed-By must be an absolute key path or an armored key")
    return value


def add_repo(name: Optional[str], types: Iterable[str], uris: Iterable[str],
             suites: Iterable[str], components: Iterable[str],
             signed_by: Optional[str], architectures: Iterable[str] = ()) -> str:
    """Body of a new .sources file. Refuses unsigned repos and invalid input."""
    if not signed_by or not signed_by.strip():
        raise ValidationError("Signed-By is required: unsigned repositories refused")
    suites = [s.strip() for s in suites]
    flat = bool(suites) and all(s.endswith("/") for s in suites if s)
    lines = []
    if name and name.strip():
        if "\n" in name:
            raise ValidationError("name must be one line")
        lines.append(f"X-Repolib-Name: {name.strip()}")
    lines.append(f"Types: {_clean('Types', types)}")
    lines.append(f"URIs: {_clean('URIs', uris)}")
    lines.append(f"Suites: {_clean('Suites', suites)}")
    comps = [c for c in components if c and c.strip()]
    if comps or not flat:
        lines.append(f"Components: {_clean('Components', comps)}")
    archs = [a for a in architectures if a and a.strip()]
    if archs:
        lines.append(f"Architectures: {_clean('Architectures', archs)}")
    lines.append(f"Signed-By: {_format_signed_by(signed_by)}")
    text = "\n".join(lines) + "\n"
    validate(text)
    return text


def suggest_basename(name: str) -> str:
    """A safe .sources basename for a human name."""
    stem = re.sub(r"[^A-Za-z0-9._-]+", "-", name.strip().lower()).strip("-._")
    return (stem or "repository") + ".sources"


# -- async wrappers: privileged changes through pkexec ---------------------

def _map_exc(e: Exception) -> BackendError:
    if isinstance(e, BackendError):
        return e
    if isinstance(e, ValidationError):
        return BackendError(ErrorKind.FAILED, str(e), Source.APT)
    if isinstance(e, FileNotFoundError):
        return BackendError(ErrorKind.NOT_FOUND, str(e), Source.APT)
    return BackendError(ErrorKind.FAILED, str(e), Source.APT)


def _run_helper(args: list[str], stdin_text: Optional[str] = None) -> None:
    proc = subprocess.run(["pkexec", HELPER_PATH, *args], input=stdin_text,
                          capture_output=True, text=True, check=False)
    if proc.returncode == 0:
        return
    if proc.returncode in (126, 127):  # polkit: dismissed (126) / not authorized (127)
        raise BackendError(ErrorKind.AUTH, "Authentication was refused or dismissed", Source.APT)
    msg = proc.stderr.strip() or f"helper exited with status {proc.returncode}"
    raise BackendError(ErrorKind.FAILED, msg, Source.APT)


def _check_basename(name: str) -> None:
    if not BASENAME_RE.match(name):
        raise ValidationError(f"bad file name: {name!r}")


def set_enabled_async(repo: Repo, enabled: bool, done: Done[bool]) -> None:
    """Enable or disable one stanza. Legacy entries are refused."""
    def work() -> bool:
        if repo.legacy or repo.file.suffix != ".sources":
            raise BackendError(ErrorKind.UNSUPPORTED, "Legacy .list entries are read-only", Source.APT)
        _check_basename(repo.file.name)
        new = set_enabled(repo.file.read_text(encoding="utf-8"), repo.index, enabled)
        _run_helper(["write", repo.file.name], new)
        return True
    run_blocking(work, done, _map_exc)


def add_repo_async(basename: str, text: str, done: Done[bool]) -> None:
    """Write a new .sources file (text from add_repo()). The helper validates again."""
    def work() -> bool:
        _check_basename(basename)
        validate(text)
        _run_helper(["write", basename], text)
        return True
    run_blocking(work, done, _map_exc)


def disable_file_async(basename: str, done: Done[bool]) -> None:
    """Rename <basename> to <basename>.disabled. Reversible; nothing is deleted."""
    def work() -> bool:
        _check_basename(basename)
        _run_helper(["disable-file", basename])
        return True
    run_blocking(work, done, _map_exc)
