"""Flatpak backend over libflatpak.

libflatpak calls block, so every one runs in a worker thread (run_blocking) and
reports back on the GLib main loop. Installation objects are created per call:
that is cheap and means every call sees fresh on-disk state.

Package.id has the form "<installation>/<ref>", for example
"user/app/org.foo.Bar/x86_64/stable" or "system/app/org.foo.Bar/x86_64/stable".
Only this module parses it.
"""

from __future__ import annotations

import dataclasses
import threading
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Callable, Optional

import gi

gi.require_version("Flatpak", "1.0")
from gi.repository import Flatpak, Gio, GLib  # noqa: E402

from .backend import (  # noqa: E402
    BackendError,
    Done,
    ErrorKind,
    OnProgress,
    Package,
    Progress,
    Source,
    on_main,
    run_blocking,
)

# New installs go to the per-user installation: it needs no polkit prompt and
# no root. Installed apps keep the installation they already live in, so
# remove and update of a system-wide app still go to the system installation.
_INSTALL_TARGET = "user"

_USER = "user"
_SYSTEM = "system"

# -- error mapping ----------------------------------------------------------

_FLATPAK_KINDS = {
    Flatpak.Error.ABORTED: ErrorKind.CANCELLED,
    Flatpak.Error.NOT_INSTALLED: ErrorKind.NOT_FOUND,
    Flatpak.Error.REF_NOT_FOUND: ErrorKind.NOT_FOUND,
    Flatpak.Error.REMOTE_NOT_FOUND: ErrorKind.NOT_FOUND,
    Flatpak.Error.RUNTIME_NOT_FOUND: ErrorKind.NOT_FOUND,
    Flatpak.Error.NOT_AUTHORIZED: ErrorKind.AUTH,
    Flatpak.Error.PERMISSION_DENIED: ErrorKind.AUTH,
    Flatpak.Error.AUTHENTICATION_FAILED: ErrorKind.AUTH,
    Flatpak.Error.NEED_NEW_FLATPAK: ErrorKind.UNSUPPORTED,
    # ALREADY_INSTALLED has no dedicated kind: it is a plain failure whose
    # message ("... is already installed") tells the user what happened.
    Flatpak.Error.ALREADY_INSTALLED: ErrorKind.FAILED,
}

_IO_KINDS = {
    Gio.IOErrorEnum.CANCELLED: ErrorKind.CANCELLED,
    Gio.IOErrorEnum.PERMISSION_DENIED: ErrorKind.AUTH,
    Gio.IOErrorEnum.NOT_FOUND: ErrorKind.NOT_FOUND,
    Gio.IOErrorEnum.NETWORK_UNREACHABLE: ErrorKind.NETWORK,
    Gio.IOErrorEnum.HOST_UNREACHABLE: ErrorKind.NETWORK,
    Gio.IOErrorEnum.HOST_NOT_FOUND: ErrorKind.NETWORK,
    Gio.IOErrorEnum.CONNECTION_REFUSED: ErrorKind.NETWORK,
    Gio.IOErrorEnum.TIMED_OUT: ErrorKind.NETWORK,
    Gio.IOErrorEnum.PROXY_FAILED: ErrorKind.NETWORK,
    Gio.IOErrorEnum.PROXY_AUTH_FAILED: ErrorKind.NETWORK,
    Gio.IOErrorEnum.PROXY_NEED_AUTH: ErrorKind.NETWORK,
    Gio.IOErrorEnum.PROXY_NOT_ALLOWED: ErrorKind.NETWORK,
    Gio.IOErrorEnum.CONNECTION_CLOSED: ErrorKind.NETWORK,
    Gio.IOErrorEnum.BROKEN_PIPE: ErrorKind.NETWORK,
}

# libflatpak often wraps libostree network failures in a generic error whose
# only clue is the text.
_NETWORK_HINTS = (
    "could not resolve",
    "temporary failure in name resolution",
    "network is unreachable",
    "unable to connect",
    "connection refused",
    "connection timed out",
    "timeout was reached",
    "no route to host",
    "name or service not known",
)


def _quark(q) -> str:
    return GLib.quark_to_string(q)


def map_error(err: Exception) -> BackendError:
    """Turn a libflatpak / GLib error into the shared error contract."""
    if isinstance(err, BackendError):
        return err
    if not isinstance(err, GLib.Error):
        return BackendError(ErrorKind.FAILED, str(err), Source.FLATPAK)

    kind = ErrorKind.FAILED
    try:
        if err.domain == _quark(Flatpak.Error.quark()):
            kind = _FLATPAK_KINDS.get(Flatpak.Error(err.code), ErrorKind.FAILED)
        elif err.domain == _quark(Gio.io_error_quark()):
            kind = _IO_KINDS.get(Gio.IOErrorEnum(err.code), ErrorKind.FAILED)
        elif err.domain in (_quark(Gio.resolver_error_quark()), _quark(Gio.tls_error_quark())):
            kind = ErrorKind.NETWORK
    except ValueError:
        pass  # an error code this libflatpak does not know
    if kind is ErrorKind.FAILED and any(h in err.message.lower() for h in _NETWORK_HINTS):
        kind = ErrorKind.NETWORK
    return BackendError(kind, err.message, Source.FLATPAK)


def _is_flatpak_error(err: Exception, code) -> bool:
    return (isinstance(err, GLib.Error)
            and err.matches(Flatpak.Error.quark(), code))


# -- installations and ids --------------------------------------------------


def _installations() -> list[tuple[str, Flatpak.Installation]]:
    """(label, installation) pairs, the install target first."""
    found: list[tuple[str, Flatpak.Installation]] = []
    try:
        found.append((_USER, Flatpak.Installation.new_user(None)))
    except GLib.Error:
        pass
    try:
        for inst in Flatpak.get_system_installations(None):
            found.append((_SYSTEM if inst.get_id() == "default" else f"{_SYSTEM}:{inst.get_id()}",
                          inst))
    except GLib.Error:
        pass
    found.sort(key=lambda pair: pair[0] != _INSTALL_TARGET)  # stable: target first
    return found


def _installation(label: str) -> Flatpak.Installation:
    for lbl, inst in _installations():
        if lbl == label:
            return inst
    raise BackendError(ErrorKind.NOT_FOUND, f"No Flatpak installation named {label!r}",
                       Source.FLATPAK)


def _make_id(label: str, ref: str) -> str:
    return f"{label}/{ref}"


def _parse_id(pkg_id: str) -> tuple[str, str]:
    label, sep, ref = pkg_id.partition("/")
    if not sep or len(ref.split("/")) != 4 or ref.split("/")[0] not in ("app", "runtime"):
        raise BackendError(ErrorKind.FAILED, f"Not a Flatpak package id: {pkg_id!r}",
                           Source.FLATPAK)
    return label, ref


def _origin_text(remote: str, label: str) -> str:
    return f"{remote} ({'user' if label == _USER else 'system'})"


def _remote_from_origin(origin: Optional[str]) -> Optional[str]:
    """Inverse of _origin_text: 'flathub (user)' gives 'flathub'."""
    if not origin:
        return None
    name, sep, _ = origin.rpartition(" (")
    return name if sep else origin


def _short(commit: Optional[str]) -> str:
    return (commit or "")[:12]


# -- remote ref cache --------------------------------------------------------


@dataclass(frozen=True)
class _RemoteApp:
    label: str  # installation that owns the remote
    remote: str
    name: str
    ref: str  # "app/<name>/<arch>/<branch>"
    installed_size: Optional[int]
    download_size: Optional[int]


def _pick_branch(refs):
    return min(refs, key=lambda r: (r.get_branch() != "stable", r.get_branch()))


def _load_remote_apps() -> dict[str, _RemoteApp]:
    """Every installable app ref from the enabled remotes. Network.

    Remotes are read in install-target-first order; the first remote that offers
    an app wins, and a remote already read through another installation (same
    URL) is skipped. A remote that fails is skipped unless all of them fail.
    """
    arches = set(Flatpak.get_supported_arches())
    apps: dict[str, _RemoteApp] = {}
    seen_urls: set[str] = set()
    first_error: Optional[Exception] = None
    succeeded = False
    installations = _installations()
    # Remotes the install target has, by URL: an app listed through another
    # installation (because the target's read failed) still installs to the target.
    target_remotes = {r.get_url(): r.get_name()
                      for lbl, inst in installations if lbl == _INSTALL_TARGET
                      for r in inst.list_remotes(None) if not r.get_disabled()}
    for label, inst in installations:
        for remote in inst.list_remotes(None):
            if remote.get_disabled() or remote.get_url() in seen_urls:
                continue
            try:
                refs = inst.list_remote_refs_sync(remote.get_name(), None)
            except GLib.Error as e:
                first_error = first_error or e
                continue
            succeeded = True
            seen_urls.add(remote.get_url())
            if remote.get_url() in target_remotes:
                app_label, remote_name = _INSTALL_TARGET, target_remotes[remote.get_url()]
            else:
                app_label, remote_name = label, remote.get_name()
            by_name: dict[str, list] = {}
            for r in refs:
                if r.get_kind() == Flatpak.RefKind.APP and r.get_arch() in arches:
                    by_name.setdefault(r.get_name(), []).append(r)
            for name, candidates in by_name.items():
                if name in apps:
                    continue
                r = _pick_branch(candidates)
                apps[name] = _RemoteApp(
                    app_label, remote_name, name,
                    f"app/{name}/{r.get_arch()}/{r.get_branch()}",
                    r.get_installed_size() or None, r.get_download_size() or None)
    if not succeeded and first_error is not None:
        raise first_error
    return apps


# -- conversions -------------------------------------------------------------


def _installed_package(label: str, ref: Flatpak.InstalledRef,
                       remote: Optional[_RemoteApp] = None) -> Package:
    name = ref.get_name()
    return Package(
        id=_make_id(label, ref.format_ref()),
        name=name,
        version=ref.get_appdata_version() or _short(ref.get_commit()),
        summary=ref.get_appdata_summary() or "",
        source=Source.FLATPAK,
        installed=True,
        title=ref.get_appdata_name() or None,
        app_id=name,
        origin=_origin_text(ref.get_origin(), label),
        icon=name,  # flatpak exports icons under the app ID
        installed_size=ref.get_installed_size() or None,
        download_size=remote.download_size if remote else None,
    )


def _remote_package(app: _RemoteApp) -> Package:
    return Package(
        id=_make_id(app.label, app.ref),
        name=app.name,
        version="",  # no appdata without installing; the catalog lane has the text
        summary="",
        source=Source.FLATPAK,
        installed=False,
        app_id=app.name,
        origin=_origin_text(app.remote, app.label),
        installed_size=app.installed_size,
        download_size=app.download_size,
    )


def _installed_apps() -> list[tuple[str, Flatpak.InstalledRef]]:
    out = []
    for label, inst in _installations():
        for ref in inst.list_installed_refs(None):
            if ref.get_kind() == Flatpak.RefKind.APP:
                out.append((label, ref))
    return out


def _find_installed(label: str, ref_str: str) -> Optional[Flatpak.InstalledRef]:
    _, name_arch_branch = ref_str.split("/", 1)
    name, arch, branch = name_arch_branch.split("/")
    try:
        return _installation(label).get_installed_ref(
            Flatpak.RefKind.APP if ref_str.startswith("app/") else Flatpak.RefKind.RUNTIME,
            name, arch, branch, None)
    except GLib.Error as e:
        if _is_flatpak_error(e, Flatpak.Error.NOT_INSTALLED):
            return None
        raise


def _appstream_versions(wanted: dict[str, set[str]]) -> dict[str, str]:
    """Newest release version per app ID from the remote's local appstream file.

    `wanted` maps an appstream.xml path to the app IDs to look up there. Best
    effort: any failure just leaves the app out (the caller falls back to the commit).
    """
    versions: dict[str, str] = {}
    for path, ids in wanted.items():
        try:
            for _event, elem in ET.iterparse(path, events=("end",)):
                if elem.tag != "component":
                    continue
                cid = (elem.findtext("id") or "").removesuffix(".desktop")
                if cid in ids:
                    release = elem.find("releases/release")
                    if release is not None and release.get("version"):
                        versions[cid] = release.get("version")
                elem.clear()
        except (OSError, ET.ParseError):
            continue
    return versions


# -- transactions -------------------------------------------------------------

_VERBS = {
    Flatpak.TransactionOperationType.INSTALL: "Installing",
    Flatpak.TransactionOperationType.UPDATE: "Updating",
    Flatpak.TransactionOperationType.UNINSTALL: "Removing",
}


def _transact(inst: Flatpak.Installation, add_ops: Callable[[Flatpak.Transaction], None],
              progress: Optional[OnProgress], simulate: bool,
              lo: int = 0, hi: int = 100) -> list[str]:
    """Run one transaction on the calling (worker) thread.

    Returns "<verb> <ref>" for each operation. With simulate it aborts from the
    ready signals, which libflatpak emits after the operations are resolved but
    before any pull, deploy or authentication, and counts that abort as success.
    Overall progress is scaled into [lo, hi].
    """
    t = Flatpak.Transaction.new_for_installation(inst, None)
    t.set_no_interaction(simulate)  # a real change may need the polkit prompt
    # Let a user install reuse runtimes that are already installed system-wide.
    t.add_default_dependency_sources()
    add_ops(t)

    ops: list[str] = []
    state = {"total": 0, "index": -1, "last": None}
    lock = threading.Lock()

    def collect(transaction) -> bool:
        ops[:] = [f"{_VERBS.get(op.get_operation_type(), 'Changing')} {op.get_ref()}"
                  for op in transaction.get_operations()]
        state["total"] = len(ops)
        return not simulate  # False aborts before anything changes

    def report(pct: Optional[int], status: str) -> None:
        if progress is None:
            return
        with lock:
            if state["last"] == (pct, status):
                return
            state["last"] = (pct, status)
        progress(Progress(pct, status))

    def new_operation(_t, op, op_progress) -> None:
        state["index"] += 1
        index = state["index"]
        verb = _VERBS.get(op.get_operation_type(), "Working on")
        status = f"{verb} {op.get_ref().split('/')[1]}"

        def changed(p) -> None:
            total = max(state["total"], 1)
            frac = (index + max(0, min(p.get_progress(), 100)) / 100) / total
            report(lo + int(frac * (hi - lo)), status)

        op_progress.connect("changed", changed)
        op_progress.set_update_frequency(200)
        report(lo + int(index / max(state["total"], 1) * (hi - lo)), status)

    def operation_error(_t, _op, _error, details) -> bool:
        # Continue only past non-fatal problems (for example a missing extension).
        return not (int(details) & int(Flatpak.TransactionErrorDetails.FATAL))

    t.connect("ready-pre-auth", collect)
    t.connect("ready", collect)
    t.connect("new-operation", new_operation)
    t.connect("operation-error", operation_error)

    try:
        t.run(None)
    except GLib.Error as e:
        if simulate and _is_flatpak_error(e, Flatpak.Error.ABORTED):
            return ops  # our own abort: the simulation worked
        raise
    return ops


class FlatpakBackend:
    source = Source.FLATPAK

    def __init__(self) -> None:
        self._remote_apps: Optional[dict[str, _RemoteApp]] = None
        self._lock = threading.Lock()
        # Operations the last simulate=True call resolved, for diagnostics and tests.
        self.last_simulation: list[str] = []

    def available(self) -> bool:
        try:
            return bool(_installations())
        except Exception:  # noqa: BLE001 - a broken libflatpak means "not available"
            return False

    # -- reads ----------------------------------------------------------

    def _remote_cache(self) -> dict[str, _RemoteApp]:
        """Remote app refs for the session. Worker thread only (network)."""
        with self._lock:
            cache = self._remote_apps
        if cache is None:
            cache = _load_remote_apps()
            with self._lock:
                self._remote_apps = cache
        return cache

    def _cached_remote(self, name: str) -> Optional[_RemoteApp]:
        with self._lock:
            return (self._remote_apps or {}).get(name)

    def lookup(self, name: str, done: Done[Package]) -> None:
        def work() -> Package:
            for label, ref in _installed_apps():
                if ref.get_name() == name:
                    return _installed_package(label, ref, self._cached_remote(name))
            app = self._remote_cache().get(name)
            if app is None:
                raise BackendError(ErrorKind.NOT_FOUND,
                                   f"{name} is not installed and no Flatpak remote offers it",
                                   Source.FLATPAK)
            return _remote_package(app)

        run_blocking(work, done, map_error)

    def search(self, query: str, done: Done[list[Package]]) -> None:
        def work() -> list[Package]:
            needle = query.strip().lower()
            if not needle:
                return []
            found: dict[str, Package] = {}
            for label, ref in _installed_apps():
                if needle in ref.get_name().lower():
                    found.setdefault(ref.get_name(),
                                     _installed_package(label, ref,
                                                        self._cached_remote(ref.get_name())))
            for name, app in self._remote_cache().items():
                if needle in name.lower() and name not in found:
                    found[name] = _remote_package(app)
            return sorted(found.values(), key=lambda p: (not p.installed, p.name.lower()))

        run_blocking(work, done, map_error)

    def list_installed(self, done: Done[list[Package]]) -> None:
        def work() -> list[Package]:
            pkgs = [_installed_package(label, ref, self._cached_remote(ref.get_name()))
                    for label, ref in _installed_apps()]
            return sorted(pkgs, key=lambda p: p.name.lower())

        run_blocking(work, done, map_error)

    def get_updates(self, done: Done[list[Package]]) -> None:
        def work() -> list[Package]:
            pending = []  # (label, installed pkg, latest commit, appstream path)
            wanted: dict[str, set[str]] = {}
            for label, inst in _installations():
                for ref in inst.list_installed_refs_for_update(None):
                    if ref.get_kind() != Flatpak.RefKind.APP:
                        continue
                    path = None
                    try:
                        appstream = inst.get_remote_by_name(ref.get_origin(), None).get_appstream_dir()
                        if appstream is not None:
                            path = f"{appstream.get_path()}/appstream.xml"
                    except GLib.Error:
                        pass
                    if path:
                        wanted.setdefault(path, set()).add(ref.get_name())
                    pending.append((label, ref, path))
            versions = _appstream_versions(wanted) if wanted else {}
            out = []
            for label, ref, path in pending:
                pkg = _installed_package(label, ref)
                remote_version = versions.get(ref.get_name()) if path else None
                # An unchanged version string would hide the update: show the commit then.
                if not remote_version or remote_version == pkg.version:
                    remote_version = _short(ref.get_latest_commit())
                out.append(dataclasses.replace(pkg, update_version=remote_version))
            return sorted(out, key=lambda p: p.name.lower())

        run_blocking(work, done, map_error)

    # -- changes --------------------------------------------------------

    def _install_target(self, pkg: Package) -> tuple[str, str, str]:
        """(installation label, remote name, ref) for installing `pkg`."""
        label, ref = _parse_id(pkg.id)
        remote = _remote_from_origin(pkg.origin)
        if not remote:
            app = self._remote_cache().get(pkg.name)
            if app is None or app.label != label:
                raise BackendError(ErrorKind.NOT_FOUND,
                                   f"No Flatpak remote known for {pkg.name}", Source.FLATPAK)
            remote = app.remote
        return label, remote, ref

    def install(self, pkg: Package, progress: OnProgress, done: Done[Package],
                simulate: bool = False) -> None:
        report = on_main(progress)

        def work() -> Package:
            label, remote, ref = self._install_target(pkg)
            inst = _installation(label)
            ops = _transact(inst, lambda t: t.add_install(remote, ref, None), report, simulate)
            if simulate:
                self.last_simulation = ops
                return pkg
            installed = _find_installed(label, ref)
            if installed is None:
                raise BackendError(ErrorKind.FAILED,
                                   f"{pkg.name} is still not installed after the transaction",
                                   Source.FLATPAK)
            return _installed_package(label, installed, self._cached_remote(pkg.name))

        run_blocking(work, done, map_error)

    def install_flatpakref(self, ref, progress: OnProgress, done: Done[Package],
                           simulate: bool = False) -> None:
        """Install the app a .flatpakref file names (links.FlatpakRef) into the user
        installation. The caller asks the person first. Refused unless the file's
        repository is https and either the file carries a GPGKey or a remote with
        that address already exists in the user installation (libflatpak then reuses
        that remote and its key)."""
        from .links import ref_source_problem
        report = on_main(progress) if progress is not None else None

        def work() -> Package:
            inst = _installation(_INSTALL_TARGET)
            urls = [r.get_url() for r in inst.list_remotes(None)]
            problem = ref_source_problem(ref, urls)
            if problem:
                raise BackendError(ErrorKind.UNSUPPORTED, problem, Source.FLATPAK)
            data = GLib.Bytes.new(ref.data)
            ops = _transact(inst, lambda t: t.add_install_flatpakref(data), report, simulate)
            if simulate:
                self.last_simulation = ops
                return Package(id=f"{_INSTALL_TARGET}/app/{ref.name}", name=ref.name,
                               version="", summary="", source=Source.FLATPAK,
                               installed=False, title=ref.title, app_id=ref.name)
            for label, installed in _installed_apps():
                if label == _INSTALL_TARGET and installed.get_name() == ref.name:
                    return _installed_package(label, installed, None)
            raise BackendError(ErrorKind.FAILED,
                               f"{ref.title} is still not installed after the transaction",
                               Source.FLATPAK)

        run_blocking(work, done, map_error)

    def remove(self, pkg: Package, progress: OnProgress, done: Done[Package],
               simulate: bool = False) -> None:
        report = on_main(progress)

        def work() -> Package:
            label, ref = _parse_id(pkg.id)
            inst = _installation(label)
            ops = _transact(inst, lambda t: t.add_uninstall(ref), report, simulate)
            if simulate:
                self.last_simulation = ops
                return pkg
            if _find_installed(label, ref) is not None:
                raise BackendError(ErrorKind.FAILED,
                                   f"{pkg.name} is still installed after the transaction",
                                   Source.FLATPAK)
            return dataclasses.replace(pkg, installed=False, installed_size=None,
                                       update_version=None)

        run_blocking(work, done, map_error)

    def update(self, pkgs: list[Package], progress: OnProgress, done: Done[list[Package]],
               simulate: bool = False) -> None:
        report = on_main(progress)

        def work() -> list[Package]:
            groups: dict[str, list[str]] = {}
            for pkg in pkgs:
                label, ref = _parse_id(pkg.id)
                groups.setdefault(label, []).append(ref)
            all_ops: list[str] = []
            for n, (label, refs) in enumerate(groups.items()):
                lo, hi = 100 * n // len(groups), 100 * (n + 1) // len(groups)

                def add(t, refs=refs):
                    for r in refs:
                        t.add_update(r, None, None)

                all_ops += _transact(_installation(label), add, report, simulate, lo, hi)
            if simulate:
                self.last_simulation = all_ops
                return list(pkgs)
            out = []
            for pkg in pkgs:
                label, ref = _parse_id(pkg.id)
                installed = _find_installed(label, ref)
                if installed is None:
                    raise BackendError(ErrorKind.FAILED,
                                       f"{pkg.name} is missing after the update", Source.FLATPAK)
                out.append(_installed_package(label, installed, self._cached_remote(pkg.name)))
            return out

        run_blocking(work, done, map_error)
