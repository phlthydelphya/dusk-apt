"""Ubuntu archive mirrors: find the current one, speed-test candidates, switch.

Modelled on Linux Mint's Software Sources. Only the main archive moves; the
security stanza stays on security.ubuntu.com. A switch rewrites the URIs field
of the main-archive stanzas in ubuntu.sources and nothing else (comments, field
order and Signed-By survive: repos.py's round-trip rule), writes it through the
root helper, then refreshes the APT cache through PackageKit.

Everything that touches the outside (network, files, the root helper, PackageKit)
is injectable, so tests run offline and never need root.

Staleness caveat: the check compares the Date of dists/<codename>/InRelease. On a
released series that file changes only at release time, so a mirror that merely
lags on -updates or -security is not detected. It is meaningful on a development
series, which is what this machine runs.
"""

from __future__ import annotations

import json
import logging
import re
import time
import urllib.request
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import urlsplit

from debian._deb822_repro import parse_deb822_file

from . import repos
from .backend import (BackendError, Done, ErrorKind, Once, OnProgress, Progress, Source, on_main,
                      run_blocking)
from .system import Mirror

log = logging.getLogger(__name__)

SOURCES_FILE = Path("/etc/apt/sources.list.d/ubuntu.sources")
OS_RELEASE = Path("/etc/os-release")
MIRRORS_LIST_URL = "http://mirrors.ubuntu.com/mirrors.txt"
OFFICIAL_URL = "http://archive.ubuntu.com/ubuntu/"
SECURITY_HOST = "security.ubuntu.com"
MAX_PARALLEL = 6
TEST_TIMEOUT = 5.0
LIST_TIMEOUT = 10.0
STALE_AFTER = timedelta(hours=6)
MAX_BODY = 8 * 1024 * 1024

_OFFICIAL_HOST = re.compile(r"^(?:[a-z]{2}\.)?archive\.ubuntu\.com$")
_CC_ARCHIVE = re.compile(r"^([a-z]{2})\.archive\.ubuntu\.com$")
# Country-code TLDs that are used as ordinary brand domains, so say nothing about location.
_GENERIC_CCTLD = frozenset({"io", "tv", "co", "me", "ai", "cc", "ws", "fm", "to", "ly", "sh",
                            "gg", "ac", "su", "sc", "gl", "gd", "ms", "tk", "ml", "ga", "cf"})


# -- fetching ---------------------------------------------------------------------

@dataclass(frozen=True)
class Fetched:
    body: bytes
    seconds: float  # wall time of the download


Fetcher = Callable[[str, float], Fetched]  # (url, timeout) -> Fetched; raises on any failure
Writer = Callable[[str, str, Done], None]  # (basename, text, done) -> root helper write
Refresher = Callable[[Done], None]


def http_fetch(url: str, timeout: float) -> Fetched:
    """GET `url`. `timeout` bounds the whole download, not just each socket wait."""
    if not url.startswith(("http://", "https://")):
        raise ValueError(f"not an http(s) URL: {url}")
    start = time.monotonic()
    deadline = start + timeout
    req = urllib.request.Request(url, headers={"User-Agent": "AppHub-mirror-test"})
    chunks: list[bytes] = []
    size = 0
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 - scheme checked
        while True:
            chunk = resp.read(65536)
            if not chunk:
                break
            chunks.append(chunk)
            size += len(chunk)
            if size > MAX_BODY:
                raise ValueError("reply too large")
            if time.monotonic() > deadline:
                raise TimeoutError(f"timed out after {timeout:g}s")
    return Fetched(b"".join(chunks), max(time.monotonic() - start, 1e-6))


# -- URLs -------------------------------------------------------------------------

def validate_mirror_url(url: str) -> None:
    """Raise ValueError unless `url` is a plain http(s) archive root ending in "/"."""
    if not isinstance(url, str) or not url or re.search(r"\s", url):
        raise ValueError("mirror URL is empty or contains whitespace")
    if not url.startswith(("http://", "https://")):
        raise ValueError("mirror URL must start with http:// or https://")
    parts = urlsplit(url)
    if not parts.hostname:
        raise ValueError("mirror URL has no host")
    if parts.query or parts.fragment or "@" in parts.netloc:
        raise ValueError("mirror URL must not carry a query, fragment or credentials")
    if not url.endswith("/"):
        raise ValueError("mirror URL must end with /")


def normalize_url(url: str) -> str:
    """Canonical form for comparing and deduplicating: lowercase scheme and host, one
    trailing slash. Raises ValueError for anything that is not an http(s) URL."""
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        raise ValueError(f"not an http(s) URL: {url!r}")
    parts = urlsplit(url)
    if not parts.hostname:
        raise ValueError(f"no host in {url!r}")
    netloc = parts.hostname.lower()
    if parts.port and parts.port != (443 if parts.scheme == "https" else 80):
        netloc += f":{parts.port}"
    path = parts.path.rstrip("/") + "/"
    return f"{parts.scheme.lower()}://{netloc}{path}"


def _dedupe_key(url: str) -> str:
    """Scheme-blind key: the same host and path over http and https is one mirror."""
    return normalize_url(url).split("://", 1)[1]


def host_of(url: str) -> str:
    return urlsplit(url.removeprefix("mirror+")).hostname or url


def is_official(url: str) -> bool:
    return bool(_OFFICIAL_HOST.match(host_of(url).lower()))


def country_of(url: str) -> Optional[str]:
    """ISO 3166 code guessed from the host: <cc>.archive.ubuntu.com or a country TLD."""
    host = host_of(url).lower()
    m = _CC_ARCHIVE.match(host)
    if m:
        return m.group(1).upper()
    tld = host.rsplit(".", 1)[-1]
    if len(tld) == 2 and tld.isalpha() and tld not in _GENERIC_CCTLD:
        return "GB" if tld == "uk" else tld.upper()
    return None


_country_names: Optional[dict[str, str]] = None


def country_name(code: Optional[str]) -> Optional[str]:
    """English name for an ISO code (iso-codes package), or the code itself."""
    global _country_names
    if not code:
        return None
    if _country_names is None:
        _country_names = {}
        try:
            data = json.loads(Path("/usr/share/iso-codes/json/iso_3166-1.json")
                              .read_text(encoding="utf-8"))
            for c in data.get("3166-1", []):
                _country_names[c["alpha_2"]] = c.get("common_name") or c["name"]
        except (OSError, ValueError, KeyError):
            pass
    return _country_names.get(code.upper(), code.upper())


def make_mirror(url: str, current: bool = False) -> Mirror:
    url = normalize_url(url)
    return Mirror(url=url, name=host_of(url), country=country_of(url),
                  current=current, official=is_official(url))


# -- ubuntu.sources (pure) ---------------------------------------------------------

def _words(value: Optional[str]) -> list[str]:
    return value.split() if value else []


def _is_main_stanza(p) -> bool:
    """Not the security stanza: it has a non-security suite, or an archive other than
    security.ubuntu.com."""
    suites = _words(p.get("Suites"))
    uris = _words(p.get("URIs"))
    if any(not s.endswith("-security") for s in suites):
        return True
    return any(host_of(u) != SECURITY_HOST for u in uris)


def read_current_url(text: str) -> str:
    """The archive URI of the main-archive stanzas. Raises ValueError when there is none."""
    try:
        stanzas = list(parse_deb822_file(text.splitlines(keepends=True)))
    except Exception as e:  # noqa: BLE001 - the parser raises several types
        raise ValueError(f"cannot parse ubuntu.sources: {e}") from None
    fallback = None
    for p in stanzas:
        if not _is_main_stanza(p):
            continue
        for u in _words(p.get("URIs")):
            if host_of(u) != SECURITY_HOST:
                return u
            fallback = fallback or u
    if fallback:
        return fallback
    raise ValueError("no main archive stanza in ubuntu.sources")


def rewrite_sources(text: str, url: str) -> str:
    """New ubuntu.sources text with the main-archive URIs pointing at `url`.

    Only the URIs value of main stanzas changes; a stanza that lists security.ubuntu.com
    keeps that entry. Everything else is byte for byte what it was.
    """
    validate_mirror_url(url)
    try:
        file = parse_deb822_file(text.splitlines(keepends=True))
        stanzas = list(file)
    except Exception as e:  # noqa: BLE001
        raise ValueError(f"cannot parse ubuntu.sources: {e}") from None
    changed = 0
    for p in stanzas:
        if not _is_main_stanza(p):
            continue
        new: list[str] = []
        for u in _words(p.get("URIs")):
            target = u if host_of(u) == SECURITY_HOST else url
            if target not in new:
                new.append(target)
        if new != _words(p.get("URIs")):
            p["URIs"] = " ".join(new)
            changed += 1
    if not changed:
        return text
    return file.dump()


def read_codename(path: Path = OS_RELEASE) -> str:
    """UBUNTU_CODENAME, else VERSION_CODENAME, from an os-release file."""
    values: dict[str, str] = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        key, sep, val = line.partition("=")
        if sep and not line.lstrip().startswith("#"):
            values[key.strip()] = val.strip().strip("\"'")
    codename = values.get("UBUNTU_CODENAME") or values.get("VERSION_CODENAME")
    if not codename or not re.fullmatch(r"[a-z][a-z0-9-]*", codename):
        raise ValueError("cannot tell the Ubuntu release name from os-release")
    return codename


# -- InRelease ----------------------------------------------------------------------

def parse_release_date(body: bytes) -> Optional[datetime]:
    """The Date: field of an InRelease file (UTC), or None when absent or unparsable."""
    for raw in body.decode("utf-8", "replace").splitlines():
        if raw.startswith("-----BEGIN PGP SIGNATURE"):
            break
        if raw.startswith("Date:"):
            try:
                when = parsedate_to_datetime(raw[5:].strip())
            except (TypeError, ValueError):
                return None
            return when.replace(tzinfo=timezone.utc) if when.tzinfo is None else when
    return None


def stale_text(mirror_date: datetime, official_date: datetime) -> Optional[str]:
    """"2 days behind" when the mirror trails the official archive by more than 6 hours."""
    behind = official_date - mirror_date
    if behind <= STALE_AFTER:
        return None
    days = behind.days
    if days >= 1:
        return f"{days} day{'s' if days != 1 else ''} behind"
    hours = int(behind.total_seconds() // 3600)
    return f"{hours} hours behind"


def sort_tested(mirrors: list[Mirror]) -> list[Mirror]:
    """Fresh mirrors by speed descending, then stale ones, then failures (no speed)."""
    def rank(m: Mirror) -> int:
        if m.speed_bytes_per_s is None:
            return 2
        return 1 if m.stale else 0

    return sorted(mirrors, key=lambda m: (rank(m), -(m.speed_bytes_per_s or 0.0)))


def _map_exc(e: Exception) -> BackendError:
    if isinstance(e, BackendError):
        return e
    if isinstance(e, FileNotFoundError):
        return BackendError(ErrorKind.NOT_FOUND, str(e), Source.APT)
    if isinstance(e, (OSError, TimeoutError)) and not isinstance(e, PermissionError):
        return BackendError(ErrorKind.NETWORK, str(e), Source.APT)
    return BackendError(ErrorKind.FAILED, str(e), Source.APT)


def _default_writer(basename: str, text: str, done: Done) -> None:
    repos.add_repo_async(basename, text, done)


def _default_refresher(done: Done) -> None:
    from .ppa import packagekit_refresh  # lazy: pulls PackageKit in only when switching
    packagekit_refresh(done)


# -- the backend ----------------------------------------------------------------------

class UbuntuMirrors:
    """Implements system.Mirrors for the Ubuntu archive.

    The Mirror contract has no field for a warning, so a refresh that failed after a
    successful switch is left in `last_warning` (None otherwise) before `done` runs.
    """

    def __init__(self, sources_path: Path = SOURCES_FILE, os_release: Path = OS_RELEASE,
                 fetch: Fetcher = http_fetch, writer: Optional[Writer] = None,
                 refresh: Optional[Refresher] = None, list_url: str = MIRRORS_LIST_URL,
                 official_url: str = OFFICIAL_URL, max_parallel: int = MAX_PARALLEL,
                 timeout: float = TEST_TIMEOUT):
        self._sources = Path(sources_path)
        self._os_release = Path(os_release)
        self._fetch = fetch
        self._write = writer or _default_writer
        self._refresh = refresh or _default_refresher
        self._list_url = list_url
        self._official_url = official_url
        self._max_parallel = max(1, max_parallel)
        self._timeout = timeout
        self.last_warning: Optional[str] = None

    # -- current ---------------------------------------------------------

    def _read_current(self) -> Mirror:
        text = self._sources.read_text(encoding="utf-8")
        try:
            url = read_current_url(text)
        except ValueError as e:
            raise BackendError(ErrorKind.NOT_FOUND, str(e), Source.APT) from None
        if url.startswith("mirror+"):  # apt's mirror method: report it, do not guess a host
            return Mirror(url=url, name=host_of(url), current=True)
        return make_mirror(url, current=True)

    def current(self, done: Done[Mirror]) -> None:
        run_blocking(self._read_current, done, _map_exc)

    # -- candidates ------------------------------------------------------

    def _candidates(self) -> list[Mirror]:
        body = self._fetch(self._list_url, LIST_TIMEOUT).body.decode("utf-8", "replace")
        found: dict[str, Mirror] = {}

        def add(m: Mirror) -> None:
            key = _dedupe_key(m.url)
            if key not in found:
                found[key] = m
            elif m.current and not found[key].current:
                found[key] = replace(found[key], current=True)

        try:
            add(self._read_current())
        except Exception:  # noqa: BLE001 - unreadable sources file: still offer the list
            pass
        add(make_mirror(self._official_url))
        for line in body.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            try:
                add(make_mirror(line))
            except ValueError:
                continue  # not an http(s) archive URL: skip the line
        if not found:
            raise BackendError(ErrorKind.FAILED, "no mirrors found", Source.APT)
        return list(found.values())

    def candidates(self, done: Done[list[Mirror]]) -> None:
        run_blocking(self._candidates, done, _map_exc)

    # -- test --------------------------------------------------------------

    def _inrelease(self, url: str, codename: str) -> Optional[tuple[float, Optional[datetime]]]:
        """(bytes per second, Date) for one mirror, or None when it failed."""
        try:
            got = self._fetch(f"{url}dists/{codename}/InRelease", self._timeout)
        except Exception as e:  # noqa: BLE001 - any failure is "this mirror does not work"
            log.info("mirror %s failed: %s", url, e)
            return None
        if not got.body:
            return None
        return len(got.body) / max(got.seconds, 1e-6), parse_release_date(got.body)

    def _test(self, mirrors: list[Mirror], progress: OnProgress) -> list[Mirror]:
        if not mirrors:
            return []
        try:
            codename = read_codename(self._os_release)
        except (OSError, ValueError) as e:
            raise BackendError(ErrorKind.FAILED, str(e), Source.APT) from None
        official_key = _dedupe_key(self._official_url)
        report = on_main(progress)
        out: list[Mirror] = []
        with ThreadPoolExecutor(max_workers=self._max_parallel) as pool:
            # Submitted first, so with FIFO workers it never waits behind the mirrors that wait on it.
            ref: Future = pool.submit(self._inrelease, normalize_url(self._official_url), codename)

            def one(m: Mirror):
                if _dedupe_key(m.url) == official_key:
                    return ref.result()
                return self._inrelease(m.url, codename)

            futures = {pool.submit(one, m): m for m in mirrors}
            total = len(futures)
            for n, fut in enumerate(as_completed(futures), start=1):
                m = futures[fut]
                try:
                    res = fut.result()
                except Exception:  # noqa: BLE001
                    res = None
                if res is None:
                    out.append(replace(m, speed_bytes_per_s=None, stale=None))
                else:
                    speed, date = res
                    official = ref.result()
                    stale = None
                    if date and official and official[1]:
                        stale = stale_text(date, official[1])
                    out.append(replace(m, speed_bytes_per_s=speed, stale=stale))
                report(Progress(n * 100 // total, f"Testing {m.name}"))
        return sort_tested(out)

    def test(self, mirrors: list[Mirror], progress: OnProgress, done: Done[list[Mirror]]) -> None:
        run_blocking(lambda: self._test(list(mirrors), progress), done, _map_exc)

    # -- use / reset -----------------------------------------------------

    def use(self, mirror: Mirror, done: Done[Mirror]) -> None:
        done = Once(done)
        self.last_warning = None
        try:
            validate_mirror_url(mirror.url)
            old = self._sources.read_text(encoding="utf-8")
            new = rewrite_sources(old, mirror.url)
        except Exception as e:  # noqa: BLE001
            done(None, self._invalid(e))
            return
        result = replace(mirror, current=True, official=is_official(mirror.url))
        if new == old:  # already there: nothing to write, no password
            done(result, None)
            return

        def written(_ok, error: Optional[BackendError]) -> None:
            if error is not None:
                done(None, error)
                return
            self._after_write(result, done)

        try:
            self._write(self._sources.name, new, written)
        except Exception as e:  # noqa: BLE001
            done(None, _map_exc(e))

    @staticmethod
    def _invalid(e: Exception) -> BackendError:
        if isinstance(e, ValueError):
            return BackendError(ErrorKind.UNSUPPORTED, str(e), Source.APT)
        return _map_exc(e)

    def _after_write(self, result: Mirror, done: Done[Mirror]) -> None:
        def refreshed(_ok, error: Optional[BackendError]) -> None:
            if error is not None:
                log.warning("APT cache refresh failed: %s", error.message)
                self.last_warning = ("Mirror changed, but the package list was not "
                                     f"refreshed: {error.message}")
            done(result, None)

        try:
            self._refresh(refreshed)
        except Exception as e:  # noqa: BLE001
            refreshed(None, _map_exc(e))

    def reset(self, done: Done[Mirror]) -> None:
        self.use(make_mirror(self._official_url), done)
