"""Bridge to Dusk's theming engine: give a widget the Dusk palette seeded from an app icon.

Dusk's "Match Colors to Wallpaper" seeds the whole desktop from the wallpaper with
tokens/dusk_seed.py (Strata's remap, held to Dusk's contrast floors). AppHub runs
the same engine with an app's icon as the seed, so a hero slide, a tile or a
details page wears that app's colours while staying inside Dusk's rules.

How it reaches the screen: Dusk's libadwaita CSS defines --accent-bg-color,
--card-bg-color, ... on :root and its rules read them with var(). A class that
redefines those variables on a widget re-themes everything inside it, so
buttons, cards and links follow without AppHub restyling them.

Without Dusk's engine (another desktop, or Dusk not installed) nothing is
seeded and widgets keep the current theme.
"""

from __future__ import annotations

import hashlib
import importlib
import json
import logging
import os
import sys
from pathlib import Path
from typing import Callable, Optional

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, Gio, GLib, Gtk  # noqa: E402

from .backend import run_blocking  # noqa: E402

log = logging.getLogger("apphub.seed")

# The dusk-theme package first; the source checkout is the dev fallback. dusk_seed finds
# Strata itself (../strata in a checkout, else the dusk-strata package's module).
TOKEN_DIRS = (Path("/usr/share/dusk-theme/src/tokens"), Path.home() / "dusk-theme" / "tokens")
# The live theme's palette, written by Dusk whenever it re-seeds (wallpaper or accent mode).
LIVE_SEED = Path(GLib.get_user_state_dir()) / "dusk" / "seed.json"
CACHE_DIR = Path(GLib.get_user_cache_dir()) / "apphub" / "seeds"
# Bump when the CSS a palette produces or the palette fields change.
_CACHE_VERSION = 2

# Palette keys AppHub uses from dusk_seed.seed(); accent-fg comes from the stock tokens.
# A palette holds both of Dusk's schemes: the dark keys as they are, the light ones
# (dusk_seed's "light" block) prefixed LIGHT. The light scheme's accent-bg is the
# dark one's, as in Dusk.
_KEYS = ("frame", "base", "card", "popover", "raised", "accent", "accent-bg")
LIGHT = "light-"

Palette = dict[str, str]


class Engine:
    """Loads dusk_seed lazily; `available` is False when Dusk is not on this machine."""

    def __init__(self, token_dirs=TOKEN_DIRS):
        self._dirs = token_dirs
        self._mod = None
        self._tokens = None
        self._stamp = ""
        self._tried = False

    def _load(self) -> bool:
        if self._tried:
            return self._mod is not None
        self._tried = True
        for d in self._dirs:
            if (d / "dusk_seed.py").is_file():
                sys.path.insert(0, str(d))
                try:
                    self._mod = importlib.import_module("dusk_seed")
                    self._tokens = importlib.import_module("dusk_tokens")
                    self._stamp = str((d / "dusk_seed.py").stat().st_mtime_ns)
                    return True
                except Exception as e:  # noqa: BLE001 - a broken engine means "no seeding"
                    log.warning("Dusk seed engine at %s unusable: %s", d, e)
                    sys.path.remove(str(d))
        return False

    @property
    def available(self) -> bool:
        return self._load()

    def palette(self, image: str, style: str) -> Optional[Palette]:
        """Blocking. The seeded palette for `image`, from the disk cache when possible."""
        if not self._load():
            return None
        st = os.stat(image)
        key = hashlib.sha256(
            f"{_CACHE_VERSION}|{image}|{st.st_mtime_ns}|{st.st_size}|{style}|{self._stamp}".encode()
        ).hexdigest()[:24]
        cached = CACHE_DIR / f"{key}.json"
        try:
            return json.loads(cached.read_text())
        except (OSError, ValueError):
            pass
        data = self._mod.seed(image, style=style)
        pal = {k: data[k] for k in _KEYS}
        pal["accent-fg"] = self._tokens.tokens("blue", style=style)["accent-fg"]
        light = data.get("light") or {}
        for k in _KEYS:
            if k in light:
                pal[LIGHT + k] = light[k]
        pal[LIGHT + "accent-fg"] = self._tokens.tokens("blue", style=style, scheme="light")["accent-fg"]
        try:
            CACHE_DIR.mkdir(parents=True, exist_ok=True)
            tmp = cached.with_suffix(".tmp")
            tmp.write_text(json.dumps(pal))
            tmp.replace(cached)
        except OSError:
            pass  # cache is an optimisation
        return pal


def icon_file(icon: Optional[str], size: int = 128) -> Optional[str]:
    """Absolute file for an icon (path or theme name): seeding needs pixels."""
    if not icon:
        return None
    if os.path.isabs(icon):
        return icon if os.path.exists(icon) else None
    display = Gdk.Display.get_default()
    if display is None:
        return None
    theme = Gtk.IconTheme.get_for_display(display)
    if not theme.has_icon(icon):
        return None
    paintable = theme.lookup_icon(icon, None, size, 1, Gtk.TextDirection.NONE, 0)
    f = paintable.get_file()
    path = f.get_path() if f else None
    # Symbolic icons are one flat colour: a poor seed. Leave those unseeded.
    return path if path and "-symbolic" not in os.path.basename(path) else None


def live_palette(path: Path = LIVE_SEED) -> Optional[Palette]:
    """The palette the desktop is wearing right now, or None outside Dusk."""
    try:
        data = json.loads(path.read_text())
        pal = {k: data[k] for k in _KEYS}
    except (OSError, ValueError, KeyError):
        return None
    pal["accent-fg"] = data.get("accent-fg", "#FFFFFF")  # Dusk's accent-fg is white in every style
    light = data.get("light") or {}
    for k in _KEYS + ("accent-fg",):
        if k in light:
            pal[LIGHT + k] = light[k]
    return pal


def scheme_palette(p: Palette, light: bool) -> Palette:
    """The dark or light half of `p`; a key the light half lacks keeps its dark value."""
    if not light:
        return {k: v for k, v in p.items() if not k.startswith(LIGHT)}
    return {k: p.get(LIGHT + k, p[k]) for k in p if not k.startswith(LIGHT)}


def current_style() -> str:
    """Dusk style of the running theme: 'atomic' for Dusk-Atomic-*, else 'dusk'."""
    try:
        theme = Gio.Settings.new("org.gnome.desktop.interface").get_string("gtk-theme")
    except Exception:  # noqa: BLE001 - schema missing outside GNOME
        theme = ""
    return "atomic" if theme.startswith("Dusk-Atomic") else "dusk"


def css_class(app_id: str) -> str:
    return "seed-" + hashlib.sha1(app_id.encode()).hexdigest()[:10]


def palette_css(cls: str, p: Palette, light: bool = False) -> str:
    """Redefine libadwaita's colour variables inside `.cls`; Dusk's rules follow them."""
    p = scheme_palette(p, light)
    return (
        f".{cls} {{"
        f" --accent-bg-color: {p['accent-bg']}; --accent-color: {p['accent']};"
        f" --accent-fg-color: {p['accent-fg']};"
        f" --card-bg-color: {p['card']}; --view-bg-color: {p['base']};"
        f" --window-bg-color: {p['frame']}; --popover-bg-color: {p['popover']};"
        f" --seed-raised: {p['raised']}; }}\n"
    )


class Seeder:
    """Seeds widgets from app icons through one application-wide CSS provider."""

    def __init__(self, engine: Optional[Engine] = None, style: Optional[str] = None):
        self.engine = engine or Engine()
        self.style = style or current_style()
        self._css: dict[str, str] = {}
        self._palettes: dict[str, Palette] = {}
        self._pending: dict[str, list[Callable[[Optional[Palette]], None]]] = {}
        self._provider = Gtk.CssProvider()
        self._installed = False
        self._flush_id = 0
        # Dusk follows GNOME's light/dark switch: seeded surfaces use the matching
        # half of each palette and are re-tinted when it flips.
        self._style_manager = None
        self._light = False
        try:
            gi.require_version("Adw", "1")
            from gi.repository import Adw
            self._style_manager = Adw.StyleManager.get_default()
            self._light = not self._style_manager.get_dark()
            self._style_manager.connect("notify::dark", self._on_dark)
        except (ValueError, ImportError):
            pass
        self._flush()  # base classes exist even before the first palette

    def _on_dark(self, manager, _pspec) -> None:
        self._light = not manager.get_dark()
        self._css = {key: palette_css(css_class(key), pal, self._light)
                     for key, pal in self._palettes.items()}
        self._schedule_flush()

    def seed(self, widget: Gtk.Widget, app_id: str, icon: Optional[str],
             then: Optional[Callable[[Optional[Palette]], None]] = None) -> None:
        """Add app_id's seed class to `widget` once its palette is ready.

        `then(palette)` runs after the class is applied (palette None when unseeded).
        `icon` is a file or an icon-theme name; symbolic or missing icons leave the
        theme as it is.
        """
        def apply(pal: Optional[Palette]) -> None:
            if pal is not None:
                widget.add_css_class(css_class(app_id))
            if then:
                then(pal)

        if app_id in self._palettes:
            apply(self._palettes[app_id])
            return
        icon = icon_file(icon) if self.engine.available else None
        if not icon:
            apply(None)
            return
        waiting = self._pending.setdefault(app_id, [])
        waiting.append(apply)
        if len(waiting) > 1:
            return  # already computing

        def done(pal, err):
            if err:
                log.info("no seed for %s: %s", app_id, err.message)
            if pal is not None:
                self._palettes[app_id] = pal
                self._css[app_id] = palette_css(css_class(app_id), pal, self._light)
                self._schedule_flush()
            for cb in self._pending.pop(app_id, []):
                cb(pal)

        from .backend import BackendError, ErrorKind
        run_blocking(lambda: self.engine.palette(icon, self.style), done,
                     lambda e: BackendError(ErrorKind.FAILED, str(e)))

    def apply(self, widget: Gtk.Widget, key: str, pal: Palette) -> None:
        """Give `widget` a palette that is already known (e.g. the live theme's)."""
        self._palettes[key] = pal
        self._css[key] = palette_css(css_class(key), pal, self._light)
        self._schedule_flush()
        widget.add_css_class(css_class(key))

    def palette(self, app_id: str) -> Optional[Palette]:
        return self._palettes.get(app_id)

    def _schedule_flush(self) -> None:
        # Many tiles finish together; rebuild the stylesheet once per main-loop turn.
        if not self._flush_id:
            self._flush_id = GLib.idle_add(self._flush)

    def _flush(self) -> bool:
        self._flush_id = 0
        self._provider.load_from_string(_BASE_CSS + "".join(self._css.values()))
        if not self._installed and (display := Gdk.Display.get_default()):
            # USER priority + 1: Dusk's user stylesheet sets these variables on :root at
            # USER priority; ours apply to descendants, so either order works, but
            # being above it keeps that true if Dusk ever scopes them to windows.
            Gtk.StyleContext.add_provider_for_display(
                display, self._provider, Gtk.STYLE_PROVIDER_PRIORITY_USER + 1)
            self._installed = True
        return False


# Surfaces that show the seed itself, not just re-coloured controls. Colours come only
# from the variables above, so unseeded widgets fall back to the current theme.
_BASE_CSS = """
.seed-glow {
  background-image:
    radial-gradient(circle at 85% 15%, alpha(var(--accent-bg-color), 0.55), transparent 62%),
    linear-gradient(135deg, var(--seed-raised, var(--card-bg-color)), var(--view-bg-color));
  transition: background-image 600ms ease;
}
/* Fully clear before the card's sides: the selected sidebar tab is Dusk's card colour
   (a fixed image), so the card it joins must show that colour at its edge. */
.seed-wash {
  background-image:
    radial-gradient(farthest-side at 50% 0%, alpha(var(--accent-bg-color), 0.35), transparent 92%);
}
"""
