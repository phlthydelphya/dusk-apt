"""Main window, laid out like a store and built the way Dusk styles sidebars.

An Adw.NavigationSplitView: the sidebar is a `.navigation-sidebar` list (Home,
Apps, Games, Library) on the window frame, whose selected row Dusk draws as the
breakout tab joining the content card; the content pane holds the search header,
the pages, and app pages pushed on its own navigation view, so the sidebar stays
while you browse an app. On narrow windows the sidebar collapses and the
sections move to a bottom bar.
"""

from __future__ import annotations

from pathlib import Path
from typing import Callable, Optional

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gio, GLib, Gtk  # noqa: E402

from . import dusk  # noqa: E402
from .backend import AppInfo, Catalog, Package, Source  # noqa: E402
from .hub import Hub  # noqa: E402
from .pages.common import error_text  # noqa: E402,F401 - re-exported for callers of Step 1
from .pages.details import DetailsPage, info_from_packages  # noqa: E402
from .pages.discover import DiscoverPage  # noqa: E402
from .pages.installed import InstalledPage  # noqa: E402
from .pages.sources import SourcesPage  # noqa: E402
from .pages.firmware import FirmwarePage  # noqa: E402
from .pages.kernels import KernelsPage  # noqa: E402
from .pages.maintenance import MaintenancePage  # noqa: E402
from .pages.mirrors import MirrorsPage  # noqa: E402
from .pages.preferences import PreferencesDialog  # noqa: E402
from .sources import load_plugins  # noqa: E402
from .pages.updates import UpdatesPage  # noqa: E402
from .seed import Seeder  # noqa: E402
from .settings import Settings  # noqa: E402

# Rail sections, in order; Alt+1..4 jump to them.
SECTIONS = (
    ("home", "Home", "go-home-symbolic"),
    ("apps", "Apps", "view-app-grid-symbolic"),
    ("games", "Games", "applications-games-symbolic"),
    ("library", "Library", "folder-download-symbolic"),
    ("sources", "Sources", "network-server-symbolic"),
)
GAMES_CATEGORY = "Game"
NARROW = "max-width: 660sp"  # below this the sidebar plus a docked search no longer fit
# Below this the window-centred search would cover the content header's back button
# (sidebar ~210px + back button, versus half the window minus half the 320px field).
MEDIUM = "max-width: 880sp"
STYLE = Path(__file__).with_name("style.css")


class SideNav(Gtk.ListBox):
    """The sidebar's section list. Dusk's theme gives `.navigation-sidebar` rows in a
    split view's sidebar pane their breakout tab; AppHub adds no styling of its own."""

    def __init__(self, on_select: Callable[[str], None]):
        super().__init__(selection_mode=Gtk.SelectionMode.SINGLE)
        self.add_css_class("navigation-sidebar")
        self.update_property([Gtk.AccessibleProperty.LABEL], ["Sections"])
        self.rows: dict[str, Gtk.ListBoxRow] = {}
        self.badges: dict[str, Gtk.Label] = {}
        self._on_select = on_select
        self._syncing = False
        for name, label, icon in SECTIONS:
            box = Gtk.Box(spacing=12)
            box.append(Gtk.Image(icon_name=icon))
            box.append(Gtk.Label(label=label, xalign=0, hexpand=True))
            badge = Gtk.Label(visible=False, valign=Gtk.Align.CENTER)
            badge.add_css_class("nav-badge")
            box.append(badge)
            row = Gtk.ListBoxRow(child=box)
            row.name = name
            row.update_property([Gtk.AccessibleProperty.LABEL], [label])
            self.append(row)
            self.rows[name] = row
            self.badges[name] = badge
        self.connect("row-selected", self._selected)

    def _selected(self, _list, row: Optional[Gtk.ListBoxRow]) -> None:
        if row is not None and not self._syncing:
            self._on_select(row.name)

    def select(self, name: Optional[str]) -> None:
        """Show `name` as selected without firing on_select; None clears (search)."""
        self._syncing = True
        try:
            if name in self.rows:
                self.select_row(self.rows[name])
            else:
                self.unselect_all()
        finally:
            self._syncing = False

    def selected_name(self) -> Optional[str]:
        row = self.get_selected_row()
        return row.name if row else None

    def set_badge(self, name: str, count: int) -> None:
        badge = self.badges[name]
        badge.set_label(str(count) if count < 100 else "99+")
        badge.set_visible(count > 0)
        self.rows[name].update_property(
            [Gtk.AccessibleProperty.DESCRIPTION],
            [f"{count} updates available" if count else ""])


class NavRail(Gtk.Box):
    """Bottom bar for narrow windows: icon-over-label buttons, one per section."""

    def __init__(self, orientation: Gtk.Orientation, on_select: Callable[[str], None]):
        super().__init__(orientation=orientation, spacing=4)
        self.add_css_class("nav-rail")
        self.add_css_class("vertical" if orientation == Gtk.Orientation.VERTICAL else "horizontal")
        self.update_property([Gtk.AccessibleProperty.LABEL], ["Sections"])
        self.buttons: dict[str, Gtk.ToggleButton] = {}
        self.badges: dict[str, Gtk.Label] = {}
        self._on_select = on_select
        self._syncing = False
        first = None
        for name, label, icon in SECTIONS:
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            overlay = Gtk.Overlay(child=Gtk.Image(icon_name=icon, pixel_size=20,
                                                  halign=Gtk.Align.CENTER))
            badge = Gtk.Label(visible=False, halign=Gtk.Align.END, valign=Gtk.Align.START)
            badge.add_css_class("rail-badge")
            overlay.add_overlay(badge)
            box.append(overlay)
            text = Gtk.Label(label=label)
            text.add_css_class("rail-label")
            box.append(text)
            button = Gtk.ToggleButton(child=box, tooltip_text=label,
                                      hexpand=orientation == Gtk.Orientation.HORIZONTAL)
            button.add_css_class("rail-button")
            button.update_property([Gtk.AccessibleProperty.LABEL], [label])
            if first is None:
                first = button
            else:
                button.set_group(first)
            button.connect("toggled", self._toggled, name)
            self.append(button)
            self.buttons[name] = button
            self.badges[name] = badge

    def _toggled(self, button: Gtk.ToggleButton, name: str) -> None:
        if button.get_active() and not self._syncing:
            self._on_select(name)

    def select(self, name: Optional[str]) -> None:
        """Show `name` as selected without firing on_select; None clears (search)."""
        self._syncing = True
        try:
            for n, b in self.buttons.items():
                b.set_active(n == name)
        finally:
            self._syncing = False

    def set_badge(self, name: str, count: int) -> None:
        badge = self.badges[name]
        badge.set_label(str(count) if count < 100 else "99+")
        badge.set_visible(count > 0)
        self.buttons[name].update_property(
            [Gtk.AccessibleProperty.DESCRIPTION],
            [f"{count} updates available" if count else ""])


class TabbedPage(Gtk.Box):
    """A titled page whose parts are switched inline (Library, Sources)."""

    def __init__(self, title_text: str, css: str):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.add_css_class(css)
        self.stack = Adw.ViewStack(vexpand=True)
        head = Gtk.Box(spacing=16, margin_top=12, margin_bottom=4, margin_start=12, margin_end=12)
        title = Gtk.Label(label=title_text, xalign=0, hexpand=True)
        title.add_css_class("store-title")
        head.append(title)
        self.switcher = Adw.InlineViewSwitcher(stack=self.stack, valign=Gtk.Align.CENTER)
        self.switcher.add_css_class("round")
        head.append(self.switcher)
        self.append(head)
        self.append(self.stack)

    def add_tab(self, widget: Gtk.Widget, name: str, title: str) -> Adw.ViewStackPage:
        return self.stack.add_titled(widget, name, title)


class LibraryPage(Gtk.Box):
    """Installed apps and updates in one place, switched inline."""

    def __init__(self, installed: InstalledPage, updates: UpdatesPage):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.add_css_class("library")
        self.stack = Adw.ViewStack(vexpand=True)
        self.installed_tab = self.stack.add_titled(installed, "installed", "Installed")
        self.updates_tab = self.stack.add_titled(updates, "updates", "Updates")
        head = Gtk.Box(spacing=16, margin_top=12, margin_bottom=4, margin_start=12, margin_end=12)
        title = Gtk.Label(label="Library", xalign=0, hexpand=True)
        title.add_css_class("store-title")
        head.append(title)
        self.switcher = Adw.InlineViewSwitcher(stack=self.stack, valign=Gtk.Align.CENTER)
        self.switcher.add_css_class("round")
        head.append(self.switcher)
        self.append(head)
        self.append(self.stack)


class AppWindow(Adw.ApplicationWindow):
    def __init__(self, app: Optional[Adw.Application], hub: Hub,
                 catalog: Optional[Catalog] = None, seeder: Optional[Seeder] = None,
                 dusk_apps: Optional[list] = None, sources: Optional[list] = None,
                 plugins: Optional[list] = None, system: Optional[dict] = None,
                 settings: Optional[Settings] = None):
        super().__init__(application=app, title="AppHub",
                         default_width=1100, default_height=740,
                         width_request=360, height_request=294)
        self.add_css_class("dusk-apphub")
        self.hub = hub
        self.catalog = catalog
        self.details: Optional[DetailsPage] = None
        self.seeder = seeder or Seeder()
        self.section = "home"
        self.settings = settings or Settings()
        self.compact = False
        self._load_style()

        self.dusk_apps = dusk.load() if dusk_apps is None else dusk_apps
        self.discover = DiscoverPage(self, hub, catalog, self.seeder, self.dusk_apps)
        self.installed = InstalledPage(self, hub)
        # Mint-style system tools; each is optional (tests, non-Ubuntu systems).
        self.system = dict(system or {})
        self.updates = UpdatesPage(self, hub, snapshots=self.system.get("snapshots"))
        self.library = LibraryPage(self.installed, self.updates)
        self.updates_tab = self.library.updates_tab
        self.kernels = None
        if self.system.get("kernels") is not None:
            self.kernels = KernelsPage(self, self.system["kernels"])
            self.library.stack.add_titled(self.kernels, "kernels", "Kernels")
        self.firmware = None
        self.firmware_tab = None
        if self.system.get("firmware") is not None:
            self.firmware = FirmwarePage(self, self.system["firmware"],
                                         on_count=self._set_firmware_count)
            self.firmware_tab = self.library.stack.add_titled(self.firmware, "firmware", "Firmware")

        # The store (home, apps, games, search) is one page with its own views.
        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, hexpand=True)
        self.stack.add_named(self.discover, "store")
        self.stack.add_named(self.library, "library")
        # Sources: Repositories, Mirrors and Maintenance, as Mint's Software Sources.
        self.sources = SourcesPage(self, sources or [],
                                   load_plugins() if plugins is None else plugins)
        self.sources_hub = TabbedPage("Sources", "sources-hub")
        self.sources_hub.add_tab(self.sources, "repositories", "Repositories")
        self.mirrors = self.maintenance = None
        if self.system.get("mirrors") is not None:
            self.mirrors = MirrorsPage(self, self.system["mirrors"])
            self.sources_hub.add_tab(self.mirrors, "mirrors", "Mirrors")
        if self.system.get("tools"):
            for tool in self.system["tools"]:
                if hasattr(tool, "alternatives"):
                    tool.alternatives = self._alternatives
            self.maintenance = MaintenancePage(self, self.system["tools"])
            self.sources_hub.add_tab(self.maintenance, "maintenance", "Maintenance")
        self.stack.add_named(self.sources_hub, "sources")

        # Content pane: search header over the pages; app pages push onto self.nav.
        header = Adw.HeaderBar(show_back_button=False)
        # The search notch hangs from the window's top edge, so it fills the bar's height.
        self.discover.search_entry.set_valign(Gtk.Align.FILL)
        # The notch shape comes from the Dusk theme (every headerbar entry). AppHub sizes it
        # like the desktop's notch and centres it on the whole window: it lives in a small
        # header bar of its own laid over the window (see below), and moves into this
        # header only on narrow windows. The pane's own title stays empty.
        search = Adw.Clamp(maximum_size=380, tightening_threshold=300,
                           child=self.discover.search_entry, hexpand=True,
                           valign=Gtk.Align.FILL)
        self.search_clamp = search
        self.content_header = header
        header.set_title_widget(Gtk.Box())
        # Main menu: Preferences (always has the Software group).
        menu = Gio.Menu()
        menu.append("Preferences", "win.preferences")
        prefs = Gio.SimpleAction.new("preferences", None)
        prefs.connect("activate", lambda *_: self.show_preferences())
        self.add_action(prefs)
        self.menu_button = Gtk.MenuButton(icon_name="open-menu-symbolic", menu_model=menu,
                                          tooltip_text="Main menu")
        self.menu_button.update_property([Gtk.AccessibleProperty.LABEL], ["Main menu"])
        header.pack_end(self.menu_button)
        self.bottom_rail = NavRail(Gtk.Orientation.HORIZONTAL, self.show_page)
        bottom = Gtk.ActionBar(revealed=False)
        bottom.set_center_widget(self.bottom_rail)
        bottom.add_css_class("rail-bar")
        self.bottom_bar = bottom
        main = Adw.ToolbarView(content=self.stack)
        main.add_top_bar(header)
        main.add_bottom_bar(bottom)
        self.nav = Adw.NavigationView()
        self.nav.add(Adw.NavigationPage(title="AppHub", tag="main", child=main))

        # Sidebar pane: the section list on the frame.
        self.rail = SideNav(self.show_page)
        # Dusk squares the card's top-left corner while the first tab is selected (the
        # tab's tail fills it); the seed wash on the card follows (style.css first-tab).
        self.rail.connect("row-selected", self._on_rail_row)
        sidebar = Adw.ToolbarView(content=Gtk.ScrolledWindow(
            child=self.rail, hscrollbar_policy=Gtk.PolicyType.NEVER))
        sidebar.add_top_bar(Adw.HeaderBar())

        self.split = Adw.NavigationSplitView(
            sidebar=Adw.NavigationPage(title="AppHub", tag="sidebar", child=sidebar),
            content=Adw.NavigationPage(title="AppHub", tag="content", child=self.nav),
            min_sidebar_width=210, max_sidebar_width=250, sidebar_width_fraction=0.2,
            show_content=True)

        # The search notch, hanging from the window's top edge at its centre, as the
        # desktop's notch hangs from the screen's. Only as wide as the field, so the
        # window buttons and the sidebar header stay clickable around it.
        self.search_bar = Gtk.HeaderBar(show_title_buttons=False, title_widget=search,
                                        halign=Gtk.Align.CENTER, valign=Gtk.Align.START)
        self.search_bar.add_css_class("search-notch-bar")
        top = Gtk.Overlay(child=self.split)
        top.add_overlay(self.search_bar)
        self.toasts = Adw.ToastOverlay(child=top)
        self.set_content(self.toasts)

        # One breakpoint applies at a time (the last that matches): MEDIUM docks the search
        # in the content header; NARROW does that too and collapses the sidebar.
        medium = Adw.Breakpoint.new(Adw.BreakpointCondition.parse(MEDIUM))
        medium.connect("apply", lambda *_: self._dock_search(True))
        medium.connect("unapply", lambda *_: self._dock_search(False))
        self.add_breakpoint(medium)

        narrow = Adw.Breakpoint.new(Adw.BreakpointCondition.parse(NARROW))
        narrow.add_setter(self.split, "collapsed", True)
        narrow.add_setter(bottom, "revealed", True)
        narrow.connect("apply", lambda *_: self._set_compact(True))
        narrow.connect("unapply", lambda *_: self._set_compact(False))
        self.add_breakpoint(narrow)

        # Typing in the search from an app page goes back to the store to show results.
        self.discover.search_entry.connect(
            "search-changed",
            lambda e: e.get_text().strip() and self.nav.get_visible_page().get_tag() != "main"
            and self.nav.pop_to_tag("main"))

        self.discover.on_view_changed = self._on_store_view
        self._add_shortcuts()
        self._select("home")

        self.discover.load()
        self.installed.load()
        self.updates.load()
        self.sources.load()
        for page in (self.kernels, self.firmware, self.mirrors, self.maintenance):
            if page is not None:
                page.load()

    def _load_style(self) -> None:
        provider = Gtk.CssProvider()
        provider.load_from_path(str(STYLE))
        # Above Dusk's USER-priority stylesheet, or its button rules reshape the tiles.
        Gtk.StyleContext.add_provider_for_display(
            self.get_display(), provider, Gtk.STYLE_PROVIDER_PRIORITY_USER + 1)

    def _add_shortcuts(self) -> None:
        shortcuts = Gtk.ShortcutController()
        for i, (name, _label, _icon) in enumerate(SECTIONS, start=1):
            shortcuts.add_shortcut(Gtk.Shortcut(
                trigger=Gtk.ShortcutTrigger.parse_string(f"<Alt>{i}"),
                action=Gtk.CallbackAction.new(lambda *_a, n=name: self.show_page(n) or True)))
        shortcuts.add_shortcut(Gtk.Shortcut(
            trigger=Gtk.ShortcutTrigger.parse_string("<Control>f"),
            action=Gtk.CallbackAction.new(lambda *_a: self.start_search() or True)))
        self.add_controller(shortcuts)
        # Escape and Alt+Left pop the app page: Adw.NavigationView does it (pop-on-escape).

    # -- navigation -----------------------------------------------------

    def show_page(self, name: str) -> None:
        """Go to a rail section: home, apps, games or library.

        The old page names still work: discover is home, installed and updates
        are the two halves of the library.
        """
        self.nav.pop_to_tag("main")
        self.split.set_show_content(True)
        name = {"discover": "home"}.get(name, name)
        if name in ("installed", "updates", "firmware") and (
                name != "firmware" or self.firmware is not None):
            self.library.stack.set_visible_child_name(name)
            name = "library"
        if name in ("library", "sources"):
            self.stack.set_visible_child_name(name)
        elif name == "home":
            self.discover.show_home()
        elif name == "apps":
            self.discover.show_apps()
        elif name == "games":
            self.discover.select_category(GAMES_CATEGORY)
        self._select(name)

    def _select(self, name: Optional[str]) -> None:
        self.section = name
        if name not in ("library", "sources"):
            self.stack.set_visible_child_name("store")
        self.rail.select(name)
        self.bottom_rail.select(name)

    def _on_store_view(self, view: str, category: Optional[str]) -> None:
        """Keep the rail in step when the store changes view by itself (search, tiles)."""
        if view == "home":
            self._select("home")
        elif view in ("apps",):
            self._select("apps")
        elif view == "category":
            self._select("games" if category == GAMES_CATEGORY else "apps")
        elif view in ("results", "idle"):
            self._select(None if view == "results" else self.section)

    def _dock_search(self, docked: bool) -> None:
        """Docked: the search sits in the content header, beside its buttons. Not docked:
        it hangs over the window's centre (only where it cannot cover a header button)."""
        if docked == (self.search_clamp.get_parent() is self.content_header
                      or self.content_header.get_title_widget() is self.search_clamp):
            return
        self.search_bar.set_title_widget(None)
        self.content_header.set_title_widget(None)
        if docked:
            self.add_css_class("search-docked")
            self.search_bar.set_visible(False)
            self.content_header.set_title_widget(self.search_clamp)
        else:
            self.remove_css_class("search-docked")
            self.content_header.set_title_widget(Gtk.Box())
            self.search_bar.set_title_widget(self.search_clamp)
            self.search_bar.set_visible(True)

    def _on_rail_row(self, _rail, row: Optional[Gtk.ListBoxRow]) -> None:
        if row is not None and row.get_index() == 0:
            self.add_css_class("first-tab")
        else:
            self.remove_css_class("first-tab")

    def _set_compact(self, compact: bool) -> None:
        self.compact = compact
        if compact:
            self.add_css_class("compact")
        else:
            self.remove_css_class("compact")
        self._dock_search(compact)
        self.discover.set_compact(compact)
        if self.details is not None:
            self.details.set_compact(compact)

    def start_search(self) -> None:
        self.nav.pop_to_tag("main")
        self.stack.set_visible_child_name("store")
        self.discover.focus_search()

    def open_app(self, info: AppInfo) -> None:
        self.nav.pop_to_tag("main")
        self.details = DetailsPage(self, self.hub, info)
        self.details.set_compact(self.compact)
        self.nav.push(self.details)

    def open_dusk_app(self, app) -> None:
        self.nav.pop_to_tag("main")
        self.details = DetailsPage(self, self.hub, app.info(), dusk_app=app)
        self.details.set_compact(self.compact)
        self.nav.push(self.details)

    def open_package(self, pkg: Package, group: Optional[list[Package]] = None) -> None:
        base = None
        if self.catalog is not None and self.discover.catalog_ready and pkg.app_id:
            base = self.catalog.get(pkg.app_id)
        self.open_app(info_from_packages(group or [pkg], base))

    def show_search(self, query: str) -> None:
        self.start_search()
        self.discover.search_entry.set_text(query)

    # -- links (links.py): what GNOME Software used to open ----------------

    def open_link(self, target) -> None:
        if target.kind == "app":
            self._when_catalog(lambda: self._open_app_id(target))
        elif target.kind in ("apt", "snap"):
            source = Source.APT if target.kind == "apt" else Source.SNAP

            def found(pkg: Optional[Package], error) -> None:
                if pkg is None:
                    why = error_text(error) if error else "It was not found"
                    self.toast(f"Cannot show {target.value}. {why}")
                    return
                self.open_package(pkg)
            self.hub.lookup(source, target.value, found)
        elif target.kind == "sources":
            self.show_page("sources")
            self.toast(target.value)
        else:
            self.toast(target.value)

    def _when_catalog(self, then: Callable[[], None]) -> None:
        if self.discover.catalog_loading:
            self.discover.on_catalog_ready.append(then)
        else:
            then()  # loaded, failed, or there is no catalog: `then` copes

    def _open_app_id(self, target) -> None:
        info = None
        if self.catalog is not None and self.discover.catalog_ready:
            info = self.catalog.get(target.value.removesuffix(".desktop"))
        if info is not None:
            self.open_app(info)
            return
        if target.ref is not None:
            self.ask_install_ref(target.ref)
            return
        # Not in the catalog (an app from a remote that is not set up, or a typo):
        # search for it instead, so the person sees what there is.
        name = target.title or target.value
        self.show_search(name)
        self.toast(f"{name} is not in the app catalog")

    def ask_install_ref(self, ref) -> Optional[Adw.AlertDialog]:
        """A .flatpakref for an app the catalog does not have: say where it comes
        from and install only on the person's yes. Returns the dialog (tests)."""
        from .links import ref_host
        backend = self.hub.backends.get(Source.FLATPAK)
        if backend is None or not hasattr(backend, "install_flatpakref"):
            self.toast("Cannot install Flatpak apps here: Flatpak is not available")
            return None
        host = ref_host(ref)
        body = (f"{ref.title} ({ref.name}) comes from {host}, not from the app catalog. "
                f"AppHub has not reviewed this source. Install it only if you trust {host}.")
        dialog = Adw.AlertDialog(heading=f"Install {ref.title}?", body=body)
        dialog.add_response("cancel", "Cancel")
        dialog.add_response("install", "Install")
        dialog.set_response_appearance("install", Adw.ResponseAppearance.SUGGESTED)
        dialog.set_default_response("cancel")
        dialog.set_close_response("cancel")
        dialog.connect("response",
                       lambda _d, r: r == "install" and self.install_ref(backend, ref))
        dialog.present(self)
        return dialog

    def install_ref(self, backend, ref) -> None:
        self.toast(f"Installing {ref.title}…")

        def done(pkg: Optional[Package], error) -> None:
            if pkg is None:
                self.toast(f"Could not install {ref.title}. {error_text(error)}")
                return
            self.toast(f"{pkg.display_name} is installed")
            self.package_changed()
            self.open_package(pkg)

        backend.install_flatpakref(ref, lambda _p: None, done)

    # -- shell services for pages ---------------------------------------

    def package_changed(self) -> None:
        """Something was installed, removed or updated: refresh the lists."""
        self.installed.load()
        self.updates.load()
        self.discover.refresh_installed()
        app = self.get_application()
        if app is not None and hasattr(app, "updates_changed"):
            app.updates_changed()  # the tray and the D-Bus count follow

    def _alternatives(self, story) -> list:
        """Other sources of the app a foreign .deb provides (Flatpak or Snap), from the
        catalog, respecting the unverified-Flatpak preference. Runs in a worker thread;
        the catalog is only read."""
        from . import policy
        from .backend import Source
        from .maintenance import Alternative
        if self.catalog is None or not self.discover.catalog_ready:
            return []
        found = []
        for app_id in story.app_ids:
            info = self.catalog.get(app_id)
            if info is not None:
                found.append(info)
        if not found:
            wanted = [n.casefold() for n in story.app_names] or [story.name.casefold()]
            for info in self.catalog.search(story.app_names[0] if story.app_names else story.name, 10):
                title = info.title.casefold()
                # Same app under a slightly different name ("Zoom" / "Zoom Workplace");
                # short titles are too easy to match by accident.
                if len(title) >= 4 and any(title == w or title in w or w in title for w in wanted):
                    found.append(info)
                    break
        out = []
        show = self.settings.show_unverified_flatpaks
        for info in found:
            visible = policy.visible(info, show)
            if visible is None:
                continue
            for source in policy.ordered(visible.candidates):
                if source in (Source.FLATPAK, Source.SNAP):
                    out.append(Alternative(str(source), visible.candidates[source], info.title,
                                           info.flatpak_verified if source == Source.FLATPAK
                                           else None))
        return out

    def show_preferences(self) -> None:
        self.preferences = PreferencesDialog(self.system.get("automation"), self.settings,
                                             on_settings_changed=self.discover.refilter)
        self.preferences.present(self)

    def sources_changed(self) -> None:
        """A source was added, removed or switched: its apps and updates change too."""
        self.discover.reload()
        self.package_changed()

    def set_update_count(self, count: int) -> None:
        self.updates_tab.set_badge_number(count)
        self.updates_tab.set_needs_attention(count > 0)
        self.rail.set_badge("library", count)
        self.bottom_rail.set_badge("library", count)

    def _set_firmware_count(self, count: int) -> None:
        if self.firmware_tab is not None:
            self.firmware_tab.set_badge_number(count)
            self.firmware_tab.set_needs_attention(count > 0)
        app = self.get_application()
        if app is not None and hasattr(app, "firmware_count_changed"):
            app.firmware_count_changed(count)

    def toast(self, text: str) -> None:
        self.toasts.add_toast(Adw.Toast(title=GLib.markup_escape_text(text), timeout=5))

    def _notify(self, title: str, body: str) -> None:
        app = self.get_application()
        if app is None:
            return
        n = Gio.Notification.new(title)
        n.set_body(body)
        app.send_notification("change", n)
