"""Timeshift restore points through the system helper's `snapshot` command.

Reading the configuration needs no root: /etc/timeshift/timeshift.json is world
readable on a normal install. Making a snapshot does, so it goes through
system.run_system_helper (pkexec apphub-system-helper snapshot COMMENT).
"""

from __future__ import annotations

import json
import re
import shutil
import time
from typing import Callable, Optional

from .backend import BackendError, Done
from .system import HelperResult, Snapshot, run_system_helper

TIMESHIFT_CONFIG = "/etc/timeshift/timeshift.json"
COMMENT_MAX = 60
DEFAULT_COMMENT = "AppHub restore point"
TAGS = "O"  # on-demand, as the helper passes --tags O

_UNSAFE = re.compile(r"[^A-Za-z0-9 .,:()-]")
# No leading "-" or space: the comment must never look like an option.
_SAFE = re.compile(r"[A-Za-z0-9.,:()][A-Za-z0-9 .,:()-]{0,%d}" % (COMMENT_MAX - 1))
# "Tagged snapshot '2026-11-03_10-00-01': ondemand"
_TAGGED = re.compile(r"Tagged snapshot '([^']+)'(?::\s*(\S+))?")
# ".../timeshift/snapshots/2026-11-03_10-00-01/info.json"
_SNAP_DIR = re.compile(r"snapshots/(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})")


def is_safe_comment(comment: str) -> bool:
    """True when `comment` is 1..60 characters from [A-Za-z0-9 .,:()-], not starting with "-"."""
    return bool(_SAFE.fullmatch(comment))


def safe_comment(comment: str) -> str:
    """`comment` with unsafe characters dropped, spaces collapsed, cut to 60 characters."""
    text = _UNSAFE.sub("", " ".join(comment.split()))  # tabs and newlines become spaces
    text = " ".join(text.split()).lstrip("- ")[:COMMENT_MAX].strip()
    return text or DEFAULT_COMMENT


def parse_snapshot(output: str, comment: str) -> Snapshot:
    """The snapshot named in Timeshift's output, or a minimal one built from the comment."""
    tagged = _TAGGED.search(output)
    if tagged:
        return Snapshot(name=tagged.group(1), comment=comment, tags=tagged.group(2) or TAGS)
    found = _SNAP_DIR.search(output)
    if found:
        return Snapshot(name=found.group(1), comment=comment, tags=TAGS)
    return Snapshot(name=time.strftime("%Y-%m-%d_%H-%M-%S"), comment=comment, tags=TAGS)


class Timeshift:
    def __init__(self, config: str = TIMESHIFT_CONFIG,
                 which: Callable[[str], Optional[str]] = shutil.which,
                 helper: Callable[[list[str], Done[HelperResult]], None] = run_system_helper):
        self._config = config
        self._which = which
        self._helper = helper

    def available(self) -> bool:
        return self._which("timeshift") is not None

    def configured(self) -> bool:
        try:
            with open(self._config, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError):
            return False
        if not isinstance(data, dict):
            return False
        device = data.get("backup_device_uuid")
        return isinstance(device, str) and bool(device.strip())

    def create(self, comment: str, done: Done[Snapshot], progress=None) -> None:
        text = safe_comment(comment)

        def finished(result: Optional[HelperResult], error: Optional[BackendError]) -> None:
            if error is not None:
                done(None, error)
            else:
                done(parse_snapshot(result.output if result else "", text), None)

        if progress is None:
            self._helper(["snapshot", text], finished)
        else:
            self._helper(["snapshot", text], finished, progress=progress)
