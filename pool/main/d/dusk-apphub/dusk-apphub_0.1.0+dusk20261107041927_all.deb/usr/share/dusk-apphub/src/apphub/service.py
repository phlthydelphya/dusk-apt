"""AppHub's background service: the update monitor, its D-Bus API and the GNOME Shell
search provider.

The service lives in whichever process owns the app ID on the session bus: the
login-time `apphub --watch`, a D-Bus activated `apphub --gapplication-service`, or
an open AppHub window. Everything here only reads; installing still happens in
the window, through the backends and their polkit prompts.

D-Bus, on the app's own bus name io.github.phlthydelphya.DuskAppHub:

  /io/github/phlthydelphya/DuskAppHub/Updates   io.github.phlthydelphya.DuskAppHub.Updates1
  /io/github/phlthydelphya/DuskAppHub/SearchProvider   org.gnome.Shell.SearchProvider2
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

from gi.repository import Gio, GLib

from .backend import BackendError, Package
from .system import Tier, tier_of

log = logging.getLogger("apphub.service")

UPDATES_PATH = "/io/github/phlthydelphya/DuskAppHub/Updates"
UPDATES_IFACE = "io.github.phlthydelphya.DuskAppHub.Updates1"
SEARCH_PATH = "/io/github/phlthydelphya/DuskAppHub/SearchProvider"
SEARCH_IFACE = "org.gnome.Shell.SearchProvider2"

FIRST_CHECK_DELAY = 90  # seconds after login: let the session settle
CHECK_INTERVAL = 6 * 60 * 60
ORDINARY_NOTIFY_INTERVAL = 24 * 60 * 60  # plain updates nag at most once a day
SEARCH_LIMIT = 10
NOTIFICATION_ID = "updates"

UPDATES_XML = f"""
<node>
  <interface name="{UPDATES_IFACE}">
    <!-- Ask for a check now. Returns at once; Changed follows when it is done. -->
    <method name="Check"/>
    <!-- (source, name, title, new version, tier) for every update that can be
         installed now. Phased updates are left out. -->
    <method name="GetUpdates">
      <arg name="updates" type="a(sssss)" direction="out"/>
    </method>
    <!-- (device id, device, current version, new version) -->
    <method name="GetFirmwareUpdates">
      <arg name="updates" type="a(ssss)" direction="out"/>
    </method>
    <method name="ShowUpdates"/>
    <method name="ShowApp">
      <arg name="app_id" type="s" direction="in"/>
    </method>
    <signal name="Changed"/>
    <property name="UpdateCount" type="u" access="read"/>
    <property name="SecurityCount" type="u" access="read"/>
    <property name="FirmwareCount" type="u" access="read"/>
    <property name="LastChecked" type="x" access="read"/>
    <property name="Checking" type="b" access="read"/>
  </interface>
</node>
"""

SEARCH_XML = f"""
<node>
  <interface name="{SEARCH_IFACE}">
    <method name="GetInitialResultSet">
      <arg type="as" name="terms" direction="in"/>
      <arg type="as" name="results" direction="out"/>
    </method>
    <method name="GetSubsearchResultSet">
      <arg type="as" name="previous_results" direction="in"/>
      <arg type="as" name="terms" direction="in"/>
      <arg type="as" name="results" direction="out"/>
    </method>
    <method name="GetResultMetas">
      <arg type="as" name="identifiers" direction="in"/>
      <arg type="aa{{sv}}" name="metas" direction="out"/>
    </method>
    <method name="ActivateResult">
      <arg type="s" name="identifier" direction="in"/>
      <arg type="as" name="terms" direction="in"/>
      <arg type="u" name="timestamp" direction="in"/>
    </method>
    <method name="LaunchSearch">
      <arg type="as" name="terms" direction="in"/>
      <arg type="u" name="timestamp" direction="in"/>
    </method>
    <!-- Ubuntu's GNOME Shell calls this when a search is abandoned -->
    <method name="XUbuntuCancel"/>
  </interface>
</node>
"""


@dataclass
class UpdateState:
    packages: list[Package] = field(default_factory=list)
    firmware: list = field(default_factory=list)  # firmware.FirmwareUpdate
    last_checked: int = 0
    checking: bool = False

    @property
    def count(self) -> int:
        return len(self.packages)

    @property
    def security(self) -> int:
        return sum(1 for p in self.packages if tier_of(p) == Tier.SECURITY)

    @property
    def total(self) -> int:
        return self.count + len(self.firmware)


def notification_text(state: UpdateState) -> Optional[tuple[str, str]]:
    """(title, body) for an update notification, or None when there is nothing to say."""
    if not state.total:
        return None
    if state.security:
        title = (f"{state.security} security update" + ("" if state.security == 1 else "s")
                 + " available")
    elif state.count:
        title = f"{state.count} update" + ("" if state.count == 1 else "s") + " available"
    else:
        title = "Firmware update available"
    parts = []
    if state.security and state.count > state.security:
        parts.append(f"{state.count - state.security} other updates are ready too.")
    if state.firmware and (state.count or len(state.firmware) > 1):
        n = len(state.firmware)
        parts.append(f"{n} device" + (" has" if n == 1 else "s have") + " new firmware.")
    if state.security:
        parts.append("Security updates fix known vulnerabilities. Install them soon.")
    return title, " ".join(parts) or "Open AppHub to see them."


class UpdateMonitor:
    """Checks every source (and fwupd) now and then; tells listeners and the person.

    hub: a Hub, or a callable returning one (loaded on the first check).
    firmware: a firmware.Fwupd, or None.
    notify(title, body, urgent) and withdraw() show and drop the notification.
    """

    def __init__(self, hub, firmware=None,
                 notify: Optional[Callable[[str, str, bool], None]] = None,
                 withdraw: Optional[Callable[[], None]] = None,
                 clock: Callable[[], float] = time.time):
        self._hub = hub
        self.firmware = firmware
        self._notify = notify
        self._withdraw = withdraw
        self._clock = clock
        self.state = UpdateState()
        self.listeners: list[Callable[[UpdateState], None]] = []
        self._notified: set[str] = set()
        self._last_ordinary_notice = 0.0
        self._timer = 0
        self._again = False

    @property
    def hub(self):
        if callable(self._hub) and not hasattr(self._hub, "get_updates"):
            self._hub = self._hub()
        return self._hub

    def start(self, first_delay: int = FIRST_CHECK_DELAY) -> None:
        """Periodic checks: one soon after start, then every CHECK_INTERVAL."""
        if self._timer:
            return
        self._timer = GLib.timeout_add_seconds(first_delay, self._first_tick)

    def _first_tick(self) -> bool:
        self.check()
        self._timer = GLib.timeout_add_seconds(CHECK_INTERVAL, self._tick)
        return False

    def _tick(self) -> bool:
        self.check()
        return True

    def check_soon(self) -> None:
        """Something changed in the window: count again in a moment."""
        GLib.timeout_add_seconds(2, lambda: (self.check(), False)[1])

    def check(self) -> None:
        if self.state.checking:
            self._again = True
            return
        self.state.checking = True
        self._emit()
        pending = {"packages": None, "firmware": None}

        def finish() -> None:
            if any(v is None for v in pending.values()):
                return
            self.state.packages = pending["packages"]
            self.state.firmware = pending["firmware"]
            self.state.last_checked = int(self._clock())
            self.state.checking = False
            self._emit()
            self._maybe_notify()
            if self._again:
                self._again = False
                self.check()

        def got_packages(pkgs: list[Package], errors: list[BackendError]) -> None:
            for e in errors:
                log.info("update check: %s", e.message)
            pending["packages"] = [p for p in pkgs or [] if not p.phased]
            finish()

        def got_firmware(updates, error) -> None:
            if error:
                log.info("firmware check: %s", error.message)
            pending["firmware"] = list(updates or [])
            finish()

        if self.firmware is None:
            pending["firmware"] = []
        else:
            self.firmware.updates(got_firmware)
        try:
            self.hub.get_updates(got_packages)
        except Exception as e:  # noqa: BLE001 - a broken hub must not stop the service
            log.warning("update check failed: %s", e)
            got_packages([], [])

    def _emit(self) -> None:
        for listener in list(self.listeners):
            try:
                listener(self.state)
            except Exception:  # noqa: BLE001
                log.exception("update listener failed")

    def _maybe_notify(self) -> None:
        ids = {f"{p.source}:{p.name}:{p.update_version}" for p in self.state.packages}
        ids |= {f"fw:{u.device_id}:{u.version}" for u in self.state.firmware}
        if not ids:
            self._notified = set()
            if self._withdraw:
                self._withdraw()
            return
        new = ids - self._notified
        self._notified = ids
        if not new or self._notify is None:
            return
        important = self.state.security > 0 or any(i.startswith("fw:") for i in new)
        now = self._clock()
        if not important and now - self._last_ordinary_notice < ORDINARY_NOTIFY_INTERVAL:
            return
        if not important:
            self._last_ordinary_notice = now
        text = notification_text(self.state)
        if text:
            self._notify(text[0], text[1], self.state.security > 0)


class UpdatesObject:
    """io.github.phlthydelphya.DuskAppHub.Updates1 over an UpdateMonitor."""

    def __init__(self, monitor: UpdateMonitor, show_updates: Callable[[], None],
                 show_app: Callable[[str], None]):
        self.monitor = monitor
        self._show_updates = show_updates
        self._show_app = show_app
        self._conn: Optional[Gio.DBusConnection] = None
        self._reg = 0
        monitor.listeners.append(lambda _s: self._changed())

    def register(self, conn: Gio.DBusConnection) -> None:
        info = Gio.DBusNodeInfo.new_for_xml(UPDATES_XML).interfaces[0]
        self._conn = conn
        self._reg = conn.register_object(UPDATES_PATH, info, self._call, self._get, None)

    def unregister(self) -> None:
        if self._conn and self._reg:
            self._conn.unregister_object(self._reg)
        self._conn, self._reg = None, 0

    def properties(self) -> dict[str, GLib.Variant]:
        s = self.monitor.state
        return {"UpdateCount": GLib.Variant("u", s.count),
                "SecurityCount": GLib.Variant("u", s.security),
                "FirmwareCount": GLib.Variant("u", len(s.firmware)),
                "LastChecked": GLib.Variant("x", s.last_checked),
                "Checking": GLib.Variant("b", s.checking)}

    def _get(self, _conn, _sender, _path, _iface, name):
        return self.properties().get(name)

    def _call(self, _conn, _sender, _path, _iface, method, params, invocation) -> None:
        s = self.monitor.state
        if method == "Check":
            self.monitor.check()
            invocation.return_value(None)
        elif method == "GetUpdates":
            rows = [(str(p.source), p.name, p.display_name, p.update_version or "",
                     str(tier_of(p))) for p in s.packages]
            invocation.return_value(GLib.Variant("(a(sssss))", (rows,)))
        elif method == "GetFirmwareUpdates":
            rows = [(u.device_id, u.device, u.current, u.version) for u in s.firmware]
            invocation.return_value(GLib.Variant("(a(ssss))", (rows,)))
        elif method == "ShowUpdates":
            self._show_updates()
            invocation.return_value(None)
        elif method == "ShowApp":
            self._show_app(params.unpack()[0])
            invocation.return_value(None)
        else:
            invocation.return_dbus_error("org.freedesktop.DBus.Error.UnknownMethod", method)

    def _changed(self) -> None:
        if not self._conn:
            return
        try:
            self._conn.emit_signal(None, UPDATES_PATH, "org.freedesktop.DBus.Properties",
                                   "PropertiesChanged",
                                   GLib.Variant("(sa{sv}as)", (UPDATES_IFACE, self.properties(), [])))
            self._conn.emit_signal(None, UPDATES_PATH, UPDATES_IFACE, "Changed", None)
        except GLib.Error as e:
            log.warning("cannot emit update signals: %s", e.message)


class SearchProvider:
    """GNOME Shell search over the AppStream catalog, like GNOME Software's provider.

    catalog: a callable returning the Catalog (loaded lazily: the first search pays
    for it, and replies wait until it is ready). open_app(app_id) and
    search(terms) open the window. activity() is called on every request, so a
    D-Bus activated service can stay up while it is in use.
    """

    def __init__(self, catalog: Callable[[], object], open_app: Callable[[str], None],
                 search: Callable[[str], None],
                 activity: Optional[Callable[[], None]] = None):
        self._catalog_factory = catalog
        self._catalog = None
        self._ready = False
        self._waiting: list[Callable[[], None]] = []
        self._open_app = open_app
        self._search = search
        self._activity = activity or (lambda: None)
        self._conn: Optional[Gio.DBusConnection] = None
        self._reg = 0

    def register(self, conn: Gio.DBusConnection) -> None:
        info = Gio.DBusNodeInfo.new_for_xml(SEARCH_XML).interfaces[0]
        self._conn = conn
        self._reg = conn.register_object(SEARCH_PATH, info, self._call, None, None)

    def unregister(self) -> None:
        if self._conn and self._reg:
            self._conn.unregister_object(self._reg)
        self._conn, self._reg = None, 0

    def _with_catalog(self, then: Callable[[], None]) -> None:
        if self._ready:
            then()
            return
        self._waiting.append(then)
        if self._catalog is not None:
            return  # already loading
        self._catalog = self._catalog_factory()
        if self._catalog is None:
            self._loaded(False, None)
            return
        self._catalog.load(self._loaded)

    def _loaded(self, _ok, error) -> None:
        if error:
            log.warning("search provider: catalog did not load: %s", error.message)
            self._catalog = None
        self._ready = True
        waiting, self._waiting = self._waiting, []
        for then in waiting:
            then()

    def results(self, terms: list[str]) -> list[str]:
        query = " ".join(t for t in terms if t).strip()
        if self._catalog is None or len(query) < 2:
            return []
        return [a.app_id for a in self._catalog.search(query, limit=SEARCH_LIMIT)]

    def metas(self, ids: list[str]) -> list[dict[str, GLib.Variant]]:
        out = []
        for app_id in ids:
            info = self._catalog.get(app_id) if self._catalog else None
            if info is None:
                continue
            meta = {"id": GLib.Variant("s", app_id),
                    "name": GLib.Variant("s", info.title),
                    "description": GLib.Variant("s", info.summary or "")}
            icon = _gicon(info.icon)
            if icon is not None:
                meta["gicon"] = GLib.Variant("s", icon.to_string())
            out.append(meta)
        return out

    def _call(self, _conn, _sender, _path, _iface, method, params, invocation) -> None:
        self._activity()
        args = params.unpack()
        if method == "GetInitialResultSet":
            self._with_catalog(lambda: invocation.return_value(
                GLib.Variant("(as)", (self.results(args[0]),))))
        elif method == "GetSubsearchResultSet":
            self._with_catalog(lambda: invocation.return_value(
                GLib.Variant("(as)", (self.results(args[1]),))))
        elif method == "GetResultMetas":
            self._with_catalog(lambda: invocation.return_value(
                GLib.Variant("(aa{sv})", (self.metas(args[0]),))))
        elif method == "ActivateResult":
            self._open_app(args[0])
            invocation.return_value(None)
        elif method == "LaunchSearch":
            self._search(" ".join(args[0]))
            invocation.return_value(None)
        elif method == "XUbuntuCancel":
            invocation.return_value(None)
        else:
            invocation.return_dbus_error("org.freedesktop.DBus.Error.UnknownMethod", method)


def _gicon(icon: Optional[str]) -> Optional[Gio.Icon]:
    if not icon:
        return None
    if icon.startswith("/"):
        return Gio.FileIcon.new(Gio.File.new_for_path(icon))
    return Gio.ThemedIcon.new(icon)
