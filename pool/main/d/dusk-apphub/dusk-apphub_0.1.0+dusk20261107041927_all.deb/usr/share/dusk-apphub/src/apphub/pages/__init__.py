"""AppHub pages: Discover, Installed, Updates and the app details page."""
