"""Linux kernels: the installed ones (dpkg) and newer generic ones APT offers (PackageKit).

Two installed kernels are protected and never removed: the running one, and the newest
other installed kernel, which is what the person boots if a new kernel fails.
Installs and removals go through PackageKit exactly as apt.py does them.
"""

from __future__ import annotations

import os
import re
import subprocess
from dataclasses import replace
from typing import Callable, Iterable, Optional

import gi

gi.require_version("PackageKitGlib", "1.0")
from gi.repository import PackageKitGlib as Pk  # noqa: E402

from .apt import _INSTALLED, AptBackend, _flags  # noqa: E402
from .backend import BackendError, Done, ErrorKind, OnProgress, Once, run_blocking  # noqa: E402
from .system import Kernel  # noqa: E402

AVAILABLE_LIMIT = 5

# linux-image-7.3.0-10-generic, linux-image-unsigned-7.3.0-10-lowlatency
_IMAGE = re.compile(r"linux-image-(?:unsigned-)?((\d+\.\d+\.\d+-\d+)-([a-z0-9][a-z0-9-]*))")
_GENERIC = re.compile(r"linux-image-((\d+\.\d+\.\d+-\d+)-generic)")
_RELEASE = re.compile(r"(\d+\.\d+\.\d+-\d+)-([a-z0-9][a-z0-9-]*)")
_NOT_INSTALLED = Pk.filter_bitfield_from_string("~installed;arch")

# run(method, args, progress, on_results, done): AptBackend._run's signature.
PkRun = Callable[..., None]


def version_key(version: str) -> tuple[int, ...]:
    """Sort key for "7.3.0-10-generic": the numbers before the flavour."""
    m = _RELEASE.fullmatch(version)
    return tuple(int(n) for n in re.findall(r"\d+", m.group(1) if m else version))


def flavour_of(version: str) -> str:
    m = _RELEASE.fullmatch(version)
    return m.group(2) if m else ""


def dpkg_kernel_packages(runner=subprocess.run) -> list[str]:
    """Names of linux-image/modules/headers packages in dpkg state "ii"."""
    proc = runner(["dpkg-query", "-W", "-f", "${db:Status-Abbrev}|${Package}\\n",
                   "linux-image-*", "linux-modules-*", "linux-headers-*"],
                  capture_output=True, text=True, timeout=30)
    # dpkg-query exits 1 when one pattern matches nothing; the others still print.
    names = []
    for line in (proc.stdout or "").splitlines():
        status, _, name = line.partition("|")
        if status.strip() == "ii" and name:
            names.append(name.strip())
    return names


def installed_kernels(names: Iterable[str], running: str) -> list[Kernel]:
    """Kernels from installed package names, newest first, with protection set."""
    found: dict[str, str] = {}
    for name in names:
        m = _IMAGE.fullmatch(name)
        if m and (m.group(1) not in found or "unsigned" in found[m.group(1)]):
            found[m.group(1)] = name
    versions = sorted(found, key=version_key, reverse=True)
    if running not in found:
        versions = sorted([*versions, running], key=version_key, reverse=True)
    fallback = next((v for v in versions if v != running), None)
    return [Kernel(version=v, flavour=flavour_of(v), installed=True, running=v == running,
                   package=found.get(v), protected=v in (running, fallback))
            for v in versions]


def kernel_packages(version: str, installed: Iterable[str]) -> list[str]:
    """Installed packages that belong to exactly this kernel version, image first."""
    installed = set(installed)
    m = _RELEASE.fullmatch(version)
    if not m:
        return []
    base = m.group(1)
    exact = [f"linux-image-{version}", f"linux-image-unsigned-{version}"]
    out = [n for n in exact if n in installed]
    out += sorted(n for n in installed
                  if n.endswith(f"-{version}") and n not in out
                  and n.startswith(("linux-modules-", "linux-headers-")))
    # linux-headers-7.3.0-10 is shared by every flavour of that ABI: only when no other remains.
    shared = f"linux-headers-{base}"
    others = [n for n in installed
              if n.startswith(f"{shared}-") and n != f"linux-headers-{version}"]
    if shared in installed and not others:
        out.append(shared)
    return out


class AptKernels:
    def __init__(self, run: Optional[PkRun] = None,
                 dpkg: Callable[[], list[str]] = dpkg_kernel_packages,
                 running: Callable[[], str] = lambda: os.uname().release):
        if run is None:
            run = AptBackend()._run  # one Pk.Client, polkit prompt allowed
        self._run = run
        self._dpkg = dpkg
        self._running = running

    # -- queries --------------------------------------------------------

    def list(self, done: Done[list[Kernel]]) -> None:
        done = Once(done)

        def got_installed(names, error):
            if error:
                done(None, error)
                return
            installed = installed_kernels(names, self._running())
            have = {k.version for k in installed}

            def found(results):
                done(installed + available_kernels(results.get_package_array(), have), None)

            # Newer kernels are optional: a failed search still lists what is installed.
            self._run("search_names", (_NOT_INSTALLED, ["linux-image-"]), None, found,
                      lambda _r, _e: done(installed, None))

        self._installed_names(got_installed)

    # -- changes --------------------------------------------------------

    def install(self, kernel: Kernel, progress: OnProgress, done: Done[Kernel]) -> None:
        done = Once(done)
        image = kernel.package or f"linux-image-{kernel.version}"

        def got_installed(names, error):
            if error:
                done(None, error)
                return
            wanted = [image]
            # Keep DKMS modules building: bring headers when headers of this flavour are in use.
            if any(n.startswith("linux-headers-") and n.endswith(f"-{kernel.flavour}")
                   for n in names):
                wanted.append(f"linux-headers-{kernel.version}")

            def resolved(results):
                ids = {p.get_name(): p.get_id() for p in results.get_package_array()}
                if image not in ids:
                    done(None, BackendError(ErrorKind.NOT_FOUND,
                                            f"{image} is not in any enabled APT repository"))
                    return
                self._run("install_packages", (_flags(False), [ids[n] for n in wanted if n in ids]),
                          progress, lambda _r: self._reread(kernel, done), done)

            self._run("resolve", (_NOT_INSTALLED, wanted), None, resolved, done)

        self._installed_names(got_installed)

    def remove(self, kernel: Kernel, progress: OnProgress, done: Done[bool]) -> None:
        done = Once(done)
        if kernel.protected or kernel.running:
            done(None, _protected(kernel))
            return

        def got_installed(names, error):
            if error:
                done(None, error)
                return
            # Check again from the system itself: `kernel` may be stale.
            now = {k.version: k for k in installed_kernels(names, self._running())}
            if kernel.version in now and now[kernel.version].protected:
                done(None, _protected(now[kernel.version]))
                return
            packages = kernel_packages(kernel.version, names)
            if not packages:
                done(None, BackendError(ErrorKind.NOT_FOUND,
                                        f"Linux {kernel.version} is not installed"))
                return

            def resolved(results):
                ids = [p.get_id() for p in results.get_package_array()
                       if p.get_name() in packages]
                if not ids:
                    done(None, BackendError(ErrorKind.NOT_FOUND,
                                            f"Linux {kernel.version} is not installed"))
                    return
                # allow_deps=False, autoremove=False: as AptBackend.remove.
                self._run("remove_packages", (_flags(False), ids, False, False), progress,
                          lambda _r: done(True, None), done)

            self._run("resolve", (_INSTALLED, packages), None, resolved, done)

        self._installed_names(got_installed)

    # -- plumbing -------------------------------------------------------

    def _installed_names(self, done: Done[list[str]]) -> None:
        run_blocking(self._dpkg, done,
                     lambda e: e if isinstance(e, BackendError)
                     else BackendError(ErrorKind.FAILED, f"Could not read installed kernels: {e}"))

    def _reread(self, kernel: Kernel, done: Done[Kernel]) -> None:
        def listed(kernels, error):
            match = next((k for k in kernels or [] if k.version == kernel.version and k.installed),
                         None)
            done(match or replace(kernel, installed=True), None)

        self.list(listed)


def available_kernels(pk_packages, installed_versions: set[str],
                      limit: int = AVAILABLE_LIMIT) -> list[Kernel]:
    """Generic kernels APT offers that are not installed, newest first, at most `limit`."""
    found: dict[str, str] = {}
    for p in pk_packages:
        m = _GENERIC.fullmatch(p.get_name())
        if m and m.group(1) not in installed_versions:
            found[m.group(1)] = p.get_name()
    versions = sorted(found, key=version_key, reverse=True)[:limit]
    return [Kernel(version=v, flavour="generic", installed=False, package=found[v])
            for v in versions]


def _protected(kernel: Kernel) -> BackendError:
    why = "is running" if kernel.running else "is the fallback kernel"
    return BackendError(ErrorKind.UNSUPPORTED,
                        f"Linux {kernel.version} {why} and cannot be removed")
