"""Flathub developer verification, read from the remote's AppStream data.

Flathub marks an app verified when its developer has proven they publish it
(a website or a code-hosting account). An unverified Flatpak is usually packaged
by a third party, so you trust that maintainer as well as the developer. Like
Linux Mint, AppHub hides unverified Flathub apps unless the person opts in.

libappstream does not expose these <custom> values, so the XML is read directly
(about 0.7 s for Flathub's ~4,800 components) and cached by file mtime.
"""

from __future__ import annotations

import glob
import gzip
import logging
import os
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

log = logging.getLogger("apphub.verification")

VERIFIED = "flathub::verification::verified"
WEBSITE = "flathub::verification::website"
LOGIN = "flathub::verification::login_name"
PROVIDER = "flathub::verification::login_provider"


@dataclass(frozen=True)
class Verification:
    verified: bool
    by: Optional[str] = None  # "gimp.org", or "github: someone"


def flathub_appstream_files() -> list[str]:
    """AppStream files of every Flathub remote (system and user installations)."""
    roots = ["/var/lib/flatpak/appstream", os.path.expanduser("~/.local/share/flatpak/appstream")]
    out = []
    for root in roots:
        for path in sorted(glob.glob(os.path.join(root, "flathub*", "*", "active", "appstream.xml*"))):
            if path.endswith((".xml", ".xml.gz")):
                out.append(path)
    return out


def _open(path: str):
    return gzip.open(path, "rb") if path.endswith(".gz") else open(path, "rb")


def parse(path: str) -> dict[str, Verification]:
    """{app ID without .desktop: Verification} for every component in one file."""
    out: dict[str, Verification] = {}
    with _open(path) as f:
        for _event, el in ET.iterparse(f, events=("end",)):
            if el.tag != "component":
                continue
            app_id = (el.findtext("id") or "").strip()
            if app_id.endswith(".desktop"):
                app_id = app_id[: -len(".desktop")]
            values = {v.get("key"): (v.text or "").strip() for v in el.iter("value")}
            verified = values.get(VERIFIED) == "true"
            by = values.get(WEBSITE) or (
                f"{values[PROVIDER]}: {values[LOGIN]}" if values.get(LOGIN) and values.get(PROVIDER)
                else values.get(LOGIN))
            if app_id:
                out[app_id] = Verification(verified, by or None)
            el.clear()
    return out


_cache: dict[str, tuple[float, dict[str, Verification]]] = {}


def flathub_verification(paths: Optional[Iterable[str]] = None) -> dict[str, Verification]:
    """Merged verification for all Flathub remotes; a verified entry wins over an unverified one."""
    merged: dict[str, Verification] = {}
    for path in (flathub_appstream_files() if paths is None else paths):
        try:
            mtime = os.stat(path).st_mtime
            hit = _cache.get(path)
            if hit is None or hit[0] != mtime:
                hit = (mtime, parse(path))
                _cache[path] = hit
        except (OSError, ET.ParseError, EOFError) as e:
            log.warning("cannot read Flathub verification from %s: %s", path, e)
            continue
        for app_id, v in hit[1].items():
            if app_id not in merged or (v.verified and not merged[app_id].verified):
                merged[app_id] = v
    return merged
