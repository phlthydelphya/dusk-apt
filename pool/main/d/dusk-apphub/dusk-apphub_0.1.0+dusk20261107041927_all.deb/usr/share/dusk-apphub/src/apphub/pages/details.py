"""App details: header, description, screenshots, info rows and the install source selector."""

from __future__ import annotations

import os
from dataclasses import replace
from typing import Optional

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, Gtk, Pango  # noqa: E402

try:
    gi.require_version("GioUnix", "2.0")
    from gi.repository import GioUnix  # noqa: E402
    DesktopAppInfo = GioUnix.DesktopAppInfo
except (ValueError, ImportError):  # GLib older than 2.86
    DesktopAppInfo = Gio.DesktopAppInfo

from ..backend import AppInfo, BackendError, ErrorKind, Package, Progress, Source  # noqa: E402
from ..hub import Hub  # noqa: E402
from .. import fuse2, launchers, policy  # noqa: E402
from .launcher_dialog import LauncherDialog  # noqa: E402
from .common import (  # noqa: E402
    ProgressRow,
    Shell,
    StateStack,
    app_icon,
    clear,
    confirm_remove,
    error_text,
    report_failure,
    size_text,
)


def info_from_packages(group: list[Package], base: Optional[AppInfo] = None) -> AppInfo:
    """An AppInfo for packages found by a plain source search (no catalog entry)."""
    pkg = group[0]
    candidates = dict(base.candidates) if base else {}
    for p in group:
        candidates.setdefault(p.source, p.name)
    if base:
        return replace(base, candidates=candidates)
    return AppInfo(app_id=pkg.app_id or pkg.name, title=pkg.display_name, summary=pkg.summary,
                   icon=pkg.icon, candidates=candidates)


def desktop_app(pkg: Package, info: AppInfo):
    """The launcher for an installed package, when its desktop file can be found."""
    own = launchers.plan_for(pkg).desktop_id if pkg.source == Source.APPIMAGE else None
    for desktop_id in dict.fromkeys(filter(None, (own, pkg.app_id, info.app_id, pkg.name))):
        try:
            app = DesktopAppInfo.new(f"{desktop_id}.desktop")
        except TypeError:
            app = None
        if app:
            return app
    return None


def verification_label(info: AppInfo) -> Gtk.Widget:
    """Who maintains the Flatpak: its developer (verified) or a third party."""
    box = Gtk.Box(spacing=6)
    if info.flatpak_verified:
        icon = Gtk.Image(icon_name="security-high-symbolic")
        by = f" ({info.flatpak_verified_by})" if info.flatpak_verified_by else ""
        text = f"Verified Flatpak: maintained by its developer{by}"
        box.add_css_class("verified")
    else:
        icon = Gtk.Image(icon_name="dialog-warning-symbolic")
        text = "Unverified Flatpak: maintained by a third party, not the developer"
        box.add_css_class("unverified")
        box.set_tooltip_text(policy.UNVERIFIED_WARNING)
    label = Gtk.Label(label=text, xalign=0, wrap=True)
    label.add_css_class("caption")
    box.append(icon)
    box.append(label)
    box.update_property([Gtk.AccessibleProperty.LABEL], [text])
    return box


class InfoCell(Gtk.Box):
    """One "Additional information" entry: a small heading over its value."""

    def __init__(self, grid: Gtk.FlowBox, title: str, link: Optional[str] = None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=2, valign=Gtk.Align.START)
        heading = Gtk.Label(label=title, xalign=0)
        heading.add_css_class("caption-heading")
        heading.add_css_class("dim-label")
        self.append(heading)
        if link:
            self.value = Gtk.LinkButton(uri=link, label=link, halign=Gtk.Align.START)
            self.value.add_css_class("info-link")
        else:
            self.value = Gtk.Label(xalign=0, wrap=True, selectable=True,
                                   wrap_mode=Pango.WrapMode.WORD_CHAR)
        self.append(self.value)
        grid.append(self)
        self.child = self.get_parent()  # the FlowBoxChild, so hiding hides the slot

    def set_subtitle(self, text: str) -> None:
        self.value.set_label(text)

    def get_subtitle(self) -> str:
        return self.value.get_label()

    def set_visible(self, visible: bool) -> None:
        (self.child or self).set_visible(visible)


class DetailsPage(Adw.NavigationPage):
    def __init__(self, shell: Shell, hub: Hub, info: AppInfo, dusk_app=None):
        super().__init__(title=info.title)
        self.dusk_app = dusk_app  # a dusk.DuskApp: made for Dusk, maybe in no package source
        self.shell = shell
        self.hub = hub
        self.info = info
        self.packages: dict[Source, Package] = {}
        self.errors: list[BackendError] = []
        self.busy = False
        self.install_button: Optional[Gtk.Widget] = None
        self.remove_button: Optional[Gtk.Button] = None
        self.launcher_button: Optional[Gtk.Button] = None
        self.launcher_dialog: Optional[LauncherDialog] = None
        self.fuse2_button: Optional[Gtk.Button] = None
        self.fuse2_dialog: Optional[Adw.AlertDialog] = None
        self._fuse2_missing = fuse2.missing_for
        self.open_button: Optional[Gtk.Button] = None
        self.picked_source: Optional[Source] = None  # what the Version picker points at
        self._cancel = Gio.Cancellable()
        self.connect("hidden", lambda *_: self._cancel.cancel())

        actions = Gio.SimpleActionGroup()
        install_from = Gio.SimpleAction.new("install-from", GLib.VariantType.new("s"))
        install_from.connect("activate", lambda _a, v: self.install_from(Source(v.get_string())))
        actions.add_action(install_from)
        self.insert_action_group("details", actions)

        view = Adw.ToolbarView()
        # No title text: the window's search hangs over the middle of this bar, and the
        # header card below already names the app.
        view.add_top_bar(Adw.HeaderBar(title_widget=Gtk.Box()))
        self.state = StateStack(self._build_content(), self.load)
        view.set_content(self.state)
        self.set_child(view)
        # Wear the app's own seeded Dusk palette, as its hero slide does. The wash goes on
        # the content card, not the whole view, so the header stays on the frame and the
        # wash keeps the card's rounded corners.
        self.state.add_css_class("seed-wash")
        if seeder := getattr(shell, "seeder", None):
            seeder.seed(self, info.app_id, info.icon)
        self.load()

    # -- layout ---------------------------------------------------------

    def _build_content(self) -> Gtk.Widget:
        info = self.info
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20,
                      margin_top=12, margin_bottom=28, margin_start=12, margin_end=12)

        # Store-style header: icon, name, maker, what it is; the action column on the right.
        header = Gtk.Box(spacing=24)
        header.add_css_class("app-header")
        header.add_css_class("seed-glow")
        header.append(app_icon(info.icon, 128))
        names = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, valign=Gtk.Align.CENTER,
                        hexpand=True)
        title = Gtk.Label(label=info.title, xalign=0, wrap=True)
        title.add_css_class("store-title")
        names.append(title)
        if info.developer:
            dev = Gtk.Label(label=info.developer, xalign=0, wrap=True)
            dev.add_css_class("app-developer")
            names.append(dev)
        if info.summary:
            summary = Gtk.Label(label=info.summary, xalign=0, wrap=True)
            summary.add_css_class("dim-label")
            names.append(summary)
        if info.categories:
            cat = Gtk.Label(label=" · ".join(info.categories[:2]), xalign=0)
            cat.add_css_class("caption")
            cat.add_css_class("dim-label")
            names.append(cat)
        if Source.FLATPAK in info.candidates and info.flatpak_verified is not None:
            names.append(verification_label(info))
        header.append(names)

        # Install / Open / Remove plus the source picker; rebuilt on every state change.
        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, valign=Gtk.Align.CENTER,
                       width_request=240)
        self.side = side
        self.actions_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        side.append(self.actions_box)
        self.version_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, visible=False)
        version_label = Gtk.Label(label="Version", xalign=0)
        version_label.add_css_class("caption-heading")
        self.version_box.append(version_label)
        self.source_dropdown = Gtk.DropDown(model=Gtk.StringList())
        self.source_dropdown.update_property([Gtk.AccessibleProperty.LABEL], ["Version to install"])
        self.source_dropdown.connect("notify::selected", lambda *_: self._on_source_picked())
        self.version_box.append(self.source_dropdown)
        side.append(self.version_box)
        self.caption = Gtk.Label(xalign=0, wrap=True, max_width_chars=30)
        self.caption.add_css_class("caption")
        side.append(self.caption)
        header.append(side)
        self.header = header
        box.append(header)

        self.progress_row = ProgressRow()
        progress_list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        progress_list.add_css_class("boxed-list")
        progress_list.append(self.progress_row)
        progress_list.set_visible(False)
        self.progress_list = progress_list
        box.append(progress_list)

        self.screenshots = self._build_screenshots()
        if self.screenshots:
            box.append(self.screenshots)

        if info.description:
            about = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
            heading = Gtk.Label(label="About this app", xalign=0)
            heading.add_css_class("shelf-title")
            about.append(heading)
            for para in info.description.split("\n\n"):
                if para.strip():
                    about.append(Gtk.Label(label=para.strip(), xalign=0, wrap=True,
                                           wrap_mode=Pango.WrapMode.WORD_CHAR, selectable=True))
            box.append(about)

        more = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        heading = Gtk.Label(label="Additional information", xalign=0)
        heading.add_css_class("shelf-title")
        more.append(heading)
        grid = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, homogeneous=True,
                           min_children_per_line=1, max_children_per_line=3,
                           column_spacing=24, row_spacing=16)
        grid.add_css_class("info-grid")
        self.version_row = InfoCell(grid, "Version")
        self.source_row = InfoCell(grid, "Installs from")
        self.size_row = InfoCell(grid, "Size")
        self.available_row = InfoCell(grid, "Available from")
        if info.developer:
            InfoCell(grid, "Developer").set_subtitle(info.developer)
        if info.license:
            InfoCell(grid, "License").set_subtitle(info.license)
        if info.homepage:
            InfoCell(grid, "Homepage", link=info.homepage)
        more.append(grid)
        box.append(more)

        clamp = Adw.Clamp(maximum_size=1240, tightening_threshold=1240, child=box)
        return Gtk.ScrolledWindow(child=clamp, hscrollbar_policy=Gtk.PolicyType.NEVER)

    def set_compact(self, compact: bool) -> None:
        """Narrow windows: stack the header, actions under the name."""
        self.header.set_orientation(Gtk.Orientation.VERTICAL if compact
                                    else Gtk.Orientation.HORIZONTAL)
        self.side.set_size_request(-1 if compact else 240, -1)
        self.side.set_halign(Gtk.Align.FILL if compact else Gtk.Align.END)

    def _build_screenshots(self) -> Optional[Gtk.Widget]:
        """A carousel filled as images load; local files only cost a disk read."""
        if not self.info.screenshots:
            return None
        self.carousel = Adw.Carousel(spacing=12, allow_scroll_wheel=False, height_request=320)
        dots = Adw.CarouselIndicatorDots(carousel=self.carousel)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, visible=False)
        box.add_css_class("card")
        box.set_overflow(Gtk.Overflow.HIDDEN)
        box.append(self.carousel)
        box.append(dots)
        for url in self.info.screenshots[:6]:
            gfile = Gio.File.new_for_path(url) if os.path.isabs(url) else Gio.File.new_for_uri(url)
            gfile.load_bytes_async(self._cancel, self._on_screenshot, box)
        return box

    def _on_screenshot(self, gfile: Gio.File, result: Gio.AsyncResult, box: Gtk.Box) -> None:
        try:
            data, _etag = gfile.load_bytes_finish(result)
            texture = Gdk.Texture.new_from_bytes(data)
        except GLib.Error:
            return  # a missing screenshot is not worth an error
        picture = Gtk.Picture(paintable=texture, content_fit=Gtk.ContentFit.CONTAIN,
                              hexpand=True, vexpand=True,
                              alternative_text=f"Screenshot of {self.info.title}")
        self.carousel.append(picture)
        box.set_visible(True)

    # -- state ----------------------------------------------------------

    def load(self) -> None:
        self.state.loading()
        sources = policy.ordered(self.info.candidates)
        if not sources and self.dusk_app is not None:
            self._render_dusk()
            self.state.content()
            return
        if not sources:
            self.state.error(f"{self.info.title} cannot be installed",
                             "No software source offers this app")
            return
        self.packages = {}
        self.errors = []
        pending = set(sources)

        for source in sources:
            def done(pkg, err, source=source):
                if source not in pending:
                    return
                pending.discard(source)
                if err:
                    err.source = err.source or source
                    self.errors.append(err)
                else:
                    self.packages[source] = pkg
                if not pending:
                    self._loaded()
            self.hub.lookup(source, self.info.candidates[source], done)

    def _loaded(self) -> None:
        if not self.packages:
            if all(e.kind in (ErrorKind.NOT_FOUND, ErrorKind.UNSUPPORTED) for e in self.errors):
                text = "No software source on this computer offers it"
            else:
                text = "; ".join(error_text(e) for e in self.errors)
            self.state.error(f"Could not load {self.info.title}", text)
            return
        self._render()
        self.state.content()

    @property
    def installed(self) -> Optional[Package]:
        for source in policy.ordered(self.packages):
            if self.packages[source].installed:
                return self.packages[source]
        return None

    @property
    def default_source(self) -> Optional[Source]:
        return policy.preferred(self.packages)

    def alternatives(self) -> list[Source]:
        return [s for s in policy.ordered(self.packages) if s != self.default_source]

    def _render(self) -> None:
        clear(self.actions_box)
        self.install_button = self.remove_button = self.open_button = self.launcher_button = None
        self.version_box.set_visible(False)
        installed = self.installed
        if installed:
            self._render_installed(installed)
        else:
            self._render_install()
        shown = installed or self.packages[self.picked_source]

        self.version_row.set_subtitle(shown.version)
        self.source_row.set_subtitle(f"{shown.source}" + (f" ({shown.origin})" if shown.origin else ""))
        self.size_row.set_subtitle(size_text(shown))
        self.available_row.set_subtitle(", ".join(str(s) for s in policy.ordered(self.packages)))
        self._set_busy(self.busy)

    def _render_install(self) -> None:
        """One big Install for the picked source; Mint-style Version picker for the rest."""
        sources = policy.ordered(self.packages)
        if self.picked_source not in sources:
            self.picked_source = self.default_source
        button = Gtk.Button(label="Install")
        button.add_css_class("suggested-action")
        button.add_css_class("install-button")
        button.connect("clicked", lambda *_: self.install_from(self.picked_source))
        self.install_button = button
        self.actions_box.append(button)

        self._dropdown_sources = sources
        labels = Gtk.StringList()
        for source in sources:
            pkg = self.packages[source]
            note = " (recommended)" if source == self.default_source and len(sources) > 1 else ""
            if source == Source.FLATPAK and self.info.flatpak_verified is False:
                note = " (unverified)"
            labels.append(" ".join(filter(None, (str(source), pkg.version))) + note)
        self._syncing_dropdown = True
        self.source_dropdown.set_model(labels)
        self.source_dropdown.set_selected(sources.index(self.picked_source))
        self._syncing_dropdown = False
        self.version_box.set_visible(len(sources) > 1)
        self._describe_pick()

    def _on_source_picked(self) -> None:
        if getattr(self, "_syncing_dropdown", False) or not getattr(self, "_dropdown_sources", None):
            return
        i = self.source_dropdown.get_selected()
        if 0 <= i < len(self._dropdown_sources):
            self.picked_source = self._dropdown_sources[i]
            self._describe_pick()
            shown = self.packages[self.picked_source]
            self.version_row.set_subtitle(shown.version)
            self.source_row.set_subtitle(f"{shown.source}" + (f" ({shown.origin})" if shown.origin else ""))
            self.size_row.set_subtitle(size_text(shown))

    def _describe_pick(self) -> None:
        source = self.picked_source
        if self.install_button is not None:
            self.install_button.set_tooltip_text(f"Install {self.info.title} from {source}")
        reason = policy.SOURCE_REASON.get(source, "")
        text = f"From <b>{source}</b>" + (f" — {GLib.markup_escape_text(reason.lower())}" if reason else "")
        others = [s for s in self.alternatives() if s != source]
        if source != self.default_source:
            text = f"From <b>{source}</b>, instead of the recommended {self.default_source}"
        elif others:
            text += ". Pick another version below."
        self.caption.set_markup(text)

    def _render_installed(self, pkg: Package) -> None:
        launcher = desktop_app(pkg, self.info)
        no_fuse2 = pkg.source == Source.APPIMAGE and self._fuse2_missing(pkg.id)
        self.fuse2_button = None
        if no_fuse2:
            self.fuse2_button = Gtk.Button(label=fuse2.BUTTON, tooltip_text=fuse2.CAPTION)
            self.fuse2_button.add_css_class("suggested-action")
            self.fuse2_button.connect("clicked", lambda *_: self.offer_fuse2(pkg))
            self.actions_box.append(self.fuse2_button)
        if launcher:
            self.open_button = Gtk.Button(label="Open")
            if not no_fuse2:
                self.open_button.add_css_class("suggested-action")
            self.open_button.add_css_class("install-button")
            # Opening an old AppImage without FUSE 2 fails silently; offer the fix instead.
            self.open_button.connect("clicked", lambda *_: self.offer_fuse2(pkg) if no_fuse2
                                     else self._launch(launcher))
            self.actions_box.append(self.open_button)
        elif pkg.source == Source.APPIMAGE:
            self.launcher_button = Gtk.Button(label="Add to App Drawer…",
                                              tooltip_text="Make a launcher and an icon for this AppImage")
            self.launcher_button.connect("clicked", lambda *_: self.offer_launcher(pkg))
            self.actions_box.append(self.launcher_button)
        if not pkg.essential:
            self.remove_button = Gtk.Button(label="Remove")
            self.remove_button.add_css_class("destructive-action")
            self.remove_button.set_tooltip_text(f"Remove {self.info.title}")
            self.remove_button.connect("clicked", lambda *_: self._confirm_remove(pkg))
            self.actions_box.append(self.remove_button)
        text = f"Installed from {pkg.source}, version {pkg.version}"
        if pkg.essential:
            text += ". Part of the system; it cannot be removed"
        if no_fuse2:
            text += ". " + fuse2.CAPTION
        self.caption.set_markup(GLib.markup_escape_text(text))

    def _render_dusk(self) -> None:
        """A Dusk app that no package source carries yet: open it, or say where it comes from."""
        app = self.dusk_app
        clear(self.actions_box)
        self.install_button = self.remove_button = self.open_button = self.launcher_button = None
        launcher = app.launcher()
        if launcher:
            self.open_button = Gtk.Button(label="Open")
            self.open_button.add_css_class("suggested-action")
            self.open_button.add_css_class("install-button")
            self.open_button.connect("clicked", lambda *_: self._launch(launcher))
            self.actions_box.append(self.open_button)
            text = "Installed with Dusk Desktop"
        else:
            text = "Ships with Dusk Desktop. It is not installed on this computer yet"
        if app.replaces:
            text += f". Dusk’s build of {app.replaces}"
        self.caption.set_markup(GLib.markup_escape_text(text + "."))
        self.version_row.set_visible(False)  # no package, so no version to report
        self.source_row.set_subtitle("Dusk Desktop")
        self.size_row.set_visible(False)
        self.available_row.set_subtitle("Dusk Desktop")
        self.progress_list.set_visible(False)

    def _set_busy(self, busy: bool) -> None:
        self.busy = busy
        self.actions_box.set_sensitive(not busy)
        self.progress_list.set_visible(busy)
        if busy:
            self.progress_row.start()
        else:
            self.progress_row.stop()

    # -- actions --------------------------------------------------------

    def install_from(self, source: Source, confirmed: bool = False) -> None:
        pkg = self.packages.get(source)
        if self.busy or pkg is None or pkg.installed:
            return
        if source == Source.FLATPAK and self.info.flatpak_verified is False and not confirmed:
            self._confirm_unverified(source)
            return
        self._set_busy(True)
        self.hub.install(pkg, self._on_progress,
                         lambda result, err: self._on_change_done("install", source, result, err))

    def _confirm_unverified(self, source: Source) -> None:
        """Linux Mint's rule: an unverified Flatpak is installed only on a clear yes."""
        dialog = Adw.AlertDialog(heading=f"Install unverified {self.info.title}?",
                                 body=policy.UNVERIFIED_WARNING)
        dialog.add_response("cancel", "Cancel")
        dialog.add_response("install", "Install Anyway")
        dialog.set_response_appearance("install", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_default_response("cancel")
        dialog.set_close_response("cancel")
        dialog.connect("response", lambda _d, r: r == "install" and self.install_from(source, True))
        dialog.present(self)
        self.unverified_dialog = dialog

    def _confirm_remove(self, pkg: Package) -> None:
        if self.busy or pkg.essential:
            return
        confirm_remove(self, pkg, lambda: self.remove(pkg))

    def remove(self, pkg: Package) -> None:
        """Remove without asking; the confirmation dialog calls this."""
        if self.busy:
            return
        self._set_busy(True)
        self.hub.remove(pkg, self._on_progress,
                        lambda result, err: self._on_change_done("remove", pkg.source, result, err))

    def _on_progress(self, p: Progress) -> None:
        self.progress_row.update(p)

    def _on_change_done(self, verb: str, source: Source, pkg: Optional[Package],
                        err: Optional[BackendError]) -> None:
        name = self.info.title
        self.busy = False
        if err:
            self._render()
            report_failure(self.shell, f"{verb} {name}", err)
            return
        self.packages[source] = pkg
        self._render()
        done = "installed" if verb == "install" else "removed"
        self.shell._notify(f"{name} {done}", f"{name} {pkg.version} from {pkg.source}")
        self.shell.package_changed()
        if source == Source.APPIMAGE:
            then = (lambda: self.offer_launcher(pkg)) if (
                verb == "install" and desktop_app(pkg, self.info) is None) else None
            if verb == "install" and self._fuse2_missing(pkg.id):
                self.offer_fuse2(pkg, then)
            elif then:
                then()
            elif verb == "remove":
                try:
                    launchers.remove(launchers.plan_for(pkg).desktop_id)
                except OSError:
                    pass

    def offer_fuse2(self, pkg: Package, then=None) -> None:
        """Ask to install FUSE 2 for an AppImage whose runtime needs it; then() follows either way."""
        name = self.info.title
        dialog = Adw.AlertDialog(heading=fuse2.TITLE.format(name=name),
                                 body=fuse2.BODY.format(name=name, package=fuse2.PACKAGES[0]))
        dialog.add_response("cancel", "Not Now")
        dialog.add_response("install", "Install")
        dialog.set_response_appearance("install", Adw.ResponseAppearance.SUGGESTED)
        dialog.set_default_response("install")
        dialog.set_close_response("cancel")

        def answered(_d, response):
            if response == "install":
                self.install_fuse2(then)
            elif then:
                then()
        dialog.connect("response", answered)
        dialog.present(self)
        self.fuse2_dialog = dialog

    def install_fuse2(self, then=None, names=fuse2.PACKAGES) -> None:
        """Find Ubuntu's FUSE 2 library in APT and install it through PackageKit."""
        if self.busy:
            return
        self._set_busy(True)
        name = self.info.title

        def finish(text: Optional[str] = None, err: Optional[BackendError] = None) -> None:
            self._set_busy(False)
            self._render()
            if err:
                report_failure(self.shell, "install FUSE 2", err)
            elif text:
                self.shell.toast(text)
            if then:
                then()

        def installed(_result, err):
            finish(None if err else fuse2.DONE.format(name=name), err)

        def try_next(rest):
            if not rest:
                finish(fuse2.NOT_FOUND)
                return

            def found(apt_pkg, err):
                if err or apt_pkg is None:
                    try_next(rest[1:])
                elif apt_pkg.installed:
                    finish(fuse2.DONE.format(name=name))
                else:
                    self.hub.install(apt_pkg, self._on_progress, installed)
            self.hub.lookup(Source.APT, rest[0], found)
        try_next(tuple(names))

    def offer_launcher(self, pkg: Package) -> None:
        """The Add to App Drawer dialog for an AppImage without a launcher."""
        self.launcher_dialog = LauncherDialog(self.shell, pkg, lambda _result: self._render())
        self.launcher_dialog.present(self)

    def _launch(self, launcher) -> None:
        try:
            launcher.launch([], self.get_display().get_app_launch_context())
        except GLib.Error as e:
            self.shell.toast(f"Could not open {self.info.title}: {e.message}")

    def _open_uri(self, uri: str) -> None:
        Gtk.UriLauncher.new(uri).launch(self.get_root(), None, None, None)
