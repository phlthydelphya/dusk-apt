"""AppHub's own preferences (not system automation), in ~/.config/apphub/settings.json."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from gi.repository import GLib

SETTINGS_FILE = Path(GLib.get_user_config_dir()) / "apphub" / "settings.json"

DEFAULTS: dict[str, Any] = {
    # Like Linux Mint: Flathub apps not verified by their developer stay hidden.
    "show_unverified_flatpaks": False,
    # Maintenance findings the person chose to keep: "tool-id:key" strings.
    "maintenance_kept": [],
    # `apphub --watch`: offer an app drawer launcher for AppImages as they
    # finish downloading (downloads.py).
    "watch_downloads": True,
    # The background service's icon in the top bar (tray.py): "updates" shows it
    # while updates wait, "always" all the time, "never" not at all.
    "tray_icon": "updates",
}

TRAY_MODES = ("updates", "always", "never")


class Settings:
    def __init__(self, path: Path = SETTINGS_FILE):
        self.path = Path(path)
        self._data = dict(DEFAULTS)
        try:
            stored = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(stored, dict):
                self._data.update({k: v for k, v in stored.items() if k in DEFAULTS})
        except (OSError, ValueError):
            pass  # missing or broken file: defaults

    def get(self, key: str) -> Any:
        return self._data.get(key, DEFAULTS.get(key))

    def set(self, key: str, value: Any) -> None:
        if key not in DEFAULTS:
            raise KeyError(key)
        self._data[key] = value
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._data, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, self.path)

    @property
    def show_unverified_flatpaks(self) -> bool:
        return bool(self.get("show_unverified_flatpaks"))

    @property
    def watch_downloads(self) -> bool:
        return bool(self.get("watch_downloads"))

    @property
    def tray_icon(self) -> str:
        """One of TRAY_MODES. Older settings stored a bool: true is "updates"."""
        value = self.get("tray_icon")
        if value is True:
            return "updates"
        if value is False:
            return "never"
        return value if value in TRAY_MODES else DEFAULTS["tray_icon"]

    def is_kept(self, tool: str, key: str) -> bool:
        return f"{tool}:{key}" in (self.get("maintenance_kept") or [])

    def keep(self, tool: str, key: str, kept: bool = True) -> None:
        items = [k for k in (self.get("maintenance_kept") or []) if k != f"{tool}:{key}"]
        if kept:
            items.append(f"{tool}:{key}")
        self.set("maintenance_kept", items)
