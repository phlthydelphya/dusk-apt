"""Automatic updates, as a root systemd timer (data/systemd/apphub-autoupdate.*).

Reading the state needs no root: `systemctl is-enabled` answers for anyone, and
autoupdate.json is world-readable. Turning it on or off goes through the system
helper (`automation on|off`, pkexec).
"""

from __future__ import annotations

import json
import subprocess
from typing import Callable, Optional

from .backend import BackendError, Done, ErrorKind, run_blocking
from .system import AutomationState, run_system_helper

TIMER = "apphub-autoupdate.timer"
STATE_FILE = "/var/lib/apphub/autoupdate.json"


def parse_state_file(text: str) -> tuple[Optional[str], Optional[str]]:
    """(last_run, last_result) from autoupdate.json; (None, None) for anything unreadable."""
    try:
        data = json.loads(text)
    except ValueError:
        return None, None
    if not isinstance(data, dict):
        return None, None
    run, result = data.get("last_run"), data.get("result")
    return (run if isinstance(run, str) else None), (result if isinstance(result, str) else None)


class SystemdAutomation:
    """Implements system.Automation."""

    def __init__(self, systemctl: Callable = subprocess.run, state_path: str = STATE_FILE,
                 helper: Callable = run_system_helper):
        self._systemctl = systemctl
        self._state_path = state_path
        self._helper = helper

    # -- blocking reads (also called by tests) --------------------------------------

    def read_state(self) -> AutomationState:
        proc = self._systemctl(["systemctl", "is-enabled", TIMER], capture_output=True,
                               text=True, timeout=10)
        # "enabled", "enabled-runtime", "disabled", "static", "not-found"... Only the
        # first two mean the timer starts by itself.
        enabled = proc.stdout.strip().startswith("enabled")
        last_run = last_result = None
        try:
            with open(self._state_path, encoding="utf-8") as f:
                last_run, last_result = parse_state_file(f.read())
        except OSError:
            pass
        return AutomationState(enabled=enabled, policy="security", last_run=last_run,
                               last_result=last_result, snapshot_first=True)

    # -- Automation -----------------------------------------------------------------

    def state(self, done: Done[AutomationState]) -> None:
        run_blocking(self.read_state, done, _map_exc)

    def set_enabled(self, enabled: bool, done: Done[AutomationState]) -> None:
        def helper_done(_result, error) -> None:
            if error:
                done(None, error)
            else:
                self.state(done)  # report what systemd says now, not what we asked for

        self._helper(["automation", "on" if enabled else "off"], helper_done)


def _map_exc(e: Exception) -> BackendError:
    if isinstance(e, BackendError):
        return e
    return BackendError(ErrorKind.FAILED, str(e))
