"""Backend contract shared by every package source. FROZEN: change only through its owner.

The UI talks only to this contract (through hub.Hub). Each source implements
Backend and turns its own failures into BackendError.

Threading rule: every callback (done, progress) runs on the GLib main thread.
A backend whose library blocks uses run_blocking(), which hops back to the
main loop for it.

Completion rule: every call ends in exactly one call to its `done`, with
exactly one of (result, error) not None. A bug inside a backend must still
reach `done` as ErrorKind.FAILED; never leave the caller waiting.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from enum import Enum, StrEnum
from typing import Callable, Generic, Optional, Protocol, TypeVar

from gi.repository import GLib

T = TypeVar("T")


class Source(StrEnum):
    APT = "APT"
    FLATPAK = "Flatpak"
    SNAP = "Snap"
    APPIMAGE = "AppImage"


@dataclass(frozen=True)
class Package:
    id: str  # opaque; only the backend that made it may parse it
    name: str  # package name, Flatpak ref name, snap name or AppImage file stem
    version: str
    summary: str
    source: Source
    installed: bool
    title: Optional[str] = None  # human app name, when the source knows it
    app_id: Optional[str] = None  # AppStream component ID without ".desktop" suffix; joins sources
    origin: Optional[str] = None  # repository, remote, channel or directory it came from
    icon: Optional[str] = None  # icon name or absolute file path
    installed_size: Optional[int] = None  # bytes
    download_size: Optional[int] = None  # bytes
    update_version: Optional[str] = None  # set only by get_updates()
    update_tier: Optional[str] = None  # get_updates(): a system.Tier value ("security", ...)
    essential: bool = False  # removal would damage the system; UI must refuse to remove
    # get_updates(): apt defers this version on this machine because the distribution
    # is rolling it out gradually (phased updates). Listed, but not installable yet.
    phased: bool = False

    @property
    def display_name(self) -> str:
        return self.title or self.name


class ErrorKind(Enum):
    AUTH = "auth"  # authentication refused or dismissed
    BUSY = "busy"  # another package manager holds the lock
    NETWORK = "network"
    NOT_FOUND = "not-found"
    CANCELLED = "cancelled"
    UNSUPPORTED = "unsupported"  # this source cannot do this operation
    FAILED = "failed"


class BackendError(Exception):
    def __init__(self, kind: ErrorKind, message: str, source: Optional[Source] = None):
        super().__init__(message)
        self.kind = kind
        self.message = message
        self.source = source


@dataclass(frozen=True)
class Progress:
    percent: Optional[int]  # 0..100, or None when the backend cannot tell
    status: str  # short human text, e.g. "Downloading"


# done(result, error): exactly one of them is not None.
Done = Callable[[Optional[T], Optional[BackendError]], None]
OnProgress = Callable[[Progress], None]


class Backend(Protocol):
    source: Source

    def available(self) -> bool:
        """Cheap synchronous check that the source exists on this machine."""

    def lookup(self, name: str, done: Done[Package]) -> None:
        """One package by exact name. NOT_FOUND when absent."""

    def search(self, query: str, done: Done[list[Package]]) -> None:
        """Packages matching free text. Empty list, not an error, when none match."""

    def list_installed(self, done: Done[list[Package]]) -> None:
        """Installed user-facing apps (APT: packages; Flatpak: apps, not runtimes)."""

    def get_updates(self, done: Done[list[Package]]) -> None:
        """Installed packages with an update; each has update_version set."""

    def install(self, pkg: Package, progress: OnProgress, done: Done[Package],
                simulate: bool = False) -> None:
        """Result is the package re-read after the change (installed=True)."""

    def remove(self, pkg: Package, progress: OnProgress, done: Done[Package],
               simulate: bool = False) -> None:
        """Result is the package re-read after the change (installed=False)."""

    def update(self, pkgs: list[Package], progress: OnProgress, done: Done[list[Package]],
               simulate: bool = False) -> None:
        """Update the given packages; result is them re-read after the change."""


# -- catalog (AppStream) ---------------------------------------------------

@dataclass(frozen=True)
class AppInfo:
    app_id: str  # AppStream component ID without ".desktop" suffix
    title: str
    summary: str
    description: str = ""  # plain text, paragraphs separated by "\n\n"
    developer: Optional[str] = None
    icon: Optional[str] = None  # absolute path to a cached icon, or an icon name
    categories: tuple[str, ...] = ()  # freedesktop main categories, e.g. "Graphics"
    screenshots: tuple[str, ...] = ()  # image URLs, default first
    homepage: Optional[str] = None
    license: Optional[str] = None
    # Where it can be installed from; each value is the name Backend.lookup() takes.
    candidates: dict[Source, str] = field(default_factory=dict)
    # Flathub's developer verification of the Flatpak candidate: True verified, False
    # not verified (maintained by a third party), None no Flathub Flatpak to judge.
    flatpak_verified: Optional[bool] = None
    flatpak_verified_by: Optional[str] = None  # the verified website or account, when known


@dataclass(frozen=True)
class Rating:
    app_id: str
    average: float  # 0..5 stars
    count: int


class Catalog(Protocol):
    def load(self, done: Done[bool]) -> None:
        """Read local AppStream metadata. Must be called before the queries below."""

    def categories(self) -> list[str]: ...

    def featured(self, limit: int = 12) -> list[AppInfo]: ...

    def in_category(self, category: str) -> list[AppInfo]: ...

    def search(self, query: str, limit: int = 50) -> list[AppInfo]: ...

    def get(self, app_id: str) -> Optional[AppInfo]: ...

    def ratings(self, app_ids: list[str], done: Done[dict[str, Rating]]) -> None:
        """Network. Anonymous read only; never sends a user or machine ID."""


# -- helpers for backend authors -------------------------------------------

def on_main(fn: Callable[..., None]) -> Callable[..., None]:
    """Wrap a callback so calls from any thread run on the GLib main loop."""
    def call(*args):
        GLib.idle_add(lambda: (fn(*args), False)[1])
    return call


def run_blocking(work: Callable[[], T], done: Done[T],
                 map_exc: Callable[[Exception], BackendError]) -> None:
    """Run blocking `work` in a thread; deliver its result or mapped error on the main loop.

    map_exc turns any exception from `work` into a BackendError. If map_exc itself
    raises, the error is reported as ErrorKind.FAILED.
    """
    def thread():
        try:
            result, error = work(), None
        except Exception as e:  # noqa: BLE001 - contract: always reach done
            try:
                result, error = None, map_exc(e)
            except Exception as e2:  # noqa: BLE001
                result, error = None, BackendError(ErrorKind.FAILED, str(e2))
        on_main(done)(result, error)

    threading.Thread(target=thread, daemon=True).start()


class Once(Generic[T]):
    """Guard a done callback so a backend bug cannot call it twice."""

    def __init__(self, done: Done[T]):
        self._done = done
        self._called = False

    def __call__(self, result: Optional[T], error: Optional[BackendError]) -> None:
        if not self._called:
            self._called = True
            self._done(result, error)
