"""Noticing AppImages as they are downloaded.

`apphub --watch` (started at login) keeps AppHub running without a window and
watches the Downloads folder. When a download finishes and the file is an
AppImage (by its header, never by running it) with no app drawer launcher
yet, it asks, in a notification, whether to add one. Adding moves the file
into ~/Applications first unless the person turns that off, so clearing
Downloads does not break the launcher, and AppHub lists it as installed.

A download counts as finished when the browser renames its partial file to
the final name, when a file is moved in, or when a writer closes it; the size
must then hold still for SETTLE_MS. Each file is offered once per session.
The watch_downloads setting turns it off.
"""

from __future__ import annotations

import logging
import os
import re
import shutil
import stat
from typing import Callable, Optional

from gi.repository import Gio, GLib

from . import appimage, launchers

log = logging.getLogger("apphub.downloads")

SETTLE_MS = 2000
APPLICATIONS_DIR = "~/Applications"

# Browsers' and download tools' names for a file still being written
_PARTIAL_SUFFIXES = (".part", ".crdownload", ".download", ".partial", ".tmp", ".opdownload")


def downloads_dir() -> Optional[str]:
    """The Downloads folder (XDG), or None when it is unset or forbidden."""
    path = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD)
    if not path or appimage.is_forbidden_dir(path):
        return None
    return path


def is_partial(name: str) -> bool:
    lower = name.lower()
    return name.startswith(".") or lower.endswith(_PARTIAL_SUFFIXES)


def looks_like_appimage(path: str) -> bool:
    """A regular file (not a symlink) with an AppImage header."""
    try:
        if not stat.S_ISREG(os.lstat(path).st_mode):
            return False
    except OSError:
        return False
    return appimage.appimage_type(path) is not None


def has_launcher(path: str, home: Optional[str] = None) -> bool:
    """True when some launcher in the user's applications folder runs this file."""
    home = home or os.path.expanduser("~")
    folder = os.path.join(home, ".local", "share", "applications")
    quoted = {path, launchers.exec_quote(path)}
    try:
        names = os.listdir(folder)
    except OSError:
        return False
    for name in names:
        if not name.endswith(".desktop"):
            continue
        try:
            with open(os.path.join(folder, name), encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    if line.startswith(("Exec=", "TryExec=")) and any(q in line for q in quoted):
                        return True
        except OSError:
            continue
    return False


def free_name(directory: str, filename: str) -> str:
    """`filename` in `directory`, or "Name (2).AppImage" and so on when taken."""
    target = os.path.join(directory, filename)
    if not os.path.lexists(target):
        return target
    stem, ext = os.path.splitext(filename)
    stem = re.sub(r" \(\d+\)$", "", stem)
    n = 2
    while True:
        target = os.path.join(directory, f"{stem} ({n}){ext}")
        if not os.path.lexists(target):
            return target
        n += 1


def relocate(path: str, directory: str = APPLICATIONS_DIR) -> str:
    """Blocking. Move the AppImage into `directory` (created if missing) under a
    free name and return its new path. A file already there stays put."""
    directory = os.path.abspath(os.path.expanduser(directory))
    if os.path.dirname(os.path.abspath(path)) == directory:
        return path
    os.makedirs(directory, exist_ok=True)
    target = free_name(directory, os.path.basename(path))
    shutil.move(path, target)
    return target


class DownloadWatcher:
    """Watches one folder; calls `on_appimage(path)` once per finished AppImage."""

    def __init__(self, folder: str, on_appimage: Callable[[str], None], *,
                 enabled: Callable[[], bool] = lambda: True,
                 home: Optional[str] = None, settle_ms: int = SETTLE_MS):
        self.folder = folder
        self._on_appimage = on_appimage
        self._enabled = enabled
        self._home = home
        self._settle_ms = settle_ms
        self._pending: dict[str, tuple[int, int]] = {}  # path -> (source id, size seen)
        self._offered: set[str] = set()
        gfile = Gio.File.new_for_path(folder)
        self.monitor = gfile.monitor_directory(Gio.FileMonitorFlags.WATCH_MOVES, None)
        self.monitor.connect("changed", self._changed)

    def stop(self) -> None:
        self.monitor.cancel()
        for source, _size in self._pending.values():
            GLib.source_remove(source)
        self._pending.clear()

    def _changed(self, _monitor, file: Gio.File, other: Optional[Gio.File], event) -> None:
        E = Gio.FileMonitorEvent
        if event == E.RENAMED and other is not None:
            path = other.get_path()  # the partial file took its final name
        elif event in (E.CREATED, E.CHANGES_DONE_HINT, E.MOVED_IN):
            path = file.get_path()
        else:
            return
        if path and os.path.dirname(path) == self.folder:
            self.consider(path)

    def consider(self, path: str) -> None:
        """Start (or restart) the settle timer for a candidate file."""
        if is_partial(os.path.basename(path)) or path in self._offered:
            return
        old = self._pending.pop(path, None)
        if old is not None:
            GLib.source_remove(old[0])
        size = _size(path)
        source = GLib.timeout_add(self._settle_ms, self._settled, path)
        self._pending[path] = (source, size)

    def _settled(self, path: str) -> bool:
        _source, size = self._pending.pop(path, (0, -1))
        now = _size(path)
        if now < 0:
            return GLib.SOURCE_REMOVE  # gone again
        if now != size:
            self.consider(path)  # still growing
            return GLib.SOURCE_REMOVE
        if (self._enabled() and looks_like_appimage(path)
                and not has_launcher(path, self._home)):
            self._offered.add(path)
            self._on_appimage(path)
        return GLib.SOURCE_REMOVE


def _size(path: str) -> int:
    try:
        return os.stat(path).st_size
    except OSError:
        return -1
