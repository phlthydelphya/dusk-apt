"""Kernels: installed Linux kernels with Remove, newer ones APT offers with Install."""

from __future__ import annotations

from typing import Callable, Optional

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gtk  # noqa: E402

from ..backend import BackendError, Progress  # noqa: E402
from ..system import Kernel, Kernels  # noqa: E402
from .common import ProgressRow, Shell, StateStack, icon_button, report_failure, widen  # noqa: E402


def kernel_label(kernel: Kernel) -> str:
    if not kernel.installed:
        return "Available"
    if kernel.running:
        return "Running"
    if kernel.protected:
        return "Fallback"
    return "Installed"


_LABEL_HELP = {
    "Running": "The kernel this computer started with. It cannot be removed.",
    "Fallback": "Kept so you can start the computer if a newer kernel fails.",
}


class KernelRow(Adw.ActionRow):
    def __init__(self, kernel: Kernel, on_install: Callable[[Kernel], None],
                 on_remove: Callable[[Kernel], None]):
        super().__init__(title=f"Linux {kernel.version}", use_markup=False)
        self.kernel = kernel
        self.label = kernel_label(kernel)
        self.set_subtitle(_LABEL_HELP.get(self.label, kernel.package or ""))
        self.add_prefix(Gtk.Image(icon_name="system-run-symbolic"))
        tag = Gtk.Label(label=self.label, valign=Gtk.Align.CENTER)
        tag.add_css_class("caption-heading" if kernel.protected else "caption")
        if not kernel.protected:
            tag.add_css_class("dim-label")
        self.add_suffix(tag)
        self.install_button: Optional[Gtk.Button] = None
        self.remove_button: Optional[Gtk.Button] = None
        if not kernel.installed:
            self.install_button = Gtk.Button(label="Install", valign=Gtk.Align.CENTER,
                                             tooltip_text=f"Install Linux {kernel.version}")
            self.install_button.connect("clicked", lambda *_: on_install(kernel))
            self.add_suffix(self.install_button)
        elif not kernel.protected:
            self.remove_button = Gtk.Button(label="Remove", valign=Gtk.Align.CENTER,
                                            tooltip_text=f"Remove Linux {kernel.version}")
            self.remove_button.add_css_class("destructive-action")
            self.remove_button.connect("clicked", lambda *_: on_remove(kernel))
            self.add_suffix(self.remove_button)

    def set_busy(self, busy: bool) -> None:
        for button in (self.install_button, self.remove_button):
            if button:
                button.set_sensitive(not busy)


class KernelsPage(Gtk.Box):
    def __init__(self, shell: Shell, kernels: Kernels):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.shell = shell
        self.kernels = kernels
        self.busy = False
        self.loading = False
        self.rows: dict[str, KernelRow] = {}
        self.dialog: Optional[Adw.AlertDialog] = None

        self.prefs = widen(Adw.PreferencesPage())
        self.progress_group = Adw.PreferencesGroup(visible=False)
        self.progress_row = ProgressRow()
        self.progress_group.add(self.progress_row)
        self.prefs.add(self.progress_group)

        self.installed_group = Adw.PreferencesGroup(
            title="Installed Kernels",
            description="The running kernel and one fallback are always kept.")
        self.refresh_button = icon_button("view-refresh-symbolic", "Reload", self.load)
        self.refresh_button.add_css_class("flat")
        self.installed_group.set_header_suffix(self.refresh_button)
        self.prefs.add(self.installed_group)

        self.available_group = Adw.PreferencesGroup(
            title="Available Kernels",
            description="Newer kernels from your software sources. They take effect after a restart.")
        self.prefs.add(self.available_group)

        self.state = StateStack(self.prefs, self.load)
        self.append(self.state)

    # -- loading --------------------------------------------------------

    def load(self) -> None:
        if self.busy or self.loading:
            return
        self.loading = True
        self.state.loading()
        self.kernels.list(self._on_loaded)

    def _on_loaded(self, kernels: Optional[list[Kernel]], error: Optional[BackendError]) -> None:
        self.loading = False
        for row in self.rows.values():
            self._group_of(row).remove(row)
        self.rows = {}
        if error:
            self.state.error("Could not list kernels", error.message)
            return
        available = False
        for kernel in kernels or []:
            row = KernelRow(kernel, self.install, self.ask_remove)
            self._group_of(row).add(row)
            self.rows[kernel.version] = row
            available = available or not kernel.installed
        self.available_group.set_visible(available)
        self.state.content()

    def _group_of(self, row: KernelRow) -> Adw.PreferencesGroup:
        return self.installed_group if row.kernel.installed else self.available_group

    # -- changes --------------------------------------------------------

    def install(self, kernel: Kernel) -> None:
        if self.busy:
            return
        self._set_busy(True, f"Installing Linux {kernel.version}")
        self.kernels.install(kernel, self._on_progress,
                             lambda k, err: self._on_changed(kernel, "installed", "install", err))

    def ask_remove(self, kernel: Kernel) -> Optional[Adw.AlertDialog]:
        if self.busy or kernel.protected:
            return None
        dialog = Adw.AlertDialog(
            heading=f"Remove Linux {kernel.version}?",
            body="Its image, modules and headers are uninstalled. "
                 "You can no longer choose it when the computer starts.")
        dialog.add_response("cancel", "Cancel")
        dialog.add_response("remove", "Remove")
        dialog.set_response_appearance("remove", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_default_response("cancel")
        dialog.set_close_response("cancel")
        dialog.connect("response", lambda _d, r: r == "remove" and self.remove(kernel))
        self.dialog = dialog
        dialog.present(self)
        return dialog

    def remove(self, kernel: Kernel) -> None:
        if self.busy:
            return
        self._set_busy(True, f"Removing Linux {kernel.version}")
        self.kernels.remove(kernel, self._on_progress,
                            lambda ok, err: self._on_changed(kernel, "removed", "remove", err))

    def _on_progress(self, p: Progress) -> None:
        self.progress_row.update(p)

    def _on_changed(self, kernel: Kernel, did: str, verb: str,
                    error: Optional[BackendError]) -> None:
        self._set_busy(False)
        if error:
            report_failure(self.shell, f"{verb} Linux {kernel.version}", error)
            return
        self.shell._notify(f"Linux {kernel.version} {did}",
                           "Restart the computer to use it." if did == "installed" else "")
        self.load()

    def _set_busy(self, busy: bool, title: str = "Starting") -> None:
        self.busy = busy
        self.refresh_button.set_sensitive(not busy)
        for row in self.rows.values():
            row.set_busy(busy)
        self.progress_group.set_visible(busy)
        if busy:
            self.progress_row.start(title)
        else:
            self.progress_row.stop()
