"""Maintenance: Mint's Software Sources > Maintenance tools, explained.

Each tool scans when asked. Every finding says, in plain words, what it is and whether
it matters, lists what the system knows about it, and offers concrete ways forward
with the best one marked: fix it, keep it (remembered), switch to a maintained copy,
or get updates from the maker. Anything that removes or downgrades is confirmed with
its own specific explanation.
"""

from __future__ import annotations

from typing import Optional

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gtk, Pango  # noqa: E402

from ..backend import BackendError, ErrorKind, Progress, Source  # noqa: E402
from ..settings import Settings  # noqa: E402
from ..system import (REMEDY_FIX, REMEDY_HOLD, REMEDY_KEEP, REMEDY_OPEN,  # noqa: E402
                      REMEDY_SWITCH, Finding, MaintenanceTool, Remedy, run_system_helper)
from .common import ProgressRow, Shell, error_text  # noqa: E402

# Tools whose fix changes the configured sources rather than installed packages.
SOURCE_TOOLS = {"mergelist", "duplicates", "missing-keys"}


def remedies_of(f: Finding) -> tuple[Remedy, ...]:
    """A finding's ways forward; tools that give none get their plain fix."""
    if f.remedies:
        return f.remedies
    return (Remedy(REMEDY_FIX, "Fix", f.detail or "Applies this tool's fix.", True, f.risky),)


def recommended_of(f: Finding) -> Optional[Remedy]:
    return next((r for r in remedies_of(f) if r.recommended), None)


class FindingRow(Adw.ExpanderRow):
    """Collapsed: the insight and the recommendation. Expanded: facts and every option."""

    def __init__(self, card: "ToolCard", finding: Finding):
        super().__init__(title=finding.title, subtitle=finding.summary or finding.detail,
                         use_markup=False, subtitle_lines=3)
        self.card = card
        self.finding = finding
        self.buttons: dict[str, Gtk.Button] = {}
        rec = recommended_of(finding)
        if rec:
            hint = Gtk.Label(label=rec.label, valign=Gtk.Align.CENTER)
            hint.add_css_class("caption")
            hint.add_css_class("dim-label")
            hint.set_tooltip_text("Recommended")
            self.add_suffix(hint)

        body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14, margin_top=12,
                       margin_bottom=14, margin_start=14, margin_end=14)
        if finding.facts:
            grid = Gtk.Grid(column_spacing=16, row_spacing=6)
            for i, fact in enumerate(finding.facts):
                label = Gtk.Label(label=fact.label, xalign=0, valign=Gtk.Align.START)
                label.add_css_class("caption-heading")
                label.add_css_class("dim-label")
                value = Gtk.Label(label=fact.value, xalign=0, wrap=True, selectable=True,
                                  wrap_mode=Pango.WrapMode.WORD_CHAR, hexpand=True)
                grid.attach(label, 0, i, 1, 1)
                grid.attach(value, 1, i, 1, 1)
            body.append(grid)
        options = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        for remedy in remedies_of(finding):
            line = Gtk.Box(spacing=12)
            button = Gtk.Button(label=remedy.label, valign=Gtk.Align.START, width_request=200)
            button.add_css_class("pill")
            if remedy.recommended:
                button.add_css_class("suggested-action")
            elif remedy.destructive:
                button.add_css_class("destructive-action")
            button.connect("clicked", lambda _b, r=remedy: card.page.choose(card, finding, r))
            self.buttons[remedy.id] = button
            why = Gtk.Label(label=remedy.explanation, xalign=0, wrap=True, hexpand=True,
                            valign=Gtk.Align.CENTER, wrap_mode=Pango.WrapMode.WORD_CHAR)
            why.add_css_class("dim-label")
            line.append(button)
            line.append(why)
            options.append(line)
        body.append(options)
        holder = Gtk.ListBoxRow(activatable=False, child=body)
        self.add_row(holder)

    def set_busy(self, busy: bool) -> None:
        for b in self.buttons.values():
            b.set_sensitive(not busy)


class ToolCard(Gtk.Box):
    """One tool: what it checks, Scan, then each finding explained."""

    def __init__(self, page: "MaintenancePage", tool: MaintenanceTool):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.add_css_class("card")
        self.page = page
        self.tool = tool
        self.rows: list[FindingRow] = []
        self.findings: list[Finding] = []
        self.show_kept = False
        self.busy = False
        self.scanned = False

        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin_top=14,
                        margin_bottom=14, margin_start=14, margin_end=14)
        head = Gtk.Box(spacing=12)
        names = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, hexpand=True)
        title = Gtk.Label(label=tool.title, xalign=0, wrap=True)
        title.add_css_class("heading")
        desc = Gtk.Label(label=tool.description, xalign=0, wrap=True,
                         wrap_mode=Pango.WrapMode.WORD_CHAR)
        desc.add_css_class("dim-label")
        names.append(title)
        names.append(desc)
        head.append(names)
        self.scan_button = Gtk.Button(label="Scan", valign=Gtk.Align.CENTER,
                                      tooltip_text=f"Scan: {tool.title}")
        self.scan_button.add_css_class("pill")
        self.scan_button.connect("clicked", lambda *_: self.scan())
        head.append(self.scan_button)
        inner.append(head)

        self.spinner = Adw.Spinner(halign=Gtk.Align.CENTER, height_request=32, visible=False)
        inner.append(self.spinner)
        status = Gtk.Box(spacing=12)
        self.status = Gtk.Label(xalign=0, wrap=True, visible=False, hexpand=True)
        self.status.add_css_class("dim-label")
        status.append(self.status)
        self.kept_button = Gtk.Button(visible=False, valign=Gtk.Align.CENTER)
        self.kept_button.add_css_class("flat")
        self.kept_button.connect("clicked", lambda *_: self._toggle_kept())
        status.append(self.kept_button)
        inner.append(status)

        self.list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE, visible=False)
        self.list.add_css_class("boxed-list")
        self.list.update_property([Gtk.AccessibleProperty.LABEL], [f"{tool.title} findings"])
        inner.append(self.list)
        self.progress = ProgressRow()
        self.progress_list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE, visible=False)
        self.progress_list.add_css_class("boxed-list")
        self.progress_list.append(self.progress)
        inner.append(self.progress_list)
        if tool.needs_password:
            note = Gtk.Label(label="Fixes ask for your password", xalign=1)
            note.add_css_class("caption")
            note.add_css_class("dim-label")
            inner.append(note)
        self.append(inner)

    # -- scanning -----------------------------------------------------------

    def scan(self) -> None:
        if self.busy:
            return
        self._set_busy(True)
        self.spinner.set_visible(True)
        self.status.set_visible(False)
        try:
            self.tool.scan(self._scanned)
        except Exception as e:  # noqa: BLE001 - a broken tool must not wedge the card
            self._scanned(None, BackendError(ErrorKind.FAILED, str(e)))

    def _scanned(self, findings: Optional[list[Finding]], err: Optional[BackendError]) -> None:
        self._set_busy(False)
        self.spinner.set_visible(False)
        self.scanned = True
        if err:
            self.findings = []
            self._render()
            self._say(f"Could not scan: {error_text(err)}")
            return
        self.findings = list(findings or [])
        self._render()

    def _key(self, f: Finding) -> str:
        return f.key or f.id

    def kept(self, f: Finding) -> bool:
        return self.page.settings.is_kept(self.tool.id, self._key(f))

    def _render(self) -> None:
        self.list.remove_all()
        self.rows = []
        shown = [f for f in self.findings if self.show_kept or not self.kept(f)]
        n_kept = sum(1 for f in self.findings if self.kept(f))
        for f in shown:
            row = FindingRow(self, f)
            self.rows.append(row)
            self.list.append(row)
        self.list.set_visible(bool(self.rows))
        frozen = list(getattr(self.tool, "frozen", []) or [])
        note = (f" Frozen on purpose, so left alone: {', '.join(frozen)}." if frozen else "")
        if not self.findings:
            self._say(("Nothing to fix." + note) if self.scanned else "")
        elif not shown:
            self._say("Nothing new. Everything found is something you chose to keep." + note)
        elif note:
            self._say(note.strip())
        else:
            self.status.set_visible(False)
        self.kept_button.set_visible(n_kept > 0)
        self.kept_button.set_label(("Hide kept" if self.show_kept else f"Show kept ({n_kept})"))

    def _toggle_kept(self) -> None:
        self.show_kept = not self.show_kept
        self._render()

    def _say(self, text: str) -> None:
        self.status.set_label(text)
        self.status.set_visible(True)

    def _set_busy(self, busy: bool) -> None:
        self.busy = busy
        self.scan_button.set_sensitive(not busy)
        for r in self.rows:
            r.set_busy(busy)

    def row_for(self, finding: Finding) -> Optional[FindingRow]:
        return next((r for r in self.rows if r.finding is finding), None)

    # -- fixing -------------------------------------------------------------

    def fix(self, findings: list[Finding], then=None) -> None:
        if self.busy or not findings:
            return
        self._set_busy(True)
        self.progress.start("Starting")
        self.progress_list.set_visible(True)

        def done(count: Optional[int], err: Optional[BackendError]) -> None:
            self.progress.stop()
            self.progress_list.set_visible(False)
            self._set_busy(False)
            if then is not None:
                then(count, err)
            else:
                self.page.fixed(self, findings, count, err)

        try:
            self.tool.fix(findings, lambda p: self.progress.update(p), done)
        except Exception as e:  # noqa: BLE001
            done(None, BackendError(ErrorKind.FAILED, str(e)))


class MaintenancePage(Gtk.Box):
    def __init__(self, shell: Shell, tools: list[MaintenanceTool], helper=run_system_helper):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.add_css_class("maintenance")
        self.shell = shell
        self._helper = helper
        self.settings: Settings = getattr(shell, "settings", None) or Settings()
        self.cards: dict[str, ToolCard] = {}
        self.confirm_dialog: Optional[Adw.AlertDialog] = None

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18,
                      margin_top=12, margin_bottom=28, margin_start=12, margin_end=12)
        head = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        title = Gtk.Label(label="Maintenance", xalign=0)
        title.add_css_class("store-title")
        sub = Gtk.Label(label="Checks for common package problems. Scanning changes nothing; "
                              "each finding explains itself and suggests what to do.",
                        xalign=0, wrap=True)
        sub.add_css_class("dim-label")
        head.append(title)
        head.append(sub)
        box.append(head)
        for tool in tools:
            card = ToolCard(self, tool)
            self.cards[tool.id] = card
            box.append(card)
        if not tools:
            box.append(Adw.StatusPage(icon_name="emblem-system-symbolic",
                                      title="No Maintenance Tools",
                                      description="None are available on this system."))
        clamp = Adw.Clamp(maximum_size=1240, tightening_threshold=1240, child=box)
        self.append(Gtk.ScrolledWindow(child=clamp,
                                       hscrollbar_policy=Gtk.PolicyType.NEVER, vexpand=True))

    def load(self) -> None:
        """Nothing scans by itself: some scans refresh APT, which can ask for a password."""

    # -- choosing a way forward --------------------------------------------

    def choose(self, card: ToolCard, finding: Finding, remedy: Remedy) -> None:
        if remedy.id == REMEDY_KEEP:
            self.keep(card, finding)
        elif remedy.id.startswith(REMEDY_OPEN):
            url = remedy.id[len(REMEDY_OPEN):]
            Gtk.UriLauncher.new(url).launch(self.get_root(), None, None, None)
        elif remedy.id.startswith(REMEDY_HOLD):
            self.freeze(card, finding, remedy.id[len(REMEDY_HOLD):])
        elif remedy.id.startswith(REMEDY_SWITCH):
            self._confirm(f"{remedy.label}?", f"{finding.summary}\n\n{remedy.explanation}",
                          remedy.label, False, lambda: self.switch(card, finding, remedy))
        elif remedy.id == REMEDY_FIX:
            if remedy.destructive or finding.risky:
                self._confirm(f"{remedy.label}: {finding.title}?",
                              f"{finding.summary}\n\n{remedy.explanation}",
                              remedy.label, remedy.destructive, lambda: card.fix([finding]))
            else:
                card.fix([finding])

    def _confirm(self, heading: str, body: str, action: str, destructive: bool, go) -> None:
        dialog = Adw.AlertDialog(heading=heading, body=body)
        dialog.add_response("cancel", "Cancel")
        dialog.add_response("go", action)
        dialog.set_response_appearance(
            "go", Adw.ResponseAppearance.DESTRUCTIVE if destructive else Adw.ResponseAppearance.SUGGESTED)
        dialog.set_default_response("cancel")
        dialog.set_close_response("cancel")
        dialog.connect("response", lambda _d, r: r == "go" and go())
        dialog.present(self)
        self.confirm_dialog = dialog

    def keep(self, card: ToolCard, finding: Finding) -> None:
        key = finding.key or finding.id
        self.settings.keep(card.tool.id, key, True)
        card._render()
        toast = Adw.Toast(title=f"Kept {finding.title}. AppHub won't list it again.", timeout=6,
                          button_label="Undo")
        toast.connect("button-clicked", lambda *_: (self.settings.keep(card.tool.id, key, False),
                                                    card._render()))
        self._toast(toast)

    def freeze(self, card: ToolCard, finding: Finding, name: str) -> None:
        """apt-mark hold through the system helper; the rescan then leaves it out."""
        card._set_busy(True)

        def held(_result, err: Optional[BackendError]) -> None:
            card._set_busy(False)
            if err:
                self.shell.toast(f"Could not freeze {name}: {error_text(err)}")
                return
            self.shell.toast(f"Froze {name}: updates and clean-ups leave it as it is")
            self.shell.package_changed()
            card.scan()

        self._helper(["hold", name], held)

    def switch(self, card: ToolCard, finding: Finding, remedy: Remedy) -> None:
        """Install the maintained copy first; remove the old one only when that worked."""
        _, source_name, name = remedy.id.split(":", 2)
        source = Source(source_name)
        hub = self.shell.hub
        card._set_busy(True)
        card.progress.start(f"Finding {name}")
        card.progress_list.set_visible(True)

        def stop(err: Optional[BackendError], what: str) -> None:
            card.progress.stop()
            card.progress_list.set_visible(False)
            card._set_busy(False)
            self.shell.toast(f"{what}: {error_text(err)}" if err else what)

        def looked_up(pkg, err) -> None:
            if err:
                stop(err, f"Could not find {name}")
                return
            card.progress.start(f"Installing from {source}")
            hub.install(pkg, card.progress.update, installed)

        def installed(pkg, err) -> None:
            if err:
                stop(err, f"Could not install the {source} version; nothing was removed")
                return
            card.progress.stop()
            card.progress_list.set_visible(False)
            card._set_busy(False)
            # The new copy works: now remove the old one through the tool's own fix.
            card.fix([finding], then=lambda count, e: self._switched(card, finding, source, count, e))

        hub.lookup(source, name, looked_up)

    def _switched(self, card, finding, source, count, err) -> None:
        if err:
            self.shell.toast(f"The {source} version is installed, but removing the old copy "
                             f"failed: {error_text(err)}")
        else:
            self.shell.toast(f"Switched {finding.title} to the {source} version")
        self.shell.package_changed()
        card.scan()

    def _toast(self, toast: Adw.Toast) -> None:
        overlay = getattr(self.shell, "toasts", None)
        if isinstance(overlay, Adw.ToastOverlay):  # the window's: toasts with an Undo button
            overlay.add_toast(toast)
        else:
            self.shell.toast(toast.get_title())

    def fixed(self, card: ToolCard, findings: list[Finding], count: Optional[int],
              err: Optional[BackendError]) -> None:
        if err:
            self.shell.toast(f"Could not fix: {error_text(err)}")
            return
        n = count or 0
        done = findings[0].title if len(findings) == 1 else f"{n} of {len(findings)}"
        self.shell.toast(f"{card.tool.title}: done ({done})" if n else
                         f"{card.tool.title}: nothing changed")
        if n:
            changed = "sources_changed" if card.tool.id in SOURCE_TOOLS else "package_changed"
            fn = getattr(self.shell, changed, None)
            if fn:
                fn()
        card.scan()
