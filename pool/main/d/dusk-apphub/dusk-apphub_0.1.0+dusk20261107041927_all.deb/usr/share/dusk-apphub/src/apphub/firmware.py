"""Firmware updates from the LVFS, through fwupd.

Reads come from `fwupdmgr --json`, which never prompts. An update runs
`fwupdmgr update <device> --json --no-reboot-check`: fwupd downloads the
cabinet, checks it against the signed metadata and asks polkit itself, so
AppHub never handles firmware files. --json turns off every interactive
question, including "Restart now?", so nothing restarts on its own.

Firmware is never part of "Update all" and never installed automatically.
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Callable, Optional

from .backend import BackendError, Done, ErrorKind, OnProgress, Progress, on_main, run_blocking

FWUPDMGR = "fwupdmgr"
TIMEOUT = 60  # reads
INSTALL_TIMEOUT = 60 * 30  # a large capsule download on a slow line

# fwupd device ids are SHA-1 hex; anything else never reaches the command line.
_DEVICE_ID = re.compile(r"[0-9a-f]{40}")
_TAG = re.compile(r"<[^>]+>")

# Runner(argv, timeout) -> (returncode, stdout, stderr)
Runner = Callable[[list[str], int], tuple[int, str, str]]


@dataclass(frozen=True)
class FirmwareUpdate:
    device_id: str
    device: str  # "System Firmware"
    vendor: str
    current: str
    version: str  # the newest release offered
    summary: str
    notes: str  # plain text
    urgency: str  # "", "low", "medium", "high", "critical"
    size: Optional[int]  # bytes
    needs_reboot: bool
    needs_shutdown: bool
    requires_ac: bool
    issues: tuple[str, ...] = field(default_factory=tuple)  # CVE / vendor advisories


def run_fwupdmgr(argv: list[str], timeout: int) -> tuple[int, str, str]:
    proc = subprocess.run([FWUPDMGR, *argv], capture_output=True, text=True, timeout=timeout,
                          stdin=subprocess.DEVNULL)
    return proc.returncode, proc.stdout or "", proc.stderr or ""


def markup_to_text(markup: str) -> str:
    """fwupd release descriptions are AppStream markup: <p>, <ul><li>."""
    text = re.sub(r"(?i)<li>", "• ", markup or "")
    text = re.sub(r"(?i)</(p|li|ul|ol)>", "\n", text)
    text = _TAG.sub("", text)
    text = (text.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"')
            .replace("&#39;", "'").replace("&amp;", "&"))
    return "\n".join(line.strip() for line in text.splitlines() if line.strip())


def parse_updates(text: str) -> list[FirmwareUpdate]:
    """`fwupdmgr get-updates --json`: one entry per device, its newest release."""
    try:
        data = json.loads(text or "{}")
    except ValueError as e:
        raise BackendError(ErrorKind.FAILED, f"fwupd answered something unreadable: {e}") from e
    out = []
    for dev in data.get("Devices") or []:
        releases = dev.get("Releases") or []
        device_id = str(dev.get("DeviceId") or "")
        if not releases or not _DEVICE_ID.fullmatch(device_id):
            continue
        rel = releases[0]  # fwupd lists the newest first
        flags = set(dev.get("Flags") or [])
        try:
            size = int(rel.get("Size")) if rel.get("Size") is not None else None
        except (TypeError, ValueError):
            size = None
        out.append(FirmwareUpdate(
            device_id=device_id,
            device=str(dev.get("Name") or "Device"),
            vendor=str(dev.get("Vendor") or rel.get("Vendor") or ""),
            current=str(dev.get("Version") or ""),
            version=str(rel.get("Version") or ""),
            summary=str(rel.get("Summary") or ""),
            notes=markup_to_text(str(rel.get("Description") or "")),
            urgency=str(rel.get("Urgency") or ""),
            size=size,
            needs_reboot="needs-reboot" in flags,
            needs_shutdown="needs-shutdown" in flags,
            requires_ac="require-ac" in flags,
            issues=tuple(str(i) for i in rel.get("Issues") or []),
        ))
    return out


def _nothing_to_do(code: int, out: str, err: str) -> bool:
    # fwupdmgr exits 2 ("nothing to do") when no device has an update.
    return code == 2 or "No updatable devices" in err or "No updates available" in (out + err)


class Fwupd:
    """Implements the firmware part of the system tools."""

    def __init__(self, runner: Runner = run_fwupdmgr,
                 which: Callable[[str], Optional[str]] = shutil.which):
        self._runner = runner
        self._which = which

    def available(self) -> bool:
        return self._which(FWUPDMGR) is not None

    def updates(self, done: Done[list[FirmwareUpdate]]) -> None:
        run_blocking(self._updates, done, _map_error)

    def _updates(self) -> list[FirmwareUpdate]:
        code, out, err = self._runner(["get-updates", "--json"], TIMEOUT)
        if code != 0:
            if _nothing_to_do(code, out, err):
                return []
            raise BackendError(ErrorKind.FAILED, _first_line(err) or f"fwupdmgr exited with {code}")
        return parse_updates(out)

    def install(self, update: FirmwareUpdate, progress: OnProgress,
                done: Done[FirmwareUpdate]) -> None:
        report = on_main(progress)

        def work() -> FirmwareUpdate:
            if not _DEVICE_ID.fullmatch(update.device_id):
                raise BackendError(ErrorKind.FAILED, "Not a fwupd device id")
            report(Progress(None, f"Updating {update.device}"))
            code, _out, err = self._runner(
                ["update", update.device_id, "--json", "--no-reboot-check"], INSTALL_TIMEOUT)
            if code != 0:
                raise BackendError(ErrorKind.FAILED,
                                   _first_line(err) or f"fwupdmgr exited with {code}")
            return update

        run_blocking(work, done, _map_error)


def _first_line(text: str) -> str:
    return next((line.strip() for line in (text or "").splitlines() if line.strip()), "")


def _map_error(e: Exception) -> BackendError:
    if isinstance(e, BackendError):
        return e
    if isinstance(e, subprocess.TimeoutExpired):
        return BackendError(ErrorKind.FAILED, "fwupd did not answer in time")
    if isinstance(e, FileNotFoundError):
        return BackendError(ErrorKind.UNSUPPORTED, "fwupd is not installed")
    return BackendError(ErrorKind.FAILED, str(e))
