from __future__ import annotations

import hashlib
import os
import sys
from typing import Optional

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gio, GLib  # noqa: E402

import importlib  # noqa: E402
import logging  # noqa: E402

from .backend import BackendError, ErrorKind, run_blocking  # noqa: E402
from .hub import Hub  # noqa: E402
from .window import AppWindow  # noqa: E402

APP_ID = "io.github.phlthydelphya.DuskAppHub"

log = logging.getLogger("apphub")

# (module, class). A source whose library is missing is left out; Hub also
# drops any whose available() is False. Order here is not preference: see policy.py.
_BACKENDS = [
    ("apt", "AptBackend"),
    ("flatpak", "FlatpakBackend"),
    ("snap", "SnapBackend"),
    ("appimage", "AppImageBackend"),
]


def _load(module: str, cls: str):
    try:
        return getattr(importlib.import_module(f".{module}", __package__), cls)()
    except (ImportError, ValueError) as e:  # ValueError: gi typelib missing
        log.warning("%s unavailable: %s", cls, e)
        return None


# Source managers for the Sources page: (module, class), same rules as _BACKENDS.
_SOURCE_MANAGERS = [
    ("remotes", "FlatpakRemotes"),
    ("ppa", "AptSources"),
    ("pools", "AppImagePools"),
]


def make_sources():
    """Return (hub, catalog) for the window. The window works with any mix of
    backends and with catalog=None."""
    hub = Hub(b for b in (_load(m, c) for m, c in _BACKENDS) if b is not None)
    catalog = _load("catalog", "AppStreamCatalog")
    return hub, catalog


def make_system() -> dict:
    """Mint-style system tools for the window; anything that cannot load is left out."""
    out = {}
    for key, module, cls in (("mirrors", "mirrors", "UbuntuMirrors"),
                             ("kernels", "kernels", "AptKernels"),
                             ("snapshots", "snapshots", "Timeshift"),
                             ("automation", "automation", "SystemdAutomation"),
                             ("firmware", "firmware", "Fwupd")):
        obj = _load(module, cls)
        if obj is not None and (key != "firmware" or obj.available()):
            out[key] = obj
    try:
        from .maintenance import default_tools
        out["tools"] = default_tools()
    except (ImportError, ValueError) as e:
        log.warning("maintenance tools unavailable: %s", e)
    return out


def make_source_managers() -> list:
    return [m for m in (_load(mod, cls) for mod, cls in _SOURCE_MANAGERS) if m is not None]


def make_firmware():
    """A firmware.Fwupd when fwupdmgr is installed, else None."""
    fw = _load("firmware", "Fwupd")
    return fw if fw is not None and fw.available() else None


# A D-Bus activated service (the Shell search provider woke it) stays this long
# after its last request, then exits.
SERVICE_IDLE_MS = 60 * 1000


class AppHub(Adw.Application):
    """The window, and the background service (service.py) in the same process.

    Whichever process owns the app ID serves the D-Bus API and the search
    provider. `apphub --watch` (autostart) is that process from login: it holds
    itself, checks for updates (UpdateMonitor), shows the top bar icon (tray.py)
    and watches Downloads. Opening AppHub then opens the window in it.
    """

    def __init__(self, watch: bool = False, service: bool = False):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.HANDLES_OPEN)
        self.hub = None
        self.catalog = None
        # Started by `apphub --watch`: the first activation (from run()) opens
        # no window, so the process waits in the background
        self._quiet_start = watch
        # D-Bus activated (--gapplication-service): answer, then exit when idle
        self._service_mode = service
        self._watcher = None
        self._background = False
        self._conn: Optional[Gio.DBusConnection] = None
        self.monitor = None  # service.UpdateMonitor, once on the bus
        self._updates_object = None
        self._search_provider = None
        self.tray = None

    def do_startup(self):
        Adw.Application.do_startup(self)
        # Dusk follows GNOME's light/dark switch (light scheme since 2026-11-04), so
        # AppHub keeps libadwaita's default: follow the system.
        for name, param, handler in (
                # `apphub --watch`, and Preferences turning the watcher on
                ("watch-downloads", None, self._on_background),
                ("add-launcher", "s", self._on_add_launcher),
                ("ignore-download", "s", lambda *_: None),
                ("show-updates", None, lambda *_: self.show_page("updates")),
                ("show-firmware", None, lambda *_: self.show_page("firmware")),
                ("show-app", "s", lambda _a, p: self.show_app(p.get_string())),
                ("check-updates", None, lambda *_: self.monitor and self.monitor.check())):
            action = Gio.SimpleAction.new(name, GLib.VariantType.new(param) if param else None)
            action.connect("activate", handler)
            self.add_action(action)
        if self._service_mode:
            self.set_inactivity_timeout(SERVICE_IDLE_MS)

    # -- the background service (service.py) -----------------------------------

    def do_dbus_register(self, connection, object_path):
        if not Adw.Application.do_dbus_register(self, connection, object_path):
            return False
        from . import service
        self._conn = connection
        self.monitor = service.UpdateMonitor(
            self._get_hub, firmware=make_firmware(), notify=self._notify_updates,
            withdraw=lambda: self.withdraw_notification(service.NOTIFICATION_ID))
        self._updates_object = service.UpdatesObject(
            self.monitor, lambda: self.show_page("updates"), self.show_app)
        self._search_provider = service.SearchProvider(
            self._get_catalog, self.show_app, self.show_search, activity=self._busy)
        try:
            self._updates_object.register(connection)
            self._search_provider.register(connection)
        except GLib.Error as e:
            log.warning("cannot export AppHub's D-Bus objects: %s", e.message)
        return True

    def do_dbus_unregister(self, connection, object_path):
        if self.tray is not None:
            self.tray.stop()
            self.tray = None
        for obj in (self._updates_object, self._search_provider):
            if obj is not None:
                obj.unregister()
        self._conn = None
        Adw.Application.do_dbus_unregister(self, connection, object_path)

    def _get_hub(self):
        self._ensure_sources()
        return self.hub

    def _get_catalog(self):
        self._ensure_sources()
        return self.catalog

    def _busy(self) -> None:
        """A D-Bus request came in: in service mode, stay up a while longer."""
        if not self._service_mode:
            return
        self.hold()
        GLib.timeout_add(SERVICE_IDLE_MS, lambda: (self.release(), False)[1])

    def _on_background(self, *_args) -> None:
        """Keep running with no window: update checks, the tray icon, Downloads."""
        if not self._background:
            self._background = True
            self.hold()
            if self.monitor is not None:
                self.monitor.start()
            self.tray_setting_changed()
        self._on_watch()

    def tray_setting_changed(self) -> None:
        """Show or drop the top bar icon to match Preferences (tray_icon)."""
        from .settings import Settings
        mode = Settings().tray_icon
        wanted = (self._background and self.monitor is not None and self._conn is not None
                  and mode != "never")
        if wanted and self.tray is None:
            from .tray import Tray
            self.tray = Tray(self.monitor, lambda: self.show_page("updates"),
                             lambda: self.show_page("discover"), always=mode == "always")
            self.tray.start(self._conn)
        elif wanted:
            self.tray.set_always(mode == "always")
        elif not wanted and self.tray is not None:
            self.tray.stop()
            self.tray = None

    def updates_changed(self) -> None:
        """The window installed, removed or updated something: count again."""
        if self.monitor is not None and (self._background or self.monitor.state.last_checked):
            self.monitor.check_soon()

    def firmware_count_changed(self, count: int) -> None:
        if self.monitor is not None and count != len(self.monitor.state.firmware):
            self.updates_changed()

    def _window_visible(self) -> bool:
        win = self.get_active_window()
        return win is not None and win.get_visible() and win.is_active()

    def _notify_updates(self, title: str, body: str, urgent: bool) -> None:
        if self._window_visible():
            return  # the person is looking at AppHub already
        from . import service
        state = self.monitor.state if self.monitor is not None else None
        target = ("app.show-firmware" if state is not None and not state.count and state.firmware
                  else "app.show-updates")
        note = Gio.Notification.new(title)
        note.set_body(body)
        note.set_icon(Gio.ThemedIcon.new("software-update-urgent-symbolic" if urgent
                                         else "software-update-available-symbolic"))
        note.set_priority(Gio.NotificationPriority.HIGH if urgent
                          else Gio.NotificationPriority.NORMAL)
        note.set_default_action(target)
        note.add_button("Show Updates", target)
        self.send_notification(service.NOTIFICATION_ID, note)

    # -- opening pages, links and files --------------------------------------------

    def show_page(self, name: str) -> None:
        self.window().show_page(name)

    def show_app(self, app_id: str) -> None:
        from .links import Target
        self.window().open_link(Target("app", app_id))

    def show_search(self, query: str) -> None:
        self.window().show_search(query)

    def do_open(self, files, _n_files, _hint):
        from . import links
        win = self.window()
        for f in files:
            win.open_link(links.parse(f.get_uri()))

    def _ensure_sources(self) -> None:
        # Loaded on first use, not at startup: the background watcher needs none
        if self.hub is None:
            self.hub, self.catalog = make_sources()

    def window(self) -> AppWindow:
        self._ensure_sources()
        win = self.get_active_window() or AppWindow(self, self.hub, self.catalog,
                                                    sources=make_source_managers(),
                                                    system=make_system())
        win.present()
        return win

    def do_activate(self):
        if self._quiet_start:
            self._quiet_start = False
            return
        self.window()

    # -- the Downloads watcher (downloads.py) -----------------------------------

    def _on_watch(self) -> None:
        if self._watcher is not None:
            return
        from . import downloads
        from .settings import Settings
        folder = downloads.downloads_dir()
        if folder is None or not os.path.isdir(folder):
            log.warning("no Downloads folder to watch")
            return
        self._watcher = downloads.DownloadWatcher(
            folder, self._offer,
            enabled=lambda: bool(Settings().get("watch_downloads")))

    def _offer(self, path: str) -> None:
        """Ask, in a notification, whether to add the AppImage to the app drawer."""
        run_blocking(lambda: _inspect(path), lambda pkg, _err: self._notify_offer(path, pkg),
                     lambda e: BackendError(ErrorKind.FAILED, str(e)))

    def _notify_offer(self, path: str, pkg) -> None:
        name = (pkg.display_name if pkg is not None else None) or os.path.basename(path)
        note = Gio.Notification.new(f"{name} downloaded")
        note.set_body("It is an AppImage, which has no entry in the app drawer. "
                      "Add one, so it opens like any installed app?")
        if pkg is not None and pkg.icon:
            note.set_icon(Gio.FileIcon.new(Gio.File.new_for_path(pkg.icon)))
        target = GLib.Variant("s", path)
        note.set_default_action_and_target("app.add-launcher", target)
        note.add_button_with_target("Add to App Drawer", "app.add-launcher", target)
        note.add_button_with_target("Not Now", "app.ignore-download", target)
        self.send_notification(_offer_id(path), note)

    def _on_add_launcher(self, _action, param) -> None:
        path = param.get_string()
        self.withdraw_notification(_offer_id(path))
        from .pages.launcher_dialog import LauncherDialog

        def show(pkg, err) -> None:
            win = self.window()
            if pkg is None:
                win.toast(f"{os.path.basename(path)} is no longer there")
                return
            from . import appimage
            in_pool = os.path.dirname(path) in [
                os.path.abspath(os.path.expanduser(d)) for d in appimage.DEFAULT_DIRS]
            dialog = LauncherDialog(win, pkg, lambda _result: win.package_changed(),
                                    offer_move=not in_pool)
            dialog.present(win)
        run_blocking(lambda: _inspect(path), show, lambda e: BackendError(ErrorKind.FAILED, str(e)))


def _offer_id(path: str) -> str:
    return "appimage-" + hashlib.sha1(path.encode("utf-8", "surrogateescape")).hexdigest()[:16]


def _inspect(path: str):
    """Blocking. The AppImage at `path` as a Package (name, icon read from the
    image), or None when it is gone or not an AppImage."""
    from .appimage import AppImageBackend
    folder = os.path.dirname(path)
    pkg, _ident = AppImageBackend(dirs=[folder])._inspect(folder, os.path.basename(path), path)
    return pkg


def main() -> int:
    argv = list(sys.argv)
    watch = "--watch" in argv
    if not watch:
        # GApplication handles --gapplication-service itself; AppHub only needs to know
        return AppHub(service="--gapplication-service" in argv).run(argv)
    # Background mode: start the watcher in whichever process owns the app ID.
    # If AppHub is already open, that one starts watching and this one exits.
    app = AppHub(watch=True)
    app.register(None)
    app.activate_action("watch-downloads", None)
    if app.get_is_remote():
        return 0
    return app.run([a for a in argv if a != "--watch"])
