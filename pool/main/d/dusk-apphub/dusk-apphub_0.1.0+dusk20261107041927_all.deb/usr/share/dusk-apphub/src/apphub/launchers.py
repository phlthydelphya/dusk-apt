"""App-drawer launchers for AppImages, which bring none of their own.

An AppImage is one file; GNOME's app grid only lists .desktop files. This
writes one into ~/.local/share/applications pointing at the file, puts the
app's own icon (read from the image by appimage.py, never by running it)
into the hicolor icon theme and, when Dusk's icon engine is installed,
draws a Strata slab of that icon into the active Strata theme so the new
app looks like the rest of the drawer. Everything lives under the home
folder; nothing needs root. Launchers written here carry X-AppHub-Launcher,
and only those are ever removed again.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import stat
import subprocess
from dataclasses import dataclass, replace
from typing import Callable, Optional

import gi

gi.require_version("GdkPixbuf", "2.0")
from gi.repository import GdkPixbuf, GLib  # noqa: E402

from .backend import Package  # noqa: E402

MARK = "X-AppHub-Launcher"
STRATA_THEME = "Strata"
CATEGORIES = [("Utility", "Utilities"), ("Development", "Development"), ("Graphics", "Graphics"),
              ("Network", "Internet"), ("Office", "Office"), ("AudioVideo", "Sound and video"),
              ("Game", "Games"), ("System", "System"), ("Education", "Education"), ("Science", "Science")]
_ICON_EXTS = (".png", ".svg", ".svgz", ".xpm")


@dataclass(frozen=True)
class Plan:
    """One launcher, before it is written."""
    desktop_id: str  # file name without .desktop; also the icon name
    name: str
    comment: str
    exec_path: str  # the AppImage
    icon_src: Optional[str]  # the icon read out of the image, or None
    category: str = "Utility"
    version: str = ""

    @property
    def icon_name(self) -> str:
        return self.desktop_id

    def with_choices(self, name: str, comment: str, category: str) -> "Plan":
        return replace(self, name=name.strip() or self.name, comment=comment.strip(),
                       category=category if category in dict(CATEGORIES) else "Utility")


def _slug(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "-", text).strip("-.") or "app"


def plan_for(pkg: Package, category: str = "Utility") -> Plan:
    """The launcher an AppImage package would get. Always prefixed, so it can
    never shadow a system launcher of the same name in the user's folder."""
    base = pkg.app_id or pkg.name
    return Plan(desktop_id="apphub-" + _slug(base), name=(pkg.title or pkg.name).strip() or pkg.name,
                comment=(pkg.summary or "").strip(), exec_path=pkg.id, icon_src=pkg.icon,
                category=category if category in dict(CATEGORIES) else "Utility",
                version="" if pkg.version in ("", "unknown") else pkg.version)


def exec_quote(path: str) -> str:
    """A path as one Exec= argument, quoted the way the desktop entry spec wants."""
    if re.fullmatch(r"[A-Za-z0-9._/+:@%,=-]+", path):
        return path
    esc = path.replace("\\", "\\\\").replace('"', '\\"').replace("`", "\\`").replace("$", "\\$")
    return f'"{esc}"'


def desktop_text(plan: Plan, icon_name: Optional[str]) -> str:
    kf = GLib.KeyFile()
    g = "Desktop Entry"
    kf.set_string(g, "Type", "Application")
    kf.set_string(g, "Name", plan.name)
    if plan.comment:
        kf.set_string(g, "Comment", plan.comment)
    kf.set_string(g, "Exec", exec_quote(plan.exec_path) + " %U")
    kf.set_string(g, "TryExec", plan.exec_path)
    kf.set_string(g, "Icon", icon_name or "application-x-executable")
    kf.set_string(g, "Terminal", "false")
    kf.set_string(g, "Categories", plan.category + ";")
    kf.set_string(g, "StartupNotify", "true")
    if plan.version:
        kf.set_string(g, "X-AppImage-Version", plan.version)
    kf.set_string(g, MARK, "true")
    return kf.to_data()[0]


# -- icons ------------------------------------------------------------------

def _icon_dir(src: str) -> str:
    """hicolor size directory for the icon: scalable for SVG, WxH for a bitmap."""
    if src.lower().endswith((".svg", ".svgz")):
        return "scalable"
    try:
        _fmt, w, h = GdkPixbuf.Pixbuf.get_file_info(src)
        if w > 0 and h > 0:
            return f"{w}x{h}"
    except Exception:  # noqa: BLE001 - unreadable header: a safe default size
        pass
    return "256x256"


def install_icon(plan: Plan, home: str) -> Optional[str]:
    """Copy the icon into ~/.local/share/icons/hicolor; returns the icon name, or None."""
    src = plan.icon_src
    if not src or not os.path.isfile(src):
        return None
    ext = os.path.splitext(src)[1].lower()
    dest_dir = os.path.join(home, ".local/share/icons/hicolor", _icon_dir(src), "apps")
    os.makedirs(dest_dir, exist_ok=True)
    if ext in _ICON_EXTS:
        shutil.copyfile(src, os.path.join(dest_dir, plan.icon_name + ext))
    else:
        try:
            GdkPixbuf.Pixbuf.new_from_file(src).savev(os.path.join(dest_dir, plan.icon_name + ".png"), "png", [], [])
        except GLib.Error:
            return None
    return plan.icon_name


def read_art(path: str) -> Optional[tuple[bytes, str]]:
    """(bytes, 'svg' | 'png') for an icon file Strata can slab, else None."""
    try:
        with open(path, "rb") as fh:
            raw = fh.read()
    except OSError:
        return None
    low = path.lower()
    if low.endswith(".svgz"):
        import gzip
        try:
            raw = gzip.decompress(raw)
        except (OSError, EOFError):
            return None
        return raw, "svg"
    if low.endswith(".svg"):
        return raw, "svg"
    if low.endswith(".png"):
        return raw, "png"
    return None


def strata_theme_dir(home: str) -> str:
    return os.path.join(home, ".local/share/icons", STRATA_THEME)


def strata_available(home: str) -> bool:
    """Dusk's icon engine is importable and this account has a built Strata theme."""
    try:
        import strata  # noqa: F401
    except ImportError:
        return False
    return os.path.isfile(os.path.join(strata_theme_dir(home), "strata.json"))


def scheme_from_summary(summary: dict):
    """A Strata Scheme rebuilt from the theme's own strata.json (seed, swatches, vibrancy)."""
    from strata.color import parse_color, to_oklch
    from strata.palette import Palette, Swatch
    from strata.scheme import Scheme

    def swatch(hexs: str, share: float) -> Swatch:
        rgb, _alpha = parse_color(hexs)
        lightness, chroma, hue = to_oklch(*rgb)
        return Swatch(lightness, chroma, hue, share, share, hexs)

    seed = swatch(summary["seed"], 1.0)
    others = [swatch(s, 0.5) for s in summary.get("swatches") or []] or [seed]
    vibrancy = float(summary.get("vibrancy", 1.0))
    palette = Palette(seed, others, vibrancy, 0.5, seed.C < 0.02)
    return Scheme(palette, summary.get("scheme", "harmony"), vibrancy)


def strata_slab(plan: Plan, home: str, slab: Optional[Callable] = None, scheme=None) -> bool:
    """Draw the icon on a Strata slab into the active theme. False on any trouble:
    the plain hicolor icon is then what the drawer shows."""
    if not plan.icon_src:
        return False
    theme_dir = strata_theme_dir(home)
    try:
        art = read_art(plan.icon_src)
        if art is None:
            return False
        if scheme is None:
            with open(os.path.join(theme_dir, "strata.json"), encoding="utf-8") as fh:
                scheme = scheme_from_summary(json.load(fh))
        if slab is None:
            from strata.slab import slab as draw
        else:
            draw = slab
        svg = draw(scheme, art[0], art[1], key=plan.icon_name)
        out_dir = os.path.join(theme_dir, "scalable", "apps")
        os.makedirs(out_dir, exist_ok=True)
        tmp = os.path.join(out_dir, "." + plan.icon_name + ".svg.tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            fh.write(svg)
        os.replace(tmp, os.path.join(out_dir, plan.icon_name + ".svg"))
        return True
    except Exception:  # noqa: BLE001
        return False


def refresh_icon_cache(theme_dir: str, run=subprocess.run) -> bool:
    """Rebuild a theme's icon-theme.cache when it has one. GTK and the shell trust
    an existing cache, so a new icon file is invisible until it is refreshed."""
    if not os.path.isfile(os.path.join(theme_dir, "icon-theme.cache")):
        return False
    tool = shutil.which("gtk4-update-icon-cache") or shutil.which("gtk-update-icon-cache")
    if tool is None:
        return False
    try:
        return run([tool, "-q", "-t", "-f", theme_dir], capture_output=True, timeout=120,
                   check=False).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def ensure_executable(path: str) -> bool:
    """Add the owner's execute bit to an AppImage the user owns; True when it can run."""
    try:
        st = os.stat(path)
        if st.st_mode & stat.S_IXUSR:
            return True
        if st.st_uid != os.getuid():
            return False
        os.chmod(path, stat.S_IMODE(st.st_mode) | stat.S_IXUSR)
        return True
    except OSError:
        return False


# -- the launcher file ---------------------------------------------------------

def _ours(path: str) -> bool:
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            return f"{MARK}=true" in fh.read()
    except OSError:
        return False


def launcher_path(desktop_id: str, home: str) -> str:
    return os.path.join(home, ".local/share/applications", desktop_id + ".desktop")


def write_launcher(plan: Plan, icon_name: Optional[str], home: str) -> str:
    path = launcher_path(plan.desktop_id, home)
    if os.path.exists(path) and not _ours(path):
        raise FileExistsError(f"{path} exists and was not made by AppHub")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(desktop_text(plan, icon_name))
    os.chmod(tmp, 0o644)
    os.replace(tmp, path)
    return path


def create(plan: Plan, home: Optional[str] = None, with_strata: bool = True, *,
           available: Callable[[str], bool] = strata_available, slab: Optional[Callable] = None,
           scheme=None, refresh: Callable[[str], bool] = refresh_icon_cache) -> dict:
    """Blocking. Icon first, then the slab, then the launcher that names them.
    Returns {"desktop": path, "icon": name or None, "strata": bool}."""
    home = home or os.path.expanduser("~")
    if not os.path.isfile(plan.exec_path):
        raise FileNotFoundError(f"{plan.exec_path} no longer exists")
    if not ensure_executable(plan.exec_path):
        raise PermissionError(f"{plan.exec_path} is not executable and is not yours to change")
    icon = install_icon(plan, home)
    if icon:
        refresh(os.path.join(home, ".local/share/icons/hicolor"))
    strata = bool(icon and with_strata and available(home) and strata_slab(plan, home, slab, scheme))
    if strata:
        refresh(strata_theme_dir(home))
    desktop = write_launcher(plan, icon, home)
    return {"desktop": desktop, "icon": icon, "strata": strata}


def remove(desktop_id: str, home: Optional[str] = None,
           refresh: Callable[[str], bool] = refresh_icon_cache) -> bool:
    """Remove a launcher AppHub made, with its icons. Any other launcher is left alone."""
    home = home or os.path.expanduser("~")
    path = launcher_path(desktop_id, home)
    if not desktop_id.startswith("apphub-") or not _ours(path):
        return False
    os.remove(path)
    for root in (os.path.join(home, ".local/share/icons/hicolor"), strata_theme_dir(home)):
        if not os.path.isdir(root):
            continue
        gone = False
        for sub in os.listdir(root):
            for ext in _ICON_EXTS:
                p = os.path.join(root, sub, "apps", desktop_id + ext)
                if os.path.isfile(p):
                    os.remove(p)
                    gone = True
        if gone:
            refresh(root)
    return True
