"""The updates icon in the top bar: a StatusNotifierItem with a com.canonical.dbusmenu menu.

GTK 4 has no tray API and libayatana-appindicator is GTK 3 only, so both
interfaces are served straight over Gio. The host is GNOME Shell's AppIndicator
extension (ubuntu-appindicators); without a StatusNotifierWatcher on the bus the
icon never shows and nothing fails.

The icon is Passive (hidden) while nothing needs updating, Active when updates
wait, and NeedsAttention when one of them is a security update. With
always=True (Preferences: "always") it stays Active while nothing waits.
"""

from __future__ import annotations

import logging
from typing import Callable, Optional

from gi.repository import Gio, GLib

log = logging.getLogger("apphub.tray")

ITEM_PATH = "/io/github/phlthydelphya/DuskAppHub/StatusNotifierItem"
MENU_PATH = "/io/github/phlthydelphya/DuskAppHub/Menu"
ITEM_IFACE = "org.kde.StatusNotifierItem"
MENU_IFACE = "com.canonical.dbusmenu"
WATCHER_NAME = "org.kde.StatusNotifierWatcher"
WATCHER_PATH = "/StatusNotifierWatcher"

ICON = "software-update-available-symbolic"
URGENT_ICON = "software-update-urgent-symbolic"

ITEM_XML = f"""
<node>
  <interface name="{ITEM_IFACE}">
    <property name="Category" type="s" access="read"/>
    <property name="Id" type="s" access="read"/>
    <property name="Title" type="s" access="read"/>
    <property name="Status" type="s" access="read"/>
    <property name="WindowId" type="i" access="read"/>
    <property name="IconName" type="s" access="read"/>
    <property name="IconPixmap" type="a(iiay)" access="read"/>
    <property name="OverlayIconName" type="s" access="read"/>
    <property name="AttentionIconName" type="s" access="read"/>
    <property name="ToolTip" type="(sa(iiay)ss)" access="read"/>
    <property name="ItemIsMenu" type="b" access="read"/>
    <property name="Menu" type="o" access="read"/>
    <method name="ContextMenu"><arg name="x" type="i" direction="in"/><arg name="y" type="i" direction="in"/></method>
    <method name="Activate"><arg name="x" type="i" direction="in"/><arg name="y" type="i" direction="in"/></method>
    <method name="SecondaryActivate"><arg name="x" type="i" direction="in"/><arg name="y" type="i" direction="in"/></method>
    <method name="Scroll"><arg name="delta" type="i" direction="in"/><arg name="orientation" type="s" direction="in"/></method>
    <signal name="NewTitle"/>
    <signal name="NewIcon"/>
    <signal name="NewAttentionIcon"/>
    <signal name="NewToolTip"/>
    <signal name="NewStatus"><arg name="status" type="s"/></signal>
  </interface>
</node>
"""

MENU_XML = f"""
<node>
  <interface name="{MENU_IFACE}">
    <method name="GetLayout">
      <arg name="parentId" type="i" direction="in"/>
      <arg name="recursionDepth" type="i" direction="in"/>
      <arg name="propertyNames" type="as" direction="in"/>
      <arg name="revision" type="u" direction="out"/>
      <arg name="layout" type="(ia{{sv}}av)" direction="out"/>
    </method>
    <method name="GetGroupProperties">
      <arg name="ids" type="ai" direction="in"/>
      <arg name="propertyNames" type="as" direction="in"/>
      <arg name="properties" type="a(ia{{sv}})" direction="out"/>
    </method>
    <method name="GetProperty">
      <arg name="id" type="i" direction="in"/>
      <arg name="name" type="s" direction="in"/>
      <arg name="value" type="v" direction="out"/>
    </method>
    <method name="Event">
      <arg name="id" type="i" direction="in"/>
      <arg name="eventId" type="s" direction="in"/>
      <arg name="data" type="v" direction="in"/>
      <arg name="timestamp" type="u" direction="in"/>
    </method>
    <method name="EventGroup">
      <arg name="events" type="a(isvu)" direction="in"/>
      <arg name="idErrors" type="ai" direction="out"/>
    </method>
    <method name="AboutToShow">
      <arg name="id" type="i" direction="in"/>
      <arg name="needUpdate" type="b" direction="out"/>
    </method>
    <method name="AboutToShowGroup">
      <arg name="ids" type="ai" direction="in"/>
      <arg name="updatesNeeded" type="ai" direction="out"/>
      <arg name="idErrors" type="ai" direction="out"/>
    </method>
    <signal name="ItemsPropertiesUpdated">
      <arg name="updatedProps" type="a(ia{{sv}})"/>
      <arg name="removedProps" type="a(ias)"/>
    </signal>
    <signal name="LayoutUpdated">
      <arg name="revision" type="u"/>
      <arg name="parent" type="i"/>
    </signal>
    <property name="Version" type="u" access="read"/>
    <property name="TextDirection" type="s" access="read"/>
    <property name="Status" type="s" access="read"/>
    <property name="IconThemePath" type="as" access="read"/>
  </interface>
</node>
"""

# Menu item ids; 0 is the root.
SUMMARY, SHOW_UPDATES, CHECK, SEPARATOR, OPEN = 1, 2, 3, 4, 5


def _plural(n: int, word: str) -> str:
    return f"{n} {word}" + ("" if n == 1 else "s")


def summary_text(state) -> str:
    """One line for the menu and the tooltip; `state` is a service.UpdateState."""
    if state.checking and not state.last_checked:
        return "Checking for updates…"
    parts = []
    if state.count:
        parts.append(_plural(state.count, "update"))
    if state.firmware:
        parts.append(_plural(len(state.firmware), "firmware update"))
    if not parts:
        return "Everything is up to date"
    text = " and ".join(parts) + " available"
    if state.security:
        text += f" ({state.security} for security)"
    return text


def status_of(state, always: bool = False) -> str:
    if state.security:
        return "NeedsAttention"
    return "Active" if state.total or always else "Passive"


class Tray:
    """One StatusNotifierItem over a service.UpdateMonitor.

    show_updates() and open_app() open the window; check() asks for a check now.
    """

    def __init__(self, monitor, show_updates: Callable[[], None], open_app: Callable[[], None],
                 always: bool = False):
        self.monitor = monitor
        self.always = always
        self._show_updates = show_updates
        self._open_app = open_app
        self._conn: Optional[Gio.DBusConnection] = None
        self._regs: list[int] = []
        self._watch = 0
        self._revision = 1
        self._status = status_of(monitor.state, always)
        self._listener = lambda _s: self._changed()
        monitor.listeners.append(self._listener)

    # -- bus ------------------------------------------------------------

    def start(self, conn: Gio.DBusConnection) -> None:
        if self._conn is not None:
            return
        self._conn = conn
        item = Gio.DBusNodeInfo.new_for_xml(ITEM_XML).interfaces[0]
        menu = Gio.DBusNodeInfo.new_for_xml(MENU_XML).interfaces[0]
        self._regs = [conn.register_object(ITEM_PATH, item, self._item_call, self._item_get, None),
                      conn.register_object(MENU_PATH, menu, self._menu_call, self._menu_get, None)]
        # The watcher can come and go (GNOME Shell restarts, the extension is
        # switched off and on): register again every time it appears.
        self._watch = Gio.bus_watch_name_on_connection(
            conn, WATCHER_NAME, Gio.BusNameWatcherFlags.NONE, self._watcher_appeared, None)

    def stop(self) -> None:
        if self._watch:
            Gio.bus_unwatch_name(self._watch)
            self._watch = 0
        if self._conn is not None:
            for reg in self._regs:
                self._conn.unregister_object(reg)
        self._regs = []
        self._conn = None
        if self._listener in self.monitor.listeners:
            self.monitor.listeners.remove(self._listener)

    def _watcher_appeared(self, conn, _name, _owner) -> None:
        conn.call(WATCHER_NAME, WATCHER_PATH, WATCHER_NAME, "RegisterStatusNotifierItem",
                  GLib.Variant("(s)", (ITEM_PATH,)), None, Gio.DBusCallFlags.NONE, -1, None,
                  self._registered)

    def _registered(self, conn, result) -> None:
        try:
            conn.call_finish(result)
        except GLib.Error as e:
            log.warning("tray: StatusNotifierWatcher refused the icon: %s", e.message)

    # -- StatusNotifierItem ---------------------------------------------

    def item_properties(self) -> dict[str, GLib.Variant]:
        s = self.monitor.state
        icon = URGENT_ICON if s.security else ICON
        return {
            "Category": GLib.Variant("s", "SystemServices"),
            "Id": GLib.Variant("s", "apphub-updates"),
            "Title": GLib.Variant("s", "AppHub"),
            "Status": GLib.Variant("s", status_of(s, self.always)),
            "WindowId": GLib.Variant("i", 0),
            "IconName": GLib.Variant("s", icon),
            "IconPixmap": GLib.Variant("a(iiay)", []),
            "OverlayIconName": GLib.Variant("s", ""),
            "AttentionIconName": GLib.Variant("s", URGENT_ICON),
            "ToolTip": GLib.Variant("(sa(iiay)ss)", (icon, [], "AppHub", summary_text(s))),
            "ItemIsMenu": GLib.Variant("b", False),
            "Menu": GLib.Variant("o", MENU_PATH),
        }

    def _item_get(self, _conn, _sender, _path, _iface, name):
        return self.item_properties().get(name)

    def _item_call(self, _conn, _sender, _path, _iface, method, _params, invocation) -> None:
        if method in ("Activate", "SecondaryActivate"):
            self._show_updates()
        elif method not in ("ContextMenu", "Scroll"):
            invocation.return_dbus_error("org.freedesktop.DBus.Error.UnknownMethod", method)
            return
        invocation.return_value(None)

    # -- dbusmenu -------------------------------------------------------

    def items(self) -> list[tuple[int, dict[str, GLib.Variant]]]:
        s = self.monitor.state
        busy = s.checking
        return [
            (SUMMARY, {"label": GLib.Variant("s", summary_text(s)),
                       "enabled": GLib.Variant("b", False)}),
            (SHOW_UPDATES, {"label": GLib.Variant("s", "Show Updates"),
                            "enabled": GLib.Variant("b", bool(s.total))}),
            (CHECK, {"label": GLib.Variant("s", "Checking…" if busy else "Check for Updates"),
                     "enabled": GLib.Variant("b", not busy)}),
            (SEPARATOR, {"type": GLib.Variant("s", "separator")}),
            (OPEN, {"label": GLib.Variant("s", "Open AppHub")}),
        ]

    def layout(self) -> tuple:
        children = [GLib.Variant("(ia{sv}av)", (i, props, [])) for i, props in self.items()]
        return (0, {"children-display": GLib.Variant("s", "submenu")}, children)

    def _menu_get(self, _conn, _sender, _path, _iface, name):
        return {"Version": GLib.Variant("u", 3),
                "TextDirection": GLib.Variant("s", "ltr"),
                "Status": GLib.Variant("s", "normal"),
                "IconThemePath": GLib.Variant("as", [])}.get(name)

    def activate(self, item_id: int) -> None:
        if item_id == SHOW_UPDATES:
            self._show_updates()
        elif item_id == CHECK:
            self.monitor.check()
        elif item_id == OPEN:
            self._open_app()

    def _menu_call(self, _conn, _sender, _path, _iface, method, params, invocation) -> None:
        args = params.unpack()
        if method == "GetLayout":
            invocation.return_value(GLib.Variant("(u(ia{sv}av))", (self._revision, self.layout())))
        elif method == "GetGroupProperties":
            wanted = set(args[0])
            rows = [(i, props) for i, props in self.items() if not wanted or i in wanted]
            invocation.return_value(GLib.Variant("(a(ia{sv}))", (rows,)))
        elif method == "GetProperty":
            props = dict(self.items()).get(args[0], {})
            if args[1] not in props:
                invocation.return_dbus_error("org.freedesktop.DBus.Error.InvalidArgs", args[1])
                return
            invocation.return_value(GLib.Variant("(v)", (props[args[1]],)))
        elif method == "Event":
            if args[1] == "clicked":
                # After the reply: opening a window must not hold up the menu
                GLib.idle_add(lambda i=args[0]: (self.activate(i), False)[1])
            invocation.return_value(None)
        elif method == "EventGroup":
            for item_id, event, _data, _ts in args[0]:
                if event == "clicked":
                    GLib.idle_add(lambda i=item_id: (self.activate(i), False)[1])
            invocation.return_value(GLib.Variant("(ai)", ([],)))
        elif method == "AboutToShow":
            invocation.return_value(GLib.Variant("(b)", (False,)))
        elif method == "AboutToShowGroup":
            invocation.return_value(GLib.Variant("(aiai)", ([], [])))
        else:
            invocation.return_dbus_error("org.freedesktop.DBus.Error.UnknownMethod", method)

    # -- changes ----------------------------------------------------------

    def set_always(self, always: bool) -> None:
        """Preferences moved between "updates" and "always"."""
        if always != self.always:
            self.always = always
            self._changed()

    def _changed(self) -> None:
        if self._conn is None:
            return
        s = self.monitor.state
        status = status_of(s, self.always)
        try:
            self._emit(ITEM_PATH, ITEM_IFACE, "NewIcon", None)
            self._emit(ITEM_PATH, ITEM_IFACE, "NewToolTip", None)
            if status != self._status:
                self._status = status
                self._emit(ITEM_PATH, ITEM_IFACE, "NewStatus", GLib.Variant("(s)", (status,)))
            # The labels change with every check (Checking…, the count): new layout
            self._revision += 1
            self._emit(MENU_PATH, MENU_IFACE, "LayoutUpdated",
                       GLib.Variant("(ui)", (self._revision, 0)))
        except GLib.Error as e:
            log.warning("tray: cannot emit signals: %s", e.message)

    def _emit(self, path: str, iface: str, name: str, params) -> None:
        self._conn.emit_signal(None, path, iface, name, params)
