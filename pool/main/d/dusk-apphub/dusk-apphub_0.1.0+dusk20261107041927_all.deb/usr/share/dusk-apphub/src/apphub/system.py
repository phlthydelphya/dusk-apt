"""System management contract, modelled on Linux Mint's Update Manager and Software
Sources. FROZEN: change only through its owner, as backend.py and sources.py.

  Update tiers   updates sorted into Security, Software, Kernel, Flatpak, Snap
  Kernels        installed and available kernels; the running one is never removed
  Snapshots      a Timeshift restore point before updating
  Maintenance    tools that SCAN and report findings; nothing changes until the
                 person picks findings and confirms FIX
  Mirrors        the Ubuntu archive mirror: speed test, staleness, reset
  Automation     a root systemd timer that installs Security updates only

Root work goes through exactly two pkexec helpers with fixed commands: the existing
apphub-sources-helper (writes .sources files; mirrors and keys use it) and
apphub-system-helper below. Package changes go through PackageKit.

Completion and threading rules are backend.py's: every async call ends in exactly
one done(result, error) on the GLib main thread.
"""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from enum import StrEnum
from typing import Optional, Protocol

from .backend import BackendError, Done, ErrorKind, OnProgress, Package, Progress, Source, on_main, run_blocking

# -- update tiers ---------------------------------------------------------------


class Tier(StrEnum):
    SECURITY = "security"  # fixes for known vulnerabilities
    SOFTWARE = "software"  # bug fixes and ordinary updates
    KERNEL = "kernel"  # Linux kernel packages, shown and chosen separately
    FLATPAK = "flatpak"
    SNAP = "snap"
    APPIMAGE = "appimage"


TIER_ORDER = (Tier.SECURITY, Tier.KERNEL, Tier.SOFTWARE, Tier.FLATPAK, Tier.SNAP, Tier.APPIMAGE)
KERNEL_PREFIXES = ("linux-image-", "linux-headers-", "linux-modules-", "linux-generic",
                   "linux-signed-", "linux-hwe-", "linux-lowlatency")


def is_kernel_package(name: str) -> bool:
    return name.startswith(KERNEL_PREFIXES) or name in ("linux-generic", "linux-image-generic")


def tier_of(pkg: Package) -> Tier:
    """The tier an update belongs to. APT backends set update_tier; others follow source."""
    if pkg.source == Source.FLATPAK:
        return Tier.FLATPAK
    if pkg.source == Source.SNAP:
        return Tier.SNAP
    if pkg.source == Source.APPIMAGE:
        return Tier.APPIMAGE
    if pkg.update_tier:
        try:
            return Tier(pkg.update_tier)
        except ValueError:
            pass
    return Tier.KERNEL if is_kernel_package(pkg.name) else Tier.SOFTWARE


# The only tiers automation may install by itself (the user chose "security only").
AUTOMATIC_TIERS = (Tier.SECURITY, Tier.FLATPAK)

# -- kernels ----------------------------------------------------------------------


@dataclass(frozen=True)
class Kernel:
    version: str  # "6.17.0-5-generic"
    flavour: str  # "generic", "lowlatency", ...
    installed: bool
    running: bool = False
    package: Optional[str] = None  # the linux-image-* package name
    supported_until: Optional[str] = None  # when known
    protected: bool = False  # never removable: running, or the only fallback


class Kernels(Protocol):
    def list(self, done: Done[list[Kernel]]) -> None: ...
    def install(self, kernel: Kernel, progress: OnProgress, done: Done[Kernel]) -> None: ...
    def remove(self, kernel: Kernel, progress: OnProgress, done: Done[bool]) -> None:
        """Refuse (UNSUPPORTED) when kernel.protected."""


# -- snapshots -------------------------------------------------------------------


@dataclass(frozen=True)
class Snapshot:
    name: str  # Timeshift's snapshot name (its timestamp)
    comment: str
    tags: str


class Snapshots(Protocol):
    def available(self) -> bool:
        """Timeshift is installed."""

    def configured(self) -> bool:
        """Timeshift has a snapshot device set up, so a snapshot can be made."""

    def create(self, comment: str, done: Done[Snapshot], progress: Optional[OnProgress] = None) -> None:
        """A restore point now (system helper `snapshot`). `progress`, when given,
        gets the helper's "progress N% TEXT" lines as Progress while it runs."""


# -- maintenance -----------------------------------------------------------------


@dataclass(frozen=True)
class Fact:
    """One thing known about a finding, shown as "label: value"."""
    label: str  # "Installed"
    value: str  # "23 Oct 2026, from droidcam_client_amd64.deb (a file you downloaded)"


# Remedy ids every page understands; tools add their own.
REMEDY_FIX = "fix"  # the tool's own fix() for this finding
REMEDY_KEEP = "keep"  # leave it as it is, and stop showing it
REMEDY_OPEN = "open:"  # + a URL: open the maker's site
REMEDY_SWITCH = "switch:"  # + "<Source>:<name>": install that instead, then fix() (remove) this
REMEDY_HOLD = "hold:"  # + package name: freeze it at this version (apt-mark hold)


@dataclass(frozen=True)
class Remedy:
    """One way to resolve a finding: what the button says and exactly what it does."""
    id: str  # REMEDY_FIX, REMEDY_KEEP, REMEDY_OPEN + url, REMEDY_SWITCH + "Flatpak:org.x"
    label: str  # "Switch to the Flatpak"
    explanation: str  # what happens, in a sentence or two
    recommended: bool = False  # the one to do; at most one per finding
    destructive: bool = False  # removes or downgrades something


@dataclass(frozen=True)
class Finding:
    id: str  # opaque to the tool that made it
    title: str  # "libfoo1 (from ppa:x/y)"
    detail: str = ""  # why it was found, what fixing does
    selected: bool = True  # pre-ticked in the UI
    risky: bool = False  # the UI asks again before fixing a risky finding
    summary: str = ""  # the insight in one plain sentence: what it is, whether it matters
    facts: tuple[Fact, ...] = ()
    remedies: tuple[Remedy, ...] = ()  # empty: the page offers the tool's fix
    key: str = ""  # stable across versions ("zoom"), for remembering "keep"


class MaintenanceTool(Protocol):
    id: str  # "mergelist", "residual-config", "duplicates", "missing-keys",
    #          "foreign-downgrade", "foreign-remove"
    title: str
    description: str
    needs_password: bool

    def scan(self, done: Done[list[Finding]]) -> None:
        """Read only. An empty list means nothing to fix."""

    def fix(self, findings: list[Finding], progress: OnProgress, done: Done[int]) -> None:
        """Fix exactly the given findings; the result is how many were fixed."""


# -- mirrors -----------------------------------------------------------------------


@dataclass(frozen=True)
class Mirror:
    url: str  # archive root, ending in "/": "http://mirrors.example.org/ubuntu/"
    name: str  # host or the mirror's own name
    country: Optional[str] = None
    speed_bytes_per_s: Optional[float] = None  # measured; None until tested or if it failed
    stale: Optional[str] = None  # set when behind the official archive: "2 days behind"
    current: bool = False  # the mirror this system uses now
    official: bool = False  # archive.ubuntu.com itself


class Mirrors(Protocol):
    def current(self, done: Done[Mirror]) -> None: ...
    def candidates(self, done: Done[list[Mirror]]) -> None:
        """Mirrors near the person (network). Untested."""

    def test(self, mirrors: list[Mirror], progress: OnProgress, done: Done[list[Mirror]]) -> None:
        """Measure speed and staleness; result sorted fastest first, stale ones last."""

    def use(self, mirror: Mirror, done: Done[Mirror]) -> None:
        """Point the Ubuntu archive at `mirror` (security stays on the official host)."""

    def reset(self, done: Done[Mirror]) -> None:
        """Back to the official archive."""


# -- automation --------------------------------------------------------------------


@dataclass(frozen=True)
class AutomationState:
    enabled: bool
    policy: str = "security"  # what it may install; only "security" exists for now
    last_run: Optional[str] = None  # ISO time
    last_result: Optional[str] = None  # one line: "Installed 3 security updates"
    snapshot_first: bool = True


class Automation(Protocol):
    def state(self, done: Done[AutomationState]) -> None: ...
    def set_enabled(self, enabled: bool, done: Done[AutomationState]) -> None:
        """Turns the systemd timer on or off (system helper `automation on|off`)."""


# -- the system helper ---------------------------------------------------------------
#
# /usr/libexec/apphub/apphub-system-helper, run by pkexec, polkit action SYSTEM_ACTION.
# It takes exactly these commands and validates every argument again as root:
#   fix-mergelist                 empty /var/lib/apt/lists (files only; lock and partial/ kept)
#   purge-residual PKG...         dpkg --purge, only for packages in "rc" state
#   snapshot COMMENT              timeshift --create --scripted --comments COMMENT --tags O
#   automation on|off             systemctl enable|disable --now apphub-autoupdate.timer
#   hold PKG... / unhold PKG...   apt-mark hold|unhold, only for installed ("ii") packages
# Exit codes: 0 ok, 2 usage, 3 refused by validation, 4 the command failed. pkexec
# itself exits 126 (dismissed) or 127 (not authorised).

SYSTEM_HELPER = "/usr/libexec/apphub/apphub-system-helper"
SYSTEM_ACTION = "io.github.phlthydelphya.DuskAppHub.manage-system"
HELPER_COMMANDS = ("fix-mergelist", "purge-residual", "snapshot", "automation", "hold", "unhold")


@dataclass(frozen=True)
class HelperResult:
    output: str  # the helper's stdout, for logs


PROGRESS_LINE = re.compile(r"^progress (\d+)% ?(.*)$")


def parse_helper_stream(lines, on_progress: Optional[OnProgress]) -> str:
    """Hand the helper's "progress N% TEXT" lines to on_progress as Progress;
    return the other lines joined, the helper's real output."""
    kept = []
    for raw in lines:
        line = raw.rstrip("\n")
        found = PROGRESS_LINE.match(line)
        if found and on_progress is not None:
            percent = int(found.group(1))
            # Above 100 the helper's estimate has run out: percent unknown, keep going.
            on_progress(Progress(percent=percent if percent <= 100 else None, status=found.group(2) or "Working"))
        else:
            kept.append(line)
    return "".join(line + "\n" for line in kept)


def run_system_helper(args: list[str], done: Done[HelperResult],
                      helper: str = SYSTEM_HELPER, runner=subprocess.run,
                      progress: Optional[OnProgress] = None, popen=subprocess.Popen) -> None:
    """Run one helper command through pkexec, off the main thread. With
    `progress`, the helper's output is read line by line as it runs."""
    if not args or args[0] not in HELPER_COMMANDS:
        done(None, BackendError(ErrorKind.FAILED, f"unknown helper command {args[:1]}"))
        return

    def work() -> HelperResult:
        if progress is None:
            proc = runner(["pkexec", helper, *args], capture_output=True, text=True, timeout=3600)
            code, out, err = proc.returncode, proc.stdout, proc.stderr
        else:
            proc = popen(["pkexec", helper, *args], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            out = parse_helper_stream(proc.stdout, on_main(progress))
            err = proc.stderr.read()
            code = proc.wait(timeout=3600)
        if code in (126, 127):
            raise BackendError(ErrorKind.AUTH, "Authentication was not given")
        if code != 0:
            msg = (err or out or "").strip().splitlines()
            raise BackendError(ErrorKind.FAILED, msg[-1] if msg else f"helper exited {code}")
        return HelperResult(out)

    def map_exc(e: Exception) -> BackendError:
        if isinstance(e, BackendError):
            return e
        return BackendError(ErrorKind.FAILED, str(e))

    run_blocking(work, done, map_exc)

