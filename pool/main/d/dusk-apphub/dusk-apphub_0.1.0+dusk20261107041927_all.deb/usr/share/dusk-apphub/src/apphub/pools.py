"""AppImage pools: the folders AppHub scans and the feeds it searches.

A pool is either
  a folder  spec: an absolute path or a "~" path; AppHub scans it for AppImages.
  a feed    spec: an https URL to an AppImageHub-format feed.json; AppHub searches
            it and can download AppImages from it into the first folder.

The config is a small JSON file, ~/.config/apphub/appimage-pools.json:
  {"folders": [{"path": "~/Applications", "enabled": true}],
   "feeds":   [{"url": "https://...", "name": "AppImageHub", "enabled": true}]}
When the file is missing the folders are appimage.DEFAULT_DIRS and there are no
feeds. Plain strings are accepted for folders and feeds when the file is edited by hand.

Removing or disabling a pool only edits the config. No file or folder is ever deleted.
Everything here is read-only towards the network except an AppImage download, which
lives in appimage.py.
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
import threading
from dataclasses import dataclass, replace
from typing import Callable, Optional
from urllib.parse import urlsplit

from gi.repository import GLib

from .appimage import (
    DEFAULT_DIRS,
    FeedStore,
    Fetcher,
    default_feed_name,
    is_forbidden_dir,
    normalize_url,
)
from .backend import BackendError, Done, ErrorKind, Once, Source, on_main, run_blocking
from .sources import SourceEntry, SourcePlugin, SpecCheck

log = logging.getLogger("apphub.pools")

FOLDER_ID = "folder:"
FEED_ID = "feed:"


def default_config_path() -> str:
    return os.path.join(GLib.get_user_config_dir(), "apphub", "appimage-pools.json")


def resolve_folder(path: str) -> str:
    return os.path.abspath(os.path.expanduser(path))


def _tilde(path: str) -> str:
    home = os.path.expanduser("~")
    return "~" + path[len(home):] if path == home or path.startswith(home + os.sep) else path


@dataclass(frozen=True)
class FolderPool:
    path: str  # as the person wrote it: absolute or "~/..."
    enabled: bool = True

    @property
    def resolved(self) -> str:
        return resolve_folder(self.path)


@dataclass(frozen=True)
class FeedPool:
    url: str
    name: str
    enabled: bool = True


@dataclass(frozen=True)
class Pools:
    folders: tuple[FolderPool, ...]
    feeds: tuple[FeedPool, ...]


class PoolConfig:
    """The pool config file. Read on every call, so another instance's change is seen."""

    def __init__(self, path: Optional[str] = None,
                 default_folders: tuple[str, ...] = DEFAULT_DIRS) -> None:
        self.path = path or default_config_path()
        self._defaults = default_folders
        self._lock = threading.Lock()

    # -- reading --------------------------------------------------------

    def exists(self) -> bool:
        return os.path.isfile(self.path)

    def load(self) -> Pools:
        defaults = tuple(FolderPool(d) for d in self._defaults)
        try:
            with open(self.path, encoding="utf-8") as f:
                raw = json.load(f)
        except FileNotFoundError:
            return Pools(defaults, ())
        except (OSError, ValueError) as e:
            log.warning("ignoring unreadable pool config %s: %s", self.path, e)
            return Pools(defaults, ())
        if not isinstance(raw, dict):
            return Pools(defaults, ())
        folders = self._folders(raw.get("folders")) if "folders" in raw else defaults
        return Pools(folders, self._feeds(raw.get("feeds")))

    @staticmethod
    def _folders(raw) -> tuple[FolderPool, ...]:
        out: list[FolderPool] = []
        for e in raw if isinstance(raw, list) else []:
            if isinstance(e, str):
                e = {"path": e}
            if isinstance(e, dict) and isinstance(e.get("path"), str) and e["path"].strip():
                out.append(FolderPool(e["path"].strip(), e.get("enabled", True) is not False))
        return tuple(out)

    @staticmethod
    def _feeds(raw) -> tuple[FeedPool, ...]:
        out: list[FeedPool] = []
        for e in raw if isinstance(raw, list) else []:
            if isinstance(e, str):
                e = {"url": e}
            if isinstance(e, dict) and isinstance(e.get("url"), str) and e["url"].strip():
                url = e["url"].strip()
                name = e.get("name") if isinstance(e.get("name"), str) and e["name"] else None
                out.append(FeedPool(url, name or default_feed_name(url),
                                    e.get("enabled", True) is not False))
        return tuple(out)

    def folders(self) -> list[FolderPool]:
        return list(self.load().folders)

    def feeds(self) -> list[FeedPool]:
        return list(self.load().feeds)

    def enabled_folders(self) -> list[str]:
        return [f.resolved for f in self.load().folders if f.enabled]

    # -- writing --------------------------------------------------------

    def update(self, change: Callable[[Pools], Pools]) -> Pools:
        """Read, change and atomically write the config. The first write also saves
        the default folders, so a later change to the defaults cannot surprise anyone."""
        with self._lock:
            new = change(self.load())
            self._save(new)
            return new

    def _save(self, pools: Pools) -> None:
        data = {
            "folders": [{"path": f.path, "enabled": f.enabled} for f in pools.folders],
            "feeds": [{"url": f.url, "name": f.name, "enabled": f.enabled} for f in pools.feeds],
        }
        directory = os.path.dirname(self.path)
        try:
            os.makedirs(directory, exist_ok=True)
            fd, tmp = tempfile.mkstemp(prefix=".tmp-", suffix=".json", dir=directory)
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2)
                    f.write("\n")
                os.replace(tmp, self.path)
            except BaseException:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
                raise
        except OSError as e:
            raise BackendError(ErrorKind.FAILED, f"Could not save {self.path}: {e.strerror or e}",
                               Source.APPIMAGE) from e


# -- specs ---------------------------------------------------------------

def _fail(message: str, kind: ErrorKind = ErrorKind.FAILED) -> BackendError:
    return BackendError(kind, message, Source.APPIMAGE)


def classify(spec: str) -> tuple[str, str]:
    """("folder", path), ("feed", url) or raise a BackendError saying what is wrong."""
    spec = spec.strip()
    low = spec.lower()
    if low.startswith("https://"):
        if not urlparse_host(spec):
            raise _fail("That feed address has no host name")
        return "feed", spec
    if low.startswith("http://"):
        raise _fail("Plain http feeds are not allowed. Use an https address.")
    if spec == "~" or spec.startswith(("~/", "/")):
        if is_forbidden_dir(spec):
            raise _fail("Folders on ~/GoogleDrive or ~/OneDrive are never scanned: "
                        "they are cloud mounts and reading them can freeze the computer.")
        return "folder", spec
    raise _fail("Enter a folder (an absolute path or one starting with ~) "
                "or an https address ending in feed.json.")


def urlparse_host(url: str) -> Optional[str]:
    try:
        return urlsplit(url).hostname
    except ValueError:
        return None


def _folder_name(path: str) -> str:
    return os.path.basename(resolve_folder(path).rstrip(os.sep)) or path


def _folder_warning(pool: FolderPool) -> Optional[str]:
    if is_forbidden_dir(pool.path):
        return "Not scanned: cloud drive folders are never read"
    resolved = pool.resolved
    if not os.path.exists(resolved):
        return "Folder does not exist yet"
    if not os.path.isdir(resolved):
        return "Not a folder"
    if not os.access(resolved, os.W_OK | os.X_OK):
        return "Read only: AppImages can be found here but not installed"
    return None


def _folder_entry(pool: FolderPool) -> SourceEntry:
    return SourceEntry(
        id=FOLDER_ID + pool.resolved, kind=Source.APPIMAGE, name=_folder_name(pool.path),
        detail=_tilde(pool.resolved), enabled=pool.enabled, warning=_folder_warning(pool))


def _feed_entry(pool: FeedPool) -> SourceEntry:
    return SourceEntry(id=FEED_ID + normalize_url(pool.url), kind=Source.APPIMAGE,
                       name=pool.name, detail=pool.url, enabled=pool.enabled)


def _spec_id(kind: str, spec: str) -> str:
    return FOLDER_ID + resolve_folder(spec) if kind == "folder" else FEED_ID + normalize_url(spec)


# -- the source manager --------------------------------------------------

class AppImagePools:
    kind = Source.APPIMAGE

    def __init__(self, config: Optional[PoolConfig] = None, cache_dir: Optional[str] = None,
                 fetcher: Optional[Fetcher] = None, feeds: Optional[FeedStore] = None) -> None:
        self._config = config or PoolConfig()
        self._feeds = feeds if feeds is not None else FeedStore(cache_dir, fetcher)

    def available(self) -> bool:
        return True

    def _run(self, work, done) -> None:
        run_blocking(work, Once(done), lambda e: e if isinstance(e, BackendError)
                     else _fail(str(e) or type(e).__name__))

    # -- reads ----------------------------------------------------------

    def _entries(self) -> list[SourceEntry]:
        pools = self._config.load()
        return ([_folder_entry(f) for f in pools.folders]
                + [_feed_entry(f) for f in pools.feeds])

    def list(self, done: Done[list[SourceEntry]]) -> None:
        self._run(self._entries, done)

    def check(self, spec: str, done: Done[SpecCheck]) -> None:
        self._run(lambda: self._check(spec), done)

    def _check(self, spec: str) -> SpecCheck:
        try:
            kind, spec = classify(spec)
        except BackendError as e:
            return SpecCheck(False, e.message)
        if _spec_id(kind, spec) in {e.id for e in self._entries()}:
            return SpecCheck(False, "Already added")
        if kind == "folder":
            return self._check_folder(spec)
        try:
            feed = self._feeds.load(spec)
        except BackendError as e:
            return SpecCheck(False, e.message)
        n = len(feed.items)
        note = " (offline copy)" if feed.stale else ""
        return SpecCheck(n > 0, f"Feed with {n} app{'s' if n != 1 else ''}{note}"
                         if n else "The feed has no apps",
                         default_feed_name(spec, feed.title))

    @staticmethod
    def _check_folder(spec: str) -> SpecCheck:
        path = resolve_folder(spec)
        name = _folder_name(spec)
        if not os.path.exists(path):
            return SpecCheck(True, "Folder does not exist yet; it is created when you "
                             "install an app into it", name)
        if not os.path.isdir(path):
            return SpecCheck(False, "That path is not a folder", name)
        if not os.access(path, os.W_OK | os.X_OK):
            return SpecCheck(True, "Folder exists but is read only: apps here are listed "
                             "but nothing can be installed into it", name)
        return SpecCheck(True, "Folder exists and is writable", name)

    # -- changes --------------------------------------------------------

    def add(self, spec: str, done: Done[SourceEntry], name: Optional[str] = None) -> None:
        self._run(lambda: self._add(spec, name), done)

    def _add(self, spec: str, name: Optional[str]) -> SourceEntry:
        kind, spec = classify(spec)
        new_id = _spec_id(kind, spec)
        made: list[SourceEntry] = []

        def change(pools: Pools) -> Pools:
            if any(e.id == new_id for e in
                   [_folder_entry(f) for f in pools.folders] + [_feed_entry(f) for f in pools.feeds]):
                raise _fail("Already added")
            if kind == "folder":
                pool = FolderPool(spec)
                made.append(_folder_entry(pool))
                return replace(pools, folders=pools.folders + (pool,))
            feed = FeedPool(spec, (name or "").strip() or default_feed_name(spec))
            made.append(_feed_entry(feed))
            return replace(pools, feeds=pools.feeds + (feed,))

        self._config.update(change)
        return made[0]

    def set_enabled(self, entry: SourceEntry, enabled: bool, done: Done[SourceEntry]) -> None:
        self._run(lambda: self._set_enabled(entry, enabled), done)

    def _set_enabled(self, entry: SourceEntry, enabled: bool) -> SourceEntry:
        made: list[SourceEntry] = []

        def change(pools: Pools) -> Pools:
            folders = []
            for f in pools.folders:
                if FOLDER_ID + f.resolved == entry.id:
                    f = replace(f, enabled=enabled)
                    made.append(_folder_entry(f))
                folders.append(f)
            feeds = []
            for f in pools.feeds:
                if FEED_ID + normalize_url(f.url) == entry.id:
                    f = replace(f, enabled=enabled)
                    made.append(_feed_entry(f))
                feeds.append(f)
            if not made:
                raise _fail("That pool is no longer in the list", ErrorKind.NOT_FOUND)
            return Pools(tuple(folders), tuple(feeds))

        self._config.update(change)
        return made[0]

    def remove(self, entry: SourceEntry, done: Done[bool]) -> None:
        self._run(lambda: self._remove(entry), done)

    def _remove(self, entry: SourceEntry) -> bool:
        """Drops the pool from the config. Never touches the folder or its files."""
        def change(pools: Pools) -> Pools:
            folders = tuple(f for f in pools.folders if FOLDER_ID + f.resolved != entry.id)
            feeds = tuple(f for f in pools.feeds if FEED_ID + normalize_url(f.url) != entry.id)
            if len(folders) == len(pools.folders) and len(feeds) == len(pools.feeds):
                raise _fail("That pool is no longer in the list", ErrorKind.NOT_FOUND)
            return Pools(folders, feeds)

        self._config.update(change)
        return True

    def matches(self, plugin: SourcePlugin, entry: SourceEntry) -> bool:
        if plugin.kind != Source.APPIMAGE or entry.kind != Source.APPIMAGE:
            return False
        try:
            kind, spec = classify(plugin.spec)
        except BackendError:
            return False
        return entry.id == _spec_id(kind, spec)
