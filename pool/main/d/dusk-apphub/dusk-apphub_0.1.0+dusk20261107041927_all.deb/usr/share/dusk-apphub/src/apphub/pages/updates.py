"""Updates: available updates from every source in tiers, like Mint's Update Manager.

Sections follow system.TIER_ORDER. Every row and every tier has its own Update
button. Update All leaves kernels out unless the person turns on "Include kernel
updates". When Timeshift is set up, a restore point is made first; if that fails,
the person is asked before anything is updated.
"""

from __future__ import annotations

from typing import Callable, Optional

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gtk  # noqa: E402

from ..backend import BackendError, Package, Progress, Source  # noqa: E402
from ..hub import Hub  # noqa: E402
from ..system import TIER_ORDER, Snapshot, Snapshots, Tier, tier_of  # noqa: E402
from .common import (
    widen,  # noqa: E402
    QUIET_KINDS,
    ProgressRow,
    Shell,
    SourceBanners,
    StateStack,
    app_icon,
    error_text,
    icon_button,
    source_label,
)

# heading, one-line explanation, the word in "Update all <word>"
TIER_TEXT: dict[Tier, tuple[str, str, str]] = {
    Tier.SECURITY: ("Security Updates",
                    "Fixes for known vulnerabilities. Install these soon.", "security"),
    Tier.KERNEL: ("Kernel Updates",
                  "New Linux kernels. They take effect after a restart.", "kernel"),
    Tier.SOFTWARE: ("Software Updates",
                    "Bug fixes and improvements for system packages.", "software"),
    Tier.FLATPAK: ("Flatpak", "Apps and runtimes from Flatpak remotes.", "Flatpak"),
    Tier.SNAP: ("Snap", "Apps from the Snap Store.", "Snap"),
    Tier.APPIMAGE: ("AppImage", "Portable apps in your AppImage folders.", "AppImage"),
}


def snapshot_comment(pkgs: list[Package]) -> str:
    n = len(pkgs)
    return f"AppHub: before {n} update" + ("" if n == 1 else "s")


PHASED_NOTE = "rolling out gradually, not yet for this computer"
PHASED_TOAST = "Rolling out gradually: not available for this computer yet"


def ready(pkgs: list[Package]) -> list[Package]:
    """The updates that can be installed now: phased ones are only shown."""
    return [p for p in pkgs if not p.phased]


class UpdateRow(Adw.ActionRow):
    def __init__(self, pkg: Package, on_update):
        subtitle = f"{pkg.version} → {pkg.update_version or 'newer version'}"
        if pkg.phased:
            subtitle += " · " + PHASED_NOTE
        super().__init__(title=pkg.display_name, use_markup=False, subtitle=subtitle)
        self.pkg = pkg
        self.add_prefix(app_icon(pkg.icon, 40))
        self.add_suffix(source_label(str(pkg.source)))
        self.update_button = Gtk.Button(label="Update", valign=Gtk.Align.CENTER,
                                        tooltip_text=f"Update {pkg.display_name}")
        self.update_button.connect("clicked", lambda *_: on_update([pkg]))
        self.update_button.set_visible(not pkg.phased)
        self.add_suffix(self.update_button)


class TierGroup(Adw.PreferencesGroup):
    """One tier: heading, explanation, count and an "Update all <tier>" button."""

    def __init__(self, tier: Tier, pkgs: list[Package],
                 on_update: Callable[[list[Package]], None]):
        heading, explanation, word = TIER_TEXT[tier]
        super().__init__(title=heading, description=explanation)
        self.tier = tier
        self.packages = pkgs
        n, waiting = len(ready(pkgs)), len(pkgs) - len(ready(pkgs))
        suffix = Gtk.Box(spacing=12, valign=Gtk.Align.CENTER)
        self.count_label = source_label(f"{n} update" + ("" if n == 1 else "s")
                                        + (f", {waiting} rolling out" if waiting else ""))
        self.update_button = Gtk.Button(label=f"Update all {word}", valign=Gtk.Align.CENTER)
        self.update_button.connect("clicked", lambda *_: on_update(list(self.packages)))
        suffix.append(self.count_label)
        suffix.append(self.update_button)
        self.set_header_suffix(suffix)
        self.rows: list[UpdateRow] = []
        for pkg in pkgs:
            row = UpdateRow(pkg, on_update)
            self.add(row)
            self.rows.append(row)


class UpdatesPage(Gtk.Box):
    def __init__(self, shell: Shell, hub: Hub, snapshots: Optional[Snapshots] = None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.shell = shell
        self.hub = hub
        self.snapshots = snapshots
        self.busy = False
        self.loading = False
        self.reload_pending = False
        self.packages: list[Package] = []
        self.rows: dict[str, UpdateRow] = {}
        self.list_rows: list[UpdateRow] = []
        self.tier_groups: dict[Tier, TierGroup] = {}
        self.snapshot_dialog: Optional[Adw.AlertDialog] = None

        self.banners = SourceBanners(self.load)
        self.append(self.banners)

        self.prefs = widen(Adw.PreferencesPage())
        self.progress_group = Adw.PreferencesGroup(visible=False)
        self.progress_row = ProgressRow()
        self.progress_group.add(self.progress_row)
        self.prefs.add(self.progress_group)

        # Summary: the total, Update All and the choices that shape it.
        self.group = Adw.PreferencesGroup()
        suffix = Gtk.Box(spacing=8, valign=Gtk.Align.CENTER)
        self.refresh_button = icon_button("view-refresh-symbolic", "Check for Updates", self.load)
        self.refresh_button.add_css_class("flat")
        self.update_all_button = Gtk.Button(label="Update All", valign=Gtk.Align.CENTER)
        self.update_all_button.add_css_class("suggested-action")
        self.update_all_button.add_css_class("pill")
        self.update_all_button.connect("clicked", lambda *_: self.update_all())
        suffix.append(self.refresh_button)
        suffix.append(self.update_all_button)
        self.group.set_header_suffix(suffix)
        self.kernel_switch = Adw.SwitchRow(
            title="Include kernel updates",
            subtitle="Update All leaves new kernels out unless this is on",
            active=False, visible=False)
        self.kernel_switch.connect("notify::active", lambda *_: self._sync_buttons())
        self.group.add(self.kernel_switch)
        self.snapshot_switch = Adw.SwitchRow(
            title="Make a Timeshift restore point first",
            subtitle="Lets you roll the system back if an update goes wrong",
            active=True, visible=False)
        self.group.add(self.snapshot_switch)
        self.prefs.add(self.group)

        self.state = StateStack(self.prefs, self.load)
        self.append(self.state)

    # -- loading --------------------------------------------------------

    def load(self) -> None:
        if self.busy:
            return
        if self.loading:
            self.reload_pending = True
            return
        self.loading = True
        self.state.loading()
        self.hub.get_updates(self._on_loaded)

    def _on_loaded(self, packages: list[Package], errors: list[BackendError]) -> None:
        self.loading = False
        if self.reload_pending:
            self.reload_pending = False
            self.load()
            return
        for group in self.tier_groups.values():
            self.prefs.remove(group)
        self.tier_groups = {}
        self.list_rows = []
        self.rows = {}
        by_tier: dict[Tier, list[Package]] = {}
        for pkg in sorted(packages, key=lambda p: p.display_name.casefold()):
            by_tier.setdefault(tier_of(pkg), []).append(pkg)
        self.packages = [p for tier in TIER_ORDER for p in by_tier.get(tier, [])]
        self.shell.set_update_count(len(ready(self.packages)))

        if not packages and errors:
            self.banners.show_errors([])
            self.state.error("Could not check for updates",
                             "; ".join(f"{e.source}: {error_text(e)}" for e in errors))
            return
        self.banners.show_errors(errors)
        if not packages:
            check = Gtk.Button(label="Check Again", halign=Gtk.Align.CENTER)
            check.add_css_class("pill")
            check.connect("clicked", lambda *_: self.load())
            self.state.empty("Up to Date", "Every installed app is on its newest version.",
                             "object-select-symbolic", check)
            return

        n, waiting = len(ready(self.packages)), len(self.packages) - len(ready(self.packages))
        self.group.set_title(f"{n} Update" + ("" if n == 1 else "s")
                             + (f", {waiting} rolling out" if waiting else ""))
        self.kernel_switch.set_visible(Tier.KERNEL in by_tier)
        self.snapshot_switch.set_visible(self._can_snapshot())
        for tier in TIER_ORDER:
            if tier not in by_tier:
                continue
            group = TierGroup(tier, by_tier[tier], self.update)
            self.prefs.add(group)
            self.tier_groups[tier] = group
            for row in group.rows:
                self.list_rows.append(row)
                self.rows[row.pkg.id] = row
        self._sync_buttons()
        self.state.content()

    def _can_snapshot(self) -> bool:
        if self.snapshots is None:
            return False
        try:
            return bool(self.snapshots.available() and self.snapshots.configured())
        except Exception:  # noqa: BLE001 - a broken probe means "no restore points"
            return False

    # -- updating -------------------------------------------------------

    def update_all_packages(self) -> list[Package]:
        """What Update All installs: everything except kernels, unless they are included."""
        with_kernels = self.kernel_switch.get_active()
        return [p for p in ready(self.packages) if with_kernels or tier_of(p) != Tier.KERNEL]

    def update_all(self) -> None:
        self.update(self.update_all_packages())

    def update_tier(self, tier: Tier) -> None:
        group = self.tier_groups.get(tier)
        if group:
            self.update(list(group.packages))

    def wants_snapshot(self, pkgs: list[Package]) -> bool:
        # Timeshift covers the system, so only system packages (APT) need a restore point.
        return (self.snapshot_switch.get_visible() and self.snapshot_switch.get_active()
                and any(p.source == Source.APT for p in pkgs))

    def update(self, pkgs: list[Package]) -> None:
        if self.busy or not pkgs:
            return
        if not ready(pkgs):
            self.shell.toast(PHASED_TOAST)
            return
        pkgs = ready(pkgs)
        self._set_busy(True)
        if self.wants_snapshot(pkgs):
            self.progress_row.start("Making a restore point")
            self.snapshots.create(snapshot_comment(pkgs),
                                  lambda snap, err: self._on_snapshot(pkgs, snap, err),
                                  progress=self._snapshot_progress)
            return
        self._start_update(pkgs)

    def _snapshot_progress(self, p: Progress) -> None:
        """Timeshift's own "N% complete (M remaining)" while the restore point is
        made. Its estimate comes from the previous snapshot and often runs past
        100%, so after that the bar pulses with a plain message."""
        if p.percent is None or p.percent >= 100:
            self.progress_row.update(Progress(percent=None, status="Making a restore point: still copying files"))
        else:
            self.progress_row.update(Progress(percent=p.percent, status=f"Making a restore point: {p.status}"))

    def _on_snapshot(self, pkgs: list[Package], snap: Optional[Snapshot],
                     error: Optional[BackendError]) -> None:
        if error is None:
            self.shell.toast("Restore point made")
            self._start_update(pkgs)
            return
        self.ask_without_snapshot(pkgs, error)

    def ask_without_snapshot(self, pkgs: list[Package], error: BackendError) -> Adw.AlertDialog:
        dialog = Adw.AlertDialog(
            heading="Could not make a restore point",
            body=f"{error_text(error)}. Update anyway, without a way to roll back?")
        dialog.add_response("cancel", "Cancel")
        dialog.add_response("update", "Update Anyway")
        dialog.set_response_appearance("update", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_default_response("cancel")
        dialog.set_close_response("cancel")
        dialog.connect("response", lambda _d, r: self._on_snapshot_answer(pkgs, r))
        self.snapshot_dialog = dialog
        dialog.present(self)
        return dialog

    def _on_snapshot_answer(self, pkgs: list[Package], response: str) -> None:
        self.snapshot_dialog = None
        if response == "update":
            self._start_update(pkgs)
        else:
            self._set_busy(False)

    def _start_update(self, pkgs: list[Package]) -> None:
        self.progress_row.start()
        self.hub.update(pkgs, self._on_progress,
                        lambda updated, errors: self._on_updated(pkgs, updated, errors))

    def _sync_buttons(self) -> None:
        idle = not self.busy
        self.update_all_button.set_sensitive(idle and bool(self.update_all_packages()))
        self.refresh_button.set_sensitive(idle)
        self.kernel_switch.set_sensitive(idle)
        self.snapshot_switch.set_sensitive(idle)
        for group in self.tier_groups.values():
            group.update_button.set_sensitive(idle and bool(ready(group.packages)))
        for row in self.list_rows:
            row.update_button.set_sensitive(idle)

    def _set_busy(self, busy: bool) -> None:
        self.busy = busy
        self._sync_buttons()
        self.progress_group.set_visible(busy)
        if busy:
            self.progress_row.start()
        else:
            self.progress_row.stop()

    def _on_progress(self, p: Progress) -> None:
        self.progress_row.update(p)

    def _on_updated(self, asked: list[Package], updated: list[Package],
                    errors: list[BackendError]) -> None:
        self._set_busy(False)
        for err in errors:
            self.shell.toast(f"{err.source}: {error_text(err)}" if err.source else error_text(err))
        loud = [e for e in errors if e.kind not in QUIET_KINDS]
        if updated:
            title = (f"{updated[0].display_name} updated" if len(updated) == 1
                     else f"{len(updated)} apps updated")
            if errors:
                title = f"{len(updated)} of {len(asked)} updates installed"
            body = ", ".join(p.display_name for p in updated)
            if loud:
                body += ". " + "; ".join(f"{e.source}: {error_text(e)}" for e in loud)
            self.shell._notify(title, body)
        elif loud:
            what = asked[0].display_name if len(asked) == 1 else f"{len(asked)} apps"
            self.shell._notify(f"Could not update {what}",
                               "; ".join(f"{e.source}: {error_text(e)}" for e in loud))
        if updated:
            self.shell.package_changed()
