"""Add to App Drawer: the small dialog offered after an AppImage is installed,
and from its details page while it has no launcher. Name, description and
category are editable; the Strata icon switch shows when Dusk's icon engine
is installed. The work itself is launchers.create, off the main thread.

Offered for a fresh download (downloads.py), it also shows a switch to move
the file into ~/Applications first, on by default."""

from __future__ import annotations

import dataclasses
from typing import Callable, Optional

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gtk  # noqa: E402

from .. import downloads, launchers  # noqa: E402
from ..backend import BackendError, ErrorKind, Package, run_blocking  # noqa: E402
from .common import Shell, app_icon  # noqa: E402


class LauncherDialog(Adw.Dialog):
    def __init__(self, shell: Shell, pkg: Package, on_done: Callable[[dict], None], *,
                 create=launchers.create, strata_available=launchers.strata_available,
                 run=run_blocking, home: Optional[str] = None, offer_move: bool = False,
                 relocate=downloads.relocate):
        super().__init__(title="Add to App Drawer", content_width=440)
        self.shell = shell
        self.pkg = pkg
        self.on_done = on_done
        self._create = create
        self._run = run
        self._home = home
        self._relocate = relocate
        plan = launchers.plan_for(pkg)

        view = Adw.ToolbarView()
        view.add_top_bar(Adw.HeaderBar())
        page = Adw.PreferencesPage()
        group = Adw.PreferencesGroup(
            description="AppImages have no entry in the app drawer. This adds one, so "
                        f"{plan.name} opens like any installed app.")
        header = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, halign=Gtk.Align.CENTER,
                         margin_bottom=12)
        header.append(app_icon(pkg.icon, 96))
        group.set_header_suffix(None)
        page.add(group)

        self.name_row = Adw.EntryRow(title="Name", text=plan.name)
        self.comment_row = Adw.EntryRow(title="Description", text=plan.comment)
        self.category_row = Adw.ComboRow(title="Category",
                                         model=Gtk.StringList.new([t for _k, t in launchers.CATEGORIES]))
        self.strata_row = Adw.SwitchRow(
            title="Strata icon", active=True,
            subtitle="Draw its icon on a slab in your wallpaper colours, like the rest of the drawer")
        self.strata_row.set_visible(bool(pkg.icon) and strata_available(home or _home()))
        self.move_row = Adw.SwitchRow(
            title="Move to Applications", active=True,
            subtitle="Keeps it in ~/Applications, so clearing Downloads does not break the launcher")
        self.move_row.set_visible(offer_move)
        for row in (self.name_row, self.comment_row, self.category_row, self.strata_row,
                    self.move_row):
            group.add(row)

        buttons = Gtk.Box(spacing=12, halign=Gtk.Align.END, margin_top=12, margin_bottom=12,
                          margin_start=12, margin_end=12)
        cancel = Gtk.Button(label="Cancel")
        cancel.connect("clicked", lambda *_: self.close())
        self.add_button = Gtk.Button(label="Add", css_classes=["suggested-action"])
        self.add_button.connect("clicked", lambda *_: self.add())
        buttons.append(cancel)
        buttons.append(self.add_button)
        body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        body.append(header)
        body.append(page)
        body.append(buttons)
        view.set_content(body)
        self.set_child(view)
        self.set_default_widget(self.add_button)

    def plan(self) -> launchers.Plan:
        key = launchers.CATEGORIES[self.category_row.get_selected()][0]
        return launchers.plan_for(self.pkg).with_choices(self.name_row.get_text(), self.comment_row.get_text(), key)

    def add(self) -> None:
        plan = self.plan()
        if not self.name_row.get_text().strip():
            self.shell.toast("Give the launcher a name")
            return
        with_strata = self.strata_row.get_visible() and self.strata_row.get_active()
        move = self.move_row.get_visible() and self.move_row.get_active()
        self.add_button.set_sensitive(False)

        def work() -> dict:
            target = plan
            if move:
                target = dataclasses.replace(plan, exec_path=self._relocate(plan.exec_path))
            result = self._create(target, self._home, with_strata)
            result["path"] = target.exec_path
            return result
        self._run(work, self._done, lambda e: BackendError(ErrorKind.FAILED, str(e)))

    def _done(self, result: Optional[dict], err: Optional[BackendError]) -> None:
        if err is not None or result is None:
            self.add_button.set_sensitive(True)
            self.shell.toast(f"Could not add the launcher: {err.message if err else 'unknown error'}")
            return
        self.close()
        self.shell.toast("Added to the app drawer" + (" with a Strata icon" if result.get("strata") else ""))
        self.on_done(result)


def _home() -> str:
    import os
    return os.path.expanduser("~")
