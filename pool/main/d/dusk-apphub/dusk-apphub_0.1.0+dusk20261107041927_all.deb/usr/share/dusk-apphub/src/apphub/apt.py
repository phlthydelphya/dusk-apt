"""APT backend over PackageKit.

PackageKit is the privileged side: it owns the D-Bus API, polkit
authentication and the APT lock, so AppHub runs unprivileged.
"""

from __future__ import annotations

import subprocess
from dataclasses import replace
from pathlib import Path
from typing import Optional

import gi

gi.require_version("PackageKitGlib", "1.0")
from gi.repository import Gio, GLib, PackageKitGlib as Pk  # noqa: E402

from .package_story import held_packages, phased_packages  # noqa: E402
from .backend import (  # noqa: E402
    BackendError,
    Done,
    ErrorKind,
    OnProgress,
    Package,
    Progress,
    Source,
    run_blocking,
)
from .system import Tier, is_kernel_package  # noqa: E402

# pk-client reports daemon errors as PK_CLIENT_ERROR with code 0xff + PkErrorEnum.
_DAEMON_ERROR_BASE = 0xFF

_DAEMON_KINDS = {
    Pk.ErrorEnum.NOT_AUTHORIZED: ErrorKind.AUTH,
    Pk.ErrorEnum.CANNOT_GET_LOCK: ErrorKind.BUSY,
    Pk.ErrorEnum.NO_NETWORK: ErrorKind.NETWORK,
    Pk.ErrorEnum.PACKAGE_NOT_FOUND: ErrorKind.NOT_FOUND,
    Pk.ErrorEnum.PACKAGE_NOT_INSTALLED: ErrorKind.NOT_FOUND,
    Pk.ErrorEnum.TRANSACTION_CANCELLED: ErrorKind.CANCELLED,
}

_CLIENT_KINDS = {
    Pk.ClientError.FAILED_AUTH: ErrorKind.AUTH,
    Pk.ClientError.DECLINED_INTERACTION: ErrorKind.CANCELLED,
}

_STATUS_TEXT = {
    Pk.StatusEnum.WAITING_FOR_AUTH: "Waiting for authentication",
    Pk.StatusEnum.WAITING_FOR_LOCK: "Waiting for another package manager",
    Pk.StatusEnum.WAIT: "Waiting",
    Pk.StatusEnum.SETUP: "Preparing",
    Pk.StatusEnum.LOADING_CACHE: "Preparing",
    Pk.StatusEnum.DEP_RESOLVE: "Resolving dependencies",
    Pk.StatusEnum.DOWNLOAD: "Downloading",
    Pk.StatusEnum.INSTALL: "Installing",
    Pk.StatusEnum.REMOVE: "Removing",
    Pk.StatusEnum.CLEANUP: "Cleaning up",
    Pk.StatusEnum.FINISHED: "Finishing",
}

_NO_FILTER = Pk.filter_bitfield_from_string("none")
_INSTALLED = Pk.filter_bitfield_from_string("installed")
_INSTALLED_APPS = Pk.filter_bitfield_from_string("installed;application;arch")
_SEARCH_FILTER = Pk.filter_bitfield_from_string("newest;arch")

# Removing these breaks the desktop even though dpkg does not mark them Essential.
_PROTECTED = frozenset({
    "gnome-shell", "gdm3", "mutter", "gnome-session", "gnome-control-center",
    "nautilus", "network-manager", "systemd", "apt", "dpkg", "sudo", "polkitd",
    "packagekit", "ubuntu-desktop", "ubuntu-desktop-minimal", "linux-generic",
    "xdg-desktop-portal", "xdg-desktop-portal-gnome",
})
_essential_cache: Optional[frozenset] = None

# Launchers of apt-installed apps, for their names
APP_DIRS = (Path("/usr/share/applications"), Path("/usr/local/share/applications"))


def dpkg_owners(paths: list[str]) -> dict[str, str]:
    """{path: package} for the paths dpkg installed, in one dpkg-query call."""
    if not paths:
        return {}
    try:
        out = subprocess.run(["dpkg-query", "-S", *paths], capture_output=True, text=True,
                             timeout=30, check=False).stdout
    except (OSError, subprocess.SubprocessError):
        return {}
    owners = {}
    for line in out.splitlines():
        head, sep, path = line.partition(": ")
        if sep and not head.startswith("diversion"):
            owners[path.strip()] = head.split(",", 1)[0].strip().split(":", 1)[0]
    return owners


def _flag(key: GLib.KeyFile, name: str) -> bool:
    try:
        return key.get_boolean("Desktop Entry", name)
    except GLib.Error:
        return False


def _join_names(names: list[str]) -> str:
    names = list(dict.fromkeys(names))
    if len(names) <= 3:
        return ", ".join(names)
    return f"{names[0]}, {names[1]} and {len(names) - 2} more"


def app_titles(dirs=APP_DIRS, owners=dpkg_owners) -> dict[str, str]:
    """{package: its apps' names} from the launchers it installed, so a package
    reads as what a person sees in the app menu ("FreeOffice 2024 PlanMaker"),
    not as its package name. Hidden launchers are skipped."""
    names: dict[str, str] = {}
    for d in dirs:
        for f in sorted(d.glob("*.desktop")) if d.is_dir() else []:
            key = GLib.KeyFile()
            try:
                key.load_from_file(str(f), GLib.KeyFileFlags.NONE)
                if any(_flag(key, k) for k in ("NoDisplay", "Hidden")):
                    continue
                name = key.get_locale_string("Desktop Entry", "Name", None).strip()
            except GLib.Error:
                continue
            if name:
                names[str(f)] = name
    by_pkg: dict[str, list[str]] = {}
    for path, pkg in owners(list(names)).items():
        if path in names:
            by_pkg.setdefault(pkg, []).append(names[path])
    return {pkg: _join_names(n) for pkg, n in by_pkg.items()}


def _essentials() -> frozenset:
    """Package names AppHub must never remove: dpkg Essential, priority required/important, _PROTECTED."""
    global _essential_cache
    if _essential_cache is None:
        names = set(_PROTECTED)
        try:
            out = subprocess.run(
                ["dpkg-query", "-W", "-f", "${Package} ${Essential} ${Priority}\\n"],
                capture_output=True, text=True, timeout=10, check=True).stdout
            for line in out.splitlines():
                parts = line.split()
                if len(parts) == 3 and (parts[1] == "yes" or parts[2] in ("required", "important")):
                    names.add(parts[0])
        except (OSError, subprocess.SubprocessError):
            pass  # _PROTECTED alone still guards the desktop
        _essential_cache = frozenset(names)
    return _essential_cache


def _origin(pk_pkg) -> Optional[str]:
    """PackageKit data field, e.g. "ubuntu-stonking-universe" or "auto:ubuntu-stonking-main"."""
    data = pk_pkg.get_data() or ""
    return data.rsplit(":", 1)[-1] or None


def update_tier(name: str, info) -> Tier:
    """The update tier for one PackageKit update (its Pk.InfoEnum `info`).

    Kernel packages are their own tier even when the update is a security fix: the
    person chooses kernel updates separately.
    """
    if is_kernel_package(name):
        return Tier.KERNEL
    if info == Pk.InfoEnum.SECURITY:
        return Tier.SECURITY
    return Tier.SOFTWARE


def _unique(pkgs: list[Package]) -> list[Package]:
    seen, out = set(), []
    for p in pkgs:
        if p.name not in seen:
            seen.add(p.name)
            out.append(p)
    return out


PHASED_TEXT = ("Not available for this computer yet: the distribution is rolling this update out "
               "gradually")
# PackageKit's apt backend answers a phased candidate with PACKAGE_NOT_FOUND and this text.
_PHASED_REFUSAL = "is not available as an update candidate"


def map_error(err: GLib.Error) -> BackendError:
    """Turn a PackageKit GLib.Error into the shared error contract."""
    if _PHASED_REFUSAL in (err.message or ""):
        return BackendError(ErrorKind.FAILED, PHASED_TEXT)
    kind = ErrorKind.FAILED
    if err.domain == GLib.quark_to_string(Pk.ClientError.quark()):
        if err.code >= _DAEMON_ERROR_BASE:
            try:
                kind = _DAEMON_KINDS.get(
                    Pk.ErrorEnum(err.code - _DAEMON_ERROR_BASE), ErrorKind.FAILED)
            except ValueError:
                pass
        else:
            try:
                kind = _CLIENT_KINDS.get(Pk.ClientError(err.code), ErrorKind.FAILED)
            except ValueError:
                pass
    elif err.matches(Gio.io_error_quark(), Gio.IOErrorEnum.CANCELLED):
        kind = ErrorKind.CANCELLED
    return BackendError(kind, err.message)


class AptBackend:
    # Which update names apt defers on this machine; tests replace it.
    phased_lookup = staticmethod(phased_packages)

    def _phased_async(self, done) -> None:
        """phased_lookup off the main thread; done(frozenset, None) on the main loop."""
        run_blocking(self.phased_lookup, done, lambda e: BackendError(ErrorKind.FAILED, str(e)))

    source = Source.APT

    def __init__(self) -> None:
        self._client = Pk.Client()
        self._client.set_interactive(True)  # allow the polkit prompt

    def set_interactive(self, interactive: bool) -> None:
        """False for unattended use (apphub-cli): never raise a polkit prompt."""
        self._client.set_interactive(interactive)

    def available(self) -> bool:
        return True  # PackageKit is D-Bus activated; a missing daemon surfaces as FAILED

    # -- queries --------------------------------------------------------

    def lookup(self, name: str, done: Done[Package]) -> None:
        def resolved(results):
            pkgs = [p for p in results.get_package_array() if p.get_name() == name]
            if not pkgs:
                done(None, BackendError(ErrorKind.NOT_FOUND,
                                        f"{name} is not in any enabled APT repository"))
                return
            # An installed entry wins; otherwise the candidate APT offers.
            pkgs.sort(key=lambda p: p.get_info() != Pk.InfoEnum.INSTALLED)
            self._detailed([pkgs[0]], lambda found, err: self._titled(found, lambda t, e: done(t[0], None)))

        self._run("resolve", (_NO_FILTER, [name]), None, resolved, done)

    def search(self, query: str, done: Done[list[Package]]) -> None:
        self._run("search_names", (_SEARCH_FILTER, [query]), None,
                  lambda r: done(_unique([self._to_package(p) for p in r.get_package_array()]),
                                 None),
                  done)

    def list_installed(self, done: Done[list[Package]]) -> None:
        # "application" = packages that ship a .desktop file, i.e. what a person sees as an app.
        def titled(pkgs, error):
            if error is not None or not pkgs:
                done(pkgs, error)
                return
            self._titled(pkgs, done)

        self._run("get_packages", (_INSTALLED_APPS,), None,
                  lambda r: self._detailed(list(r.get_package_array()), titled), done)

    def _titled(self, pkgs: list[Package], done: Done[list[Package]]) -> None:
        """The packages named by their apps (a thread: dpkg-query takes a moment);
        left as they are if that fails."""
        run_blocking(lambda: app_titles(),
                     lambda titles, _err: done(
                         [replace(p, title=p.title or (titles or {}).get(p.name)) for p in pkgs], None),
                     lambda e: BackendError(ErrorKind.FAILED, str(e), self.source))

    def get_updates(self, done: Done[list[Package]]) -> None:
        # Two answers meet here: PackageKit's list, and apt's own view of which
        # of them are phased (deferred on this machine). Whichever lands last
        # builds the result; `done` is called exactly once.
        state: dict = {"phased": None, "pk": None, "finished": False}

        def maybe_finish():
            if state["finished"] or state["phased"] is None or state["pk"] is None:
                return
            state["finished"] = True
            new, current = state["pk"]
            out = []
            for name, upd in sorted(new.items()):
                cur = current.get(name)
                out.append(Package(
                    id=upd.get_id(),  # the new version's ID is what update() installs
                    name=name,
                    version=cur.get_version() if cur else "",
                    summary=upd.get_summary() or "",
                    source=self.source,
                    installed=True,
                    origin=_origin(upd),
                    update_version=upd.get_version(),
                    update_tier=str(update_tier(name, upd.get_info())),
                    essential=name in _essentials(),
                    phased=name in state["phased"],
                ))
            done(out, None)

        def got_phased(result, _error):
            state["phased"] = result if result is not None else frozenset()
            maybe_finish()

        self._phased_async(got_phased)

        def got_updates(results):
            # Held packages (apt-mark hold) are frozen on purpose: never offered as updates.
            held = held_packages()
            new = {p.get_name(): p for p in results.get_package_array()
                   if p.get_name() not in held}
            if not new:
                state["finished"] = True
                done([], None)
                return

            def got_installed(r):
                state["pk"] = (new, {p.get_name(): p for p in r.get_package_array()})
                maybe_finish()

            self._run("resolve", (_INSTALLED, list(new)), None, got_installed, done)

        self._run("get_updates", (_NO_FILTER,), None, got_updates, done)

    def _detailed(self, pk_pkgs: list, done: Done[list[Package]]) -> None:
        """Attach sizes from one batched GetDetails call. Sizes are optional."""
        if not pk_pkgs:
            done([], None)
            return

        def got(results):
            sizes = {d.get_property("package-id"): d for d in results.get_details_array()}
            out = []
            for p in pk_pkgs:
                d = sizes.get(p.get_id())
                out.append(self._to_package(
                    p,
                    (d.get_property("size") or None) if d else None,
                    (d.get_property("download-size") or None) if d else None))
            done(out, None)

        self._run("get_details", ([p.get_id() for p in pk_pkgs],), None, got,
                  lambda _r, _e: done([self._to_package(p) for p in pk_pkgs], None))

    def _to_package(self, pk_pkg, installed_size=None, download_size=None) -> Package:
        return Package(
            id=pk_pkg.get_id(),
            name=pk_pkg.get_name(),
            version=pk_pkg.get_version(),
            summary=pk_pkg.get_summary() or "",
            source=self.source,
            installed=pk_pkg.get_info() == Pk.InfoEnum.INSTALLED,
            origin=_origin(pk_pkg),
            installed_size=installed_size,
            download_size=download_size,
            essential=pk_pkg.get_name() in _essentials(),
        )

    # -- changes --------------------------------------------------------

    def install(self, pkg: Package, progress: OnProgress, done: Done[Package],
                simulate: bool = False) -> None:
        self._run("install_packages", (_flags(simulate), [pkg.id]), progress,
                  self._after_change(pkg, simulate, done), done)

    def remove(self, pkg: Package, progress: OnProgress, done: Done[Package],
               simulate: bool = False) -> None:
        # allow_deps=False: refuse rather than silently take dependents with it.
        # autoremove=False: apt's autoremove can sweep unrelated orphans.
        self._run("remove_packages", (_flags(simulate), [pkg.id], False, False), progress,
                  self._after_change(pkg, simulate, done), done)

    def update(self, pkgs: list[Package], progress: OnProgress, done: Done[list[Package]],
               simulate: bool = False) -> None:
        # Phased packages are skipped: PackageKit would refuse them anyway.
        pkgs = [p for p in pkgs if not p.phased]
        if not pkgs:
            done(None, BackendError(ErrorKind.FAILED, PHASED_TEXT))
            return

        def finished(_results):
            if simulate:
                done(list(pkgs), None)
                return
            self._run("resolve", (_INSTALLED, [p.name for p in pkgs]), None,
                      lambda r: self._detailed(list(r.get_package_array()), done), done)

        self._run("update_packages", (_flags(simulate), [p.id for p in pkgs]), progress,
                  finished, done)

    def _after_change(self, pkg: Package, simulate: bool, done: Done[Package]):
        def finished(_results):
            if simulate:
                done(pkg, None)
            else:
                # Re-read state from APT instead of assuming the change landed.
                self.lookup(pkg.name, done)

        return finished

    # -- plumbing -------------------------------------------------------

    def _run(self, method: str, args: tuple, progress: Optional[OnProgress],
             on_results, done) -> None:
        """Start `<method>_async`; route results to on_results, any failure to done.

        Every path ends in exactly one call to `done` (directly or via on_results),
        so a bug here shows as an error in the UI instead of a stuck spinner.
        """
        def ready(client, res, *_):
            try:
                results = client.generic_finish(res)
            except GLib.Error as e:
                done(None, map_error(e))
                return
            except Exception as e:  # noqa: BLE001 - never leave the caller waiting
                done(None, BackendError(ErrorKind.FAILED, str(e)))
                return
            try:
                on_results(results)
            except Exception as e:  # noqa: BLE001
                done(None, BackendError(ErrorKind.FAILED, str(e)))

        start = getattr(self._client, f"{method}_async")
        start(*args, None, _progress_adapter(progress), (), ready)


def _flags(simulate: bool) -> int:
    return Pk.transaction_flag_bitfield_from_string(
        "simulate;only-trusted" if simulate else "only-trusted")


def _progress_adapter(cb: Optional[OnProgress]):
    def on_progress(progress, ptype, *_):
        if cb is None or ptype not in (Pk.ProgressType.PERCENTAGE, Pk.ProgressType.STATUS):
            return
        pct = progress.get_property("percentage")
        status = progress.get_property("status")
        cb(Progress(
            percent=pct if 0 <= pct <= 100 else None,
            status=_STATUS_TEXT.get(status, "Working"),
        ))

    return on_progress
