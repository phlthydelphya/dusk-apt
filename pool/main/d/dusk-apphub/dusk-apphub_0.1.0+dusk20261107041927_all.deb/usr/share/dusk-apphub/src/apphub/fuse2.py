"""FUSE 2 for older AppImages.

An AppImage mounts itself with FUSE before it starts. Runtimes built before
about 2023 do that by loading libfuse.so.2 at start-up; the newer runtime has
FUSE built in and needs only the fusermount tool. Ubuntu ships FUSE 3 alone,
so an older AppImage there fails with "AppImages require FUSE to run" and its
launcher seems to do nothing.

needs_fuse2() reads the runtime (the ELF part in front of the image, never
the image itself, and never by running it) and looks for the library name
the old runtime loads. have_fuse2() looks for that library on disk. The fix
is Ubuntu's libfuse2t64 (libfuse2 before 24.04): the library only, which
sits beside FUSE 3. Never the package called "fuse": it replaces fuse3.
"""

from __future__ import annotations

import glob
import os
from typing import Iterable, Optional

from . import appimage

LIBRARY = "libfuse.so.2"
# Newest name first; the archive carries one of them.
PACKAGES = ("libfuse2t64", "libfuse2")
_MARKER = LIBRARY.encode()
_SCAN_LIMIT = 4 * 1024 * 1024  # runtimes are ~200 KB; never read further than this
_LIB_DIRS = ("/usr/lib", "/usr/lib64", "/lib", "/lib64", "/usr/local/lib")

TITLE = "{name} needs FUSE 2 to start"
BODY = ("{name} was built with an older AppImage runtime. It loads FUSE 2, and "
        "Ubuntu now ships only FUSE 3, so it cannot open yet.\n\n"
        "AppHub can install Ubuntu's FUSE 2 library ({package}). It sits beside "
        "FUSE 3 and changes nothing else. You will be asked for your password.")
CAPTION = "It cannot start until FUSE 2 support is installed"
BUTTON = "Install FUSE 2…"
DONE = "FUSE 2 installed. {name} can start now"
NOT_FOUND = "Ubuntu's FUSE 2 library could not be found in your software sources"


def needs_fuse2(path: str) -> bool:
    """True when the AppImage at path loads libfuse.so.2 at start-up."""
    header = appimage._read_header(path)
    if header is None or appimage.header_type(header) is None:
        return False
    end = appimage.payload_offset(header)
    limit = min(end, _SCAN_LIMIT) if end else _SCAN_LIMIT
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    except OSError:
        return False
    try:
        data = os.read(fd, limit)
    except OSError:
        return False
    finally:
        os.close(fd)
    return _MARKER in data


def have_fuse2(roots: Iterable[str] = _LIB_DIRS) -> bool:
    """True when libfuse.so.2 is installed, in a library folder or its multiarch one."""
    for root in roots:
        if os.path.exists(os.path.join(root, LIBRARY)):
            return True
        if glob.glob(os.path.join(glob.escape(root), "*-linux-*", LIBRARY)):
            return True
    return False


def missing_for(path: Optional[str], *, needs=needs_fuse2, have=have_fuse2) -> bool:
    """True when this AppImage needs FUSE 2 and the system has none."""
    return bool(path) and needs(path) and not have()
