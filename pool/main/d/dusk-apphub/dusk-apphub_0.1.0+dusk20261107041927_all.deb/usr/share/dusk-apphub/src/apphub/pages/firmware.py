"""Firmware: device firmware updates from the LVFS, through fwupd (firmware.py).

Each device is updated on its own, after a confirmation that says what can go
wrong. Firmware is never part of Update All and never installed automatically.
"""

from __future__ import annotations

from typing import Callable, Optional

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, GLib, Gtk  # noqa: E402

from ..backend import BackendError, Progress  # noqa: E402
from ..firmware import FirmwareUpdate, Fwupd  # noqa: E402
from .common import ProgressRow, Shell, StateStack, icon_button, report_failure, widen  # noqa: E402

URGENT = ("high", "critical")


def update_subtitle(u: FirmwareUpdate) -> str:
    parts = [f"{u.current} to {u.version}" if u.current else u.version]
    if u.vendor:
        parts.append(u.vendor)
    if u.size:
        parts.append(GLib.format_size(u.size))
    return " · ".join(parts)


def restart_word(u: FirmwareUpdate) -> Optional[str]:
    if u.needs_shutdown:
        return "shut down"
    if u.needs_reboot:
        return "restart"
    return None


def confirm_body(u: FirmwareUpdate) -> str:
    lines = ["Do not turn the computer off or unplug the device while it updates."]
    if u.requires_ac:
        lines.append("The computer must be plugged in.")
    word = restart_word(u)
    if word:
        lines.append(f"The update finishes the next time you {word} the computer. "
                     "AppHub does not do that for you.")
    return "\n\n".join(lines)


class FirmwareRow(Adw.ExpanderRow):
    def __init__(self, update: FirmwareUpdate, on_install: Callable[[FirmwareUpdate], None]):
        super().__init__(title=GLib.markup_escape_text(update.device),
                         subtitle=GLib.markup_escape_text(update_subtitle(update)))
        self.update = update
        self.add_prefix(Gtk.Image(icon_name="application-x-firmware-symbolic"))
        if update.urgency in URGENT or update.issues:
            tag = Gtk.Label(label="Security" if update.issues else "Important",
                            valign=Gtk.Align.CENTER)
            tag.add_css_class("caption-heading")
            tag.add_css_class("warning")
            self.add_suffix(tag)
        self.button = Gtk.Button(label="Update", valign=Gtk.Align.CENTER,
                                 tooltip_text=f"Update {update.device} to {update.version}")
        self.button.add_css_class("suggested-action")
        self.button.connect("clicked", lambda *_: on_install(update))
        self.add_suffix(self.button)
        notes = update.notes or update.summary or "No release notes."
        if update.issues:
            notes += "\n\nFixes: " + ", ".join(update.issues)
        label = Gtk.Label(label=notes, wrap=True, xalign=0, selectable=True,
                          margin_top=12, margin_bottom=12, margin_start=12, margin_end=12)
        self.add_row(label)

    def set_busy(self, busy: bool) -> None:
        self.button.set_sensitive(not busy)


class FirmwarePage(Gtk.Box):
    def __init__(self, shell: Shell, fwupd: Fwupd,
                 on_count: Optional[Callable[[int], None]] = None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.shell = shell
        self.fwupd = fwupd
        self.on_count = on_count
        self.busy = False
        self.loading = False
        self.rows: list[FirmwareRow] = []
        self.dialog: Optional[Adw.AlertDialog] = None

        self.prefs = widen(Adw.PreferencesPage())
        self.progress_group = Adw.PreferencesGroup(visible=False)
        self.progress_row = ProgressRow()
        self.progress_group.add(self.progress_row)
        self.prefs.add(self.progress_group)

        self.group = Adw.PreferencesGroup(
            title="Firmware Updates",
            description="Updates for this computer's devices, published by their makers on "
                        "the Linux Vendor Firmware Service. Each one is installed on its own.")
        self.refresh_button = icon_button("view-refresh-symbolic", "Reload", self.load)
        self.refresh_button.add_css_class("flat")
        self.group.set_header_suffix(self.refresh_button)
        self.prefs.add(self.group)
        self.empty_row = Adw.ActionRow(title="All firmware is up to date", visible=False)
        self.empty_row.add_prefix(Gtk.Image(icon_name="emblem-ok-symbolic"))
        self.group.add(self.empty_row)

        self.state = StateStack(self.prefs, self.load)
        self.append(self.state)

    def load(self) -> None:
        if self.busy or self.loading:
            return
        self.loading = True
        self.state.loading()
        self.fwupd.updates(self._on_loaded)

    def _on_loaded(self, updates: Optional[list[FirmwareUpdate]],
                   error: Optional[BackendError]) -> None:
        self.loading = False
        for row in self.rows:
            self.group.remove(row)
        self.rows = []
        if error:
            self.state.error("Could not check firmware", error.message)
            return
        for u in updates or []:
            row = FirmwareRow(u, self.ask_install)
            self.group.add(row)
            self.rows.append(row)
        self.empty_row.set_visible(not self.rows)
        if self.on_count:
            self.on_count(len(self.rows))
        self.state.content()

    def ask_install(self, update: FirmwareUpdate) -> Optional[Adw.AlertDialog]:
        if self.busy:
            return None
        dialog = Adw.AlertDialog(heading=f"Update {update.device}?", body=confirm_body(update))
        dialog.add_response("cancel", "Cancel")
        dialog.add_response("update", "Update")
        dialog.set_response_appearance("update", Adw.ResponseAppearance.SUGGESTED)
        dialog.set_default_response("cancel")
        dialog.set_close_response("cancel")
        dialog.connect("response", lambda _d, r: r == "update" and self.install(update))
        self.dialog = dialog
        dialog.present(self)
        return dialog

    def install(self, update: FirmwareUpdate) -> None:
        if self.busy:
            return
        self._set_busy(True, f"Updating {update.device}")
        self.fwupd.install(update, self.progress_row.update,
                           lambda _u, err: self._on_installed(update, err))

    def _on_installed(self, update: FirmwareUpdate, error: Optional[BackendError]) -> None:
        self._set_busy(False)
        if error:
            report_failure(self.shell, f"update {update.device}", error)
            return
        word = restart_word(update)
        self.shell._notify(f"{update.device} updated to {update.version}",
                           f"It finishes the next time you {word} the computer." if word else "")
        self.load()

    def _set_busy(self, busy: bool, title: str = "Starting") -> None:
        self.busy = busy
        self.refresh_button.set_sensitive(not busy)
        for row in self.rows:
            row.set_busy(busy)
        self.progress_group.set_visible(busy)
        if busy:
            self.progress_row.start(title)
        else:
            self.progress_row.stop()
