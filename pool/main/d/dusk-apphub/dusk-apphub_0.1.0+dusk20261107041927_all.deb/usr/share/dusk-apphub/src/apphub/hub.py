"""Hub: the one object the UI talks to. Fans queries out to every available
backend and routes changes to the backend that owns the package.

A failing source never hides the others: queries return everything that
succeeded plus a list of per-source errors.
"""

from __future__ import annotations

from typing import Callable, Iterable, Optional

from .backend import (
    Backend,
    BackendError,
    Done,
    ErrorKind,
    OnProgress,
    Package,
    Source,
)

# done(packages, errors): packages from every source that answered, errors from the rest.
Gathered = Callable[[list[Package], list[BackendError]], None]


class Hub:
    def __init__(self, backends: Iterable[Backend]):
        self.backends: dict[Source, Backend] = {}
        for b in backends:
            try:
                ok = b.available()
            except Exception:  # noqa: BLE001 - a broken probe means "not available"
                ok = False
            if ok:
                self.backends[b.source] = b

    @property
    def sources(self) -> list[Source]:
        return list(self.backends)

    # -- queries --------------------------------------------------------

    def search(self, query: str, done: Gathered) -> None:
        self._gather(lambda b, d: b.search(query, d), done)

    def list_installed(self, done: Gathered) -> None:
        self._gather(lambda b, d: b.list_installed(d), done)

    def get_updates(self, done: Gathered) -> None:
        self._gather(lambda b, d: b.get_updates(d), done)

    def lookup(self, source: Source, name: str, done: Done[Package]) -> None:
        backend = self._backend(source, done)
        if backend:
            backend.lookup(name, done)

    # -- changes --------------------------------------------------------

    def install(self, pkg: Package, progress: OnProgress, done: Done[Package],
                simulate: bool = False) -> None:
        if backend := self._backend(pkg.source, done):
            backend.install(pkg, progress, done, simulate)

    def remove(self, pkg: Package, progress: OnProgress, done: Done[Package],
               simulate: bool = False) -> None:
        if pkg.essential:
            done(None, BackendError(
                ErrorKind.UNSUPPORTED,
                f"{pkg.display_name} is part of the system and cannot be removed",
                pkg.source))
            return
        if backend := self._backend(pkg.source, done):
            backend.remove(pkg, progress, done, simulate)

    def update(self, pkgs: list[Package], progress: OnProgress, done: Gathered,
               simulate: bool = False) -> None:
        """Update packages from any mix of sources, one source at a time.

        Sources run in sequence, not in parallel: APT and snapd both take
        system-wide locks, and one progress bar is easier to follow.
        """
        by_source: dict[Source, list[Package]] = {}
        for p in pkgs:
            by_source.setdefault(p.source, []).append(p)
        queue = list(by_source.items())
        updated: list[Package] = []
        errors: list[BackendError] = []

        def next_source():
            if not queue:
                done(updated, errors)
                return
            source, group = queue.pop(0)
            backend = self.backends.get(source)
            if backend is None:
                errors.append(_missing(source))
                next_source()
                return

            def finished(result, error):
                if error:
                    error.source = error.source or source
                    errors.append(error)
                else:
                    updated.extend(result)
                next_source()

            _guarded(lambda: backend.update(group, progress, finished, simulate), source, finished)

        next_source()

    # -- plumbing -------------------------------------------------------

    def _backend(self, source: Source, done: Done) -> Optional[Backend]:
        backend = self.backends.get(source)
        if backend is None:
            done(None, _missing(source))
        return backend

    def _gather(self, call: Callable[[Backend, Done], None], done: Gathered) -> None:
        if not self.backends:
            done([], [])
            return
        pending = set(self.backends)
        found: list[Package] = []
        errors: list[BackendError] = []

        for source, backend in list(self.backends.items()):
            def finished(result, error, source=source):
                if source not in pending:
                    return  # a backend answered twice; keep the first answer
                pending.discard(source)
                if error:
                    error.source = error.source or source
                    errors.append(error)
                else:
                    found.extend(result or [])
                if not pending:
                    done(found, errors)

            _guarded(lambda b=backend, f=finished: call(b, f), source, finished)


def _guarded(start: Callable[[], None], source: Source, done: Done) -> None:
    """Start a backend call; a synchronous exception becomes a FAILED result."""
    try:
        start()
    except Exception as e:  # noqa: BLE001
        done(None, BackendError(ErrorKind.FAILED, str(e), source))


def _missing(source: Source) -> BackendError:
    return BackendError(ErrorKind.UNSUPPORTED, f"{source} is not available on this computer", source)
