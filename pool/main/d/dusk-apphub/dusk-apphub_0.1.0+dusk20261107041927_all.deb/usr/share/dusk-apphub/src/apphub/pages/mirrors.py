"""Mirrors: which server Ubuntu's software archive is downloaded from.

Find faster mirrors tests the nearby ones, then each result can be switched to. A
switch asks first and says the password will be requested.
"""

from __future__ import annotations

from dataclasses import replace
from typing import Optional

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gtk  # noqa: E402

from ..backend import BackendError, Progress  # noqa: E402
from ..mirrors import OFFICIAL_URL, country_name, normalize_url  # noqa: E402
from ..system import Mirror  # noqa: E402
from .common import ProgressRow, Shell, error_text  # noqa: E402


def speed_text(bytes_per_s: Optional[float]) -> str:
    if bytes_per_s is None:
        return ""
    mb = bytes_per_s / 1_000_000
    return "under 0.1 MB/s" if mb < 0.1 else f"{mb:.1f} MB/s"


def _same(a: str, b: str) -> bool:
    try:
        return normalize_url(a).split("://", 1)[1] == normalize_url(b).split("://", 1)[1]
    except ValueError:
        return a == b


def _badge(text: str, css: str) -> Gtk.Label:
    label = Gtk.Label(label=text, valign=Gtk.Align.CENTER)
    label.add_css_class("caption")
    label.add_css_class(css)
    return label


class MirrorRow(Adw.ActionRow):
    """One tested mirror: host, where it is and how fast, a stale badge, and Use."""

    def __init__(self, mirror: Mirror, on_use):
        parts = []
        if mirror.country:
            parts.append(country_name(mirror.country) or mirror.country)
        if mirror.speed_bytes_per_s is not None:
            parts.append(speed_text(mirror.speed_bytes_per_s))
        elif mirror.speed_bytes_per_s is None and not mirror.current:
            parts.append("Not reachable or not tested")
        super().__init__(title=mirror.name, subtitle=" · ".join(parts), use_markup=False,
                         subtitle_selectable=True)
        self.mirror = mirror
        if mirror.stale:
            self.stale_badge = _badge(mirror.stale, "warning")
            self.add_suffix(self.stale_badge)
        if mirror.current:
            self.add_suffix(_badge("In use", "dim-label"))
        if mirror.official:
            self.add_suffix(_badge("Official", "dim-label"))
        self.use_button = Gtk.Button(label="Use", valign=Gtk.Align.CENTER,
                                     tooltip_text=f"Use {mirror.name}")
        self.use_button.add_css_class("pill")
        self.use_button.update_property([Gtk.AccessibleProperty.LABEL], [f"Use {mirror.name}"])
        self.use_button.set_sensitive(not mirror.current)
        self.use_button.connect("clicked", lambda *_: on_use(mirror))
        self.add_suffix(self.use_button)


class MirrorsPage(Gtk.Box):
    def __init__(self, shell: Shell, mirrors):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.add_css_class("sources")
        self.shell = shell
        self.mirrors = mirrors
        self.busy = False
        self.current: Optional[Mirror] = None
        self.results: list[Mirror] = []
        self.rows: list[MirrorRow] = []
        self.confirm_dialog: Optional[Adw.AlertDialog] = None

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=24,
                      margin_top=12, margin_bottom=28, margin_start=12, margin_end=12)
        head = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        title = Gtk.Label(label="Mirrors", xalign=0)
        title.add_css_class("store-title")
        sub = Gtk.Label(label="The server Ubuntu's software is downloaded from", xalign=0, wrap=True)
        sub.add_css_class("dim-label")
        head.append(title)
        head.append(sub)
        box.append(head)

        # Current mirror, with the two actions.
        current_list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        current_list.add_css_class("boxed-list")
        current_list.update_property([Gtk.AccessibleProperty.LABEL], ["Current mirror"])
        self.current_row = Adw.ActionRow(title="Current mirror", subtitle="Reading…",
                                         use_markup=False, subtitle_selectable=True)
        self.current_warning = Gtk.Image(icon_name="dialog-warning-symbolic", visible=False,
                                         valign=Gtk.Align.CENTER)
        self.current_warning.add_css_class("warning")
        self.current_row.add_suffix(self.current_warning)
        current_list.append(self.current_row)
        self.progress = ProgressRow()
        current_list.append(self.progress)
        box.append(current_list)

        actions = Adw.WrapBox(child_spacing=12, line_spacing=8)  # wraps on narrow windows
        self.find_button = Gtk.Button(label="Find faster mirrors")
        self.find_button.add_css_class("pill")
        self.find_button.add_css_class("suggested-action")
        self.find_button.connect("clicked", lambda *_: self.find())
        self.reset_button = Gtk.Button(label="Reset to official")
        self.reset_button.add_css_class("pill")
        self.reset_button.connect("clicked", lambda *_: self.ask_reset())
        actions.append(self.find_button)
        actions.append(self.reset_button)
        box.append(actions)

        # Results.
        self.results_heading = Gtk.Label(label="Nearby mirrors", xalign=0, visible=False)
        self.results_heading.add_css_class("shelf-title")
        box.append(self.results_heading)
        self.list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE, visible=False)
        self.list.add_css_class("boxed-list")
        self.list.update_property([Gtk.AccessibleProperty.LABEL], ["Mirrors"])
        box.append(self.list)

        clamp = Adw.Clamp(maximum_size=1240, tightening_threshold=1240, child=box)
        self.append(Gtk.ScrolledWindow(child=clamp,
                                       hscrollbar_policy=Gtk.PolicyType.NEVER, vexpand=True))

    # -- current ----------------------------------------------------------

    def load(self) -> None:
        self.mirrors.current(self._got_current)

    def _got_current(self, mirror: Optional[Mirror], err: Optional[BackendError]) -> None:
        if err:
            self.current = None
            self.current_row.set_subtitle(f"Could not read it: {error_text(err)}")
            return
        self.current = mirror
        self._show_current()

    def _show_current(self) -> None:
        m = self.current
        if m is None:
            return
        parts = [m.url]
        if m.speed_bytes_per_s is not None:
            parts.append(speed_text(m.speed_bytes_per_s))
        if m.official:
            parts.append("Official")
        self.current_row.set_title(m.name)
        self.current_row.set_subtitle(" · ".join(parts))
        self.current_warning.set_visible(bool(m.stale))
        self.current_warning.set_tooltip_text(m.stale or "")
        if m.stale:
            self.current_warning.update_property([Gtk.AccessibleProperty.LABEL],
                                                 [f"This mirror is {m.stale}"])

    # -- finding ----------------------------------------------------------

    def find(self) -> None:
        if self.busy:
            return
        self._set_busy(True)
        self.progress.start("Finding mirrors…")
        self.mirrors.candidates(self._got_candidates)

    def _got_candidates(self, found: Optional[list[Mirror]], err: Optional[BackendError]) -> None:
        if err:
            self._finish_find()
            self.shell.toast(f"Could not get the mirror list: {error_text(err)}")
            return
        self.mirrors.test(found or [], self._on_progress, self._got_results)

    def _on_progress(self, p: Progress) -> None:
        self.progress.update(p)

    def _got_results(self, results: Optional[list[Mirror]], err: Optional[BackendError]) -> None:
        self._finish_find()
        if err:
            self.shell.toast(f"Could not test the mirrors: {error_text(err)}")
            return
        self.results = list(results or [])
        for r in self.results:
            if r.current:
                self.current = r
        self._show_current()
        self._render()
        ok = sum(1 for r in self.results if r.speed_bytes_per_s is not None)
        self.shell.toast(f"Tested {len(self.results)} mirrors, {ok} answered")

    def _finish_find(self) -> None:
        self.progress.stop()
        self._set_busy(False)

    def _render(self) -> None:
        self.list.remove_all()
        self.rows = []
        for m in self.results:
            row = MirrorRow(m, self.ask_use)
            self.list.append(row)
            self.rows.append(row)
        shown = bool(self.rows)
        self.list.set_visible(shown)
        self.results_heading.set_visible(shown)
        self._sync_buttons()

    # -- switching --------------------------------------------------------

    def ask_use(self, mirror: Mirror) -> None:
        self._confirm(
            f"Use {mirror.name}?",
            f"Ubuntu's software will be downloaded from {mirror.url}. Security updates still "
            "come from security.ubuntu.com. Your password will be asked for.",
            "Use", lambda: self.use(mirror))

    def ask_reset(self) -> None:
        self._confirm(
            "Reset to the official mirror?",
            f"Ubuntu's software will be downloaded from {OFFICIAL_URL} again. Your password "
            "will be asked for.",
            "Reset", self.reset)

    def _confirm(self, heading: str, body: str, label: str, action) -> None:
        dialog = Adw.AlertDialog(heading=heading, body=body)
        dialog.add_response("cancel", "Cancel")
        dialog.add_response("go", label)
        dialog.set_response_appearance("go", Adw.ResponseAppearance.SUGGESTED)
        dialog.set_default_response("cancel")
        dialog.set_close_response("cancel")
        dialog.connect("response", lambda _d, r: r == "go" and action())
        dialog.present(self)
        self.confirm_dialog = dialog

    def use(self, mirror: Mirror) -> None:
        if self.busy:
            return
        self._set_busy(True)
        self.mirrors.use(mirror, lambda m, e: self._switched(m, e, mirror.name))

    def reset(self) -> None:
        if self.busy:
            return
        self._set_busy(True)
        self.mirrors.reset(lambda m, e: self._switched(m, e, "the official mirror"))

    def _switched(self, result: Optional[Mirror], err: Optional[BackendError], name: str) -> None:
        self._set_busy(False)
        if err:
            self.shell.toast(f"Could not switch to {name}: {error_text(err)}")
            return
        warning = getattr(self.mirrors, "last_warning", None)
        self.shell.toast(f"Now using {result.name}" + (f". {warning}" if warning else ""))
        self.current = result
        self.results = [replace(r, current=_same(r.url, result.url)) for r in self.results]
        self._show_current()
        self._render()
        self.shell.sources_changed()

    def _set_busy(self, busy: bool) -> None:
        self.busy = busy
        self._sync_buttons()

    def _sync_buttons(self) -> None:
        self.find_button.set_sensitive(not self.busy)
        self.reset_button.set_sensitive(not self.busy)
        for row in self.rows:
            row.use_button.set_sensitive(not self.busy and not row.mirror.current)
