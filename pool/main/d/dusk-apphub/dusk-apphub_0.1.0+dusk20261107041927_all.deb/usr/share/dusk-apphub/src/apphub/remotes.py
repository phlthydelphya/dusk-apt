"""Flatpak remotes: list, check, add, enable/disable and remove, over libflatpak.

A remote is a .flatpakrepo URL or an OCI registry ("oci+https://HOST[#tag]").
New remotes always go to the per-user installation, so adding needs no password.
Existing system remotes can be changed too; libflatpak asks polkit for that.

SourceEntry.id has the form "<installation>/<remote>", for example "user/flathub".
Only this module parses it.

Every libflatpak call and every network fetch runs in run_blocking, so each
public call ends in exactly one done(result, error) on the GLib main thread.
"""

from __future__ import annotations

import logging
import re
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Callable, Iterable, Optional
from urllib.parse import urlsplit, urlunsplit

import gi

gi.require_version("Flatpak", "1.0")
from gi.repository import Flatpak, GLib  # noqa: E402

from .backend import BackendError, Done, ErrorKind, Once, Source, run_blocking  # noqa: E402
from .flatpak import _INSTALL_TARGET, _installations, map_error  # noqa: E402
from .sources import SourceEntry, SourcePlugin, SpecCheck  # noqa: E402

log = logging.getLogger("apphub.remotes")

# fetch(url) -> (http status, body). Raises OSError when the server cannot be reached.
Fetcher = Callable[[str], "tuple[int, bytes]"]
Installations = Callable[[], "list[tuple[str, Flatpak.Installation]]"]
# installed refs of an installation; each needs get_name(), get_kind(), get_origin()
RefLister = Callable[["Flatpak.Installation"], "Iterable"]

_GROUP = "Flatpak Repo"
_NAME_RE = re.compile(r"[A-Za-z0-9._-]+")
_GENERIC_STEMS = {"repo", "remote", "index", "default"}
_MAX_REPO_FILE = 256 * 1024
_TIMEOUT = 15
_REGISTRY_OK = (200, 401)


# -- small helpers ------------------------------------------------------------


def _norm_url(url: str) -> str:
    """Lower-case scheme and host, drop one trailing slash. The #tag of an OCI URL stays."""
    try:
        s = urlsplit(url.strip())
    except ValueError:
        return url.strip()
    path = s.path[:-1] if s.path.endswith("/") else s.path
    return urlunsplit((s.scheme.lower(), s.netloc.lower(), path, s.query, s.fragment))


def _is_oci(spec: str) -> bool:
    return spec.startswith("oci+")


def _is_repo_file(spec: str) -> bool:
    try:
        return urlsplit(spec).path.endswith(".flatpakrepo")
    except ValueError:
        return False


def _valid_name(name: str) -> bool:
    return bool(_NAME_RE.fullmatch(name)) and not name.startswith(".")


def derive_name(spec: str) -> Optional[str]:
    """Remote name from a .flatpakrepo address: flathub-beta.flatpakrepo gives flathub-beta.

    A generic file name ("repo.flatpakrepo") would be a poor remote name, so the
    host's main label is used instead. OCI remotes have no derived name.
    """
    if _is_oci(spec) or not _is_repo_file(spec):
        return None
    s = urlsplit(spec)
    stem = s.path.rsplit("/", 1)[-1][: -len(".flatpakrepo")]
    stem = re.sub(r"[^A-Za-z0-9._-]+", "-", stem).strip("-.")
    if stem.lower() in _GENERIC_STEMS or not stem:
        labels = (s.hostname or "").split(".")
        stem = labels[-2] if len(labels) >= 2 else (labels[0] if labels else "")
        stem = re.sub(r"[^A-Za-z0-9._-]+", "-", stem).strip("-.")
    return stem if stem and _valid_name(stem) else None


def _split_id(entry_id: str) -> tuple[str, str]:
    label, sep, name = entry_id.partition("/")
    if not sep or not label or not name:
        raise BackendError(ErrorKind.FAILED, f"Not a Flatpak remote id: {entry_id!r}", Source.FLATPAK)
    return label, name


def _scope(label: str) -> str:
    return "user" if label == "user" else "system"


def _fail(message: str) -> BackendError:
    return BackendError(ErrorKind.FAILED, message, Source.FLATPAK)


def _default_fetch(url: str) -> tuple[int, bytes]:
    """GET `url` read only. HTTP errors come back as a status; an https page never
    redirects to plain http."""

    class NoDowngrade(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            if urlsplit(req.full_url).scheme == "https" and urlsplit(newurl).scheme != "https":
                raise urllib.error.HTTPError(newurl, code, "redirect to plain http refused",
                                             headers, fp)
            return super().redirect_request(req, fp, code, msg, headers, newurl)

    opener = urllib.request.build_opener(NoDowngrade)
    req = urllib.request.Request(url, headers={"User-Agent": "AppHub", "Accept": "*/*"})
    try:
        with opener.open(req, timeout=_TIMEOUT) as r:
            return r.status, r.read(_MAX_REPO_FILE + 1)
    except urllib.error.HTTPError as e:
        return e.code, b""


@dataclass(frozen=True)
class _RepoFile:
    title: Optional[str]
    url: str
    has_key: bool
    gpg_verify: bool
    data: bytes


def _parse_repo_file(data: bytes) -> _RepoFile:
    """Read a .flatpakrepo. BackendError(FAILED) when it is not one."""
    kf = GLib.KeyFile()
    try:
        kf.load_from_data(data.decode("utf-8"), len(data), GLib.KeyFileFlags.NONE)
    except (GLib.Error, UnicodeDecodeError):
        raise _fail("Not a valid .flatpakrepo file") from None
    if not kf.has_group(_GROUP):
        raise _fail("Not a .flatpakrepo file: no [Flatpak Repo] section")

    def text(key: str) -> Optional[str]:
        try:
            return kf.get_string(_GROUP, key).strip() or None
        except GLib.Error:
            return None

    url = text("Url")
    if not url:
        raise _fail("The .flatpakrepo file names no Url")
    try:
        verify = kf.get_boolean(_GROUP, "GPGVerify")
    except GLib.Error:
        verify = True
    return _RepoFile(text("Title"), url, bool(text("GPGKey")), verify, data)


def _trust_problem(repo: _RepoFile, spec: str) -> Optional[str]:
    """Why the repo file cannot be trusted, or None. No key is fine only over https
    with GPGVerify=false."""
    if repo.has_key:
        return None
    if urlsplit(spec).scheme == "https" and not repo.gpg_verify:
        return None
    return "The repository has no GPG key, so its apps could not be verified"


# -- the manager --------------------------------------------------------------


class FlatpakRemotes:
    kind = Source.FLATPAK

    def __init__(self, installations: Optional[Installations] = None,
                 fetch: Optional[Fetcher] = None,
                 installed_refs: Optional[RefLister] = None,
                 arch: Optional[str] = None,
                 refresh_appstream: bool = True):
        self._installations = installations or _installations
        self._fetch_raw = fetch or _default_fetch
        self._installed_refs = installed_refs or (lambda inst: inst.list_installed_refs(None))
        self._arch = arch
        self._refresh = refresh_appstream
        # .flatpakrepo address -> the Url the file declares (for matches())
        self._declared: dict[str, str] = {}

    # -- plumbing -------------------------------------------------------------

    def _run(self, work, done) -> None:
        run_blocking(work, Once(done), map_error)

    def _target(self) -> Flatpak.Installation:
        for label, inst in self._installations():
            if label == _INSTALL_TARGET:
                return inst
        raise BackendError(ErrorKind.UNSUPPORTED, "No per-user Flatpak installation here",
                           Source.FLATPAK)

    def _find(self, entry_id: str) -> tuple[str, Flatpak.Installation, str]:
        label, name = _split_id(entry_id)
        for lbl, inst in self._installations():
            if lbl == label:
                return lbl, inst, name
        raise BackendError(ErrorKind.NOT_FOUND, f"No Flatpak installation named {label!r}",
                           Source.FLATPAK)

    def _get(self, url: str) -> tuple[int, bytes]:
        try:
            return self._fetch_raw(url)
        except OSError as e:
            raise BackendError(ErrorKind.NETWORK, f"Cannot reach {urlsplit(url).netloc}: {e}",
                               Source.FLATPAK) from e

    def _fetch_repo(self, spec: str) -> _RepoFile:
        status, body = self._get(spec)
        if status != 200:
            raise _fail(f"The server answered {status} for the .flatpakrepo file")
        if len(body) > _MAX_REPO_FILE:
            raise _fail("The .flatpakrepo file is too large")
        repo = _parse_repo_file(body)
        self._declared[spec] = repo.url
        return repo

    def _refs_by_origin(self, inst: Flatpak.Installation) -> dict[str, list]:
        by: dict[str, list] = {}
        try:
            refs = list(self._installed_refs(inst))
        except GLib.Error as e:
            log.warning("cannot list installed refs: %s", e.message)
            return by
        for ref in refs:
            by.setdefault(ref.get_origin(), []).append(ref)
        return by

    @staticmethod
    def _used_warning(refs: list) -> Optional[str]:
        apps = sum(1 for r in refs if r.get_kind() == Flatpak.RefKind.APP)
        if apps:
            return f"{apps} installed app{'s' if apps != 1 else ''} come{'' if apps != 1 else 's'} from here"
        if refs:
            n = len(refs)
            return f"{n} installed runtime{'s' if n != 1 else ''} come{'' if n != 1 else 's'} from here"
        return None

    @staticmethod
    def _remove_blocker(refs: list) -> Optional[str]:
        """Why a remote cannot be removed: Flatpak refuses while installed refs come from it."""
        if not refs:
            return None
        ordered = sorted(refs, key=lambda r: (r.get_kind() != Flatpak.RefKind.APP, r.get_name()))
        names = [r.get_name() for r in ordered]
        shown = ", ".join(names[:3]) + (f" and {len(names) - 3} more" if len(names) > 3 else "")
        return (f"installed apps and runtimes still come from it ({shown}). "
                "Remove them first.")

    def _entry(self, label: str, remote: Flatpak.Remote, refs: list,
               extra_warning: Optional[str] = None) -> SourceEntry:
        name = remote.get_name()
        warnings = [w for w in (self._used_warning(refs), extra_warning) if w]
        return SourceEntry(
            id=f"{label}/{name}", kind=Source.FLATPAK,
            name=remote.get_title() or name, detail=remote.get_url() or "",
            enabled=not remote.get_disabled(), scope=_scope(label),
            warning="; ".join(warnings) or None,
            removable=not refs, remove_note=self._remove_blocker(refs))

    def _existing_with_url(self, url: str) -> Optional[tuple[str, str]]:
        """(remote name, scope) of a remote that already has this URL, in any installation."""
        want = _norm_url(url)
        for label, inst in self._installations():
            try:
                remotes = inst.list_remotes(None)
            except GLib.Error:
                continue
            for r in remotes:
                if _norm_url(r.get_url() or "") == want:
                    return r.get_name(), _scope(label)
        return None

    # -- SourceManager --------------------------------------------------------

    def available(self) -> bool:
        try:
            return bool(self._installations())
        except Exception:  # noqa: BLE001
            return False

    def list(self, done: Done[list[SourceEntry]]) -> None:
        def work() -> list[SourceEntry]:
            out: list[SourceEntry] = []
            for label, inst in self._installations():
                try:
                    remotes = inst.list_remotes(None)
                except GLib.Error as e:
                    log.warning("cannot list remotes of %s: %s", label, e.message)
                    continue
                by_origin = self._refs_by_origin(inst)
                for r in sorted(remotes, key=lambda r: r.get_name().lower()):
                    out.append(self._entry(label, r, by_origin.get(r.get_name(), [])))
            return out

        self._run(work, done)

    def check(self, spec: str, done: Done[SpecCheck]) -> None:
        self._run(lambda: self._check(spec.strip()), done)

    def _check(self, spec: str) -> SpecCheck:
        scheme = urlsplit(spec).scheme.lower()
        if _is_oci(spec):
            return self._check_oci(spec)
        if scheme == "http":
            return SpecCheck(False, "Plain http is not safe for a software source; use https")
        if scheme != "https" or not _is_repo_file(spec):
            return SpecCheck(False, "Not a Flatpak repository: expected an https .flatpakrepo "
                                    "address or oci+https://registry")
        status, body = self._get(spec)
        if status != 200:
            return SpecCheck(False, f"The server answered {status} for this address")
        try:
            repo = _parse_repo_file(body)
        except BackendError as e:
            return SpecCheck(False, e.message)
        self._declared[spec] = repo.url
        problem = _trust_problem(repo, spec)
        if problem:
            return SpecCheck(False, problem, repo.title)
        dup = self._existing_with_url(repo.url)
        if dup:
            return SpecCheck(False, f"Already added as {dup[0]} ({dup[1]})", repo.title)
        msg = (f"{repo.title or 'Repository'}: signed with a GPG key" if repo.has_key
               else f"{repo.title or 'Repository'}: not signed (GPG verification is off)")
        return SpecCheck(True, msg, repo.title)

    def _check_oci(self, spec: str) -> SpecCheck:
        https = "https://" + spec[len("oci+https://"):] if spec.startswith("oci+https://") else None
        if https is None:
            return SpecCheck(False, "Only oci+https:// registries are supported")
        s = urlsplit(https)
        if not s.hostname:
            return SpecCheck(False, "The registry address has no host")
        status, _ = self._get(f"https://{s.netloc}/v2/")
        if status not in _REGISTRY_OK:
            return SpecCheck(False, f"{s.hostname} does not look like a container registry "
                                    f"(answered {status})")
        dup = self._existing_with_url(spec)
        if dup:
            return SpecCheck(False, f"Already added as {dup[0]} ({dup[1]})", s.hostname)
        return SpecCheck(True, f"{s.hostname} is a container registry", s.hostname)

    def add(self, spec: str, done: Done[SourceEntry], name: Optional[str] = None) -> None:
        self._run(lambda: self._add(spec.strip(), name), done)

    def _add(self, spec: str, name: Optional[str]) -> SourceEntry:
        if name is not None and not _valid_name(name):
            raise _fail("A remote name may use letters, digits, '.', '_' and '-', "
                        "and may not start with a dot")
        if _is_oci(spec):
            if not spec.startswith("oci+https://") or not urlsplit(spec[4:]).hostname:
                raise _fail("Only oci+https:// registries are supported")
            if not name:
                raise _fail("A registry needs a name for its remote")
            remote_url = spec
            repo = None
        else:
            scheme = urlsplit(spec).scheme.lower()
            if scheme == "http":
                raise _fail("Plain http is not safe for a software source; use https")
            if scheme != "https" or not _is_repo_file(spec):
                raise _fail("Not a Flatpak repository: expected an https .flatpakrepo address")
            repo = self._fetch_repo(spec)
            problem = _trust_problem(repo, spec)
            if problem:
                raise _fail(problem)
            remote_url = repo.url
            name = name or derive_name(spec)
            if not name:
                raise _fail("Could not derive a name for this remote; give one")

        dup = self._existing_with_url(remote_url)
        if dup:
            raise _fail(f"Already added as {dup[0]} ({dup[1]})")

        inst = self._target()
        if any(r.get_name() == name for r in inst.list_remotes(None)):
            raise _fail(f"A remote named {name} already exists (user)")

        if repo is not None:
            remote = Flatpak.Remote.new_from_file(name, GLib.Bytes.new(repo.data))
        else:
            remote = Flatpak.Remote.new(name)
            remote.set_url(spec)
            remote.set_gpg_verify(False)  # registries carry no GPG signatures
        inst.add_remote(remote, True, None)

        warning = None
        try:
            if self._refresh:
                inst.update_appstream_full_sync(
                    name, self._arch or Flatpak.get_default_arch(), None, None)
        except GLib.Error as e:
            log.warning("appstream update for %s failed: %s", name, e.message)
            warning = "Added, but its app list could not be refreshed yet"
        return self._entry(_INSTALL_TARGET, inst.get_remote_by_name(name, None), [], warning)

    def set_enabled(self, entry: SourceEntry, enabled: bool, done: Done[SourceEntry]) -> None:
        def work() -> SourceEntry:
            label, inst, name = self._find(entry.id)
            remote = inst.get_remote_by_name(name, None)
            remote.set_disabled(not enabled)
            inst.modify_remote(remote, None)
            fresh = inst.get_remote_by_name(name, None)
            return self._entry(label, fresh, self._refs_by_origin(inst).get(name, []))

        self._run(work, done)

    def remove(self, entry: SourceEntry, done: Done[bool]) -> None:
        def work() -> bool:
            _, inst, name = self._find(entry.id)
            inst.get_remote_by_name(name, None)  # NOT_FOUND when it is gone already
            blocker = self._remove_blocker(self._refs_by_origin(inst).get(name, []))
            if blocker:
                raise _fail(f"Cannot remove {entry.name}: {blocker}")
            inst.remove_remote(name, None)
            return True

        self._run(work, done)

    def matches(self, plugin: SourcePlugin, entry: SourceEntry) -> bool:
        if plugin.kind != Source.FLATPAK or entry.kind != Source.FLATPAK:
            return False
        spec = plugin.spec
        url = _norm_url(entry.detail)
        if url == _norm_url(spec):
            return True
        declared = self._declared.get(spec)
        if declared and url == _norm_url(declared):
            return True
        try:
            _, name = _split_id(entry.id)
        except BackendError:
            return False
        return name in {n for n in (plugin.remote_name, derive_name(spec)) if n}

    # -- extra (not in the contract) ----------------------------------------------

    def prefetch(self, plugins: Iterable[SourcePlugin], done: Done[bool]) -> None:
        """Read the .flatpakrepo files of `plugins` so matches() knows the Url each declares.
        Files that cannot be read are skipped."""
        specs = [p.spec for p in plugins
                 if p.kind == Source.FLATPAK and not _is_oci(p.spec) and _is_repo_file(p.spec)
                 and urlsplit(p.spec).scheme == "https" and p.spec not in self._declared]

        def work() -> bool:
            for spec in specs:
                try:
                    self._fetch_repo(spec)
                except BackendError as e:
                    log.info("cannot read %s: %s", spec, e.message)
            return True

        self._run(work, done)


__all__ = ["FlatpakRemotes", "derive_name"]
