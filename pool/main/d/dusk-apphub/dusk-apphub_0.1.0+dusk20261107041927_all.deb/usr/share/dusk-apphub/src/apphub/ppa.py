"""APT sources: the configured repositories, plus adding Launchpad PPAs.

AptSources implements sources.SourceManager for Source.APT.

Reading uses repos.list_repos(). Every change goes through the pkexec helper
wrappers in repos.py, then refreshes the APT cache through PackageKit so the
new packages show up.

Adding a PPA ("ppa:owner/name"):
  1. Launchpad REST API (read only, anonymous): display name, signing key
     fingerprint, and whether it publishes anything for this Ubuntu release.
  2. The key from keyserver.ubuntu.com, checked with gpg in a throwaway
     GNUPGHOME: exactly one primary key, and its full fingerprint must equal
     Launchpad's. Anything else is refused.
  3. A DEB822 file with the armored key inline (Signed-By), named the way
     add-apt-repository names it: OWNER-ubuntu-NAME-<codename>.sources.

Network and privileged steps are constructor arguments so tests run offline
and never touch /etc.
"""

from __future__ import annotations

import dataclasses
import json
import logging
import os
import re
import subprocess
import tempfile
import urllib.error
import urllib.request
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import urlparse

from . import repos
from .backend import BackendError, Done, ErrorKind, Once, Source, run_blocking
from .sources import SourceEntry, SourcePlugin, SpecCheck

log = logging.getLogger("apphub.ppa")

LP_API = "https://api.launchpad.net/1.0"
KEYSERVER = "https://keyserver.ubuntu.com/pks/lookup?op=get&search=0x"
PPA_URI = "https://ppa.launchpadcontent.net/{owner}/{name}/ubuntu/"
PPA_HOSTS = ("ppa.launchpadcontent.net", "ppa.launchpad.net")
OS_RELEASE = Path("/etc/os-release")
USER_AGENT = "AppHub"
TIMEOUT = 20  # seconds per request
MAX_JSON = 4 * 1024 * 1024
MAX_KEY = 256 * 1024
MAX_SERIES_PROBES = 6  # other releases asked about when this one has nothing

# Launchpad names: lowercase letters, digits, "+", "." and "-", starting alphanumeric.
_LP_NAME = re.compile(r"[a-z0-9][a-z0-9+.-]{0,63}")
_SPEC = re.compile(rf"ppa:({_LP_NAME.pattern})(?:/({_LP_NAME.pattern}))?")
_FPR = re.compile(r"[0-9A-F]{40}")
_CODENAME = re.compile(r"[a-z][a-z0-9-]{0,31}")
_ARMOR_BEGIN = "-----BEGIN PGP PUBLIC KEY BLOCK-----"
_ARMOR_END = "-----END PGP PUBLIC KEY BLOCK-----"
_ARCHIVE_HOSTS = ("archive.ubuntu.com", "security.ubuntu.com", "ports.ubuntu.com")
_ARCHIVE_KEYRING = "ubuntu-archive-keyring.gpg"
LEGACY_WARNING = "Read-only: an old-style .list file; AppHub cannot change it"


class HttpError(Exception):
    """A non-2xx HTTP reply. Fetchers raise this; other OSErrors mean no network."""

    def __init__(self, status: int, url: str):
        super().__init__(f"HTTP {status} for {url}")
        self.status = status
        self.url = url


Fetch = Callable[[str, int], bytes]  # (url, max_bytes) -> body
Writer = Callable[[str, str, Done[bool]], None]  # repos.add_repo_async
Toggler = Callable[[repos.Repo, bool, Done[bool]], None]  # repos.set_enabled_async
Disabler = Callable[[str, Done[bool]], None]  # repos.disable_file_async
Refresher = Callable[[Done[bool]], None]


def urllib_fetch(url: str, max_bytes: int) -> bytes:
    """GET with a plain User-Agent, a timeout and a size cap. No cookies, no auth."""
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            body = resp.read(max_bytes + 1)
    except urllib.error.HTTPError as e:
        e.close()
        raise HttpError(e.code, url) from None
    if len(body) > max_bytes:
        raise BackendError(ErrorKind.FAILED, f"reply too large from {urlparse(url).hostname}",
                           Source.APT)
    return body


def packagekit_refresh(done: Done[bool]) -> None:
    """Refresh the APT cache through PackageKit (force=False)."""
    try:
        import gi
        gi.require_version("PackageKitGlib", "1.0")
        from gi.repository import GLib, PackageKitGlib as Pk
        from .apt import map_error
    except Exception as e:  # noqa: BLE001 - no PackageKit: report, never hang
        done(None, BackendError(ErrorKind.UNSUPPORTED, f"PackageKit unavailable: {e}", Source.APT))
        return
    done = Once(done)
    client = Pk.Client()
    client.set_interactive(True)

    def ready(c, res, *_):
        try:
            c.generic_finish(res)
        except GLib.Error as e:
            done(None, map_error(e))
            return
        except Exception as e:  # noqa: BLE001
            done(None, BackendError(ErrorKind.FAILED, str(e), Source.APT))
            return
        done(True, None)

    try:
        # Same call shape as apt.py: (args..., cancellable, progress_cb, progress_user_data, cb).
        client.refresh_cache_async(False, None, lambda *_: None, (), ready)
    except Exception as e:  # noqa: BLE001
        done(None, BackendError(ErrorKind.FAILED, str(e), Source.APT))


# -- pure helpers ------------------------------------------------------------

def parse_spec(spec: str) -> tuple[str, str]:
    """(owner, name) of "ppa:owner/name". "ppa:owner" means "ppa:owner/ppa".

    Raises ValueError for anything else. Case is folded; Launchpad names are lowercase.
    """
    if not isinstance(spec, str):
        raise ValueError("not a PPA")
    s = spec.strip().lower()
    m = _SPEC.fullmatch(s)
    if not m:
        raise ValueError(f"Not a PPA name: {spec.strip()[:80]!r} (expected ppa:owner/name)")
    return m.group(1), m.group(2) or "ppa"


def ppa_of_uri(uri: str) -> Optional[tuple[str, str]]:
    """(owner, name) when uri points at a Launchpad PPA, else None."""
    u = urlparse(uri)
    if (u.hostname or "").lower() not in PPA_HOSTS:
        return None
    parts = [p for p in u.path.split("/") if p]
    if len(parts) < 2:
        return None
    return parts[0].lower(), parts[1].lower()


def basename_for(owner: str, name: str, codename: str) -> str:
    """add-apt-repository's file name. "+" (legal on Launchpad) is not legal for the helper."""
    return f"{owner}-ubuntu-{name}-{codename}.sources".replace("+", "_")


def read_os_release(path: Path = OS_RELEASE) -> dict[str, str]:
    out: dict[str, str] = {}
    try:
        text = Path(path).read_text(encoding="utf-8")
    except OSError:
        return out
    for line in text.splitlines():
        key, sep, value = line.partition("=")
        if sep and key.strip():
            out[key.strip()] = value.strip().strip('"').strip("'")
    return out


def normalize_armor(text: str) -> str:
    """The single armored public key block in text, without armor headers.

    Raises ValueError when there is not exactly one public key block, or when
    secret key material is present.
    """
    if "PRIVATE KEY" in text or "SECRET KEY" in text:
        raise ValueError("key data contains secret key material")
    if text.count(_ARMOR_BEGIN) != 1 or text.count(_ARMOR_END) != 1:
        raise ValueError("expected exactly one armored public key block")
    body = text[text.index(_ARMOR_BEGIN) + len(_ARMOR_BEGIN):text.index(_ARMOR_END)]
    lines = [ln.strip() for ln in body.strip("\r\n").splitlines()]
    # Armor headers ("Comment: ...", "Version: ...") end at the first blank line.
    if "" in lines and all(":" in ln for ln in lines[:lines.index("")]):
        lines = lines[lines.index("") + 1:]
    lines = [ln for ln in lines if ln]
    if not lines or not all(re.fullmatch(r"[A-Za-z0-9+/=]+", ln) for ln in lines):
        raise ValueError("armored key is malformed")
    return "\n".join([_ARMOR_BEGIN, "", *lines, _ARMOR_END]) + "\n"


def verify_key(armored: str, fingerprint: str, gpg: str = "gpg") -> None:
    """Refuse unless armored holds exactly one primary key whose fingerprint is `fingerprint`.

    gpg runs in a throwaway GNUPGHOME and only shows the key; nothing is imported
    anywhere that outlives this call.
    """
    want = fingerprint.strip().upper()
    if not _FPR.fullmatch(want):
        raise ValueError("Launchpad gave no valid key fingerprint")
    with tempfile.TemporaryDirectory(prefix="apphub-gpg-") as home:
        os.chmod(home, 0o700)
        env = {k: v for k, v in os.environ.items() if k in ("PATH", "LANG", "LC_ALL")}
        env["GNUPGHOME"] = home
        try:
            proc = subprocess.run(
                [gpg, "--batch", "--no-tty", "--no-options", "--no-autostart",
                 "--homedir", home, "--with-colons", "--show-keys"],
                input=armored, capture_output=True, text=True, env=env, timeout=30, check=False)
        except (OSError, subprocess.SubprocessError) as e:
            raise ValueError(f"cannot run gpg to check the key: {e}") from None
    if proc.returncode != 0:
        raise ValueError("gpg could not read the key")
    records = [ln.split(":") for ln in proc.stdout.splitlines()]
    if any(r[0] in ("sec", "ssb") for r in records):
        raise ValueError("key data contains secret key material")
    pubs = [i for i, r in enumerate(records) if r[0] == "pub"]
    if len(pubs) != 1:
        raise ValueError(f"expected exactly one key, got {len(pubs)}")
    i = pubs[0]
    if records[i][1] in ("r", "e"):
        raise ValueError("the signing key is revoked or expired")
    nxt = records[i + 1] if i + 1 < len(records) else []
    got = nxt[9].upper() if len(nxt) > 9 and nxt[0] == "fpr" else ""
    if got != want:
        raise ValueError(f"key fingerprint {got or 'unknown'} does not match Launchpad's {want}")


def _one_line(text: str, limit: int = 100) -> str:
    return " ".join("".join(c if c.isprintable() else " " for c in text).split())[:limit]


# -- the manager -------------------------------------------------------------

@dataclasses.dataclass(frozen=True)
class _Ppa:
    owner: str
    name: str
    displayname: str
    fingerprint: Optional[str]
    count: int  # sources published for this release
    elsewhere: tuple[str, ...]  # "26.04 (resolute)", when count == 0

    @property
    def spec(self) -> str:
        return f"ppa:{self.owner}/{self.name}"


class AptSources:
    kind = Source.APT

    def __init__(self, fetch: Fetch = urllib_fetch,
                 list_repos: Callable[[], list[repos.Repo]] = repos.list_repos,
                 write: Writer = repos.add_repo_async,
                 toggle: Toggler = repos.set_enabled_async,
                 disable: Disabler = repos.disable_file_async,
                 refresh: Refresher = packagekit_refresh,
                 os_release: Path = OS_RELEASE,
                 sources_dir: Path = repos.SOURCES_DIR,
                 gpg: str = "gpg") -> None:
        self._fetch = fetch
        self._list_repos = list_repos
        self._write = write
        self._toggle = toggle
        self._disable = disable
        self._refresh = refresh
        self._os_release = os_release
        self._dir = Path(sources_dir)
        self._gpg = gpg
        self._release: Optional[tuple[str, str]] = None

    def available(self) -> bool:
        return self._dir.is_dir()

    # -- release ----------------------------------------------------------

    def release(self) -> tuple[str, str]:
        """(codename, version) of this system, e.g. ("stonking", "26.10")."""
        if self._release is None:
            info = read_os_release(self._os_release)
            code = (info.get("UBUNTU_CODENAME") or info.get("VERSION_CODENAME") or "").lower()
            if not _CODENAME.fullmatch(code):
                raise BackendError(ErrorKind.UNSUPPORTED,
                                   "Cannot tell which Ubuntu release this is", Source.APT)
            self._release = (code, info.get("VERSION_ID", ""))
        return self._release

    def _label(self) -> str:
        code, version = self.release()
        return f"Ubuntu {version} ({code})" if version else code

    # -- list -------------------------------------------------------------

    def list(self, done: Done[list[SourceEntry]]) -> None:
        run_blocking(lambda: [self._entry(r) for r in self._list_repos()], done, _map_exc)

    def _is_archive(self, r: repos.Repo) -> bool:
        if r.file.name == "ubuntu.sources" or r.file == repos.MAIN_LIST:
            return True
        if (r.signed_by or "").endswith(_ARCHIVE_KEYRING):
            return True
        for uri in r.uris:
            if uri.startswith(("mirror+", "mirror:")):
                return True
            host = (urlparse(uri).hostname or "").lower()
            if host in _ARCHIVE_HOSTS or host.endswith(".archive.ubuntu.com"):
                return True
        return False

    def _entry(self, r: repos.Repo) -> SourceEntry:
        ppa = next((p for p in map(ppa_of_uri, r.uris) if p), None)
        archive = self._is_archive(r)
        warning = None
        name = r.name
        if ppa:
            detail = f"ppa:{ppa[0]}/{ppa[1]}"
            try:
                code = self.release()[0]
                if r.suites and code not in r.suites:
                    warning = f"Built for {' '.join(r.suites)}, not this release ({code})"
            except BackendError:
                pass
        else:
            detail = " ".join([*r.uris[:1], *r.suites])
        if archive and not ppa:
            name = ("Ubuntu security updates"
                    if any("security.ubuntu.com" in u for u in r.uris) else "Ubuntu")
        if r.types == ("deb-src",):
            name += " (source code)"
        if r.legacy:
            warning = LEGACY_WARNING
        protected = archive or r.legacy
        return SourceEntry(
            id=f"{r.file}#{r.index}", kind=Source.APT, name=name, detail=detail,
            enabled=r.enabled, removable=not protected, can_disable=not protected,
            warning=warning)

    # -- check / add ------------------------------------------------------

    def check(self, spec: str, done: Done[SpecCheck]) -> None:
        def work() -> SpecCheck:
            try:
                owner, name = parse_spec(spec)
            except ValueError as e:
                return SpecCheck(False, str(e))
            if self._configured(owner, name):
                return SpecCheck(False, f"ppa:{owner}/{name} is already added")
            try:
                ppa = self._lookup(owner, name)
            except BackendError as e:
                if e.kind == ErrorKind.NOT_FOUND:
                    return SpecCheck(False, e.message)
                raise
            problem = self._problem(ppa)
            if problem:
                return SpecCheck(False, problem, ppa.displayname)
            n = ppa.count
            return SpecCheck(True, f"Has {n} package{'s' if n != 1 else ''} for {self._label()}",
                             ppa.displayname)
        run_blocking(work, done, _map_exc)

    def add(self, spec: str, done: Done[SourceEntry], name: Optional[str] = None) -> None:
        done = Once(done)

        def prepare() -> tuple[str, str, SourceEntry]:
            try:
                owner, ppa_name = parse_spec(spec)
            except ValueError as e:
                raise BackendError(ErrorKind.FAILED, str(e), Source.APT) from None
            if self._configured(owner, ppa_name):
                raise BackendError(ErrorKind.FAILED, f"ppa:{owner}/{ppa_name} is already added",
                                   Source.APT)
            code = self.release()[0]
            basename = basename_for(owner, ppa_name, code)
            if (self._dir / basename).exists():
                raise BackendError(ErrorKind.FAILED, f"{basename} already exists", Source.APT)
            ppa = self._lookup(owner, ppa_name)
            problem = self._problem(ppa)
            if problem:
                raise BackendError(ErrorKind.FAILED, problem, Source.APT)
            key = self._fetch_key(ppa.fingerprint or "")
            title = _one_line(name or "") or ppa.displayname
            text = repos.add_repo(
                title, ["deb"], [PPA_URI.format(owner=owner, name=ppa_name)], [code], ["main"],
                key)
            entry = SourceEntry(id=f"{self._dir / basename}#0", kind=Source.APT, name=title,
                                detail=ppa.spec, enabled=True)
            return basename, text, entry

        def prepared(result, error) -> None:
            if error is not None:
                done(None, error)
                return
            basename, text, entry = result
            self._guard(done, self._write, basename, text,
                        lambda _ok: self._then_refresh(entry, done))

        run_blocking(prepare, prepared, _map_exc)

    def _configured(self, owner: str, name: str) -> bool:
        want = (owner.lower(), name.lower())
        return any(ppa_of_uri(u) == want for r in self._list_repos() for u in r.uris)

    def _problem(self, ppa: _Ppa) -> Optional[str]:
        if not ppa.fingerprint:
            return f"{ppa.spec} has no signing key yet, so APT would refuse it"
        if ppa.count == 0:
            where = self._label()
            if ppa.elsewhere:
                return f"No packages for {where}; it publishes for {', '.join(ppa.elsewhere)}"
            return f"No packages for {where} or any other supported release"
        return None

    # -- network (blocking; run inside run_blocking) ---------------------

    def _get(self, url: str, max_bytes: int) -> bytes:
        """Fetch; connection failures become NETWORK. HttpError passes through."""
        try:
            return self._fetch(url, max_bytes)
        except OSError as e:  # URLError, socket errors, timeouts
            reason = getattr(e, "reason", None) or e
            raise BackendError(ErrorKind.NETWORK,
                               f"Cannot reach {urlparse(url).hostname}: {reason}",
                               Source.APT) from None

    def _json(self, url: str):
        try:
            return json.loads(self._get(url, MAX_JSON).decode("utf-8"))
        except (ValueError, UnicodeError):
            raise BackendError(ErrorKind.FAILED, "Launchpad sent an unexpected reply",
                               Source.APT) from None

    def _lookup(self, owner: str, name: str) -> _Ppa:
        path = f"/~{owner}/+archive/ubuntu/{name}"  # both validated by parse_spec
        spec = f"ppa:{owner}/{name}"
        try:
            data = self._json(LP_API + path)
        except HttpError as e:
            if e.status in (404, 410, 401, 403):
                raise BackendError(ErrorKind.NOT_FOUND, f"No such PPA on Launchpad: {spec}",
                                   Source.APT) from None
            raise
        # Launchpad redirects some unknown names elsewhere; trust only the object asked for.
        if not isinstance(data, dict) or not str(data.get("self_link", "")).lower().endswith(path):
            raise BackendError(ErrorKind.NOT_FOUND, f"No such PPA on Launchpad: {spec}", Source.APT)
        if data.get("private"):
            raise BackendError(ErrorKind.NOT_FOUND, f"{spec} is private", Source.APT)
        fpr = str(data.get("signing_key_fingerprint") or "").strip().upper() or None
        if fpr is not None and not _FPR.fullmatch(fpr):
            fpr = None
        display = _one_line(str(data.get("displayname") or "")) or spec
        code = self.release()[0]
        count = self._count(path, code)
        elsewhere: tuple[str, ...] = ()
        if count == 0:
            elsewhere = self._elsewhere(path, code)
        return _Ppa(owner, name, display, fpr, count, elsewhere)

    def _count(self, path: str, series: str) -> int:
        url = (f"{LP_API}{path}?ws.op=getPublishedSources"
               f"&distro_series={LP_API}/ubuntu/{series}&status=Published&ws.size=1")
        data = self._json(url)
        if not isinstance(data, dict):
            raise BackendError(ErrorKind.FAILED, "Launchpad sent an unexpected reply", Source.APT)
        total = data.get("total_size")
        if isinstance(total, int):
            return total
        link = data.get("total_size_link")
        if isinstance(link, str) and link.startswith(LP_API + "/"):
            n = self._json(link)
            if isinstance(n, int):
                return n
        return len(data.get("entries") or [])

    def _elsewhere(self, path: str, code: str) -> tuple[str, ...]:
        """Supported releases, newest first, that the PPA does publish for. Best effort."""
        try:
            data = self._json(f"{LP_API}/ubuntu/series")
            series = [s for s in data.get("entries", [])
                      if s.get("active") and s.get("name") != code
                      and _CODENAME.fullmatch(str(s.get("name", "")))]
            series.sort(key=lambda s: [int(x) for x in re.findall(r"\d+", str(s.get("version")))],
                        reverse=True)
            out = []
            for s in series[:MAX_SERIES_PROBES]:
                if self._count(path, s["name"]) > 0:
                    out.append(f"{s.get('version')} ({s['name']})")
            return tuple(out)
        except (BackendError, HttpError, OSError, AttributeError, TypeError, ValueError) as e:
            log.info("could not list other releases for %s: %s", path, e)
            return ()

    def _fetch_key(self, fingerprint: str) -> str:
        if not _FPR.fullmatch(fingerprint):
            raise BackendError(ErrorKind.FAILED, "Launchpad gave no valid key fingerprint",
                               Source.APT)
        try:
            raw = self._get(KEYSERVER + fingerprint, MAX_KEY)
        except HttpError as e:
            raise BackendError(ErrorKind.NETWORK,
                               f"The key server did not return the PPA key (HTTP {e.status})",
                               Source.APT) from None
        try:
            armored = normalize_armor(raw.decode("ascii"))
            verify_key(armored, fingerprint, self._gpg)
        except (ValueError, UnicodeError) as e:
            raise BackendError(ErrorKind.FAILED, f"PPA signing key refused: {e}",
                               Source.APT) from None
        return armored

    # -- enable / remove --------------------------------------------------

    def set_enabled(self, entry: SourceEntry, enabled: bool, done: Done[SourceEntry]) -> None:
        done = Once(done)

        def found(repo: repos.Repo) -> None:
            fresh = self._entry(repo)
            if not fresh.can_disable:
                done(None, BackendError(ErrorKind.UNSUPPORTED,
                                        f"{fresh.name} cannot be turned off here", Source.APT))
                return
            result = dataclasses.replace(fresh, enabled=enabled)
            self._guard(done, self._toggle, repo, enabled,
                        lambda _ok: self._then_refresh(result, done))

        self._find(entry, found, done)

    def remove(self, entry: SourceEntry, done: Done[bool]) -> None:
        done = Once(done)

        def found(repo: repos.Repo) -> None:
            if not self._entry(repo).removable:
                done(None, BackendError(ErrorKind.UNSUPPORTED,
                                        f"{entry.name} cannot be removed", Source.APT))
                return
            self._guard(done, self._disable, repo.file.name,
                        lambda _ok: self._then_refresh(True, done))

        self._find(entry, found, done)

    def _find(self, entry: SourceEntry, found: Callable[[repos.Repo], None], done) -> None:
        """Re-read the repo behind entry (off the main thread), then call found(repo)."""
        def work() -> repos.Repo:
            file, sep, index = entry.id.rpartition("#")
            if not sep or not index.isdigit():
                raise BackendError(ErrorKind.NOT_FOUND, "Not an APT source", Source.APT)
            for r in self._list_repos():
                if str(r.file) == file and r.index == int(index):
                    if r.legacy or r.file.parent != self._dir or r.file.suffix != ".sources":
                        raise BackendError(ErrorKind.UNSUPPORTED, LEGACY_WARNING, Source.APT)
                    return r
            raise BackendError(ErrorKind.NOT_FOUND, f"{entry.name} is no longer configured",
                               Source.APT)

        def after(repo, error) -> None:
            if error is not None:
                done(None, error)
                return
            try:
                found(repo)
            except Exception as e:  # noqa: BLE001 - contract: always reach done
                done(None, _map_exc(e))

        run_blocking(work, after, _map_exc)

    # -- plumbing ---------------------------------------------------------

    @staticmethod
    def _guard(done, fn, *args) -> None:
        """Call fn(*args[:-1], cb); errors (raised or reported) go to done, success to args[-1]."""
        *call_args, on_ok = args

        def cb(result, error) -> None:
            if error is not None:
                done(None, error)
                return
            try:
                on_ok(result)
            except Exception as e:  # noqa: BLE001
                done(None, _map_exc(e))

        try:
            fn(*call_args, cb)
        except Exception as e:  # noqa: BLE001
            done(None, _map_exc(e))

    def _then_refresh(self, result, done) -> None:
        """Refresh the APT cache; a failed refresh is a warning, not a failed change."""
        def refreshed(_ok, error) -> None:
            if error is None:
                done(result, None)
                return
            log.warning("APT cache refresh failed: %s", error.message)
            if isinstance(result, SourceEntry):
                done(dataclasses.replace(
                    result, warning=f"Saved, but the package list was not refreshed: "
                                    f"{error.message}"), None)
            else:
                done(result, None)

        try:
            self._refresh(refreshed)
        except Exception as e:  # noqa: BLE001
            refreshed(None, _map_exc(e))

    # -- plugins ----------------------------------------------------------

    def matches(self, plugin: SourcePlugin, entry: SourceEntry) -> bool:
        if plugin.kind != Source.APT or entry.kind != Source.APT:
            return False
        try:
            want = parse_spec(plugin.spec)
            got = parse_spec(entry.detail)
        except ValueError:
            return False
        return want == got


def _map_exc(e: Exception) -> BackendError:
    if isinstance(e, BackendError):
        return e
    if isinstance(e, HttpError):
        return BackendError(ErrorKind.NETWORK, f"Server error {e.status}", Source.APT)
    if isinstance(e, FileNotFoundError):
        return BackendError(ErrorKind.NOT_FOUND, str(e), Source.APT)
    if isinstance(e, repos.ValidationError):
        return BackendError(ErrorKind.FAILED, str(e), Source.APT)
    return BackendError(ErrorKind.FAILED, str(e) or type(e).__name__, Source.APT)
