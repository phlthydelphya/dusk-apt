import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Mtk from 'gi://Mtk';

import * as BoxPointer from 'resource:///org/gnome/shell/ui/boxpointer.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';

// One desktop menu: the desktop icons' (gtk4-ding) background menu shown in
// the Shell's own desktop menu, so it gets the Shell's acrylic like every
// other Shell menu, next to Change Background / Display Settings / Settings.
//
// Ding is a separate GTK process; its menu was a GtkPopoverMenu inside its
// desktop window. Dusk patches ding (setup/system/patch-ding.py) so a right
// click on the empty desktop first calls Show() here with its menu model
// serialized as JSON (labels, actions, targets, enabled and checked state, at
// the moment of the click). Items activate ding's actions over its exported
// org.gtk.Actions. If this module is not running, the call fails and ding
// shows its own popover, so nothing breaks.
//
// JSON items, in order:
//   {section: [items]}
//   {label, submenu: [items]}
//   {label, action: 'app.<name>', target: <GVariant text> | null,
//    enabled: bool, checked?: bool}

const BUS_PATH = '/org/gnome/Shell/Extensions/DuskShell/DesktopMenu';
const IFACE = 'org.gnome.Shell.Extensions.DuskShell.DesktopMenu';
const IFACE_XML = `<node>
  <interface name="${IFACE}">
    <method name="Show">
      <arg type="s" direction="in" name="menu"/>
      <arg type="b" direction="out" name="shown"/>
    </method>
  </interface>
</node>`;

// Fixed: items only ever activate ding's own actions, whoever calls Show()
const DING_BUS = 'com.desktop.ding';
const DING_PATH = '/com/desktop/ding';
// The Shell's desktop menu already holds what this ding item opens
const SKIP_ACTIONS = new Set(['app.displayShellBackgroundMenu']);

function activateDing(action, target) {
    const params = target ? [GLib.Variant.parse(null, target, null, null)] : [];
    Gio.DBus.session.call(
        DING_BUS, DING_PATH, 'org.gtk.Actions', 'Activate',
        new GLib.Variant('(sava{sv})', [action.slice(4), params, {}]),
        null, Gio.DBusCallFlags.NONE, -1, null,
        (conn, res) => {
            try {
                conn.call_finish(res);
            } catch (e) {
                console.error(`dusk-shell: desktop menu: ${action}: ${e.message}`);
            }
        });
}

export class DesktopMenu {
    constructor() {
        this._section = null;
        this._menu = null;
        this._menuClosedId = 0;
        this._clearId = 0;
        this._dbus = Gio.DBusExportedObject.wrapJSObject(IFACE_XML, this);
        this._dbus.export(Gio.DBus.session, BUS_PATH);
    }

    // D-Bus: show ding's menu, parsed from json, in the Shell's desktop menu
    // of the monitor under the pointer. Returns false (ding then shows its own)
    // when there is no such menu or the JSON is bad.
    Show(json) {
        try {
            const items = JSON.parse(json);
            const [x, y] = global.get_pointer();
            const rect = new Mtk.Rectangle({x, y, width: 1, height: 1});
            const monitor = global.display.get_monitor_index_for_rect(rect);
            const menu = Main.layoutManager._bgManagers[monitor]
                ?.backgroundActor?._backgroundMenu;
            if (!menu || !Array.isArray(items))
                return false;

            this._clear();
            menu.close(BoxPointer.PopupAnimation.NONE);
            // The ding items go above the Shell's own, a separator between
            const section = new PopupMenu.PopupMenuSection();
            this._fill(section, items);
            section.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
            menu.addMenuItem(section, 0);
            this._section = section;
            this._menu = menu;
            this._menuClosedId = menu.connect('open-state-changed', (_m, open) => {
                if (!open)
                    this._clearLater();
            });

            Main.layoutManager.setDummyCursorGeometry(x, y, 0, 0);
            menu.open(BoxPointer.PopupAnimation.FULL);
            return true;
        } catch (e) {
            console.error(`dusk-shell: desktop menu: ${e}`);
            this._clear();
            return false;
        }
    }

    // Sections become separator-delimited runs; empty sections are dropped
    _fill(menu, items) {
        let needSeparator = false;
        for (const item of items) {
            if (item.section) {
                if (!item.section.some(i => !SKIP_ACTIONS.has(i.action)))
                    continue;
                if (needSeparator || menu.numMenuItems > 0)
                    menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
                this._fill(menu, item.section);
                needSeparator = true;
                continue;
            }
            if (needSeparator) {
                menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
                needSeparator = false;
            }
            if (item.submenu) {
                const sub = new PopupMenu.PopupSubMenuMenuItem(item.label ?? '');
                this._fill(sub.menu, item.submenu);
                menu.addMenuItem(sub);
                continue;
            }
            if (typeof item.action !== 'string' || !item.action.startsWith('app.') ||
                SKIP_ACTIONS.has(item.action))
                continue;
            const entry = new PopupMenu.PopupMenuItem(item.label ?? '');
            entry.setSensitive(item.enabled !== false);
            if (item.checked !== undefined) {
                entry.setOrnament(item.checked
                    ? (item.target ? PopupMenu.Ornament.DOT : PopupMenu.Ornament.CHECK)
                    : PopupMenu.Ornament.NO_DOT);
            }
            entry.connect('activate', () => activateDing(item.action, item.target));
            menu.addMenuItem(entry);
        }
    }

    // After the close animation (BoxPointer's 150 ms), so the items do not
    // vanish while the menu fades
    _clearLater() {
        const section = this._section;
        if (this._clearId)
            GLib.source_remove(this._clearId);
        this._clearId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 300, () => {
            this._clearId = 0;
            if (this._section === section)
                this._clear();
            return GLib.SOURCE_REMOVE;
        });
    }

    _clear() {
        if (this._menu && this._menuClosedId)
            this._menu.disconnect(this._menuClosedId);
        this._menuClosedId = 0;
        this._menu = null;
        this._section?.destroy();
        this._section = null;
    }

    destroy() {
        if (this._clearId)
            GLib.source_remove(this._clearId);
        this._clearId = 0;
        this._dbus.unexport();
        this._dbus = null;
        this._clear();
    }
}
