// From the Launchpad extension (launchpad@phlthydelphya.github.io, same author):
// the Uninstall item of the app context menu.

import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Shell from 'gi://Shell';

import * as Dialog from 'resource:///org/gnome/shell/ui/dialog.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as ModalDialog from 'resource:///org/gnome/shell/ui/modalDialog.js';

const SOFTWARE_ID = 'org.gnome.Software.desktop';
const APPHUB_ID = 'io.github.phlthydelphya.DuskAppHub.desktop';
// pkexec's exit status when the password dialog is dismissed
const PKEXEC_DISMISSED = 126;

// Snaps that are part of Ubuntu's desktop rather than apps you added
const PROTECTED_SNAPS = new Set([
    'desktop-security-center',
    'firmware-updater',
    'prompting-client',
    'snap-store',
    'snapd',
    'snapd-desktop-integration',
]);

/**
 * How to remove an app, or null when it can't be done safely from here.
 *
 * Flatpaks and snaps are self-contained, so removing one can't take other
 * software with it. Distro packages can (dependencies, meta-packages), so
 * those go to AppHub, which opens the package that installed the launcher
 * (dpkg's owner, so apps with no AppStream data such as FreeOffice too) and
 * refuses removals that would take other packages along. GNOME Software is
 * the fallback without AppHub.
 *
 * @param {Shell.App} app - the app
 * @returns {object|null} - {label, run} for the menu item
 */
export function uninstallMethod(app) {
    const info = app.get_app_info();
    if (!info)
        return null;
    const filename = info.get_filename() ?? '';

    const flatpakId = info.get_string('X-Flatpak');
    const flatpak = GLib.find_program_in_path('flatpak');
    if (flatpakId && flatpak) {
        const userDir = GLib.build_filenamev([GLib.get_user_data_dir(), 'flatpak']);
        const user = filename.startsWith(`${userDir}/`);
        const password = user ? '' : ' You may be asked for your password.';
        return {
            label: 'Uninstall…',
            run: () => confirm(app,
                `It will be removed from this computer. Its settings and data in ~/.var/app/${flatpakId} are kept.${password}`,
                [flatpak, 'uninstall', user ? '--user' : '--system', '-y', flatpakId]),
        };
    }

    const snapName = info.get_string('X-SnapInstanceName');
    const snap = GLib.find_program_in_path('snap');
    const pkexec = GLib.find_program_in_path('pkexec');
    if (snapName) {
        if (PROTECTED_SNAPS.has(snapName) || !snap || !pkexec)
            return null;
        return {
            label: 'Uninstall…',
            run: () => confirm(app,
                'It will be removed from this computer. Snap keeps a snapshot of its data, listed by “snap saved”. You will be asked for your password.',
                [pkexec, snap, 'remove', snapName]),
        };
    }

    // Only apps the system installed; launchers in ~/.local are not packages
    const system = filename.startsWith('/usr/share/applications/') ||
        filename.startsWith('/usr/local/share/applications/');
    const appHub = Shell.AppSystem.get_default().lookup_app(APPHUB_ID);
    if (system && appHub && app !== appHub) {
        return {
            label: 'Uninstall in AppHub…',
            run: () => showInAppHub(appHub, filename),
        };
    }
    const software = Shell.AppSystem.get_default().lookup_app(SOFTWARE_ID);
    if (filename.startsWith('/usr/share/applications/') && software && app !== software) {
        return {
            label: 'Uninstall in Software…',
            run: () => showInSoftware(app),
        };
    }

    return null;
}

function confirm(app, description, argv) {
    const name = app.get_name();
    const dialog = new ModalDialog.ModalDialog();
    dialog.contentLayout.add_child(new Dialog.MessageDialogContent({
        title: `Uninstall “${name}”?`,
        description,
    }));
    // Enter cancels; uninstalling takes a deliberate click
    dialog.addButton({
        label: 'Cancel',
        action: () => dialog.close(),
        key: Clutter.KEY_Escape,
        default: true,
    });
    const button = dialog.addButton({
        label: 'Uninstall',
        action: () => {
            dialog.close();
            spawn(name, argv);
        },
    });
    button.add_style_class_name('dusk-destructive-button');
    dialog.open();
}

function spawn(name, argv) {
    let proc;
    try {
        proc = Gio.Subprocess.new(argv,
            Gio.SubprocessFlags.STDOUT_SILENCE | Gio.SubprocessFlags.STDERR_PIPE);
    } catch (e) {
        Main.notifyError(`Couldn’t uninstall ${name}`, e.message);
        return;
    }

    proc.communicate_utf8_async(null, null, (p, res) => {
        let stderr = '';
        try {
            [, , stderr] = p.communicate_utf8_finish(res);
        } catch (e) {
            stderr = e.message;
        }

        if (p.get_successful()) {
            Main.notify(`Uninstalled ${name}`);
            return;
        }
        if (argv[0].endsWith('/pkexec') && p.get_exit_status() === PKEXEC_DISMISSED)
            return;
        const lines = (stderr ?? '').trim().split('\n');
        Main.notifyError(`Couldn’t uninstall ${name}`, lines[lines.length - 1]);
    });
}

// AppHub opens a launcher's .desktop file as the page of the package that
// installed it, where Remove is
function showInAppHub(appHub, filename) {
    try {
        appHub.get_app_info().launch([Gio.File.new_for_path(filename)],
            global.create_app_launch_context(0, -1));
    } catch (e) {
        Main.notifyError('Couldn’t open AppHub', e.message);
    }
}

async function showInSoftware(app) {
    // Same call as the shell's own “App Details” item
    try {
        const bus = await Gio.DBus.get(Gio.BusType.SESSION, null);
        const args = GLib.Variant.new('(ss)', [app.get_id(), '']);
        bus.call(
            'org.gnome.Software',
            '/org/gnome/Software',
            'org.gtk.Actions', 'Activate',
            new GLib.Variant('(sava{sv})', ['details', [args], null]),
            null, 0, -1, null);
    } catch (e) {
        Main.notifyError('Couldn’t open Software', e.message);
    }
}
