import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as SwipeTracker from 'resource:///org/gnome/shell/ui/swipeTracker.js';
import {InjectionManager} from 'resource:///org/gnome/shell/extensions/extension.js';

// Names the shell passes to its SwipeTracker constructors. The lock screen
// and on-screen keyboard trackers are left alone.
const BLOCKED_NAMES = new Set([
    'Overview swipe tracker', // overview.js:226
    'WorkspaceAnimation swipe tracker', // workspaceAnimation.js:374
    'WorkspacesView swipe tracker', // workspacesView.js:867
    'AppDisplay swipe tracker', // appDisplay.js:615, also folder views
]);

function enabledSetter(tracker) {
    for (let proto = Object.getPrototypeOf(tracker); proto; proto = Object.getPrototypeOf(proto)) {
        const desc = Object.getOwnPropertyDescriptor(proto, 'enabled');
        if (desc?.set)
            return desc.set;
    }
    return null;
}

// The shell flips `enabled` on its trackers as views map and unmap, so a
// plain `enabled = false` would not stick. Each blocked tracker gets an own
// `enabled` accessor that reads false and remembers what the shell wanted.
export class GestureBlocker {
    constructor(settings) {
        this._settings = settings;
        // tracker → {wanted}
        this._blocked = new Map();
        this._injections = null;

        this._settingsId = this._settings.connect('changed::disable-gestures',
            () => this._sync());
        this._sync();
    }

    destroy() {
        this._settings.disconnect(this._settingsId);
        this._settingsId = 0;
        this._unblockAll();
        this._settings = null;
    }

    _sync() {
        if (!this._settings)
            return;
        if (this._settings.get_boolean('disable-gestures'))
            this._blockAll();
        else
            this._unblockAll();
    }

    // Shell 51 private fields: Overview._swipeTracker (overview.js:239),
    // WindowManager._workspaceAnimation (windowManager.js:934) and its
    // _swipeTracker (workspaceAnimation.js:385), ControlsManager
    // _workspacesDisplay / _appDisplay (overviewControls.js:397-401),
    // AppDisplay._folderIcons[].view (appDisplay.js:1358, 2301)
    _existingTrackers() {
        const controls = Main.overview._overview?.controls;
        const appDisplay = controls?._appDisplay;
        return [
            Main.overview._swipeTracker,
            Main.wm._workspaceAnimation?._swipeTracker,
            controls?._workspacesDisplay?._swipeTracker,
            appDisplay?._swipeTracker,
            ...(appDisplay?._folderIcons ?? []).map(icon => icon.view?._swipeTracker),
        ].filter(tracker => tracker);
    }

    _blockAll() {
        if (this._injections)
            return;

        for (const tracker of this._existingTrackers())
            this._block(tracker);

        // Folder views and rebuilt displays create trackers later
        const self = this;
        this._injections = new InjectionManager();
        this._injections.overrideMethod(SwipeTracker.SwipeTracker.prototype, '_init', original => function (actor, orientation, allowedModes, params, ...rest) {
            original.call(this, actor, orientation, allowedModes, params, ...rest);
            if (BLOCKED_NAMES.has(params?.name))
                self._block(this);
        });
    }

    _block(tracker) {
        if (this._blocked.has(tracker))
            return;
        const setter = enabledSetter(tracker);
        if (!setter)
            return;

        const record = {wanted: tracker.enabled};
        Object.defineProperty(tracker, 'enabled', {
            configurable: true,
            get: () => false,
            set: value => {
                record.wanted = value;
            },
        });
        // Goes through the real setter so the bound gestures turn off too
        setter.call(tracker, false);
        this._blocked.set(tracker, record);
    }

    _unblockAll() {
        this._injections?.clear();
        this._injections = null;

        for (const [tracker, record] of this._blocked) {
            try {
                delete tracker.enabled;
                tracker.enabled = record.wanted;
            } catch (e) {
                // Tracker of a view destroyed meanwhile (SwipeTracker is a
                // plain GObject without a destroy signal)
                console.debug(`dusk-shell: ${e.message}`);
            }
        }
        this._blocked.clear();
    }
}
