import Clutter from 'gi://Clutter';
import Cogl from 'gi://Cogl';
import GdkPixbuf from 'gi://GdkPixbuf';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Mtk from 'gi://Mtk';
import Pango from 'gi://Pango';
import Shell from 'gi://Shell';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {ensureActorVisibleInScrollView} from 'resource:///org/gnome/shell/misc/animationUtils.js';
import {gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

import Soup from 'gi://Soup?version=3.0';

import {Acrylic} from './acrylic.js';
import {CharTab} from './charTab.js';
import {GifTab} from './gifTab.js';
import {PickerStore} from './pickerStore.js';
import {OPEN_TIME, CLOSE_TIME, OPEN_MODE, CLOSE_MODE, timing} from './motion.js';

// The clipboard panel, like Windows 11's (Win+V and Win+.): a small acrylic
// card at the text cursor (or the pointer) with five tabs: Emoji, GIF,
// Kaomoji, Symbols (charTab.js, gifTab.js) and Clipboard. Super+V opens it on
// Clipboard, Super+. on Emoji. Typing searches the tab.
//
// Clipboard: the last copies (text and images), newest first. Picking one
// puts it back on the clipboard and pastes it into the focused app. Items can
// be pinned (kept across logouts) or deleted; Clear all keeps the pinned
// ones. Unpinned history lives in memory only, so it is gone at logout, as
// Windows clears it at restart. Copies that password managers mark as secret
// (x-kde-passwordManagerHint) are never recorded.
//
// Emoji, kaomoji and symbols are typed into the app through the input method
// (Wayland text-input), so the clipboard is left alone. Apps without it (X11)
// get a paste, and the clipboard then gets its earlier content back. GIFs
// are pasted as image/gif.

const MAX_ITEMS = 25; // as Windows
const MAX_TEXT = 100 * 1024; // characters kept per text item
const MAX_IMAGE = 8 * 1024 * 1024; // bytes kept per image
const PREVIEW_CHARS = 200; // about three lines in the card
const CARD_WIDTH = 400;
const CARD_HEIGHT = 540;
const SCREEN_GAP = 12;
const RISE = 8;
// Image previews keep their shape: scaled to fit this box, never stretched
const THUMB_WIDTH = 280;
const THUMB_HEIGHT = 160;
const SECRET_HINT = 'x-kde-passwordManagerHint';
const IMAGE_TYPE = 'image/png';
const GIF_TYPE = 'image/gif';
// How long a temporary paste holds the clipboard before it is given back
const RESTORE_MS = 1000;
// How long to wait for the app's text input after its window gets focus back
const IM_WAIT_MS = 400;
// A text cursor reported this recently counts as where the user is typing
const CARET_FRESH_US = 30 * 1000 * 1000;

const TABS = [
    {id: 'emoji', label: '☺', icon: 'face-smile-symbolic', name: () => _('Emoji')},
    {id: 'gif', label: 'GIF', name: () => _('GIF')},
    {id: 'kaomoji', label: ';-)', name: () => _('Kaomoji')},
    {id: 'symbols', label: 'Ω', name: () => _('Symbols')},
    {id: 'clipboard', icon: 'edit-paste-symbolic', name: () => _('Clipboard history')},
];
// Terminals paste with Ctrl+Shift+V
const TERMINALS = /terminal|ptyxis|kgx|console|kitty|alacritty|wezterm|foot|tilix|konsole|terminator|blackbox/i;

const STORE_DIR = GLib.build_filenamev([GLib.get_user_data_dir(), 'dusk', 'clipboard']);
const STORE_FILE = GLib.build_filenamev([STORE_DIR, 'pinned.json']);

const MODIFIERS = Clutter.ModifierType.CONTROL_MASK |
    Clutter.ModifierType.MOD1_MASK | Clutter.ModifierType.SUPER_MASK;

let nextId = 1;

Gio._promisify(Meta.Selection.prototype, 'transfer_async');

// The size an image is shown at: scaled down to fit the preview box, keeping
// its proportions, and never scaled up past its own size.
function fitThumb(width, height) {
    const k = Math.min(1, THUMB_WIDTH / width, THUMB_HEIGHT / height);
    return [Math.max(1, Math.round(width * k)), Math.max(1, Math.round(height * k))];
}

// An image item's preview. Decoded once, at the size it is shown (times the
// display scale), not as a square icon: a screenshot stays a wide rectangle.
function imagePreview(item) {
    const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
    if (!item.preview) {
        try {
            const loader = new GdkPixbuf.PixbufLoader();
            let shown = null;
            loader.connect('size-prepared', (l, width, height) => {
                shown = fitThumb(width, height);
                l.set_size(shown[0] * scale, shown[1] * scale);
            });
            loader.write_bytes(item.bytes);
            loader.close();
            const pixbuf = loader.get_pixbuf();
            if (pixbuf && shown)
                item.preview = {pixbuf, width: shown[0], height: shown[1]};
        } catch (e) {
            console.debug(`dusk-shell: clipboard preview not drawn: ${e}`);
        }
    }
    if (!item.preview) {
        return new St.Icon({
            icon_name: 'image-x-generic-symbolic',
            icon_size: 32,
            style_class: 'dusk-clip-image',
            x_align: Clutter.ActorAlign.START,
            x_expand: true,
        });
    }
    const {pixbuf, width, height} = item.preview;
    const image = St.ImageContent.new_with_preferred_size(pixbuf.width, pixbuf.height);
    const ctx = global.stage.context.get_backend().get_cogl_context();
    image.set_bytes(ctx, pixbuf.read_pixel_bytes(),
        pixbuf.has_alpha ? Cogl.PixelFormat.RGBA_8888 : Cogl.PixelFormat.RGB_888,
        pixbuf.width, pixbuf.height, pixbuf.rowstride);
    return new St.Widget({
        style_class: 'dusk-clip-image',
        content: image,
        content_gravity: Clutter.ContentGravity.RESIZE_ASPECT,
        width: width * scale,
        height: height * scale,
        x_align: Clutter.ActorAlign.START,
        y_align: Clutter.ActorAlign.CENTER,
        x_expand: true,
    });
}

function sameContent(a, b) {
    if (a.kind !== b.kind)
        return false;
    return a.kind === 'text' ? a.text === b.text : a.bytes.equal(b.bytes);
}

export class ClipboardHistory {
    constructor(settings) {
        this._settings = settings;
        this._items = []; // newest first
        this._isOpen = false;
        this._grab = null;
        this._ignoreNext = null; // content we just put on the clipboard
        this._changeId = 0;
        this._clipboard = St.Clipboard.get_default();
        this._selection = global.display.get_selection();
        this._store = new PickerStore(STORE_DIR);
        this._soup = new Soup.Session({timeout: 10});
        this._dir = GLib.path_get_dirname(GLib.filename_from_uri(import.meta.url)[0]);
        this._ownerChanges = 0;
        this._tab = 'clipboard';
        this._caret = null; // {rect, time, window}

        this._loadPinned();
        this._buildUi();
        this._acrylic = new Acrylic(this._card);
        global.focus_manager.add_group(this.actor);
        Main.layoutManager.addTopChrome(this.actor);

        this._ownerId = this._selection.connect('owner-changed', (_s, type) => {
            if (type !== Meta.SelectionType.SELECTION_CLIPBOARD)
                return;
            this._ownerChanges++;
            this._queueRead();
        });
        this._lockId = Main.sessionMode.connect('updated', () => {
            if (Main.sessionMode.isLocked)
                this.close(false);
        });
        Main.wm.addKeybinding('toggle-clipboard', settings, Meta.KeyBindingFlags.NONE,
            Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW, () => this.toggle('clipboard'));
        Main.wm.addKeybinding('toggle-emoji', settings, Meta.KeyBindingFlags.NONE,
            Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW, () => this.toggle('emoji'));
        // Where the app's text cursor is (Wayland text-input clients)
        Main.inputMethod.connectObject('cursor-location-changed', (_im, rect) => {
            this._caret = {rect, time: GLib.get_monotonic_time(), window: global.display.get_focus_window()};
        }, this);
    }

    destroy() {
        Main.wm.removeKeybinding('toggle-clipboard');
        Main.wm.removeKeybinding('toggle-emoji');
        Main.inputMethod.disconnectObject(this);
        this.close(false);
        for (const timeout of [this._restoreId, this._waitId]) {
            if (timeout)
                GLib.source_remove(timeout);
        }
        for (const tab of Object.values(this._pickers))
            tab.destroy();
        this._store.save();
        this._soup.abort();
        if (this._changeId)
            GLib.source_remove(this._changeId);
        this._selection.disconnect(this._ownerId);
        Main.sessionMode.disconnect(this._lockId);
        this._acrylic.destroy();
        global.focus_manager.remove_group(this.actor);
        Main.layoutManager.removeChrome(this.actor);
        this.actor.destroy();
        this._vkbd?.run_dispose();
        this._vkbd = null;
    }

    // ------------------------------------------------------------ recording

    _queueRead() {
        if (this._changeId)
            GLib.source_remove(this._changeId);
        // Apps often set the clipboard several times in a row
        this._changeId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 60, () => {
            this._changeId = 0;
            this._read();
            return GLib.SOURCE_REMOVE;
        });
    }

    _read() {
        const mimes = this._selection.get_mimetypes(Meta.SelectionType.SELECTION_CLIPBOARD) ?? [];
        if (!mimes.length || mimes.includes(SECRET_HINT))
            return;
        const hasText = mimes.some(m => m.startsWith('text/plain') || m === 'UTF8_STRING' ||
            m === 'STRING' || m === 'TEXT');
        if (mimes.includes(IMAGE_TYPE) && !hasText) {
            this._readImage();
            return;
        }
        if (!hasText)
            return;
        this._clipboard.get_text(St.ClipboardType.CLIPBOARD, (_c, text) => {
            if (text && text.trim())
                this._add({kind: 'text', text: text.slice(0, MAX_TEXT)});
        });
    }

    // Straight from the selection into memory: St.Clipboard.get_content's
    // callback hands JavaScript bytes that are already freed (crashed the Shell)
    async _readImage() {
        try {
            const stream = Gio.MemoryOutputStream.new_resizable();
            await this._selection.transfer_async(Meta.SelectionType.SELECTION_CLIPBOARD,
                IMAGE_TYPE, -1, stream, null);
            stream.close(null);
            const bytes = stream.steal_as_bytes();
            if (bytes.get_size() > 0 && bytes.get_size() <= MAX_IMAGE)
                this._add({kind: 'image', bytes});
        } catch (e) {
            console.debug(`dusk-shell: clipboard image not read: ${e}`);
        }
    }

    _add(entry) {
        // Our own paste: the item is already in the list (moved to the top)
        if (this._ignoreNext && sameContent(this._ignoreNext, entry)) {
            this._ignoreNext = null;
            return;
        }
        this._ignoreNext = null;
        const existing = this._items.find(item => sameContent(item, entry));
        if (existing) {
            this._items = [existing, ...this._items.filter(item => item !== existing)];
        } else {
            this._items.unshift({id: nextId++, pinned: false, time: Date.now(), ...entry});
            // Pinned items do not count against the limit
            const unpinned = this._items.filter(item => !item.pinned);
            if (unpinned.length > MAX_ITEMS) {
                const drop = new Set(unpinned.slice(MAX_ITEMS));
                this._items = this._items.filter(item => !drop.has(item));
            }
        }
        if (this._isOpen)
            this._render();
    }

    // ------------------------------------------------------------ pinned store

    _loadPinned() {
        try {
            const [ok, data] = GLib.file_get_contents(STORE_FILE);
            if (!ok)
                return;
            const stored = JSON.parse(new TextDecoder().decode(data));
            for (const s of stored) {
                if (s.kind === 'text' && typeof s.text === 'string') {
                    this._items.push({id: nextId++, kind: 'text', text: s.text, pinned: true, time: s.time ?? 0});
                } else if (s.kind === 'image' && s.file) {
                    const [okImg, img] = GLib.file_get_contents(GLib.build_filenamev([STORE_DIR, s.file]));
                    if (okImg)
                        this._items.push({id: nextId++, kind: 'image', bytes: new GLib.Bytes(img), pinned: true, time: s.time ?? 0});
                }
            }
        } catch {
            // No store yet, or unreadable: start empty
        }
    }

    _savePinned() {
        try {
            GLib.mkdir_with_parents(STORE_DIR, 0o700);
            const stored = [];
            const keep = new Set();
            for (const item of this._items.filter(i => i.pinned)) {
                if (item.kind === 'text') {
                    stored.push({kind: 'text', text: item.text, time: item.time});
                } else {
                    const file = `image-${GLib.compute_checksum_for_bytes(GLib.ChecksumType.SHA256, item.bytes)}.png`;
                    keep.add(file);
                    const path = GLib.build_filenamev([STORE_DIR, file]);
                    if (!GLib.file_test(path, GLib.FileTest.EXISTS))
                        GLib.file_set_contents(path, item.bytes.get_data());
                    stored.push({kind: 'image', file, time: item.time});
                }
            }
            GLib.file_set_contents(STORE_FILE, JSON.stringify(stored));
            // Images no longer pinned
            const dir = Gio.File.new_for_path(STORE_DIR);
            const files = dir.enumerate_children('standard::name', Gio.FileQueryInfoFlags.NONE, null);
            let info;
            while ((info = files.next_file(null))) {
                const name = info.get_name();
                if (name.startsWith('image-') && !keep.has(name))
                    dir.get_child(name).delete(null);
            }
        } catch (e) {
            console.warn(`dusk-shell: clipboard pins not saved: ${e}`);
        }
    }

    // ------------------------------------------------------------ UI

    _buildUi() {
        this.actor = new St.Widget({name: 'duskClipboardBackdrop', reactive: true, visible: false});
        this._card = new St.BoxLayout({
            style_class: 'dusk-clip-card',
            orientation: Clutter.Orientation.VERTICAL,
            reactive: true,
        });
        this.actor.add_child(this._card);

        // Tabs
        const tabs = new St.BoxLayout({style_class: 'dusk-clip-tabs', x_expand: true});
        this._tabButtons = new Map();
        for (const tab of TABS) {
            const button = new St.Button({
                style_class: 'dusk-clip-tab',
                can_focus: true,
                accessible_name: tab.name(),
                x_expand: true,
            });
            if (tab.icon)
                button.child = new St.Icon({icon_name: tab.icon, icon_size: 16});
            else
                button.label = tab.label;
            button.connect('clicked', () => this._showTab(tab.id));
            tabs.add_child(button);
            this._tabButtons.set(tab.id, button);
        }
        this._card.add_child(tabs);

        // Search, for every tab but Clipboard
        this._entry = new St.Entry({
            style_class: 'dusk-clip-search',
            can_focus: true,
            x_expand: true,
            primary_icon: new St.Icon({icon_name: 'edit-find-symbolic', style_class: 'dusk-clip-search-icon'}),
        });
        this._entry.clutter_text.connect('text-changed', () =>
            this._current()?.setQuery(this._entry.text));
        this._entry.clutter_text.connect('activate', () => this._current()?.focusFirst());
        this._card.add_child(this._entry);

        // Pickers
        const onText = text => this._insertText(text);
        this._pickers = {
            emoji: new CharTab({kind: 'emoji', dir: this._dir, store: this._store, onPick: onText}),
            gif: new GifTab({settings: this._settings, soup: this._soup, store: this._store,
                onPick: gif => this._insertGif(gif)}),
            kaomoji: new CharTab({kind: 'kaomoji', dir: this._dir, store: this._store, onPick: onText}),
            symbols: new CharTab({kind: 'symbols', dir: this._dir, store: this._store, onPick: onText}),
        };
        for (const tab of Object.values(this._pickers)) {
            tab.actor.hide();
            tab.connectQueryCleared?.(() => this._setEntry(''));
            this._card.add_child(tab.actor);
        }

        // Clipboard history
        this._clipPane = new St.BoxLayout({
            orientation: Clutter.Orientation.VERTICAL,
            x_expand: true,
            y_expand: true,
        });
        const header = new St.BoxLayout({style_class: 'dusk-clip-header'});
        header.add_child(new St.Label({
            style_class: 'dusk-clip-title',
            text: _('Clipboard history'),
            x_expand: true,
            y_align: Clutter.ActorAlign.CENTER,
        }));
        this._clearButton = new St.Button({
            style_class: 'dusk-clip-clear',
            label: _('Clear all'),
            can_focus: true,
        });
        this._clearButton.connect('clicked', () => this._clearAll());
        header.add_child(this._clearButton);
        this._clipPane.add_child(header);

        this._list = new St.BoxLayout({
            style_class: 'dusk-clip-list',
            orientation: Clutter.Orientation.VERTICAL,
            x_expand: true,
        });
        this._scroll = new St.ScrollView({
            style_class: 'dusk-clip-scroll vfade',
            x_expand: true,
            y_expand: true,
            overlay_scrollbars: true,
            hscrollbar_policy: St.PolicyType.NEVER,
            vscrollbar_policy: St.PolicyType.EXTERNAL,
            child: this._list,
        });
        this._clipPane.add_child(this._scroll);

        this._empty = new St.Label({
            style_class: 'dusk-clip-empty',
            text: _('You’ll see your clipboard history here once you’ve copied something.'),
            x_align: Clutter.ActorAlign.CENTER,
            y_align: Clutter.ActorAlign.CENTER,
            y_expand: true,
        });
        this._empty.clutter_text.line_wrap = true;
        this._clipPane.add_child(this._empty);
        this._card.add_child(this._clipPane);

        const click = new Clutter.ClickGesture();
        click.connect('may-recognize', () =>
            global.stage.get_event_actor(click.get_point_event(0)) === this.actor);
        click.connect('recognize', () => this.close());
        this.actor.add_action(click);

        const keys = new Clutter.KeyController();
        keys.connect('key-press', () => this._onKeyPress(keys));
        this.actor.add_action_full('dusk-clip-keys', Clutter.EventPhase.CAPTURE, keys);
    }

    // The picker shown, or null on Clipboard
    _current() {
        return this._pickers[this._tab] ?? null;
    }

    _setEntry(text) {
        if (this._entry.text !== text)
            this._entry.text = text;
    }

    _showTab(id, focus = true) {
        const previous = this._current();
        this._tab = id;
        const current = this._current();
        if (previous && previous !== current)
            previous.hide();
        for (const [tab, button] of this._tabButtons) {
            if (tab === id)
                button.add_style_pseudo_class('checked');
            else
                button.remove_style_pseudo_class('checked');
        }
        for (const [tab, picker] of Object.entries(this._pickers))
            picker.actor.visible = tab === id;
        this._clipPane.visible = !current;
        this._entry.visible = !!current;
        if (current) {
            this._entry.hint_text = current.searchHint;
            current.show(this._entry.text);
            if (focus)
                this._entry.grab_key_focus();
        } else {
            this._render();
            if (focus)
                (this._rows()[0] ?? this._tabButtons.get(id)).grab_key_focus();
        }
    }

    toggle(tab = 'clipboard') {
        if (this._isOpen && this._tab === tab)
            this.close();
        else if (this._isOpen)
            this._showTab(tab);
        else
            this.open(tab);
    }

    open(tab = 'clipboard') {
        if (this._isOpen || Main.sessionMode.isLocked)
            return;
        Main.overview.hide();
        this._target = global.display.get_focus_window();
        this._layout();
        this._grab = Main.pushModal(this.actor, {actionMode: Shell.ActionMode.POPUP});
        this._isOpen = true;
        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        this._card.remove_all_transitions();
        this._card.opacity = 0;
        this._card.translation_y = RISE * scale;
        this._acrylic.start();
        this.actor.show();
        this._setEntry('');
        this._showTab(tab);
        this._card.ease({
            opacity: 255,
            translation_y: 0,
            duration: timing(OPEN_TIME),
            mode: OPEN_MODE,
        });
    }

    close(animate = true, after = null) {
        if (!this._isOpen)
            return;
        this._isOpen = false;
        this._current()?.hide();
        if (this._grab) {
            Main.popModal(this._grab);
            this._grab = null;
        }
        const done = () => {
            if (this._isOpen)
                return;
            this.actor.hide();
            this._acrylic.stop();
            this._card.translation_y = 0;
            this._list.destroy_all_children();
        };
        if (!animate) {
            this._card.remove_all_transitions();
            done();
            after?.();
            return;
        }
        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        this._card.ease({
            opacity: 0,
            translation_y: RISE * scale,
            duration: timing(CLOSE_TIME),
            mode: CLOSE_MODE,
            onStopped: done,
        });
        after?.();
    }

    // Under the text cursor when the focused app reported one (Windows opens
    // it there), else near the pointer; kept on screen
    _layout() {
        this.actor.set_position(0, 0);
        this.actor.set_size(global.stage.width, global.stage.height);
        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        const gap = SCREEN_GAP * scale;
        let px, py, below;
        const caret = this._caret;
        if (caret && Main.inputMethod.currentFocus && caret.window === this._target &&
            GLib.get_monotonic_time() - caret.time < CARET_FRESH_US) {
            px = caret.rect.get_x();
            py = caret.rect.get_y() + caret.rect.get_height();
            below = caret.rect.get_height();
        } else {
            [px, py] = global.get_pointer();
            below = 0;
        }
        const index = global.display.get_monitor_index_for_rect(
            new Mtk.Rectangle({x: Math.round(px), y: Math.round(py), width: 1, height: 1}));
        const area = Main.layoutManager.getWorkAreaForMonitor(index >= 0 ? index : global.display.get_current_monitor());
        const width = Math.min(CARD_WIDTH * scale, area.width - 2 * gap);
        const height = Math.min(CARD_HEIGHT * scale, area.height - 2 * gap);
        const x = Math.max(area.x + gap, Math.min(px - width / 2, area.x + area.width - width - gap));
        // Above the caret line when there is no room below it
        let y = py + gap;
        if (y + height > area.y + area.height - gap && below)
            y = py - below - gap - height;
        y = Math.max(area.y + gap, Math.min(y, area.y + area.height - height - gap));
        this._card.set_position(Math.round(x), Math.round(y));
        this._card.set_size(Math.round(width), Math.round(height));
    }

    _render() {
        this._list.destroy_all_children();
        // Pinned first (in their order), then the history
        const items = [...this._items.filter(i => i.pinned), ...this._items.filter(i => !i.pinned)];
        for (const item of items)
            this._list.add_child(this._row(item));
        const any = items.length > 0;
        this._scroll.visible = any;
        this._empty.visible = !any;
        this._clearButton.reactive = this._items.some(i => !i.pinned);
    }

    _row(item) {
        const box = new St.BoxLayout({style_class: 'dusk-clip-item-box', x_expand: true});
        let content;
        if (item.kind === 'text') {
            content = new St.Label({
                style_class: 'dusk-clip-text',
                text: (() => {
                    // At most three lines, then a character limit
                    const lines = item.text.trim().split('\n');
                    let s = lines.slice(0, 3).join('\n');
                    if (s.length > PREVIEW_CHARS)
                        s = s.slice(0, PREVIEW_CHARS);
                    return s.length < item.text.trim().length ? `${s}…` : s;
                })(),
                x_expand: true,
                y_align: Clutter.ActorAlign.CENTER,
            });
            const ct = content.clutter_text;
            ct.line_wrap = true;
            ct.line_wrap_mode = Pango.WrapMode.WORD_CHAR;
            ct.ellipsize = Pango.EllipsizeMode.END;
        } else {
            content = imagePreview(item);
        }
        box.add_child(content);

        const actions = new St.BoxLayout({
            style_class: 'dusk-clip-actions',
            orientation: Clutter.Orientation.VERTICAL,
            y_align: Clutter.ActorAlign.START,
        });
        const pin = new St.Button({
            style_class: `dusk-clip-action${item.pinned ? ' pinned' : ''}`,
            can_focus: true,
            accessible_name: item.pinned ? _('Unpin') : _('Pin'),
            child: new St.Icon({icon_name: 'view-pin-symbolic', icon_size: 16}),
        });
        pin.connect('clicked', () => this._togglePin(item));
        const del = new St.Button({
            style_class: 'dusk-clip-action',
            can_focus: true,
            accessible_name: _('Delete'),
            child: new St.Icon({icon_name: 'edit-delete-symbolic', icon_size: 16}),
        });
        del.connect('clicked', () => this._delete(item));
        actions.add_child(pin);
        actions.add_child(del);
        box.add_child(actions);

        const row = new St.Button({
            style_class: `dusk-clip-item${item.pinned ? ' pinned' : ''}`,
            can_focus: true,
            x_expand: true,
            accessible_name: item.kind === 'text' ? item.text.slice(0, 80) : _('Image'),
            child: box,
        });
        row._duskItem = item;
        row.connect('clicked', () => this._paste(item));
        row.connect('key-focus-in', () => ensureActorVisibleInScrollView(this._scroll, row));
        return row;
    }

    _rows() {
        return this._list.get_children().filter(c => c._duskItem);
    }

    _togglePin(item) {
        item.pinned = !item.pinned;
        this._savePinned();
        this._render();
    }

    _delete(item) {
        this._items = this._items.filter(i => i !== item);
        if (item.pinned)
            this._savePinned();
        this._render();
        (this._rows()[0] ?? this._card).grab_key_focus();
    }

    _clearAll() {
        this._items = this._items.filter(i => i.pinned);
        this._render();
    }

    // Back on the clipboard, then pasted into the window that had focus
    _paste(item) {
        this._ignoreNext = item;
        this._items = [item, ...this._items.filter(i => i !== item)];
        this._setClipboard(item);
        const target = this._target;
        this.close(true, () => this._whenFocused(target, () => this._sendPaste(target)));
    }

    _setClipboard(item) {
        if (item.kind === 'text')
            this._clipboard.set_text(St.ClipboardType.CLIPBOARD, item.text);
        else
            this._clipboard.set_content(St.ClipboardType.CLIPBOARD, item.mime ?? IMAGE_TYPE, item.bytes);
    }

    // Typed into the app through the input method when it has text input;
    // otherwise pasted, and the clipboard given back afterwards
    _insertText(text) {
        const target = this._target;
        this.close(true, () => this._whenFocused(target, () => {
            if (Main.inputMethod.currentFocus)
                Main.inputMethod.commit(text);
            else
                this._pasteTemporarily({kind: 'text', text}, target);
        }, true));
    }

    async _insertGif(gif) {
        const target = this._target;
        let bytes;
        try {
            bytes = await this._pickers.gif.fetchFull(gif);
        } catch (e) {
            console.warn(`dusk-shell: GIF not fetched: ${e}`);
            Main.notifyError(_('Couldn’t insert the GIF'), e.message);
            return;
        }
        if (!this._isOpen)
            return;
        this.close(true, () => this._whenFocused(target, () =>
            this._pasteTemporarily({kind: 'image', mime: GIF_TYPE, bytes}, target)));
    }

    // Puts an item on the clipboard just for one paste, without recording it,
    // then restores what the clipboard held before (the newest history item),
    // unless something else was copied meanwhile
    _pasteTemporarily(item, target) {
        const previous = this._items[0] ?? null;
        this._ignoreNext = item;
        this._setClipboard(item);
        const owner = this._ownerChanges;
        this._sendPaste(target);
        if (this._restoreId)
            GLib.source_remove(this._restoreId);
        this._restoreId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, RESTORE_MS, () => {
            this._restoreId = 0;
            if (previous && this._ownerChanges === owner) {
                this._ignoreNext = previous;
                this._setClipboard(previous);
            }
            return GLib.SOURCE_REMOVE;
        });
    }

    // Runs `callback` once the grab is gone and the target window has its
    // focus back; with `needIm`, also waits a little for the app to turn its
    // text input back on (Wayland apps only: X11 ones never have it)
    _whenFocused(target, callback, needIm = false) {
        if (!target)
            return;
        if (this._waitId)
            GLib.source_remove(this._waitId);
        const wayland = target.get_client_type() === Meta.WindowClientType.WAYLAND;
        const start = GLib.get_monotonic_time();
        let activated = false;
        this._waitId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 40, () => {
            if (global.display.get_focus_window() !== target) {
                if (!activated)
                    target.activate(global.get_current_time());
                activated = true;
            }
            const waited = (GLib.get_monotonic_time() - start) / 1000;
            const focused = global.display.get_focus_window() === target;
            const ready = !needIm || !wayland || Main.inputMethod.currentFocus;
            if ((focused && ready && waited >= 80) || waited >= IM_WAIT_MS + 120) {
                this._waitId = 0;
                callback();
                return GLib.SOURCE_REMOVE;
            }
            return GLib.SOURCE_CONTINUE;
        });
    }

    _sendPaste(target) {
        const seat = global.stage.context.get_backend().get_default_seat();
        this._vkbd ??= seat.create_virtual_device(Clutter.InputDeviceType.KEYBOARD_DEVICE);
        const shift = TERMINALS.test(target.get_wm_class() ?? '');
        let t = GLib.get_monotonic_time();
        const key = (keyval, state) => this._vkbd.notify_keyval(t++, keyval, state);
        key(Clutter.KEY_Control_L, Clutter.KeyState.PRESSED);
        if (shift)
            key(Clutter.KEY_Shift_L, Clutter.KeyState.PRESSED);
        key(Clutter.KEY_v, Clutter.KeyState.PRESSED);
        key(Clutter.KEY_v, Clutter.KeyState.RELEASED);
        if (shift)
            key(Clutter.KEY_Shift_L, Clutter.KeyState.RELEASED);
        key(Clutter.KEY_Control_L, Clutter.KeyState.RELEASED);
    }

    _cycleTab(step) {
        const ids = TABS.map(t => t.id);
        const i = (ids.indexOf(this._tab) + step + ids.length) % ids.length;
        this._showTab(ids[i]);
    }

    _onKeyPress(keys) {
        const [, symbol] = keys.get_key();
        const [, state] = keys.get_state();
        const focus = global.stage.get_key_focus();
        const picker = this._current();
        const inEntry = focus === this._entry.clutter_text || focus === this._entry;

        switch (symbol) {
        case Clutter.KEY_Escape:
            if (inEntry && this._entry.text) {
                this._setEntry('');
                return Clutter.EVENT_STOP;
            }
            this.close();
            return Clutter.EVENT_STOP;
        case Clutter.KEY_v:
        case Clutter.KEY_V:
        case Clutter.KEY_period:
        case Clutter.KEY_semicolon:
            if (state & Clutter.ModifierType.SUPER_MASK) {
                this.toggle(symbol === Clutter.KEY_v || symbol === Clutter.KEY_V ? 'clipboard' : 'emoji');
                return Clutter.EVENT_STOP;
            }
            break;
        case Clutter.KEY_Tab:
        case Clutter.KEY_ISO_Left_Tab:
            if (state & Clutter.ModifierType.CONTROL_MASK) {
                this._cycleTab(state & Clutter.ModifierType.SHIFT_MASK ? -1 : 1);
                return Clutter.EVENT_STOP;
            }
            break;
        case Clutter.KEY_Page_Up:
        case Clutter.KEY_Page_Down:
            if (state & Clutter.ModifierType.CONTROL_MASK) {
                this._cycleTab(symbol === Clutter.KEY_Page_Down ? 1 : -1);
                return Clutter.EVENT_STOP;
            }
            break;
        }

        if (picker)
            return this._pickerKey(picker, symbol, state, focus, inEntry);
        return this._clipboardKey(symbol, state, focus);
    }

    _pickerKey(picker, symbol, state, focus, inEntry) {
        const dirs = {
            [Clutter.KEY_Up]: St.DirectionType.UP,
            [Clutter.KEY_Down]: St.DirectionType.DOWN,
            [Clutter.KEY_Left]: St.DirectionType.LEFT,
            [Clutter.KEY_Right]: St.DirectionType.RIGHT,
        };
        if (inEntry) {
            if (symbol === Clutter.KEY_Down) {
                picker.focusFirst();
                return Clutter.EVENT_STOP;
            }
            return Clutter.EVENT_PROPAGATE;
        }
        if (symbol in dirs && picker.contains(focus)) {
            if (!picker.navigate(focus, dirs[symbol]) && symbol === Clutter.KEY_Up)
                this._entry.grab_key_focus();
            return Clutter.EVENT_STOP;
        }
        // Typing goes to the search field
        const ch = Clutter.keysym_to_unicode(symbol);
        if (ch >= 0x20 && ch !== 0x7f && !(state & MODIFIERS) &&
            symbol !== Clutter.KEY_space) {
            this._entry.grab_key_focus();
            this._entry.clutter_text.insert_unichar(ch);
            return Clutter.EVENT_STOP;
        }
        if (symbol === Clutter.KEY_BackSpace) {
            this._entry.grab_key_focus();
            this._setEntry(this._entry.text.slice(0, -1));
            return Clutter.EVENT_STOP;
        }
        return Clutter.EVENT_PROPAGATE;
    }

    _clipboardKey(symbol, state, focus) {
        const rows = this._rows();
        const row = rows.find(r => r === focus || r.contains(focus));
        switch (symbol) {
        case Clutter.KEY_Up:
        case Clutter.KEY_Down: {
            if (!rows.length)
                return Clutter.EVENT_STOP;
            let i = rows.indexOf(row);
            i = symbol === Clutter.KEY_Down ? Math.min(i + 1, rows.length - 1) : Math.max(i - 1, 0);
            rows[i].grab_key_focus();
            return Clutter.EVENT_STOP;
        }
        case Clutter.KEY_Delete:
            if (row) {
                this._delete(row._duskItem);
                return Clutter.EVENT_STOP;
            }
            break;
        case Clutter.KEY_Return:
        case Clutter.KEY_KP_Enter:
            if (row && focus === row && !(state & MODIFIERS)) {
                this._paste(row._duskItem);
                return Clutter.EVENT_STOP;
            }
            break;
        }
        return Clutter.EVENT_PROPAGATE;
    }
}
