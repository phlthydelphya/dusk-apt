import Clutter from 'gi://Clutter';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as MessageTray from 'resource:///org/gnome/shell/ui/messageTray.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {InjectionManager, gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

const DOCK_UUIDS = ['dash-to-dock@micxgx.gmail.com', 'ubuntu-dock@ubuntu.com'];

function appId(source) {
    const app = source.app ?? source._app;
    return app?.get_id?.() ?? app?.id ?? app?._appId ?? null;
}

function dismissSources(sources) {
    // Dismissing the last notification can destroy its source synchronously.
    for (const source of [...sources]) {
        for (const notification of [...source.notifications])
            notification.destroy(MessageTray.NotificationDestroyedReason.DISMISSED);
    }
}

export class NotificationActions {
    constructor() {
        this._destroyed = false;
        this._injections = new InjectionManager();
        this._groups = new Map();
        this._menuItems = new Set();
        this._dockMonitors = new Set();
        // Dismiss also clears the app's own launcher count (the Unity
        // LauncherEntry count the dock adds to its badge, which the app keeps
        // up itself): app id -> that count when dismissed. The badge shows
        // only what the app counts above it; it is forgotten at zero.
        this._clearedRemote = new Map();
        this._dockManager = null;
        this._view =Main.panel.statusArea.dateMenu?._messageList?._messageView;
        this._trayId = Main.messageTray.connect('source-added', (_tray, source) =>
            this._addGroup(source));
        for (const source of Main.messageTray.getSources())
            this._addGroup(source);
        this._installDockMenus();
    }

    _addGroup(source) {
        const group = this._view?._notificationSourceToGroup?.get(source);
        if (!group?._headerBox || this._groups.has(group))
            return;
        const button = new St.Button({
            style_class: 'message-close-button',
            icon_name: 'window-close-symbolic',
            can_focus: true,
            y_align: Clutter.ActorAlign.CENTER,
            accessible_name: _('Dismiss notifications from this application'),
        });
        button.connect('clicked', () => {
            const id = appId(source);
            this._dismiss(id, id ? Main.messageTray.getSources().filter(s => appId(s) === id) : [source]);
        });
        group._headerBox.insert_child_below(button, group._unexpandButton);
        const destroyId = group.connect('destroy', () => this._groups.delete(group));
        this._groups.set(group, {button, destroyId});
    }

    _dismiss(id, sources) {
        dismissSources(sources);
        if (this._clearRemote(id))
            this._refreshDock();
    }

    // Marks the app's current launcher count as seen; true when it had one
    _clearRemote(id) {
        const entry = id && this._dockManager?.remoteModel?.lookupById(id);
        const remote = entry?.['count-visible'] ? entry.count ?? 0 : 0;
        if (remote > 0)
            this._clearedRemote.set(id, remote);
        return remote > 0;
    }

    // App ids the dock holds a launcher entry for (LauncherEntryRemoteModel
    // keeps one per app id that sent an Update or was looked up)
    _remoteIds() {
        return [...this._dockManager?.remoteModel?._entrySourceStacks?.keys() ?? []];
    }

    // Whether any app shows a notification count or has notifications
    hasActiveNotifications() {
        return Main.messageTray.getSources().some(s => s.notifications.length) ||
            this._remoteIds().some(id => this._hasActiveCount(id));
    }

    // Dismisses every notification and marks every app's launcher count as
    // seen, so all dock badges clear until new ones come in
    dismissAll() {
        dismissSources(Main.messageTray.getSources());
        for (const id of this._remoteIds())
            this._clearRemote(id);
        this._refreshDock();
    }

    // The part of an app's launcher count still to show after a dismiss
    _remoteShown(id, remote) {
        if (!this._clearedRemote.has(id))
            return remote;
        const base = Math.min(this._clearedRemote.get(id), remote);
        if (base === 0)
            this._clearedRemote.delete(id);
        else
            this._clearedRemote.set(id, base);
        return remote - base;
    }

    // Whether the app has anything to dismiss: notifications in the tray or
    // a dock badge count, which can come from the app's launcher count alone
    _hasActiveCount(id) {
        if (Main.messageTray.getSources().some(s => appId(s) === id && s.notifications.length))
            return true;
        const dock = this._dockManager;
        const entry = dock?.remoteModel?.lookupById(id);
        let remote = entry?.['count-visible'] ? entry.count ?? 0 : 0;
        // A count gone without a signal reaching the badge: forget the dismiss
        if (remote === 0)
            this._clearedRemote.delete(id);
        else if (this._clearedRemote.has(id))
            remote -= Math.min(this._clearedRemote.get(id), remote);
        if (remote > 0)
            return true;
        return (dock?.notificationsMonitor?.getAppNotificationsCount(id) ?? 0) > 0;
    }

    _refreshDock() {
        for (const monitor of this._dockMonitors)
            monitor.emit('changed');
    }

    async _installDockBadges(base) {
        const {DockManager} = await import(`${base}/docking.js`);
        const {UnityIndicator} = await import(`${base}/appIconIndicators.js`);
        if (this._destroyed)
            return;
        const self = this;
        this._dockManager = DockManager.getDefault();
        // As the dock's own (appIconIndicators.js), with the launcher count
        // cut down to what came after a dismiss
        this._injections.overrideMethod(UnityIndicator.prototype, '_updateNotificationsCount',
            original => function (...args) {
                const id = this._source?.app?.id;
                const entry = this._remoteEntry;
                if (!id || !entry || !self._clearedRemote.has(id))
                    return original.apply(this, args);
                const remote = self._remoteShown(id, entry['count-visible'] ? entry.count ?? 0 : 0);
                if (remote > 0 && DockManager.settings.applicationCounterOverridesNotifications) {
                    this.setNotificationCount(remote);
                    return undefined;
                }
                const monitor = DockManager.getDefault().notificationsMonitor;
                this.setNotificationCount(remote + monitor.getAppNotificationsCount(id));
                return undefined;
            });
        const monitor = DockManager.getDefault()?.notificationsMonitor;
        if (monitor)
            this._dockMonitors.add(monitor);
    }

    async _installDockMenus() {
        for (const uuid of DOCK_UUIDS) {
            const extension = Main.extensionManager.lookup(uuid);
            if (!extension?.dir)
                continue;
            try {
                await this._installDockBadges(extension.dir.get_uri());
            } catch (e) {
                console.warn(`Dusk Shell: could not follow dismissed counts in ${uuid} badges: ${e.message}`);
            }
            if (this._destroyed)
                return;
            try {
                const {DockAbstractAppIcon} = await import(`${extension.dir.get_uri()}/appIcons.js`);
                if (this._destroyed)
                    return;
                const self = this;
                this._injections.overrideMethod(DockAbstractAppIcon.prototype, 'popupMenu', original => function (...args) {
                    const result = original.apply(this, args);
                    const id = this.app?.get_id?.() ?? this.app?.id;
                    if (!id || !this._menu || !self._hasActiveCount(id))
                        return result;
                    const item = new PopupMenu.PopupMenuItem(_('Dismiss notifications'));
                    item.connect('activate', () => self._dismiss(id,
                        Main.messageTray.getSources().filter(s => appId(s) === id)));
                    self._menuItems.add(item);
                    item.connect('destroy', () => self._menuItems.delete(item));
                    this._menu.addMenuItem(item);
                    return result;
                });
            } catch (e) {
                console.warn(`Dusk Shell: could not add notification actions to ${uuid}: ${e.message}`);
            }
        }
    }

    destroy() {
        this._destroyed = true;
        this._injections.clear();
        this._refreshDock();
        this._dockMonitors.clear();
        for (const item of this._menuItems)
            item.destroy();
        this._menuItems.clear();
        Main.messageTray.disconnect(this._trayId);
        for (const [group, {button, destroyId}] of this._groups) {
            group.disconnect(destroyId);
            button.destroy();
        }
        this._groups.clear();
    }
}
