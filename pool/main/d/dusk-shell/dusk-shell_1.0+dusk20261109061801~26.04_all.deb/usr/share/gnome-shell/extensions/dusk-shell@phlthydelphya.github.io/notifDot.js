import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import {gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

import {arrangerOwnsPanel} from './panelLayout.js';

const ROLE = 'dusk-notif-dot';
const STATES = ['unread', 'empty', 'dnd'];

// Far-right panel item: a dot that shows unread / none / Do Not Disturb and
// toggles the notification drawer
export class NotificationDot {
    constructor(drawer) {
        this._drawer = drawer;
        // source → notify::count handler id
        this._sources = new Map();
        this._notificationSettings = new Gio.Settings({
            schema_id: 'org.gnome.desktop.notifications',
        });

        this._button = new PanelMenu.Button(0.5, _('Notifications'), true);
        this._button.add_style_class_name('dusk-notif-dot-button');
        this._dot = new St.Widget({
            style_class: 'dusk-notif-dot',
            x_align: Clutter.ActorAlign.CENTER,
            y_align: Clutter.ActorAlign.CENTER,
        });
        this._button.add_child(this._dot);
        // On shell exit actors are destroyed without disable(); stop syncing
        this._dot.connect('destroy', () => {
            this._dot = null;
        });

        // Without a menu, PanelMenu.Button's own click gesture is disabled
        const click = new Clutter.ClickGesture();
        click.set_recognize_on_press(true);
        click.connect('recognize', () => this._drawer.toggle());
        this._button.add_action(click);

        const keys = new Clutter.KeyController();
        keys.connect('key-press', () => {
            const [, symbol] = keys.get_key();
            if (![Clutter.KEY_Return, Clutter.KEY_KP_Enter, Clutter.KEY_space].includes(symbol))
                return Clutter.EVENT_PROPAGATE;
            this._drawer.toggle();
            return Clutter.EVENT_STOP;
        });
        this._button.add_action(keys);

        const rightBox = Main.panel._rightBox; // panel.js:478
        Main.panel.addToStatusArea(ROLE, this._button,
            rightBox?.get_n_children() ?? 0, 'right');

        const tray = Main.messageTray;
        this._signals = [
            [tray, tray.connect('source-added', (t, source) => this._addSource(source))],
            [tray, tray.connect('source-removed', (t, source) => this._removeSource(source))],
            [tray, tray.connect('queue-changed', () => this._sync())],
            [this._notificationSettings, this._notificationSettings.connect('changed::show-banners',
                () => this._sync())],
            [this._drawer, this._drawer.connect('open-state-changed', (d, open) => {
                if (open)
                    this._button.add_style_pseudo_class('active');
                else
                    this._button.remove_style_pseudo_class('active');
            })],
            // The panel re-appends its own items on session-mode changes
            // (panel.js:698 _updateBox); stay last. Connected after
            // PanelLayout's handler, so the clock has already moved.
            [Main.sessionMode, Main.sessionMode.connect('updated', () => this._moveToEnd())],
        ];
        for (const source of tray.getSources())
            this._addSource(source);
        this._sync();
    }

    destroy() {
        for (const [object, id] of this._signals)
            object.disconnect(id);
        this._signals = [];
        for (const [source, id] of this._sources)
            source.disconnect(id);
        this._sources.clear();

        // Panel drops the statusArea entry on destroy
        this._button?.destroy();
        this._button = null;
        this._dot = null;
        this._notificationSettings = null;
        this._drawer = null;
    }

    _moveToEnd() {
        // Panel Arranger places the dot itself
        if (arrangerOwnsPanel())
            return;
        const container = this._button.container;
        const box = container.get_parent();
        box?.set_child_above_sibling(container, null);
    }

    _addSource(source) {
        if (this._sources.has(source))
            return;
        this._sources.set(source, source.connect('notify::count', () => this._sync()));
        this._sync();
    }

    _removeSource(source) {
        const id = this._sources.get(source);
        if (id)
            source.disconnect(id);
        this._sources.delete(source);
        this._sync();
    }

    _sync() {
        // Source signals can still fire during session teardown
        if (!this._button || !this._dot)
            return;
        // Same count as the shell's MessagesIndicator (dateMenu.js:787-790)
        let unseen = 0;
        for (const source of this._sources.keys())
            unseen += source.unseenCount;
        unseen -= Main.messageTray.queueCount;

        const dnd = !this._notificationSettings.get_boolean('show-banners');
        const state = dnd ? 'dnd' : unseen > 0 ? 'unread' : 'empty';

        for (const s of STATES) {
            const name = `dusk-notif-dot--${s}`;
            if (s === state)
                this._dot.add_style_class_name(name);
            else
                this._dot.remove_style_class_name(name);
        }
        this._button.accessible_name = dnd
            ? _('Notifications, Do Not Disturb on')
            : unseen > 0 ? _('Notifications, unread') : _('Notifications');
    }
}
