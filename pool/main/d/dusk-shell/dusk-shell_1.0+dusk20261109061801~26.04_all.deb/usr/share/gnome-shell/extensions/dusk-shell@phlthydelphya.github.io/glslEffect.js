import Clutter from 'gi://Clutter';
import Cogl from 'gi://Cogl';
import GObject from 'gi://GObject';
import Shell from 'gi://Shell';

// One base for Dusk's GLSL effects on GNOME Shell 50 and 51.
//
// Shell 51 removed Shell.GLSLEffect: effects extend Clutter.ShaderEffect,
// return their snippet from vfunc_get_static_snippet and set uniforms by
// name. Shell 50 (Ubuntu 26.04) has Shell.GLSLEffect: the snippet is added
// in vfunc_build_pipeline and uniforms are set by location, and its
// Clutter.ShaderEffect has no get_static_snippet (overriding it fails the
// whole extension).
//
// Subclasses implement snippet(), returning [declarations, code, replace]
// (replace: the code replaces the fragment hook's default instead of
// following it), and set uniforms with setUniform(name, count, values).
export const GlslEffect = Shell.GLSLEffect
    ? GObject.registerClass(
        class DuskGlslEffect extends Shell.GLSLEffect {
            vfunc_build_pipeline() {
                const [declarations, code, replace] = this.snippet();
                this.add_glsl_snippet(Cogl.SnippetHook.FRAGMENT,
                    declarations, code, replace);
            }

            setUniform(name, count, values) {
                this._uniforms ??= new Map();
                let location = this._uniforms.get(name);
                if (location === undefined) {
                    location = this.get_uniform_location(name);
                    this._uniforms.set(name, location);
                }
                this.set_uniform_float(location, count, values);
            }
        })
    : GObject.registerClass(
        class DuskGlslEffect extends Clutter.ShaderEffect {
            vfunc_get_static_snippet() {
                const [declarations, code, replace] = this.snippet();
                const snippet = Cogl.Snippet.new(Cogl.SnippetHook.FRAGMENT,
                    declarations, replace ? null : code);
                if (replace)
                    snippet.set_replace(code);
                return snippet;
            }

            setUniform(name, count, values) {
                this.set_uniform_float(name, count, values);
            }
        });
