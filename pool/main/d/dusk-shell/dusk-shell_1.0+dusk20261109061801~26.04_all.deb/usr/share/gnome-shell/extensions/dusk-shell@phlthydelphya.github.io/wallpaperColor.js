import GdkPixbuf from 'gi://GdkPixbuf';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';

// The Dusk accent closest to a wallpaper's colors, for wallpaperAccent.js.
// No Shell imports, so it also runs under plain gjs (tests).
//
// The picture is read small (SAMPLE px). Each colorful pixel (CIELAB chroma
// above MIN_CHROMA, not near black or white) votes, weighted by its chroma,
// for the accent nearest to it by CIEDE2000 with lightness counted at half
// weight (kL = 2): wallpapers are often darker or brighter than an accent, and
// hue and colorfulness matter more. Each accent is matched by its light and
// its filled shade, whichever is nearer. A picture with few colorful pixels
// is a grey one: Slate.

const SAMPLE = 96;
const MIN_CHROMA = 14;
const MIN_COLORFUL = 0.06; // share of pixels that must be colorful
const GREY_SLOT = 'slate';
const ACCENTS_FILE = '/usr/share/dusk/accents.json';

Gio._promisify(GdkPixbuf.Pixbuf, 'new_from_stream_at_scale_async', 'new_from_stream_finish');
Gio._promisify(Gio.File.prototype, 'read_async');

function srgbToLab(r, g, b) {
    const lin = c => {
        c /= 255;
        return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
    };
    const R = lin(r), G = lin(g), B = lin(b);
    // D65
    const x = (R * 0.4124 + G * 0.3576 + B * 0.1805) / 0.95047;
    const y = R * 0.2126 + G * 0.7152 + B * 0.0722;
    const z = (R * 0.0193 + G * 0.1192 + B * 0.9505) / 1.08883;
    const f = t => t > 216 / 24389 ? Math.cbrt(t) : (24389 / 27 * t + 16) / 116;
    const fx = f(x), fy = f(y), fz = f(z);
    return [116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)];
}

function hexToLab(hex) {
    const n = parseInt(hex.slice(1, 7), 16);
    return srgbToLab((n >> 16) & 255, (n >> 8) & 255, n & 255);
}

// CIEDE2000 (Sharma, Wu and Dalal 2005), with a lightness weight kL
export function deltaE2000([L1, a1, b1], [L2, a2, b2], kL = 1) {
    const rad = Math.PI / 180;
    const C1 = Math.hypot(a1, b1), C2 = Math.hypot(a2, b2);
    const Cm = (C1 + C2) / 2;
    const G = 0.5 * (1 - Math.sqrt(Cm ** 7 / (Cm ** 7 + 25 ** 7)));
    const a1p = (1 + G) * a1, a2p = (1 + G) * a2;
    const C1p = Math.hypot(a1p, b1), C2p = Math.hypot(a2p, b2);
    const h = (a, b) => {
        if (a === 0 && b === 0)
            return 0;
        const d = Math.atan2(b, a) / rad;
        return d < 0 ? d + 360 : d;
    };
    const h1p = h(a1p, b1), h2p = h(a2p, b2);
    const dL = L2 - L1, dC = C2p - C1p;
    let dh = 0;
    if (C1p * C2p !== 0) {
        dh = h2p - h1p;
        if (dh > 180)
            dh -= 360;
        else if (dh < -180)
            dh += 360;
    }
    const dH = 2 * Math.sqrt(C1p * C2p) * Math.sin(dh * rad / 2);
    const Lm = (L1 + L2) / 2, Cpm = (C1p + C2p) / 2;
    let hm = h1p + h2p;
    if (C1p * C2p !== 0) {
        if (Math.abs(h1p - h2p) > 180)
            hm += hm < 360 ? 360 : -360;
        hm /= 2;
    }
    const T = 1 - 0.17 * Math.cos((hm - 30) * rad) + 0.24 * Math.cos(2 * hm * rad) +
        0.32 * Math.cos((3 * hm + 6) * rad) - 0.20 * Math.cos((4 * hm - 63) * rad);
    const dTheta = 30 * Math.exp(-(((hm - 275) / 25) ** 2));
    const RC = 2 * Math.sqrt(Cpm ** 7 / (Cpm ** 7 + 25 ** 7));
    const SL = 1 + 0.015 * (Lm - 50) ** 2 / Math.sqrt(20 + (Lm - 50) ** 2);
    const SC = 1 + 0.045 * Cpm, SH = 1 + 0.015 * Cpm * T;
    const RT = -Math.sin(2 * dTheta * rad) * RC;
    return Math.sqrt((dL / (kL * SL)) ** 2 + (dC / SC) ** 2 + (dH / SH) ** 2 +
        RT * (dC / SC) * (dH / SH));
}

// [{slot, name, labs: [Lab of accent, Lab of accent_bg]}] from accents.json
export function loadAccents(path = ACCENTS_FILE) {
    try {
        const [, data] = GLib.file_get_contents(path);
        return JSON.parse(new TextDecoder().decode(data)).accents.map(a => ({
            slot: a.slot,
            name: a.name,
            labs: [hexToLab(a.accent), hexToLab(a.accent_bg)],
        }));
    } catch {
        return [];
    }
}

// The slot whose accent best matches the pixbuf, with every slot's score
export function pickAccent(pixbuf, accents) {
    const chromatic = accents.filter(a => a.slot !== GREY_SLOT);
    const scores = new Map(accents.map(a => [a.slot, 0]));
    const px = pixbuf.get_pixels();
    const stride = pixbuf.get_rowstride(), n = pixbuf.get_n_channels();
    const alpha = pixbuf.get_has_alpha();
    // Nearest slot per color, quantized to 5 bits a channel: photos repeat
    // colors, and CIEDE2000 against every accent is the costly part
    const nearest = new Map();
    let total = 0, colorful = 0;
    for (let y = 0; y < pixbuf.get_height(); y++) {
        for (let x = 0; x < pixbuf.get_width(); x++) {
            const i = y * stride + x * n;
            if (alpha && px[i + 3] < 128)
                continue;
            total++;
            const r = px[i] & 0xf8, g = px[i + 1] & 0xf8, b = px[i + 2] & 0xf8;
            const lab = srgbToLab(r + 4, g + 4, b + 4);
            const chroma = Math.hypot(lab[1], lab[2]);
            if (chroma < MIN_CHROMA || lab[0] < 8 || lab[0] > 97)
                continue;
            colorful++;
            const q = (r << 16) | (g << 8) | b;
            let best = nearest.get(q);
            if (best === undefined) {
                let bestD = Infinity;
                for (const a of chromatic) {
                    const d = Math.min(...a.labs.map(l => deltaE2000(lab, l, 2)));
                    if (d < bestD) {
                        bestD = d;
                        best = a.slot;
                    }
                }
                nearest.set(q, best);
            }
            scores.set(best, scores.get(best) + chroma);
        }
    }
    if (!total || colorful / total < MIN_COLORFUL)
        return {slot: GREY_SLOT, scores};
    let slot = GREY_SLOT, top = -1;
    for (const [s, v] of scores) {
        if (v > top) {
            top = v;
            slot = s;
        }
    }
    return {slot, scores};
}

// The current wallpaper's file (the dark variant first: Dusk is dark only)
export function wallpaperFile(background) {
    for (const key of ['picture-uri-dark', 'picture-uri']) {
        const uri = background.get_string(key);
        if (uri)
            return Gio.File.new_for_uri(uri);
    }
    return null;
}

export async function pickForFile(file, accents, cancellable = null) {
    const stream = await file.read_async(GLib.PRIORITY_LOW, cancellable);
    try {
        const pixbuf = await GdkPixbuf.Pixbuf.new_from_stream_at_scale_async(
            stream, SAMPLE, SAMPLE, true, cancellable);
        return pickAccent(pixbuf, accents);
    } finally {
        stream.close(null);
    }
}

