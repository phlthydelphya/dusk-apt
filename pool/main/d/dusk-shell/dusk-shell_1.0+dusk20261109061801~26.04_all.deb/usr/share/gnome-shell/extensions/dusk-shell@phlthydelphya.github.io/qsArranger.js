import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Shell from 'gi://Shell';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as Util from 'resource:///org/gnome/shell/misc/util.js';
import {
    QuickMenuToggle, QuickSettingsItem, QuickSlider, QuickToggle,
} from 'resource:///org/gnome/shell/ui/quickSettings.js';

import {
    ACTION_CLASS_IDS, CUSTOM_PREFIX, SIZE_KEYS, SPACER_ID,
    builtinActionLabel, builtinItemLabel, mergeOrder, parseCustomItems,
} from './qsArrangerCommon.js';

const LOG_PREFIX = '[qs-arranger]';
const ORIG_SPACER_PREFIX = '__spacer';
const DEFAULT_ICON = 'emblem-system-symbolic';

function launch(command) {
    command = command?.trim();
    if (!command)
        return;

    Main.overview.hide();
    Main.panel.closeQuickSettings();

    if (command.endsWith('.desktop')) {
        const app = Shell.AppSystem.get_default().lookup_app(command);
        if (app)
            app.activate();
        else
            Main.notifyError('Quick Settings Arranger', `No application named ${command}`);
        return;
    }

    Util.spawnCommandLine(command);
}

// Whether a command line (no shell; use sh -c for one) exits 0. Used for a
// command toggle's status; false when it cannot run.
function commandSucceeds(command) {
    return new Promise(resolve => {
        try {
            const [, argv] = GLib.shell_parse_argv(command);
            const proc = Gio.Subprocess.new(argv,
                Gio.SubprocessFlags.STDOUT_SILENCE | Gio.SubprocessFlags.STDERR_SILENCE);
            proc.wait_check_async(null, (p, res) => {
                try {
                    resolve(p.wait_check_finish(res));
                } catch {
                    resolve(false);
                }
            });
        } catch {
            resolve(false);
        }
    });
}

function isBooleanKey(schemaId, key) {
    if (!schemaId || !key)
        return false;
    const schema = Gio.SettingsSchemaSource.get_default()?.lookup(schemaId, true);
    if (!schema?.has_key(key))
        return false;
    return schema.get_key(key).get_value_type().dup_string() === 'b';
}

function uniqueId(base, taken) {
    let id = base;
    for (let n = 2; taken.has(id); n++)
        id = `${base}#${n}`;
    return id;
}

function kindOf(actor) {
    if (actor.constructor.name === 'SystemItem')
        return 'system';
    if (actor instanceof QuickSlider)
        return 'slider';
    if (actor instanceof QuickToggle || actor instanceof QuickMenuToggle)
        return 'toggle';
    return 'item';
}

// Put an actor at `index` in `container`, re-adding it if we detached it.
function attach(container, stash, actor, index) {
    if (stash.has(actor)) {
        stash.delete(actor);
        // Clutter shows actors on re-parenting; keep their own visibility
        const {visible} = actor;
        container.insert_child_at_index(actor, index);
        actor.visible = visible;
    } else if (actor.get_parent() === container) {
        container.set_child_at_index(actor, index);
    } else {
        return false;
    }
    return true;
}

// Take an actor out of `container`, keeping a reference so it can come back.
function detach(container, stash, actor) {
    if (actor.get_parent() !== container)
        return;
    if (actor.menu?.isOpen)
        actor.menu.close(false);
    container.remove_child(actor);
    stash.add(actor);
}

const GSettingsToggle = GObject.registerClass(
class GSettingsToggle extends QuickToggle {
    _init(def) {
        super._init({
            title: def.title || def.key,
            subtitle: def.subtitle || null,
            iconName: def.icon || DEFAULT_ICON,
            toggleMode: true,
        });

        this._settings = new Gio.Settings({schema_id: def.schema});
        const flags = def.invert
            ? Gio.SettingsBindFlags.INVERT_BOOLEAN
            : Gio.SettingsBindFlags.DEFAULT;
        this._settings.bind(def.key, this, 'checked', flags);

        this.connect('destroy', () => {
            Gio.Settings.unbind(this, 'checked');
            this._settings = null;
        });
    }
});

const LauncherToggle = GObject.registerClass(
class LauncherToggle extends QuickToggle {
    _init(def) {
        super._init({
            title: def.title || def.command,
            subtitle: def.subtitle || null,
            iconName: def.icon || 'application-x-executable-symbolic',
        });

        this.connect('clicked', () => launch(def.command));
    }
});

// A toggle that runs one command to turn something on and another to turn it
// off. With a status command (exit 0 = on) it shows the real state, checked
// again whenever Quick Settings opens and shortly after each click; without
// one it only remembers its own last click.
const CommandToggle = GObject.registerClass(
class CommandToggle extends QuickToggle {
    _init(def) {
        super._init({
            title: def.title || 'Command',
            subtitle: def.subtitle || null,
            iconName: def.icon || DEFAULT_ICON,
            toggleMode: true,
        });
        this._def = def;
        this._recheckId = 0;

        // toggle-mode buttons flip `checked` before emitting clicked
        this.connect('clicked', () => {
            const command = (this.checked ? def.on : def.off)?.trim();
            if (command)
                Util.spawnCommandLine(command);
            this._queueRefresh();
        });
        Main.panel.statusArea.quickSettings?.menu?.connectObject('open-state-changed', (_menu, open) => {
            if (open)
                this._refresh();
        }, this);
        this.connect('destroy', () => {
            if (this._recheckId)
                GLib.source_remove(this._recheckId);
            this._recheckId = 0;
            this._def = null;
        });
        this._refresh();
    }

    _queueRefresh() {
        if (!this._def?.status?.trim() || this._recheckId)
            return;
        // The on/off command runs in the background; check once it had time
        this._recheckId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 1500, () => {
            this._recheckId = 0;
            this._refresh();
            return GLib.SOURCE_REMOVE;
        });
    }

    async _refresh() {
        const status = this._def?.status?.trim();
        if (!status)
            return;
        const on = await commandSucceeds(status);
        if (this._def)
            this.checked = on;
    }
});

const ActionButton = GObject.registerClass(
class ActionButton extends QuickSettingsItem {
    _init(def) {
        super._init({
            style_class: 'icon-button',
            can_focus: true,
            icon_name: def.icon || 'application-x-executable-symbolic',
            accessible_name: def.title || def.command || '',
        });

        this.connect('clicked', () => launch(def.command));
    }
});

function createGridItem(def) {
    if (def.kind === 'launcher')
        return new LauncherToggle(def);
    if (def.kind === 'command')
        return new CommandToggle(def);

    if (!isBooleanKey(def.schema, def.key)) {
        console.warn(`${LOG_PREFIX} skipping toggle "${def.title}": ` +
            `${def.schema} ${def.key} is not a boolean GSettings key`);
        return null;
    }
    return new GSettingsToggle(def);
}

class Arranger {
    constructor(settings) {
        this._settings = settings;

        this._qs = Main.panel.statusArea.quickSettings;
        this._grid = this._qs.menu._grid;
        this._layout = this._grid.layout_manager;
        this._placeholder = this._layout._overlay;
        this._origColumns = this._layout.nColumns;

        this._items = new Map(); // actor -> {id, label, kind, span}
        this._defaultOrder = []; // ids in the shell's own order
        this._stash = new Set(); // hidden grid actors
        this._customGrid = [];
        this._customJson = null;
        this._customActionDefs = [];
        this._actionsDirty = true;
        this._row = null;

        this._applying = false;
        this._applyId = 0;

        // Other extensions add grid items with menu.insertItemBefore(item,
        // sibling); the shell's addExternalIndicator passes the Background
        // Apps toggle as the sibling. While a hidden item like that is out of
        // the grid the insert fails (clutter_actor_insert_child_below:
        // sibling not a child) and the new item never shows: Dusk Cast's
        // toggle vanished after every unlock, when extensions re-enable. Aim
        // such inserts at the next item still in the grid instead.
        const menu = this._qs.menu;
        this._origInsertBefore = menu.insertItemBefore;
        menu.insertItemBefore = (item, sibling, ...rest) => {
            if (sibling && sibling.get_parent() !== this._grid)
                sibling = this._gridSuccessor(sibling);
            return this._origInsertBefore.call(menu, item, sibling, ...rest);
        };

        this._gridGone = false;
        this._grid.connectObject(
            'child-added', () => this._onExternalChange(),
            'child-removed', () => this._onExternalChange(),
            'destroy', () => this._onGridDestroyed(),
            this);
        this._settings.connectObject('changed', (_s, key) => {
            if (!key.startsWith('known-') && !SIZE_KEYS.includes(key))
                this._queueApply();
        }, this);

        this._queueApply();
    }

    // The first item after `actor` in the shell's own order that is still in
    // the grid (null: the end), for an insert aimed at a detached item
    _gridSuccessor(actor) {
        const id = this._items.get(actor)?.id;
        const start = id ? this._defaultOrder.indexOf(id) : -1;
        if (start < 0)
            return null;
        const byId = new Map([...this._items].map(([a, info]) => [info.id, a]));
        for (const next of this._defaultOrder.slice(start + 1)) {
            const a = byId.get(next);
            if (a?.get_parent() === this._grid)
                return a;
        }
        return null;
    }

    _onExternalChange() {
        if (!this._applying)
            this._queueApply();
    }

    _onGridDestroyed() {
        // The shell is tearing the panel down; nothing left to restore
        this._gridGone = true;
        this._cancelApply();
        this._row = null;
        this._items.clear();
        this._stash.clear();
        this._customGrid = [];
        this._defaultOrder = [];
    }

    _cancelApply() {
        if (this._applyId)
            GLib.source_remove(this._applyId);
        this._applyId = 0;
    }

    _queueApply() {
        if (this._applyId || this._gridGone)
            return;
        this._applyId = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
            this._applyId = 0;
            this._apply();
            return GLib.SOURCE_REMOVE;
        });
    }

    _apply() {
        this._applying = true;
        try {
            this._syncCustomItems();
            this._discoverGrid();
            this._applyGrid();
            this._applyRow();
            this._publish();
        } catch (e) {
            console.error(`${LOG_PREFIX} ${e}\n${e.stack}`);
        } finally {
            this._applying = false;
        }
    }

    // Grid

    _track(actor, id, extra = {}) {
        const label = extra.label ?? builtinItemLabel(id) ??
            (actor.title || actor.accessible_name || id);
        const info = {
            id,
            label,
            kind: extra.kind ?? kindOf(actor),
            span: this._layout.get_child_meta(this._grid, actor)?.columnSpan ?? 1,
        };
        this._items.set(actor, info);
        actor.connectObject('destroy', () => this._untrack(actor), this);
        return info;
    }

    _untrack(actor) {
        const info = this._items.get(actor);
        if (!info)
            return;
        this._items.delete(actor);
        this._stash.delete(actor);
        this._defaultOrder = this._defaultOrder.filter(id => id !== info.id);
        if (!this._applying)
            this._queueApply();
    }

    _discoverGrid() {
        const taken = new Set([...this._items.values()].map(i => i.id));
        let prevId = null;

        for (const actor of this._grid.get_children()) {
            if (actor === this._placeholder)
                continue;

            let info = this._items.get(actor);
            if (!info) {
                const id = uniqueId(actor.constructor.name || 'Item', taken);
                taken.add(id);
                info = this._track(actor, id);
                const at = prevId ? this._defaultOrder.indexOf(prevId) + 1 : 0;
                this._defaultOrder.splice(at, 0, id);
            }
            prevId = info.id;
        }
    }

    _syncCustomItems() {
        const json = this._settings.get_string('custom-items');
        if (json === this._customJson)
            return;
        this._customJson = json;

        this._customGrid.forEach(a => a.destroy());
        this._customGrid = [];

        const defs = parseCustomItems(json);
        this._customActionDefs = defs.filter(d => d.kind === 'action');
        this._actionsDirty = true;

        for (const def of defs.filter(d => d.kind !== 'action')) {
            const actor = createGridItem(def);
            if (!actor)
                continue;
            const id = CUSTOM_PREFIX + def.id;
            this._grid.add_child(actor);
            this._track(actor, id, {label: def.title || 'Custom item', kind: 'custom'});
            this._defaultOrder.push(id);
            this._customGrid.push(actor);
        }
    }

    _spanFor(info, override, nCols) {
        if (override === -1)
            return nCols;
        if (override > 0)
            return Math.min(override, nCols);
        // Items that filled the stock grid stay full width
        return info.span >= this._origColumns ? nCols : Math.min(info.span, nCols);
    }

    _setSpan(actor, span) {
        this._layout.child_set_property(this._grid, actor, 'column-span', span);
    }

    _applyGrid() {
        const nCols = this._settings.get_int('n-columns');
        if (this._layout.nColumns !== nCols)
            this._layout.nColumns = nCols;

        const hidden = new Set(this._settings.get_strv('hidden-items'));
        const spans = this._settings.get_value('item-spans').deepUnpack();
        const order = mergeOrder(this._settings.get_strv('grid-order'), this._defaultOrder);
        const byId = new Map([...this._items].map(([actor, info]) => [info.id, actor]));

        let index = 0;
        for (const id of order) {
            const actor = byId.get(id);
            if (hidden.has(id)) {
                detach(this._grid, this._stash, actor);
                continue;
            }
            if (!attach(this._grid, this._stash, actor, index))
                continue;
            this._setSpan(actor, this._spanFor(this._items.get(actor), spans[id] ?? 0, nCols));
            index++;
        }
        this._layout.layout_changed();
    }

    // Quick action buttons (the system row)

    _ensureRow() {
        if (this._row)
            return this._row;

        const systemItem = this._qs._system?._systemItem;
        const box = systemItem?.child;
        if (!(box instanceof St.BoxLayout))
            return null;

        const spacer = new Clutter.Actor({x_expand: true, visible: true});
        this._row = {
            box,
            items: new Map(), // actor -> id
            labels: new Map(), // id -> label
            defaultActors: [],
            stash: new Set([spacer]),
            customs: [],
            spacer,
            published: [],
        };
        box.connectObject(
            'child-added', () => this._onExternalChange(),
            'child-removed', () => this._onExternalChange(),
            'destroy', () => (this._row = null),
            this);
        return this._row;
    }

    _forgetRowActor(row, actor) {
        const id = row.items.get(actor);
        row.items.delete(actor);
        row.labels.delete(id);
        row.stash.delete(actor);
        row.defaultActors = row.defaultActors.filter(a => a !== actor);
        row.customs = row.customs.filter(a => a !== actor);
    }

    _rebuildRowCustoms(row) {
        row.customs.forEach(a => a.destroy());
        row.customs = [];

        for (const def of this._customActionDefs) {
            const actor = new ActionButton(def);
            const id = CUSTOM_PREFIX + def.id;
            row.box.add_child(actor);
            row.items.set(actor, id);
            row.labels.set(id, def.title || def.command || 'Custom button');
            row.customs.push(actor);
            actor.connectObject('destroy', () => this._forgetRowActor(row, actor), this);
        }
    }

    _discoverRow(row) {
        const taken = new Set(row.items.values());

        for (const actor of row.box.get_children()) {
            if (actor === row.spacer || row.items.has(actor))
                continue;

            let base;
            if (actor.constructor === Clutter.Actor)
                base = ORIG_SPACER_PREFIX;
            else
                base = ACTION_CLASS_IDS[actor.constructor.name] ?? actor.constructor.name;

            const id = uniqueId(base, taken);
            taken.add(id);
            row.items.set(actor, id);
            row.labels.set(id, builtinActionLabel(id) || actor.accessible_name || id);
            row.defaultActors.push(actor);
            actor.connectObject('destroy', () => {
                this._forgetRowActor(row, actor);
                if (!this._applying)
                    this._queueApply();
            }, this);
        }
    }

    // Stock order, with custom buttons after the settings button
    _rawRowOrder(row) {
        const ids = row.defaultActors.map(a => row.items.get(a));
        const customIds = row.customs.map(a => row.items.get(a));
        const at = ids.indexOf('settings');
        ids.splice(at >= 0 ? at + 1 : ids.length, 0, ...customIds);
        return ids;
    }

    // The stock row uses two spacers and shows one of them depending on
    // whether there is a battery. A customised row uses a single spacer.
    _collapseSpacers(row, raw) {
        const byId = new Map([...row.items].map(([a, id]) => [id, a]));
        const spacers = raw.filter(id => id.startsWith(ORIG_SPACER_PREFIX));
        const visible = spacers.find(id => byId.get(id)?.visible);
        const ids = raw.filter(id => !id.startsWith(ORIG_SPACER_PREFIX));

        const anchor = visible ?? spacers[0];
        let at = ids.length;
        if (anchor) {
            // Position of the anchor among the non-spacer ids
            at = raw.slice(0, raw.indexOf(anchor))
                .filter(id => !id.startsWith(ORIG_SPACER_PREFIX)).length;
        }
        ids.splice(at, 0, SPACER_ID);
        return ids;
    }

    _applyRow() {
        const row = this._ensureRow();
        if (!row)
            return;

        if (this._actionsDirty) {
            this._rebuildRowCustoms(row);
            this._actionsDirty = false;
        }
        this._discoverRow(row);

        const raw = this._rawRowOrder(row);
        row.published = this._collapseSpacers(row, raw);

        const userOrder = this._settings.get_strv('action-order');
        const hidden = new Set(this._settings.get_strv('hidden-actions'));
        const byId = new Map([...row.items].map(([a, id]) => [id, a]));
        byId.set(SPACER_ID, row.spacer);

        let order;
        if (userOrder.length > 0) {
            order = mergeOrder(userOrder, row.published);
            raw.filter(id => id.startsWith(ORIG_SPACER_PREFIX))
                .forEach(id => detach(row.box, row.stash, byId.get(id)));
        } else {
            order = raw;
            detach(row.box, row.stash, row.spacer);
        }

        let index = 0;
        for (const id of order) {
            const actor = byId.get(id);
            if (hidden.has(id) && id !== SPACER_ID) {
                detach(row.box, row.stash, actor);
                continue;
            }
            if (attach(row.box, row.stash, actor, index))
                index++;
        }
    }

    // Tell the prefs window what exists

    _publish() {
        const byId = new Map([...this._items.values()].map(i => [i.id, i]));
        const items = this._defaultOrder.map(id => {
            const {label, kind, span} = byId.get(id);
            return {id, label, kind, span};
        });
        this._writeIfChanged('known-items', JSON.stringify(items));

        if (this._row) {
            const actions = this._row.published.map(id => ({
                id,
                label: builtinActionLabel(id) ?? this._row.labels.get(id) ?? id,
                kind: id.startsWith(CUSTOM_PREFIX) ? 'custom' : 'action',
            }));
            this._writeIfChanged('known-actions', JSON.stringify(actions));
        }
    }

    _writeIfChanged(key, value) {
        if (this._settings.get_string(key) !== value)
            this._settings.set_string(key, value);
    }

    destroy() {
        this._cancelApply();
        this._settings.disconnectObject(this);
        this._settings = null;
        // The menu's own insertItemBefore again (ours was an own property)
        if (this._qs?.menu?.insertItemBefore !== this._origInsertBefore)
            delete this._qs.menu.insertItemBefore;
        if (this._gridGone)
            return;

        this._grid.disconnectObject(this);
        this._applying = true;

        const row = this._row;
        if (row) {
            row.box.disconnectObject(this);
            [...row.customs].forEach(a => a.destroy());
            row.spacer.destroy();
            row.defaultActors.forEach((actor, i) => {
                attach(row.box, row.stash, actor, i);
                actor.disconnectObject(this);
            });
            this._row = null;
        }

        [...this._customGrid].forEach(a => a.destroy());
        this._customGrid = [];

        this._layout.nColumns = this._origColumns;
        const byId = new Map([...this._items].map(([actor, info]) => [info.id, actor]));
        let index = 0;
        for (const id of this._defaultOrder) {
            const actor = byId.get(id);
            if (attach(this._grid, this._stash, actor, index)) {
                this._setSpan(actor, this._items.get(actor).span);
                index++;
            }
            actor.disconnectObject(this);
        }
        this._layout.layout_changed();

        this._items.clear();
        this._stash.clear();
        this._defaultOrder = [];
    }
}

// Toggle sizes come from the theme, so they are changed with a generated
// stylesheet. The shell carries custom stylesheets over when it reloads the
// theme, so this survives light/dark and user theme switches.
class ToggleSizer {
    constructor(settings) {
        this._settings = settings;
        this._file = Gio.File.new_for_path(GLib.build_filenamev(
            [GLib.get_user_runtime_dir(), 'qs-arranger-toggles.css']));
        this._loaded = false;
        this._css = null;
        this._timeoutId = 0;

        this._settings.connectObject(
            ...SIZE_KEYS.flatMap(key => [`changed::${key}`, () => this._queueUpdate()]),
            this);
        this._update();
    }

    // Vertical and horizontal padding + border of the first grid item with
    // style class `cls` (and of its inner toggle, for split toggles). The
    // theme pads toggles (Dusk with !important); St sizes are content-box,
    // so the settings' outer sizes are turned into content sizes with these.
    _chrome(cls) {
        const grid = Main.panel.statusArea.quickSettings?.menu?._grid;
        // A split toggle is .quick-toggle-has-menu only; a plain one is
        // .quick-toggle without it
        const split = cls === 'quick-toggle-has-menu';
        const actor = grid?.get_children().find(a => a.has_style_class_name?.(cls) &&
            a.has_style_class_name('quick-toggle-has-menu') === split);
        const measure = widget => {
            const zero = {v: 0, h: 0};
            if (!widget?.get_stage())
                return zero;
            try {
                const node = widget.get_theme_node();
                const side = s => node.get_padding(s) + node.get_border_width(s);
                return {
                    v: side(St.Side.TOP) + side(St.Side.BOTTOM),
                    h: side(St.Side.LEFT) + side(St.Side.RIGHT),
                };
            } catch {
                return zero;
            }
        };
        const inner = cls === 'quick-toggle-has-menu'
            ? actor?.get_children().find(c => c.has_style_class_name?.('quick-toggle'))
            : null;
        return {outer: measure(actor), inner: measure(inner)};
    }

    _generate() {
        const s = this._settings;
        if (!s.get_boolean('toggle-size-enabled'))
            return null;

        const width = s.get_int('toggle-width');
        const height = s.get_int('toggle-height');
        const icon = s.get_int('toggle-icon-size');
        const scale = s.get_int('toggle-text-scale') / 100;
        const spacing = s.get_int('grid-spacing');
        const grid = '.quick-settings .quick-settings-grid';
        // Only grid items: the battery button in the system row is a
        // quick-toggle too, and must keep its size
        const inside = sel =>
            `${grid} > .quick-toggle ${sel}, ${grid} > .quick-toggle-has-menu ${sel}`;
        const plain = this._chrome('quick-toggle');
        const split = this._chrome('quick-toggle-has-menu');
        const px = n => `${Math.max(0, Math.round(n))}px`;

        // Width and height are the toggle's outer size, as the settings say.
        // Width only on the items themselves: the inner toggle of a menu
        // toggle keeps its auto width. The inner toggle's height is set too,
        // or it would hold the outer one at the theme's height.
        return `${grid} {
  spacing-rows: ${spacing}px;
  spacing-columns: ${spacing}px;
}
${grid} > .quick-toggle {
  min-width: ${px(width - plain.outer.h)};
  max-width: ${px(width - plain.outer.h)};
  min-height: ${px(height - plain.outer.v)};
}
${grid} > .quick-toggle-has-menu {
  min-width: ${px(width - split.outer.h)};
  max-width: ${px(width - split.outer.h)};
  min-height: ${px(height - split.outer.v)};
}
${grid} > .quick-toggle-has-menu .quick-toggle {
  min-height: ${px(height - split.outer.v - split.inner.v)};
}
${inside('.quick-toggle-icon')} {
  icon-size: ${icon}px;
}
${inside('.quick-toggle-title')} {
  font-size: ${scale.toFixed(3)}em;
}
${inside('.quick-toggle-subtitle')} {
  font-size: ${(0.818 * scale).toFixed(3)}em;
}
`;
    }

    _queueUpdate() {
        if (this._timeoutId)
            GLib.source_remove(this._timeoutId);
        // Spin buttons send a burst of changes; reload the theme once
        this._timeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 200, () => {
            this._timeoutId = 0;
            this._update();
            return GLib.SOURCE_REMOVE;
        });
    }

    _update() {
        const css = this._generate();
        if (css === this._css)
            return;
        this._css = css;

        const theme = St.ThemeContext.get_for_stage(global.stage).get_theme();
        if (this._loaded) {
            theme.unload_stylesheet(this._file);
            this._loaded = false;
        }

        if (css) {
            try {
                this._file.replace_contents(new TextEncoder().encode(css), null,
                    false, Gio.FileCreateFlags.REPLACE_DESTINATION, null);
                theme.load_stylesheet(this._file);
                this._loaded = true;
            } catch (e) {
                console.error(`${LOG_PREFIX} cannot load toggle size stylesheet: ${e.message}`);
            }
        }

        // Rebuild the theme so existing widgets pick up the change
        Main.loadTheme();
    }

    destroy() {
        if (this._timeoutId)
            GLib.source_remove(this._timeoutId);
        this._timeoutId = 0;
        this._settings.disconnectObject(this);

        if (this._loaded) {
            St.ThemeContext.get_for_stage(global.stage).get_theme()
                .unload_stylesheet(this._file);
            Main.loadTheme();
        }
        this._file.delete_async(GLib.PRIORITY_DEFAULT, null, null);
        this._settings = null;
    }
}

// Dusk Shell module (formerly the Quick Settings Arranger extension); its
// settings keep their own schema, org.gnome.shell.extensions.qs-arranger
export class QuickSettingsArranger {
    constructor(settings) {
        this._arranger = new Arranger(settings);
        this._sizer = new ToggleSizer(settings);
    }

    destroy() {
        this._sizer?.destroy();
        this._sizer = null;
        this._arranger?.destroy();
        this._arranger = null;
    }
}
