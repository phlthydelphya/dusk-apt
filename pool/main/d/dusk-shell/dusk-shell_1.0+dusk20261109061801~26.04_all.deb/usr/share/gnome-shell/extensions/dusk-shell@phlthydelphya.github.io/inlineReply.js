import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as MessageList from 'resource:///org/gnome/shell/ui/messageList.js';
import * as MessageTray from 'resource:///org/gnome/shell/ui/messageTray.js';
import {InjectionManager, gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

// Shell 51's misc/dbusUtils.js has emitSignalToDestination, Shell 50 does not.
// A static import of a missing export fails the whole extension, so Dusk
// emits the unicast signal itself, the same way.
function emitSignalToDestination(impl, destination, name, parameters) {
    const iface = impl.get_info().name;
    const path = impl.get_object_path();
    for (const connection of impl.get_connections())
        connection.emit_signal(destination, path, iface, name, parameters);
}

// Inline replies in notifications, as in Windows toasts and KDE Plasma.
//
// GNOME Shell's notification server has no reply entry. Dusk adds Plasma's
// inline-reply protocol to it, as a Dusk capability that apps opt in to:
//   - GetCapabilities also reports "x-dusk-inline-reply".
//   - A notification with the action "inline-reply" and the hint
//     x-dusk-inline-reply (a boolean, true) shows that action as a Reply
//     button. The button opens an entry and a Send button in place of the
//     notification's buttons, with Plasma's hints
//     x-kde-reply-placeholder-text and x-kde-reply-submit-button-text.
//   - Send emits NotificationReplied(u id, s text) to the app and closes the
//     notification (a resident one stays). An empty entry can't be sent.
//     Escape closes the entry and brings the buttons back.
// While the entry is open, the banner stays up even when the pointer leaves
// it. On the lock screen the Reply button keeps the stock behaviour: it
// invokes the "inline-reply" action, and the app shows its own reply UI.
//
// Why a Dusk capability and not Plasma's "inline-reply": apps don't talk to
// the shell. org.gnome.Shell.Notifications, a separate process, owns
// org.freedesktop.Notifications and passes on only the signals it knows
// (ActionInvoked, NotificationClosed, ActivationToken). So the shell sends
// NotificationReplied to the app itself (the x-shell-sender that process
// adds), from the shell's own name. An app must accept that signal from
// the owner of org.gnome.Shell, which Plasma apps don't do; they keep the
// stock Reply button.

const REPLY_ACTION = 'inline-reply';
const CAPABILITY = 'x-dusk-inline-reply';
const OPT_IN_HINT = 'x-dusk-inline-reply';
const SENDER_HINT = 'x-shell-sender';
const PROXY_NAME = 'org.freedesktop.Notifications';
const PLACEHOLDER_HINT = 'x-kde-reply-placeholder-text';
const SUBMIT_HINT = 'x-kde-reply-submit-button-text';

function boolHint(hints, key) {
    const value = hints?.[key];
    try {
        return value instanceof GLib.Variant && value.deepUnpack() === true;
    } catch {
        return false;
    }
}

function stringHint(hints, key) {
    const value = hints?.[key];
    if (!(value instanceof GLib.Variant))
        return null;
    try {
        const text = value.deepUnpack();
        return typeof text === 'string' && text ? text : null;
    } catch {
        return null;
    }
}

export class InlineReply {
    constructor() {
        this._daemon = Main.notificationDaemon?._fdoNotificationDaemon;
        if (typeof this._daemon?.NotifyAsync !== 'function' ||
            typeof this._daemon?.GetCapabilities !== 'function' ||
            !(this._daemon._notifications instanceof Map) ||
            typeof MessageList.NotificationMessage?.prototype._addAction !== 'function') {
            console.warn('Dusk Shell: inline reply off, the notification daemon has changed');
            this._daemon = null;
            return;
        }

        // The reply that addAction is adding right now (see _notify)
        this._tagging = null;
        this._composers = new Set();
        this._injections = new InjectionManager();
        const self = this;

        // x-shell-sender is trusted only from the process that owns the
        // notification name (the proxy that adds it)
        this._proxyOwner = null;
        this._proxyWatch = Gio.bus_watch_name(Gio.BusType.SESSION, PROXY_NAME,
            Gio.BusNameWatcherFlags.NONE,
            (_conn, _name, owner) => (this._proxyOwner = owner),
            () => (this._proxyOwner = null));

        this._injections.overrideMethod(this._daemon, 'GetCapabilities',
            original => function () {
                const caps = original.call(this);
                return caps.includes(CAPABILITY) ? caps : [...caps, CAPABILITY];
            });
        this._injections.overrideMethod(this._daemon, 'NotifyAsync',
            original => function (params, invocation) {
                return self._notify(this, original, params, invocation);
            });

        this._injections.overrideMethod(MessageList.NotificationMessage.prototype, '_addAction',
            original => function (action) {
                if (self._tagging && !action._duskReply)
                    action._duskReply = self._tagging;
                original.call(this, action);
                if (action._duskReply)
                    self._replaceButton(this, action);
            });

        // A banner with an open entry stays up when the pointer leaves it
        this._injections.overrideMethod(Main.messageTray, '_updateState',
            original => function () {
                if (this._banner?._duskReplying && !this._notificationRemoved)
                    this._pointerInNotification = true;
                return original.call(this);
            });
    }

    // Runs the shell's Notify, and tags the Action that it makes for
    // "inline-reply" with what the entry needs.
    _notify(daemon, original, params, invocation) {
        const actions = params[5] ?? [];
        let replyIndex = -1;
        let label = null;
        // addAction is called for every action but "default", in order
        for (let i = 0, n = 0; i + 1 < actions.length; i += 2) {
            if (actions[i] === 'default')
                continue;
            if (actions[i] === REPLY_ACTION) {
                replyIndex = n;
                label = actions[i + 1];
                break;
            }
            n++;
        }
        // Read before Notify unpacks the hints in place
        const hints = params[6];
        if (replyIndex < 0 || !boolHint(hints, OPT_IN_HINT))
            return original.call(daemon, params, invocation);

        let sender = invocation.get_sender();
        if (sender === this._proxyOwner)
            sender = stringHint(hints, SENDER_HINT) ?? sender;
        const reply = {
            label,
            placeholder: stringHint(hints, PLACEHOLDER_HINT) ?? label,
            submit: stringHint(hints, SUBMIT_HINT) ?? _('Send'),
            id: 0,
            send: text => {
                if (!reply.id)
                    return;
                emitSignalToDestination(daemon._dbusImpl, sender,
                    'NotificationReplied', new GLib.Variant('(us)', [reply.id, text]));
            },
        };

        const proto = MessageTray.Notification.prototype;
        const addAction = proto.addAction;
        let added = 0;
        const self = this;
        proto.addAction = function (actionLabel, callback) {
            if (added++ !== replyIndex)
                return addAction.call(this, actionLabel, callback);
            // Messages already showing this notification tag it as
            // action-added reaches them; later ones find the tag.
            self._tagging = reply;
            try {
                const action = addAction.call(this, actionLabel, callback);
                action._duskReply = reply;
                return action;
            } finally {
                self._tagging = null;
            }
        };
        try {
            return original.call(daemon, params, invocation);
        } finally {
            proto.addAction = addAction;
            for (const [id, notification] of daemon._notifications) {
                if (notification.actions.some(a => a._duskReply === reply)) {
                    reply.id = id;
                    break;
                }
            }
        }
    }

    // Swaps the stock button (which invokes the action) for a Reply button
    // that opens the entry.
    _replaceButton(message, action) {
        const stock = message._actions?.get(action);
        const box = message._buttonBox;
        if (!stock || !box)
            return;

        const button = new St.Button({
            style_class: 'notification-button',
            x_expand: true,
            can_focus: true,
            label: action.label,
        });
        if (Main.sessionMode.isLocked)
            button.connect('clicked', () => action.activate());
        else
            button.connect('clicked', () => this._openComposer(message, action));

        const index = box.get_children().indexOf(stock);
        stock.destroy();
        box.insert_child_at_index(button, index);
        message._actions.set(action, button);
        button.connect('destroy', () => message._duskComposer?.duskClose());
    }

    _openComposer(message, action) {
        if (message._duskComposer)
            return;
        const reply = action._duskReply;
        const box = message._buttonBox;
        const hidden = box.get_children().filter(child => child.visible);
        hidden.forEach(child => child.hide());

        const composer = new St.BoxLayout({
            style_class: 'dusk-reply',
            x_expand: true,
            reactive: true,
            track_hover: true,
        });
        const entry = new St.Entry({
            style_class: 'dusk-reply-entry',
            hint_text: reply.placeholder,
            can_focus: true,
            x_expand: true,
            y_align: Clutter.ActorAlign.CENTER,
        });
        const send = new St.Button({
            style_class: 'notification-button dusk-reply-send',
            label: reply.submit,
            can_focus: true,
            reactive: false,
            y_align: Clutter.ActorAlign.CENTER,
        });
        composer.add_child(entry);
        composer.add_child(send);
        box.add_child(composer);

        const tray = Main.messageTray;
        const inBanner = tray._banner === message;

        let gone = false;
        const forget = () => {
            message._duskComposer = null;
            message._duskReplying = false;
            this._composers.delete(close);
        };
        // The message (and the row with it) can go first: a banner that
        // hides, a notification the app withdraws
        composer.connect('destroy', () => {
            gone = true;
            forget();
        });
        const close = () => {
            if (gone)
                return;
            gone = true;
            forget();
            composer.destroy();
            hidden.forEach(child => child.show());
            if (inBanner && tray._banner === message) {
                // Let the banner go as usual if the pointer is gone
                tray._pointerInNotification = tray._bannerBin?.hover ?? false;
                tray._updateNotificationTimeout?.(2000);
                tray._updateState();
            }
        };
        const submit = () => {
            const text = entry.get_text();
            if (!text.trim())
                return;
            const notification = message.notification;
            reply.send(text);
            close();
            if (notification && !notification.resident)
                notification.destroy(MessageTray.NotificationDestroyedReason.DISMISSED);
        };

        entry.clutter_text.connect('text-changed', () => {
            send.reactive = !!entry.get_text().trim();
            if (send.reactive)
                send.remove_style_pseudo_class('insensitive');
            else
                send.add_style_pseudo_class('insensitive');
        });
        send.add_style_pseudo_class('insensitive');
        entry.clutter_text.connect('activate', submit);
        entry.clutter_text.connect('key-press-event', (_actor, event) => {
            if (event.get_key_symbol() !== Clutter.KEY_Escape)
                return Clutter.EVENT_PROPAGATE;
            close();
            return Clutter.EVENT_STOP;
        });
        send.connect('clicked', submit);

        // A click in the entry row is not a click on the notification
        if (!message._duskClickGuard) {
            message._duskClickGuard = message.connect('clicked', () => {
                if (message._duskComposer?.hover)
                    GObject.signal_stop_emission_by_name(message, 'clicked');
            });
        }

        message._duskComposer = composer;
        composer.duskClose = close;
        message._duskReplying = inBanner;
        this._composers.add(close);
        // The banner's focus grab gives the keyboard back to the window
        // that had it once the banner hides
        if (inBanner)
            tray._ensureBannerFocused?.();
        entry.grab_key_focus();
    }

    destroy() {
        if (this._proxyWatch)
            Gio.bus_unwatch_name(this._proxyWatch);
        this._proxyWatch = 0;
        for (const close of [...(this._composers ?? [])])
            close();
        this._composers?.clear();
        this._injections?.clear();
        this._injections = null;
        this._daemon = null;
    }
}
