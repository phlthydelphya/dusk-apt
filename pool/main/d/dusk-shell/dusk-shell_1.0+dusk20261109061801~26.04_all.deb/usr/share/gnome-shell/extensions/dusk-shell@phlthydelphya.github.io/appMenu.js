import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Pango from 'gi://Pango';
import Shell from 'gi://Shell';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {AppMenu as ShellAppMenu} from 'resource:///org/gnome/shell/ui/appMenu.js';
import {ensureActorVisibleInScrollView} from 'resource:///org/gnome/shell/misc/animationUtils.js';
import {gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

import {Acrylic} from './acrylic.js';
import {resolveFolder} from './folders.js';
import {uninstallMethod} from './uninstall.js';
import {OPEN_TIME, CLOSE_TIME, OPEN_MODE, CLOSE_MODE, timing} from './motion.js';

// Logical pixels; spacing inside the card comes from the stylesheet
// Sized together, 125% of the previous 416x624 menu
const MENU_WIDTH = 520;
const MENU_HEIGHT = 780;
const SCREEN_GAP = 12; // $gap-m
const RISE = 24;
// Content settling in after a view, folder or drawer change: a short fade
// with a small drift (logical px) from where it came from
const SETTLE_TIME = 220;
const SETTLE_MODE = Clutter.AnimationMode.EASE_OUT_CUBIC;
const SETTLE_DRIFT = 12;

const GRID_COLUMNS = 4;
const GRID_ICON_SIZE = 56;
const GRID_SPACING = 4; // logical px between cells
const LETTER_COLUMNS = 6;
// A category folder's preview: its first apps' icons, 2x2
const PREVIEW_ICONS = 4;
const PREVIEW_ICON_SIZE = 24;
// The app-menu-view key: auto-made category folders, the A-Z grid packed,
// the A-Z list (tiles under letter headers, with the letter index)
const VIEWS = [
    ['categories', 'folder-symbolic'],
    ['grid', 'view-app-grid-symbolic'],
    ['list', 'view-list-symbolic'],
];
// '#' for names that start with anything but a letter, as Windows does
const LETTERS = ['#', ...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'];

const DUSK_SHELL_UUID = 'dusk-shell@phlthydelphya.github.io';
// The footer's extension manager: Extension Manager, else GNOME's Extensions
const EXTENSION_APPS = ['com.mattjakeman.ExtensionManager.desktop', 'org.gnome.Shell.Extensions.desktop',
    'org.gnome.Extensions.desktop'];

const MODIFIERS = Clutter.ModifierType.CONTROL_MASK |
    Clutter.ModifierType.MOD1_MASK |
    Clutter.ModifierType.MOD4_MASK |
    Clutter.ModifierType.SUPER_MASK;

// The index letter of an app: its name's first letter without accents
function letterOf(app) {
    const ch = app.get_name().normalize('NFD').replace(/[\u0300-\u036f]/g, '').charAt(0).toUpperCase();
    return /^[A-Z]$/.test(ch) ? ch : '#';
}

// app-drawers: [{name, apps: [app id, ...]}, ...]; anything malformed is dropped
function parseDrawers(json) {
    try {
        const list = JSON.parse(json);
        if (!Array.isArray(list))
            return [];
        return list
            .filter(d => d && typeof d.name === 'string' && d.name.trim())
            .map(d => ({
                name: d.name.trim(),
                apps: Array.isArray(d.apps) ? d.apps.filter(a => typeof a === 'string') : [],
            }));
    } catch {
        return [];
    }
}

// Category folders, from the apps' freedesktop Categories; the first match
// wins, so Development;Utility is Development. Names are translated when
// shown (gettext needs the extension's context).
const CATEGORIES = [
    ['internet', 'Internet', ['Network', 'WebBrowser', 'Email', 'Chat', 'InstantMessaging']],
    ['media', 'Media', ['AudioVideo', 'Audio', 'Video', 'Music', 'Player', 'Recorder']],
    ['graphics', 'Graphics', ['Graphics', 'Photography', '2DGraphics', '3DGraphics']],
    ['office', 'Office', ['Office', 'WordProcessor', 'Spreadsheet', 'Presentation', 'Calendar',
        'ContactManagement', 'Viewer']],
    ['games', 'Games', ['Game']],
    ['development', 'Development', ['Development', 'IDE', 'Building', 'Debugger']],
    ['education', 'Education & Science', ['Education', 'Science']],
    ['system', 'System', ['System', 'Settings', 'Monitor', 'PackageManager', 'HardwareSettings',
        'DesktopSettings', 'Security', 'TerminalEmulator']],
    ['utilities', 'Utilities', ['Utility', 'Accessories', 'TextEditor', 'FileManager', 'Archiving',
        'Calculator', 'Clock', 'Core']],
];
const OTHER = ['other', 'Other'];

function categoryOf(app) {
    const cats = new Set((app.get_app_info()?.get_categories?.() ?? '').split(';').filter(c => c));
    const hit = CATEGORIES.find(([, , names]) => names.some(n => cats.has(n)));
    return hit ? hit[0] : OTHER[0];
}

function searchText(app) {
    const info = app.get_app_info();
    return [
        app.get_name(),
        info?.get_generic_name?.(),
        ...info?.get_keywords?.() ?? [],
        app.get_id(),
        info?.get_executable?.(),
    ].filter(s => s).join('\n').toLowerCase();
}

export class AppMenu {
    constructor(settings) {
        this._settings = settings;
        this._isOpen = false;
        this._grab = null;
        this._anchor = null;
        this._closedAt = 0;
        this._appsDirty = true;
        this._foldersDirty = true;

        this._appSys = Shell.AppSystem.get_default();

        // Custom drawers (app-drawers) and the one shown; null: All apps
        this._drawers = parseDrawers(this._settings.get_string('app-drawers'));
        this._drawer = null;
        this._tabMenu = null;
        this._editing = null; // the inline name entry of a new or renamed drawer
        // Letter index: header per letter in the current list
        this._headers = new Map();

        // How All is shown (app-menu-view), and the category folder open in it
        this._view = this._viewSetting();
        this._pane = null;
        // Category folders: [{id, name, items, tile}]
        this._categories = [];

        // app id → {app, tile, text}
        this._apps = new Map();
        this._sorted = [];
        this._hits = [];
        this._bindings = [];

        this._buildUi();
        this._acrylic = new Acrylic(this._card);
        // Right-click menus on app tiles
        this._menuManager = new PopupMenu.PopupMenuManager(this.actor);
        this._contextMenu = null;

        global.focus_manager.add_group(this.actor);
        Main.layoutManager.addTopChrome(this.actor);

        this._signals = [
            [this._appSys, this._appSys.connect('installed-changed', () => {
                this._appsDirty = true;
                if (this._isOpen)
                    this._refresh();
            })],
            [this._settings, this._settings.connect('changed::quick-folders', () => {
                this._foldersDirty = true;
            })],
            [this._settings, this._settings.connect('changed::app-menu-view', () => {
                this._view = this._viewSetting();
                this._pane = null;
                this._syncViewButtons();
                if (this._isOpen) {
                    this._showLetters(false);
                    this._filter();
                    this._settle(this._scroll, 0, SETTLE_DRIFT);
                }
            })],
            [this._settings, this._settings.connect('changed::app-drawers', () => {
                this._drawers = parseDrawers(this._settings.get_string('app-drawers'));
                if (this._drawer !== null && this._drawer >= this._drawers.length)
                    this._drawer = null;
                this._buildTabs();
                if (this._isOpen)
                    this._filter();
            })],
            [Main.layoutManager, Main.layoutManager.connect('monitors-changed', () => this.close(false))],
            [Main.sessionMode, Main.sessionMode.connect('updated', () => {
                if (Main.sessionMode.isLocked)
                    this.close(false);
            })],
            [Main.overview, Main.overview.connect('showing', () => this.close(false))],
        ];
    }

    get isOpen() {
        return this._isOpen;
    }

    // Super released right after a close must not reopen the menu
    get recentlyClosed() {
        return GLib.get_monotonic_time() - this._closedAt < 300 * 1000;
    }

    _buildUi() {
        // Full-stage backdrop: takes the modal grab and the outside clicks
        this.actor = new St.Widget({
            name: 'duskAppMenuBackdrop',
            reactive: true,
            visible: false,
        });

        this._card = new St.BoxLayout({
            style_class: 'dusk-app-menu',
            orientation: Clutter.Orientation.VERTICAL,
            reactive: true,
        });
        this.actor.add_child(this._card);

        this._entry = new St.Entry({
            style_class: 'dusk-app-menu-search',
            hint_text: _('Search apps'),
            can_focus: true,
            // A notch hanging from the card's top edge, centered (the
            // top-bar search's shape)
            x_align: Clutter.ActorAlign.CENTER,
            primary_icon: new St.Icon({
                icon_name: 'edit-find-symbolic',
                style_class: 'dusk-app-menu-search-icon',
            }),
        });
        this._text = this._entry.clutter_text;
        this._text.connect('text-changed', () => this._filter());
        this._text.connect('activate', () => this._activateFirst());
        this._card.add_child(this._entry);

        // Drawers: All, the user's own, and + to make one
        this._tabs = new St.BoxLayout({style_class: 'dusk-app-menu-tabs', x_expand: true});
        this._tabScroll = new St.ScrollView({
            style_class: 'dusk-app-menu-tabs-scroll',
            x_expand: true,
            overlay_scrollbars: true,
            hscrollbar_policy: St.PolicyType.EXTERNAL,
            vscrollbar_policy: St.PolicyType.NEVER,
            child: this._tabs,
        });
        // Drawer tabs on the left, the view switcher on the right
        const tabRow = new St.BoxLayout({style_class: 'dusk-app-menu-tab-row', x_expand: true});
        tabRow.add_child(this._tabScroll);
        const views = new St.BoxLayout({style_class: 'dusk-app-menu-views'});
        const names = {categories: _('Categories'), grid: _('Grid'), list: _('List')};
        this._viewButtons = new Map();
        for (const [view, icon] of VIEWS) {
            const button = new St.Button({
                style_class: 'dusk-app-menu-view',
                can_focus: true,
                accessible_name: names[view],
                child: new St.Icon({icon_name: icon, icon_size: 16}),
            });
            button.connect('clicked', () => this._settings.set_string('app-menu-view', view));
            views.add_child(button);
            this._viewButtons.set(view, button);
        }
        tabRow.add_child(views);
        this._card.add_child(tabRow);
        this._buildTabs();
        this._syncViewButtons();

        // An open category folder: back, and its name
        this._paneHeader = new St.BoxLayout({style_class: 'dusk-app-menu-pane-header', visible: false});
        const back = new St.Button({
            style_class: 'dusk-app-menu-pane-back',
            can_focus: true,
            accessible_name: _('Back'),
            child: new St.Icon({icon_name: 'go-previous-symbolic', icon_size: 16}),
        });
        back.connect('clicked', () => this._openPane(null));
        this._paneHeader.add_child(back);
        this._paneTitle = new St.Label({
            style_class: 'dusk-app-menu-pane-title',
            y_align: Clutter.ActorAlign.CENTER,
        });
        this._paneHeader.add_child(this._paneTitle);
        this._card.add_child(this._paneHeader);

        this._gridLayout = new Clutter.GridLayout({
            column_homogeneous: true,
            column_spacing: GRID_SPACING * St.ThemeContext.get_for_stage(global.stage).scale_factor,
            row_spacing: GRID_SPACING * St.ThemeContext.get_for_stage(global.stage).scale_factor,
        });
        // ScrollView needs an StScrollable child
        this._grid = new St.Viewport({
            style_class: 'dusk-app-menu-grid',
            layout_manager: this._gridLayout,
            x_expand: true,
        });
        this._scroll = new St.ScrollView({
            style_class: 'dusk-app-menu-scroll vfade',
            x_expand: true,
            y_expand: true,
            overlay_scrollbars: true,
            hscrollbar_policy: St.PolicyType.NEVER,
            // Scrolls by wheel/touchpad/keys; no visible scrollbar (Dusk hides them)
            vscrollbar_policy: St.PolicyType.EXTERNAL,
            child: this._grid,
        });
        this._card.add_child(this._scroll);

        // The letter index (a letter header opens it), in place of the list
        this._lettersLayout = new Clutter.GridLayout({column_homogeneous: true, row_homogeneous: true});
        this._letters = new St.Widget({
            style_class: 'dusk-app-menu-letters',
            layout_manager: this._lettersLayout,
            x_expand: true,
            y_expand: true,
            visible: false,
        });
        this._letterButtons = new Map();
        LETTERS.forEach((letter, i) => {
            const button = new St.Button({
                style_class: 'dusk-app-menu-letter-button',
                label: letter,
                can_focus: true,
                x_expand: true,
                y_expand: true,
            });
            button.connect('clicked', () => this._jumpTo(letter));
            this._lettersLayout.attach(button, i % LETTER_COLUMNS, Math.floor(i / LETTER_COLUMNS), 1, 1);
            this._letterButtons.set(letter, button);
        });
        this._card.add_child(this._letters);

        this._noResults = new St.Label({
            style_class: 'dusk-app-menu-empty',
            text: _('No apps found'),
            x_align: Clutter.ActorAlign.CENTER,
            visible: false,
        });
        this._card.add_child(this._noResults);

        const footer = new St.BoxLayout({style_class: 'dusk-app-menu-footer'});
        this._folders = new St.BoxLayout({
            style_class: 'dusk-app-menu-folders',
            x_expand: true,
        });
        footer.add_child(this._folders);

        // Dusk Shell's settings and the extension manager (power, lock and log
        // out live in Quick Settings)
        const tools = new St.BoxLayout({style_class: 'dusk-app-menu-power'});
        tools.add_child(this._footerButton('emblem-system-symbolic', _('Dusk Shell Settings'), () => {
            this.close(false);
            try {
                Main.extensionManager.openExtensionPrefs(DUSK_SHELL_UUID, '', {});
            } catch (e) {
                Main.notifyError(_('Could not open Dusk Shell settings'), e.message);
            }
        }));
        this._extensionsButton = this._footerButton('application-x-addon-symbolic', _('Extensions'), () => {
            const app = this._extensionsApp();
            if (app)
                this._launch(app);
        });
        tools.add_child(this._extensionsButton);
        footer.add_child(tools);
        this._card.add_child(footer);

        // Clicks on the backdrop, not on the card
        const click = new Clutter.ClickGesture();
        click.connect('may-recognize', () => {
            const event = click.get_point_event(0);
            return global.stage.get_event_actor(event) === this.actor;
        });
        click.connect('recognize', () => this.close());
        this.actor.add_action(click);

        // Capture phase, so Escape and arrows win over the entry and buttons
        const keys = new Clutter.KeyController();
        keys.connect('key-press', () => this._onKeyPress(keys));
        this.actor.add_action_full('dusk-app-menu-keys', Clutter.EventPhase.CAPTURE, keys);
    }

    destroy() {
        this.close(false);
        this._contextMenu?.destroy();
        this._contextMenu = null;
        this._tabMenu?.destroy();
        this._tabMenu = null;
        for (const [object, id] of this._signals)
            object.disconnect(id);
        this._signals = [];
        for (const binding of this._bindings)
            binding.unbind();
        this._bindings = [];
        this._acrylic.destroy();
        this._acrylic = null;
        global.focus_manager.remove_group(this.actor);
        Main.layoutManager.removeChrome(this.actor);
        this.actor.destroy();
        this._apps.clear();
        this._sorted = [];
        this._hits = [];
    }

    // Builds the lists ahead of time, so the first open doesn't stutter
    prepare() {
        this._refresh();
    }

    toggle(anchor = null) {
        if (this._isOpen)
            this.close();
        else
            this.open(anchor);
    }

    open(anchor = null) {
        if (this._isOpen || Main.sessionMode.isLocked)
            return;

        this._refresh();
        this._entry.text = '';
        this._pane = null;
        this._showLetters(false);
        this._extensionsButton.visible = this._extensionsApp() !== null;
        this._filter();

        this._anchor = anchor;
        this._layout();

        this._grab = Main.pushModal(this.actor, {actionMode: Shell.ActionMode.POPUP});
        this._isOpen = true;

        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        this._card.remove_all_transitions();
        this._card.opacity = 0;
        this._card.translation_y = RISE * scale;
        this._acrylic.start();
        this.actor.show();
        this._entry.grab_key_focus();

        this._card.ease({
            opacity: 255,
            translation_y: 0,
            duration: timing(OPEN_TIME),
            mode: OPEN_MODE,
        });
    }

    close(animate = true) {
        if (!this._isOpen)
            return;
        this._isOpen = false;
        this._closedAt = GLib.get_monotonic_time();
        this._anchor = null;
        this._contextMenu?.close();
        this._tabMenu?.close();
        this._endEdit(false);

        // Give input back right away, before the fade finishes
        if (this._grab) {
            Main.popModal(this._grab);
            this._grab = null;
        }

        const done = () => {
            // Reopened while fading out
            if (this._isOpen)
                return;
            this.actor.hide();
            this._acrylic.stop();
            this._card.translation_y = 0;
            this._entry.text = '';
        };

        if (!animate) {
            this._card.remove_all_transitions();
            done();
            return;
        }

        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        this._card.ease({
            opacity: 0,
            translation_y: RISE * scale,
            duration: timing(CLOSE_TIME),
            mode: CLOSE_MODE,
            onStopped: done,
        });
    }

    // Above the start button when there is one, else bottom-center
    _layout() {
        this.actor.set_position(0, 0);
        this.actor.set_size(global.stage.width, global.stage.height);

        const layout = Main.layoutManager;
        const anchor = this._anchor?.mapped ? this._anchor : null;
        const index = anchor ? layout.findIndexForActor(anchor) : layout.primaryIndex;
        const monitor = layout.monitors[index];
        const area = layout.getWorkAreaForMonitor(index);

        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        const gap = SCREEN_GAP * scale;
        const width = Math.min(MENU_WIDTH * scale, area.width - 2 * gap);
        let height = Math.min(MENU_HEIGHT * scale, area.height - 2 * gap);

        let x, bottom;
        if (anchor) {
            // Centered over the start button, clamped to the monitor below
            const [ax, ay] = anchor.get_transformed_position();
            const [aw] = anchor.get_transformed_size();
            x = ax + (aw - width) / 2;
            bottom = ay - gap;
        } else {
            x = area.x + (area.width - width) / 2;
            bottom = area.y + area.height - gap;
        }
        x = Math.max(monitor.x + gap, Math.min(x, monitor.x + monitor.width - width - gap));
        // An autohidden dock sits below the screen edge
        bottom = Math.min(bottom, monitor.y + monitor.height - gap);
        height = Math.min(height, bottom - (area.y + gap));

        this._card.set_position(Math.round(x), Math.round(bottom - height));
        this._card.set_size(Math.round(width), Math.round(height));
    }

    _refresh() {
        if (this._appsDirty)
            this._loadApps();
        if (this._foldersDirty)
            this._loadFolders();
    }

    _loadApps() {
        this._appsDirty = false;

        const seen = new Set();
        for (const info of this._appSys.get_installed()) {
            let show = false;
            try {
                show = info.should_show();
            } catch {
                // Broken .desktop files throw; skip them
            }
            const app = show ? this._appSys.lookup_app(info.get_id()) : null;
            if (!app)
                continue;
            const id = app.get_id();
            seen.add(id);
            if (!this._apps.has(id)) {
                this._apps.set(id, {
                    app,
                    tile: this._appTile(app),
                    text: searchText(app),
                });
            }
        }

        for (const [id, item] of this._apps) {
            if (!seen.has(id)) {
                item.tile.destroy();
                this._apps.delete(id);
            }
        }

        this._sorted = [...this._apps.values()].sort((a, b) =>
            a.app.get_name().localeCompare(b.app.get_name()));
        this._buildCategories();
        this._filter();
    }

    _buildCategories() {
        for (const cat of this._categories)
            cat.tile.destroy();
        const byId = new Map();
        for (const item of this._sorted) {
            const id = categoryOf(item.app);
            if (!byId.has(id))
                byId.set(id, []);
            byId.get(id).push(item);
        }
        this._categories = [...CATEGORIES, OTHER]
            .filter(([id]) => byId.has(id))
            .map(([id, name]) => {
                const cat = {id, name: _(name), items: byId.get(id)};
                cat.tile = this._folderTile(cat);
                return cat;
            });
        if (this._pane && !byId.has(this._pane))
            this._pane = null;
    }

    _folderTile(cat) {
        const previewLayout = new Clutter.GridLayout({column_homogeneous: true, row_homogeneous: true});
        const preview = new St.Widget({
            style_class: 'dusk-app-menu-folder-preview',
            layout_manager: previewLayout,
            x_align: Clutter.ActorAlign.CENTER,
        });
        cat.items.slice(0, PREVIEW_ICONS).forEach((item, i) => {
            const icon = item.app.create_icon_texture(PREVIEW_ICON_SIZE);
            icon.x_align = icon.y_align = Clutter.ActorAlign.CENTER;
            previewLayout.attach(icon, i % 2, Math.floor(i / 2), 1, 1);
        });
        const box = new St.BoxLayout({
            style_class: 'dusk-app-menu-tile-box',
            orientation: Clutter.Orientation.VERTICAL,
        });
        box.add_child(preview);
        box.add_child(this._tileLabel(cat.name));
        const tile = new St.Button({
            style_class: 'dusk-app-menu-tile dusk-app-menu-folder',
            can_focus: true,
            x_expand: true,
            accessible_name: cat.name,
            child: box,
        });
        tile.connect('clicked', () => this._openPane(cat.id));
        tile.connect('key-focus-in', () => ensureActorVisibleInScrollView(this._scroll, tile));
        return tile;
    }

    // Opens a category folder in the menu's pane; null goes back to the folders
    _openPane(id) {
        const from = this._pane;
        this._pane = id;
        this._filter();
        const drift = (id ? SETTLE_DRIFT : -SETTLE_DRIFT);
        this._settle(this._scroll, drift, 0);
        if (id)
            this._settle(this._paneHeader, drift, 0);
        const target = id
            ? this._hits[0]?.tile
            : this._categories.find(c => c.id === from)?.tile;
        target?.grab_key_focus();
    }

    _viewSetting() {
        const view = this._settings.get_string('app-menu-view');
        return VIEWS.some(([v]) => v === view) ? view : 'categories';
    }

    _syncViewButtons() {
        for (const [view, button] of this._viewButtons ?? [])
            button.checked = view === this._view;
    }

    // Tiles and folders stay alive between filters; only their grid cells
    // change. `mode`: 'grid' (app tiles) or 'folders' (category folders).
    // With `headers`, each new first letter starts a row under a letter
    // header (click one for the letter index).
    _layoutGrid(items, mode = 'grid', headers = false) {
        for (const header of this._headers.values())
            header.destroy();
        this._headers.clear();
        this._grid.remove_all_children();
        this._grid.set_style_class_name(`dusk-app-menu-grid dusk-app-menu-${mode}`);
        let row = 0, col = 0, current = null;
        for (const item of items) {
            if (headers) {
                const letter = letterOf(item.app);
                if (letter !== current) {
                    if (col) {
                        row++;
                        col = 0;
                    }
                    const header = new St.Button({
                        style_class: 'dusk-app-menu-letter',
                        label: letter,
                        can_focus: true,
                        x_align: Clutter.ActorAlign.START,
                        accessible_name: _('Jump to a letter'),
                    });
                    header.connect('clicked', () => this._showLetters(true));
                    header.connect('key-focus-in', () => ensureActorVisibleInScrollView(this._scroll, header));
                    this._gridLayout.attach(header, 0, row, GRID_COLUMNS, 1);
                    this._headers.set(letter, header);
                    current = letter;
                    row++;
                }
            }
            this._gridLayout.attach(item.tile, col, row, 1, 1);
            if (++col === GRID_COLUMNS) {
                col = 0;
                row++;
            }
        }
    }

    // The letter index in place of the list: letters with apps are live
    _showLetters(show) {
        const changed = this._letters.visible !== show;
        this._letters.visible = show;
        this._scroll.visible = !show;
        if (changed)
            this._settle(show ? this._letters : this._scroll, 0, show ? -SETTLE_DRIFT : SETTLE_DRIFT);
        if (!show)
            return;
        let first = null;
        for (const [letter, button] of this._letterButtons) {
            const live = this._headers.has(letter);
            button.reactive = live;
            button.can_focus = live;
            if (live)
                button.remove_style_pseudo_class('insensitive');
            else
                button.add_style_pseudo_class('insensitive');
            first ??= live ? button : null;
        }
        first?.grab_key_focus();
    }

    _jumpTo(letter) {
        this._showLetters(false);
        const header = this._headers.get(letter);
        if (!header)
            return;
        // After the list is shown again and laid out
        GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
            const [, y] = header.get_position();
            this._scroll.vadjustment.value = y;
            header.grab_key_focus();
            return GLib.SOURCE_REMOVE;
        });
    }

    // ---- drawers

    _saveDrawers() {
        this._settings.set_string('app-drawers', JSON.stringify(this._drawers));
    }

    _buildTabs() {
        this._tabs.destroy_all_children();
        const tab = (label, index) => {
            const button = new St.Button({
                style_class: 'dusk-app-menu-tab',
                label,
                can_focus: true,
                toggle_mode: false,
                checked: this._drawer === index,
            });
            button.connect('clicked', () => this._selectDrawer(index));
            if (index !== null) {
                const rightClick = new Clutter.ClickGesture({
                    required_button: Clutter.BUTTON_SECONDARY,
                    recognize_on_press: true,
                });
                rightClick.connect('recognize', () => this._popupTabMenu(button, index));
                button.add_action(rightClick);
                button.connect('popup-menu', () => this._popupTabMenu(button, index));
            }
            return button;
        };
        this._tabs.add_child(tab(_('All'), null));
        this._drawers.forEach((d, i) => this._tabs.add_child(tab(d.name, i)));
        const add = new St.Button({
            style_class: 'dusk-app-menu-tab dusk-app-menu-tab-add',
            can_focus: true,
            accessible_name: _('New Drawer'),
            child: new St.Icon({icon_name: 'list-add-symbolic'}),
        });
        add.connect('clicked', () => this._beginEdit(null));
        this._tabs.add_child(add);
        this._addTab = add;
    }

    _selectDrawer(index) {
        this._drawer = index;
        this._pane = null;
        this._entry.text = '';
        this._showLetters(false);
        this._buildTabs();
        this._filter();
        this._settle(this._scroll, 0, SETTLE_DRIFT);
    }

    // Fades `actor` in from a small drift (logical px); instant with
    // reduced motion. Only while open: open() has its own rise.
    _settle(actor, dx, dy) {
        actor.remove_all_transitions();
        if (!this._isOpen || !actor.visible) {
            actor.opacity = 255;
            actor.translation_x = actor.translation_y = 0;
            return;
        }
        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        actor.opacity = 0;
        actor.translation_x = dx * scale;
        actor.translation_y = dy * scale;
        actor.ease({
            opacity: 255,
            translation_x: 0,
            translation_y: 0,
            duration: timing(SETTLE_TIME),
            mode: SETTLE_MODE,
        });
    }

    // Right-click on a drawer's tab: Rename, Delete
    _popupTabMenu(button, index) {
        if (this._tabMenu || !this._isOpen)
            return;
        const menu = new PopupMenu.PopupMenu(button, 0.5, St.Side.TOP);
        menu.actor.add_style_class_name('dusk-app-menu-context');
        menu.addAction(_('Rename…'), () => this._beginEdit(index));
        menu.addAction(_('Delete Drawer'), () => {
            this._drawers.splice(index, 1);
            if (this._drawer === index)
                this._drawer = null;
            else if (this._drawer !== null && this._drawer > index)
                this._drawer--;
            this._saveDrawers();
        });
        this._tabMenu = menu;
        Main.uiGroup.add_child(menu.actor);
        this._menuManager.addMenu(menu);
        menu.connect('open-state-changed', (_m, open) => {
            if (!open)
                this._tabMenu = null;
        });
        menu.connect('menu-closed', () => {
            GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                menu.destroy();
                return GLib.SOURCE_REMOVE;
            });
        });
        menu.open();
    }

    // An entry in the tab row to name a drawer: a new one (index null,
    // optionally with an app in it), or rename one. Enter saves, Escape or
    // leaving it cancels.
    _beginEdit(index, withApp = null) {
        this._endEdit(false);
        const entry = new St.Entry({
            style_class: 'dusk-app-menu-tab-entry',
            hint_text: _('Drawer name'),
            text: index === null ? '' : this._drawers[index].name,
            can_focus: true,
        });
        const at = index === null ? this._tabs.get_children().indexOf(this._addTab) : index + 1;
        this._tabs.insert_child_at_index(entry, at);
        if (index !== null)
            this._tabs.get_child_at_index(at + 1)?.hide();
        else
            this._addTab.hide();
        this._editing = {entry, index, withApp};
        entry.clutter_text.connect('activate', () => this._endEdit(true));
        entry.clutter_text.connect('key-focus-out', () => {
            GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                if (this._editing?.entry === entry)
                    this._endEdit(false);
                return GLib.SOURCE_REMOVE;
            });
        });
        entry.grab_key_focus();
        entry.clutter_text.set_selection(0, -1);
    }

    _endEdit(save) {
        const edit = this._editing;
        if (!edit)
            return;
        this._editing = null;
        const name = edit.entry.text.trim();
        if (save && name) {
            if (edit.index === null) {
                this._drawers.push({name, apps: edit.withApp ? [edit.withApp] : []});
                this._drawer = this._drawers.length - 1;
            } else {
                this._drawers[edit.index].name = name;
            }
            this._saveDrawers();
            // Also when nothing changed (the same name): no changed signal then
            this._buildTabs();
            this._filter();
            this._entry.grab_key_focus();
            return;
        }
        this._buildTabs();
        this._entry.grab_key_focus();
    }

    _toggleInDrawer(index, appId) {
        const apps = this._drawers[index].apps;
        const at = apps.indexOf(appId);
        if (at >= 0)
            apps.splice(at, 1);
        else
            apps.push(appId);
        this._saveDrawers();
    }

    _extensionsApp() {
        for (const id of EXTENSION_APPS) {
            const app = this._appSys.lookup_app(id);
            if (app)
                return app;
        }
        return null;
    }

    _loadFolders() {
        this._foldersDirty = false;
        this._folders.destroy_all_children();

        for (const entry of this._settings.get_strv('quick-folders')) {
            const folder = resolveFolder(entry);
            if (!folder)
                continue;
            this._folders.add_child(this._footerButton(folder.icon, folder.label,
                () => this._openFolder(folder.path)));
        }
    }

    _appTile(app) {
        const box = new St.BoxLayout({
            style_class: 'dusk-app-menu-tile-box',
            orientation: Clutter.Orientation.VERTICAL,
        });
        box.add_child(app.create_icon_texture(GRID_ICON_SIZE));
        box.add_child(this._tileLabel(app.get_name()));

        const tile = new St.Button({
            style_class: 'dusk-app-menu-tile',
            can_focus: true,
            x_expand: true,
            accessible_name: app.get_name(),
            child: box,
        });
        return this._wireApp(tile, app);
    }

    // One line under a tile's icon, ellipsized; the full name is the
    // tile's accessible name
    _tileLabel(text) {
        const label = new St.Label({
            style_class: 'dusk-app-menu-tile-label',
            text,
            x_align: Clutter.ActorAlign.CENTER,
        });
        label.clutter_text.ellipsize = Pango.EllipsizeMode.END;
        return label;
    }

    // Launch on click; the app's context menu on right-click, long-press,
    // Menu key or Shift+F10
    _wireApp(tile, app) {
        tile.connect('clicked', () => this._launch(app));
        tile.connect('key-focus-in', () => ensureActorVisibleInScrollView(this._scroll, tile));

        // The app's context menu: right-click, long-press, Menu key/Shift+F10
        const rightClick = new Clutter.ClickGesture({
            required_button: Clutter.BUTTON_SECONDARY,
            recognize_on_press: true,
        });
        rightClick.connect('recognize', () => this._popupContextMenu(tile, app));
        tile.add_action(rightClick);
        const longPress = new Clutter.LongPressGesture();
        longPress.connect('recognize', () => this._popupContextMenu(tile, app));
        tile.add_action(longPress);
        tile.connect('popup-menu', () => {
            this._popupContextMenu(tile, app);
            this._contextMenu?.actor.navigate_focus(null, St.DirectionType.TAB_FORWARD, false);
        });
        return tile;
    }

    // The shell's own app menu (open windows, app actions, New Window, Pin to
    // Dock, App Details, Quit) plus Uninstall, as in the Launchpad extension
    _popupContextMenu(tile, app) {
        if (this._contextMenu || !this._isOpen)
            return;

        const menu = new ShellAppMenu(tile, St.Side.LEFT, {
            favoritesSection: true,
            showSingleWindows: true,
        });
        menu.setApp(app);
        menu.actor.add_style_class_name('dusk-app-menu-context');

        let afterClose = null;
        // Drawers: a check for each one the app is in; New Drawer… makes one
        // with it. These keep the app menu open.
        const stay = new Set();
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem(_('Drawers')));
        this._drawers.forEach((drawer, i) => {
            const item = menu.addAction(drawer.name, () => this._toggleInDrawer(i, app.get_id()));
            item.setOrnament(drawer.apps.includes(app.get_id())
                ? PopupMenu.Ornament.CHECK : PopupMenu.Ornament.NO_DOT);
            stay.add(item);
        });
        const newDrawer = menu.addAction(_('New Drawer…'), () => {
            afterClose = () => this._beginEdit(null, app.get_id());
        });
        stay.add(newDrawer);
        const uninstall = uninstallMethod(app);
        if (uninstall) {
            menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
            menu.addAction(uninstall.label, () => {
                afterClose = uninstall.run;
            });
        }

        // Pinning and quitting keep the app menu open; every other item opens
        // something, so the app menu gets out of its way
        let leave = false;
        menu.connect('activate', (_m, item) => {
            leave = item !== menu._toggleFavoriteItem && item !== menu._quitItem && !stay.has(item);
        });

        this._contextMenu = menu;
        Main.uiGroup.add_child(menu.actor);
        this._menuManager.addMenu(menu);
        // Connected after the manager's handler, so the menu's grab is
        // already gone when this runs
        menu.connect('open-state-changed', (_m, open) => {
            if (open)
                return;
            tile.checked = false;
            this._contextMenu = null;
            if (leave)
                this.close();
            afterClose?.();
        });
        // Destroy once the close animation is over, outside its callback
        menu.connect('menu-closed', () => {
            GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                menu.destroy();
                return GLib.SOURCE_REMOVE;
            });
        });

        tile.checked = true;
        menu.open();
    }

    _footerButton(iconName, name, callback) {
        const button = new St.Button({
            style_class: 'dusk-app-menu-footer-button',
            can_focus: true,
            accessible_name: name,
            child: new St.Icon({icon_name: iconName}),
        });
        button.connect('clicked', callback);
        return button;
    }

    _filter() {
        const query = this._entry.text.trim().toLowerCase();
        const searching = query !== '';

        if (searching && this._letters.visible)
            this._showLetters(false);
        const drawer = this._drawer === null ? null : this._drawers[this._drawer];
        // Category folders only in All, not while searching
        const folders = !searching && !drawer && this._view === 'categories';
        const pane = folders && this._pane
            ? this._categories.find(c => c.id === this._pane) : null;
        this._paneHeader.visible = !!pane;
        if (pane)
            this._paneTitle.text = pane.name;
        if (folders && !pane) {
            this._hits = [];
            this._layoutGrid(this._categories, 'folders');
            this._noResults.visible = false;
            this._scroll.vadjustment.value = 0;
            return;
        }
        if (pane) {
            this._hits = pane.items;
        } else if (!searching) {
            this._hits = drawer
                ? this._sorted.filter(item => drawer.apps.includes(item.app.get_id()))
                : this._sorted;
        } else {
            // Name prefix, then word start in the name, then anywhere
            const rank = item => {
                const name = item.app.get_name().toLowerCase();
                if (name.startsWith(query))
                    return 0;
                if (name.includes(` ${query}`))
                    return 1;
                if (name.includes(query))
                    return 2;
                return item.text.includes(query) ? 3 : -1;
            };
            this._hits = this._sorted
                .map(item => [rank(item), item])
                .filter(([r]) => r >= 0)
                .sort((a, b) => a[0] - b[0])
                .map(([, item]) => item);
        }
        // Search always covers every app; letter headers (and the letter
        // index) only in the A-Z list
        const list = this._view === 'list' && !pane;
        this._layoutGrid(this._hits, 'grid', list && !searching);

        this._noResults.text = searching ? _('No apps found')
            : _('This drawer is empty. Right-click an app in All to add it.');
        this._noResults.visible = this._hits.length === 0 && (searching || this._drawer !== null);
        this._scroll.vadjustment.value = 0;
    }

    _activateFirst() {
        const first = this._hits[0];
        if (first)
            this._launch(first.app);
    }

    _launch(app) {
        this.close();
        Main.overview.hide();
        app.activate();
    }

    _openFolder(path) {
        this.close();
        const uri = Gio.File.new_for_path(path).get_uri();
        try {
            Gio.AppInfo.launch_default_for_uri(uri,
                global.create_app_launch_context(0, -1));
        } catch (e) {
            Main.notifyError(_('Could not open folder'), e.message);
        }
    }

    _onKeyPress(keys) {
        const [, symbol] = keys.get_key();
        const [, state] = keys.get_state();
        const focus = global.stage.get_key_focus();
        // The search entry, or a drawer's name entry
        const inEntry = focus instanceof Clutter.Text;

        switch (symbol) {
        case Clutter.KEY_Escape:
            if (this._editing)
                this._endEdit(false);
            else if (this._letters.visible)
                this._showLetters(false);
            else if (this._entry.text === '' && this._pane && this._view === 'categories' &&
                     this._drawer === null)
                this._openPane(null);
            else if (this._entry.text !== '')
                this._entry.text = '';
            else
                this.close();
            return Clutter.EVENT_STOP;
        case Clutter.KEY_Super_L:
        case Clutter.KEY_Super_R:
            this.close();
            return Clutter.EVENT_STOP;
        case Clutter.KEY_Up:
        case Clutter.KEY_Down:
            this._navigate(focus, symbol === Clutter.KEY_Up
                ? St.DirectionType.UP : St.DirectionType.DOWN);
            return Clutter.EVENT_STOP;
        case Clutter.KEY_Left:
        case Clutter.KEY_Right:
            // In the entry they move the cursor
            if (inEntry)
                return Clutter.EVENT_PROPAGATE;
            this._navigate(focus, symbol === Clutter.KEY_Left
                ? St.DirectionType.LEFT : St.DirectionType.RIGHT);
            return Clutter.EVENT_STOP;
        case Clutter.KEY_BackSpace:
            if (!inEntry) {
                this._entry.grab_key_focus();
                this._entry.text = this._entry.text.slice(0, -1);
                return Clutter.EVENT_STOP;
            }
            return Clutter.EVENT_PROPAGATE;
        }

        // Typing while a tile has focus goes to the search entry
        if (!inEntry && (state & MODIFIERS) === 0) {
            const ch = Clutter.keysym_to_unicode(symbol);
            if (ch > 0x20 && ch !== 0x7f) {
                this._entry.grab_key_focus();
                this._entry.text += String.fromCodePoint(ch);
                this._text.set_cursor_position(-1);
                return Clutter.EVENT_STOP;
            }
        }
        return Clutter.EVENT_PROPAGATE;
    }

    _navigate(focus, direction) {
        let from = this._card.contains(focus) ? focus : null;
        if (from === this._text)
            from = this._entry;
        if (!this._card.navigate_focus(from, direction, false) &&
            direction === St.DirectionType.UP)
            this._entry.grab_key_focus();
    }
}
