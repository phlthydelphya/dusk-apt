import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {Panel} from 'resource:///org/gnome/shell/ui/panel.js';
import {InjectionManager} from 'resource:///org/gnome/shell/extensions/extension.js';

import {setArrangerActive} from './panelLayout.js';

import {BOXES, arrange, layoutId, parseLayout, roleLabel} from './panelArrangerCommon.js';

const LOG_PREFIX = 'panel-arranger:';

const SPACING_KEYS = {left: 'left-spacing', center: 'center-spacing', right: 'right-spacing'};
// Without anything to measure on the left, even spacing uses this gap
const FALLBACK_GAP = 12;
// Even spacing corrects the gaps from what was drawn; a few passes settle it
const EVEN_MAX_PASSES = 8;
// Smallest padding even spacing gives an item, each side of its content
const TAB_PAD = 6;

// What the bar actually draws inside an item: icons, labels, and widgets
// with nothing inside them (the notification dot)
function inkLeaves(actor) {
    if (!actor.visible)
        return [];
    if (actor instanceof St.Icon || actor instanceof St.Label)
        return [actor];
    const children = actor.get_children();
    if (!children.length)
        return [actor];
    return children.flatMap(inkLeaves);
}

// Stage-x span of an actor, or null when it is not drawn
function inkSpan(actor) {
    if (!actor.mapped || actor.width <= 0)
        return null;
    const [x] = actor.get_transformed_position();
    const [width] = actor.get_transformed_size();
    return [x, x + width];
}

// Drawn leaves of an actor, left to right, with their spans
function drawnLeaves(actor) {
    return inkLeaves(actor)
        .map(leaf => ({leaf, span: inkSpan(leaf)}))
        .filter(l => l.span)
        .sort((a, b) => a.span[0] - b.span[0]);
}

// The lowest St.BoxLayout holding both a and b, below `top`, or null
function sharedBox(a, b, top) {
    const above = new Set();
    for (let p = a.get_parent(); p && p !== top; p = p.get_parent())
        above.add(p);
    for (let p = b.get_parent(); p && p !== top; p = p.get_parent()) {
        if (above.has(p))
            return p instanceof St.BoxLayout ? p : null;
    }
    return null;
}

function joinStyle(...parts) {
    return parts
        .filter(Boolean)
        .map(p => (p.trim().endsWith(';') ? p.trim() : `${p.trim()};`))
        .join(' ') || null;
}

// Places every Main.panel.statusArea item by its layout entry.
//
// Items are found by walking statusArea on every pass, so indicators that
// extensions add later are picked up: a pass is queued by addToStatusArea,
// by any child added to or removed from the three boxes, and by
// session-mode updates (Panel._updatePanel re-appends the shell's own
// items, panel.js:652-657). Passes run before the next redraw, after every
// synchronous handler, so the bar never paints the intermediate state.
class Arranger {
    constructor(settings) {
        this._settings = settings;
        this._panel = Main.panel;
        // Private: panel.js:474-479
        this._boxes = {
            left: this._panel._leftBox,
            center: this._panel._centerBox,
            right: this._panel._rightBox,
        };
        this._boxStyles = new Map(Object.values(this._boxes).map(b => [b, b.get_style()]));

        // container -> {role, id, indicator, container, origParent,
        //               origIndex, origStyle, style, seq, box, pos}
        this._records = new Map();
        // Containers unparented to hide them; unparented, the owner keeps
        // full control of the visible flag and nothing has to be undone
        this._stash = new Set();
        this._seq = 0;
        this._firstPass = true;

        this._applying = false;
        this._laterId = 0;
        this._panelGone = false;

        this._injections = new InjectionManager();
        const queue = () => this._queueApply();
        this._injections.overrideMethod(Panel.prototype, 'addToStatusArea',
            original => function (...args) {
                const indicator = original.apply(this, args);
                if (this === Main.panel)
                    queue();
                return indicator;
            });

        for (const box of Object.values(this._boxes)) {
            box.connectObject(
                'child-added', () => this._onExternalChange(),
                'child-removed', () => this._onExternalChange(),
                this);
        }
        // The panel's own handler (panel.js:501) is connected first and
        // runs before this one
        Main.sessionMode.connectObject('updated', () => this._queueApply(), this);
        this._panel.connectObject('destroy', () => this._onPanelDestroyed(), this);
        // Even spacing: measured from what is drawn, so it is corrected after
        // each layout of either side (left: the gap to match; right: the
        // gaps to set)
        this._measuredGap = null;
        this._evenMargins = new Map(); // container -> original margin_left
        this._evenBoxStyles = new Map(); // inner box -> original inline style
        this._evenPasses = 0;
        this._evenLaterId = 0;
        for (const box of [this._boxes.left, this._boxes.right])
            box.connectObject('notify::allocation', () => this._queueEvenPass(), this);
        this._settings.connectObject('changed', (_s, key) => {
            if (key !== 'known-items')
                this._queueApply();
        }, this);

        this._apply();
        this._firstPass = false;
    }

    destroy() {
        this._cancelApply();
        this._injections.clear();
        this._injections = null;
        this._settings.disconnectObject(this);
        this._settings = null;
        Main.sessionMode.disconnectObject(this);
        if (this._panelGone)
            return;

        this._panel.disconnectObject(this);
        for (const box of Object.values(this._boxes))
            box.disconnectObject(this);

        this._applying = true;
        // Items present at enable go back to their exact places first.
        // Later ones were put into the arranged boxes, so their recorded
        // index is only what their extension asked for.
        const records = [...this._records.values()].sort((a, b) =>
            b.initial - a.initial || (a.initial ? a.origIndex - b.origIndex : a.seq - b.seq));
        for (const {container} of records)
            container.get_parent()?.remove_child(container);
        for (const rec of records) {
            const {container, origParent, indicator} = rec;
            origParent.insert_child_at_index(container,
                Math.min(rec.origIndex, origParent.get_n_children()));
            if (rec.style !== undefined)
                indicator.set_style(rec.origStyle);
            container.disconnectObject(this);
        }
        for (const [box, style] of this._boxStyles)
            box.set_style(style);
        this._evenReset();
        this._syncBanner();

        this._records.clear();
        this._stash.clear();
        this._boxStyles.clear();
        this._panel = null;
    }

    _onPanelDestroyed() {
        // Shell shutdown: nothing left to restore
        this._panelGone = true;
        this._cancelApply();
        this._records.clear();
        this._stash.clear();
        this._boxStyles.clear();
    }

    _onExternalChange() {
        if (!this._applying)
            this._queueApply();
    }

    _queueApply() {
        if (this._laterId || this._panelGone || !this._settings)
            return;
        this._laterId = global.compositor.get_laters().add(Meta.LaterType.BEFORE_REDRAW, () => {
            this._laterId = 0;
            this._apply();
            return GLib.SOURCE_REMOVE;
        });
    }

    _cancelApply() {
        if (this._laterId)
            global.compositor.get_laters().remove(this._laterId);
        this._laterId = 0;
        if (this._evenLaterId)
            global.compositor.get_laters().remove(this._evenLaterId);
        this._evenLaterId = 0;
    }

    _apply() {
        this._applying = true;
        try {
            this._discover();
            const layout = parseLayout(this._settings.get_string('layout'));
            const policy = {
                box: this._settings.get_string('unknown-box'),
                position: this._settings.get_string('unknown-position'),
            };

            const groups = this._groups();
            const items = [...groups].map(([id, members]) => ({
                id,
                box: members[0].box,
                pos: members[0].pos,
                seq: Math.min(...members.map(m => m.seq)),
            })).sort((a, b) => a.seq - b.seq);
            const order = arrange(items, layout, policy);

            const even = this._evenGap();
            this._evenPasses = 0;
            if (even === null)
                this._evenReset();
            const wanted = {left: [], center: [], right: []};
            for (const box of BOXES) {
                for (const id of order[box]) {
                    const entry = layout[id];
                    for (const rec of groups.get(id)) {
                        // An item's own padding wins; even spacing pads the
                        // rest of the right box
                        const own = Number.isInteger(entry?.padding) && entry.padding >= 0;
                        this._setPadding(rec, !own && box === 'right' && even !== null
                            ? this._evenPadding(rec, even) : entry?.padding);
                        if (entry?.hidden)
                            this._hide(rec);
                        else
                            wanted[box].push(rec.container);
                    }
                }
            }
            for (const box of BOXES)
                this._place(this._boxes[box], wanted[box]);

            this._applyBoxStyles(even);
            if (even !== null)
                this._queueEvenPass();
            this._syncBanner();
            this._publish(order, layout, groups);
        } catch (e) {
            console.error(`${LOG_PREFIX} ${e}\n${e.stack}`);
        } finally {
            this._applying = false;
        }
    }

    _boxName(actor) {
        return BOXES.find(b => this._boxes[b] === actor) ?? null;
    }

    _discover() {
        const live = new Set();
        for (const [role, indicator] of Object.entries(this._panel.statusArea)) {
            // ubuntu-appindicators parks a role as null while it re-adds it
            const container = indicator?.container;
            if (!container)
                continue;

            let rec = this._records.get(container);
            const parent = container.get_parent();
            // Re-added while hidden, e.g. by Panel._addToPanelBox on a
            // session-mode update (panel.js:711-720); hidden again below
            if (parent)
                this._stash.delete(container);
            if (rec && !this._stash.has(container) && !this._boxName(parent)) {
                // Moved out of the panel by someone else; stop managing it
                this._release(rec);
                rec = null;
            }
            if (!rec) {
                if (!this._boxName(parent))
                    continue;
                rec = {
                    container,
                    origParent: parent,
                    origIndex: parent.get_children().indexOf(container),
                    origStyle: indicator.get_style(),
                    style: undefined,
                    initial: this._firstPass,
                    seq: this._seq++,
                };
                this._records.set(container, rec);
                container.connectObject('destroy', () => this._forget(container), this);
            }
            Object.assign(rec, {role, indicator, id: layoutId(role)});
            if (!this._stash.has(container)) {
                const box = container.get_parent();
                rec.box = this._boxName(box);
                rec.pos = box.get_children().indexOf(container);
            }
            live.add(container);
        }

        for (const rec of [...this._records.values()]) {
            if (!live.has(rec.container))
                this._release(rec);
        }
    }

    // Records by layout id; group members in their current visual order
    _groups() {
        const groups = new Map();
        const recs = [...this._records.values()].sort((a, b) =>
            BOXES.indexOf(a.box) - BOXES.indexOf(b.box) || a.pos - b.pos || a.seq - b.seq);
        for (const rec of recs) {
            if (!groups.has(rec.id))
                groups.set(rec.id, []);
            groups.get(rec.id).push(rec);
        }
        return groups;
    }

    _forget(container) {
        this._records.delete(container);
        this._stash.delete(container);
        this._evenMargins?.delete(container);
    }

    // The item left statusArea but still exists: hand it back as it is
    _release(rec) {
        const {container} = rec;
        if (this._stash.has(container))
            rec.origParent.add_child(container);
        if (rec.style !== undefined)
            rec.indicator.set_style(rec.origStyle);
        container.disconnectObject(this);
        this._forget(container);
    }

    _hide(rec) {
        const {container} = rec;
        if (this._stash.has(container))
            return;
        rec.indicator.menu?.close?.();
        container.get_parent()?.remove_child(container);
        this._stash.add(container);
    }

    // Order `wanted` in `box`. Children nobody manages (actors extensions
    // insert without statusArea) stay right after the item they follow now.
    _place(box, wanted) {
        const wantedSet = new Set(wanted);
        const after = new Map([[null, []]]);
        let last = null;
        for (const child of box.get_children()) {
            if (wantedSet.has(child)) {
                last = child;
            } else if (!this._records.has(child)) {
                if (!after.has(last))
                    after.set(last, []);
                after.get(last).push(child);
            }
        }

        const final = [...after.get(null)];
        for (const container of wanted)
            final.push(container, ...(after.get(container) ?? []));

        // Each step fixes index i, so children that still have to move to
        // another box drift past the end
        final.forEach((actor, i) => {
            const parent = actor.get_parent();
            if (parent !== box) {
                parent?.remove_child(actor);
                box.insert_child_at_index(actor, i);
                this._stash.delete(actor);
            } else if (box.get_child_at_index(i) !== actor) {
                box.set_child_at_index(actor, i);
            }
        });
    }

    // ButtonBox reads its horizontal padding from these theme properties
    // (panelMenu.js:29-34)
    _setPadding(rec, padding) {
        const style = Number.isInteger(padding) && padding >= 0
            ? joinStyle(rec.origStyle,
                `-natural-hpadding: ${padding}px; -minimum-hpadding: ${padding}px;`)
            : rec.origStyle;
        if (rec.style === undefined && style === rec.origStyle)
            return;
        if (rec.style !== style) {
            rec.indicator.set_style(style);
            rec.style = style;
        }
    }

    // Box spacing and the inner padding at the bar's two ends. Only the
    // boxes are styled: the Dusk stylesheet owns #panel's margin (the tab
    // inset), and Panel.vfunc_allocate ignores #panel padding (panel.js:520).
    _applyBoxStyles(even = null) {
        const side = this._settings.get_int('side-padding');
        const rtl = this._panel.get_text_direction() === Clutter.TextDirection.RTL;
        for (const name of BOXES) {
            const box = this._boxes[name];
            // Even spacing makes the gaps with the items' padding alone
            const spacing = name === 'right' && even !== null
                ? 0 : this._settings.get_int(SPACING_KEYS[name]);
            const parts = [];
            if (spacing >= 0)
                parts.push(`spacing: ${spacing}px;`);
            if (side >= 0 && name !== 'center') {
                const outer = (name === 'left') !== rtl ? 'left' : 'right';
                parts.push(`padding-${outer}: ${side}px;`);
            }
            const style = joinStyle(this._boxStyles.get(box), ...parts);
            if (box.get_style() !== style)
                box.set_style(style);
        }
    }

    // Even spacing: the gap between neighbouring things drawn on the right
    // (each app indicator, each Quick Settings icon, the date and time, the
    // dot), or null when off. -1 in even-gap matches the gap between the
    // things drawn on the left (logo, app name, menu titles).
    _evenGap() {
        if (!this._settings.get_boolean('even-spacing'))
            return null;
        const gap = this._settings.get_int('even-gap');
        if (gap >= 0)
            return gap;
        this._measuredGap = this._leftGap() ?? this._measuredGap;
        return this._measuredGap ?? FALLBACK_GAP;
    }

    // A small hover pill around each right item (half the gap less its
    // theme border, less 3px so the margins below never need to go
    // negative); the gaps themselves are set by margins and box spacing
    _evenPadding(rec, gap) {
        let border = 0;
        try {
            border = rec.indicator.get_theme_node().get_border_width(St.Side.LEFT);
        } catch {
            // not styled yet: no border
        }
        // At least TAB_PAD: the highlight (a drop-down tab) needs room around
        // the icon; wider pads just make the even gaps a little larger
        return Math.max(TAB_PAD, Math.floor(gap / 2) - border - 3);
    }

    // The median gap between neighbouring drawn things on the left
    _leftGap() {
        const leaves = drawnLeaves(this._boxes.left);
        const gaps = [];
        for (let i = 1; i < leaves.length; i++)
            gaps.push(Math.round(leaves[i].span[0] - leaves[i - 1].span[1]));
        const valid = gaps.filter(g => g >= 0).sort((a, b) => a - b);
        return valid.length ? valid[Math.floor(valid.length / 2)] : null;
    }

    _queueEvenPass() {
        if (this._evenLaterId || this._applying || this._panelGone || !this._settings ||
            this._evenPasses >= EVEN_MAX_PASSES || !this._settings.get_boolean('even-spacing'))
            return;
        this._evenLaterId = global.compositor.get_laters().add(Meta.LaterType.BEFORE_REDRAW, () => {
            this._evenLaterId = 0;
            try {
                // A settled pass gives later changes (an icon appearing, a
                // wider label) a fresh budget
                if (this._evenPass())
                    this._evenPasses++;
                else
                    this._evenPasses = 0;
            } catch (e) {
                console.error(`${LOG_PREFIX} even spacing: ${e}\n${e.stack}`);
            }
            return GLib.SOURCE_REMOVE;
        });
    }

    // Measure the right side as drawn and move each gap to the target: the
    // gap between two items by the later item's margin, the gap between two
    // things inside one item by the spacing of the box they share. True when
    // something changed (the next layout is measured again).
    _evenPass() {
        const gap = this._evenGap();
        if (gap === null)
            return false;
        const leftGap = this._settings.get_int('even-gap') < 0 ? this._measuredGap : gap;
        let changed = false;
        let prevEnd = null;
        for (const container of this._boxes.right.get_children()) {
            if (!container.visible || !container.mapped)
                continue;
            const leaves = drawnLeaves(container);
            if (!leaves.length)
                continue;

            // Inside the item: one correction per shared box (the average)
            const deltas = new Map();
            for (let i = 1; i < leaves.length; i++) {
                const box = sharedBox(leaves[i - 1].leaf, leaves[i].leaf, container);
                if (!box)
                    continue;
                const measured = leaves[i].span[0] - leaves[i - 1].span[1];
                if (!deltas.has(box))
                    deltas.set(box, []);
                deltas.get(box).push((leftGap ?? gap) - measured);
            }
            for (const [box, list] of deltas) {
                const delta = Math.round(list.reduce((a, b) => a + b, 0) / list.length);
                if (delta === 0)
                    continue;
                if (!this._evenBoxStyles.has(box)) {
                    this._evenBoxStyles.set(box, box.get_style());
                    box.connectObject('destroy', () => this._evenBoxStyles.delete(box), this);
                }
                const spacing = Math.max(0, Math.round(box.layout_manager.spacing + delta));
                if (spacing !== box.layout_manager.spacing) {
                    box.set_style(joinStyle(this._evenBoxStyles.get(box), `spacing: ${spacing}px`));
                    changed = true;
                }
            }

            // Between items: the later item's left margin
            const start = leaves[0].span[0];
            const end = Math.max(...leaves.map(l => l.span[1]));
            if (prevEnd !== null) {
                if (!this._evenMargins.has(container))
                    this._evenMargins.set(container, container.margin_left);
                const margin = Math.max(0, Math.round(container.margin_left + gap - (start - prevEnd)));
                if (margin !== container.margin_left) {
                    container.margin_left = margin;
                    changed = true;
                }
            }
            prevEnd = end;
        }
        return changed;
    }

    // Put back what even spacing changed
    _evenReset() {
        for (const [container, margin] of this._evenMargins)
            container.margin_left = margin;
        this._evenMargins.clear();
        for (const [box, style] of this._evenBoxStyles) {
            box.set_style(style);
            box.disconnectObject(this);
        }
        this._evenBoxStyles.clear();
    }

    // Same rule the panel applies for its session-mode layout (panel.js:659-665)
    _syncBanner() {
        const container = this._panel.statusArea.dateMenu?.container;
        const box = this._boxName(container?.get_parent());
        Main.messageTray.bannerAlignment = {
            left: Clutter.ActorAlign.START,
            right: Clutter.ActorAlign.END,
        }[box] ?? Clutter.ActorAlign.CENTER;
    }

    // Tell the prefs window what exists and where it ended up
    _publish(order, layout, groups) {
        const known = [];
        for (const box of BOXES) {
            order[box].forEach((id, index) => {
                const [first] = groups.get(id);
                known.push({
                    id,
                    label: roleLabel(id, first.indicator.accessible_name || first.role),
                    box,
                    index,
                    count: groups.get(id).length,
                    hidden: !!layout[id]?.hidden,
                });
            });
        }
        const json = JSON.stringify(known);
        if (this._settings.get_string('known-items') !== json)
            this._settings.set_string('known-items', json);
    }
}

// Dusk Shell module (formerly the Panel Arranger extension); its settings keep
// their own schema, org.gnome.shell.extensions.panel-arranger. While it runs
// it owns top-bar item placement (panelLayout.js defers to it).
export class PanelArranger {
    constructor(settings) {
        setArrangerActive(true);
        try {
            this._arranger = new Arranger(settings);
        } catch (e) {
            setArrangerActive(false);
            throw e;
        }
    }

    destroy() {
        this._arranger?.destroy();
        this._arranger = null;
        setArrangerActive(false);
    }
}
