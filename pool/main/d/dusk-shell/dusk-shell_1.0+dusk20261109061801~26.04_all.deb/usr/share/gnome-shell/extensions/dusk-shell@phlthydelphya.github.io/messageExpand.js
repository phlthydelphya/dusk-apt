import Pango from 'gi://Pango';

import {Message} from 'resource:///org/gnome/shell/ui/messageList.js';
import {InjectionManager} from 'resource:///org/gnome/shell/extensions/extension.js';

// Shell 51's expand button on a notification does not show more of its body.
// Message.expand() eases LabelExpanderLayout's expansion to 1, which grows the
// body to its height at the bin's width (messageList.js:263-279). But the body
// label wraps *and* ellipsizes at the end, and Pango then keeps it to one line,
// so that height is one line and nothing grows. Stock Shell does the same in
// the date menu; it is not the drawer.
//
// While a message is expanded its body is not ellipsized, so it wraps to its
// full height (the layout still caps it at 6 lines' worth); the ellipsis comes
// back once the collapse animation has ended.
export class MessageExpandFix {
    constructor() {
        // Messages whose body is shown unellipsized right now
        this._unellipsized = new Set();
        this._injections = new InjectionManager();
        const self = this;
        this._injections.overrideMethod(Message.prototype, 'expand', original => function (...args) {
            self._setEllipsized(this, false);
            return original.apply(this, args);
        });
        this._injections.overrideMethod(Message.prototype, 'unexpand', original => function (...args) {
            const result = original.apply(this, args);
            self._ellipsizeWhenCollapsed(this);
            return result;
        });
    }

    _setEllipsized(message, ellipsized) {
        const layout = message._bodyBin?.layout_manager;
        layout?.disconnectObject(this);
        const text = message._bodyLabel?.clutter_text;
        if (!text)
            return;
        text.ellipsize = ellipsized ? Pango.EllipsizeMode.END : Pango.EllipsizeMode.NONE;
        if (ellipsized) {
            message.disconnectObject(this);
            this._unellipsized.delete(message);
        } else if (!this._unellipsized.has(message)) {
            this._unellipsized.add(message);
            message.connectObject('destroy', () => this._unellipsized.delete(message), this);
        }
    }

    // The ellipsis comes back when the body has shrunk back to one line; an
    // expand() before that cancels it
    _ellipsizeWhenCollapsed(message) {
        const layout = message._bodyBin?.layout_manager;
        if (!this._unellipsized.has(message) || !layout || layout.expansion === 0) {
            this._setEllipsized(message, true);
            return;
        }
        layout.disconnectObject(this);
        layout.connectObject('notify::expansion', () => {
            if (layout.expansion === 0)
                this._setEllipsized(message, true);
        }, this);
    }

    destroy() {
        this._injections.clear();
        for (const message of [...this._unellipsized])
            this._setEllipsized(message, true);
    }
}
