import Clutter from 'gi://Clutter';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as BoxPointer from 'resource:///org/gnome/shell/ui/boxpointer.js';
import {Extension, InjectionManager} from 'resource:///org/gnome/shell/extensions/extension.js';

// Dusk motion: one place for every popup timing, curve and distance.
// Used here for top-bar menus, and by drawer.js and appMenu.js.
// The timings, scales and rise follow the mood setting (see MOOD_MOTION),
// so they are live `let` bindings: importers read them at animation time.
export let OPEN_TIME = 180;
export let CLOSE_TIME = 120;
export const OPEN_MODE = Clutter.AnimationMode.EASE_OUT_CUBIC;
export const CLOSE_MODE = Clutter.AnimationMode.EASE_IN_QUAD;
export let OPEN_SCALE = 0.97;
export let CLOSE_SCALE = 0.98;
export let RISE = 8; // logical px; scaled by the theme scale factor

// Per-mood motion. balanced is the stock values above. calm is quicker and
// travels less; vivid is slower with more scale and rise. Matches the
// mood-dur-* tokens in tokens/dusk_seed.py MOODS.
const MOOD_MOTION = {
    calm: {open: 150, close: 100, openScale: 0.98, closeScale: 0.99, rise: 6},
    balanced: {open: 180, close: 120, openScale: 0.97, closeScale: 0.98, rise: 8},
    vivid: {open: 220, close: 140, openScale: 0.95, closeScale: 0.97, rise: 12},
};

export function applyMood(mood) {
    const m = MOOD_MOTION[mood] ?? MOOD_MOTION.balanced;
    OPEN_TIME = m.open;
    CLOSE_TIME = m.close;
    OPEN_SCALE = m.openScale;
    CLOSE_SCALE = m.closeScale;
    RISE = m.rise;
}

// Reduced motion: the shell derives St.Settings.reducedMotion from the
// accessibility settings (boxpointer.js:79-80 reads it the same way); a
// session with org.gnome.desktop.interface enable-animations=false is
// covered by St.Settings.enable_animations.
export function motionEnabled() {
    const settings = St.Settings.get();
    return settings.enable_animations !== false &&
        settings.reducedMotion !== St.ReducedMotion.REDUCE;
}

// Duration that collapses to 0 (instant) when motion is off
export function timing(ms) {
    return motionEnabled() ? ms : 0;
}

function scaleFactor() {
    return St.ThemeContext.get_for_stage(global.stage).scale_factor;
}

// Only menus opened from the top bar get Dusk motion. BoxPointer._sourceActor
// is private (boxpointer.js:457-463, set by setPosition, which PopupMenu.open
// calls just before BoxPointer.open: popupMenu.js:1131-1132).
function fromTopBar(boxPointer) {
    const source = boxPointer._sourceActor;
    return !!source && Main.panel.contains(source);
}

export class PopupMotion {
    constructor() {
        this._animating = new Set();
        this._injections = new InjectionManager();

        // Mood: follow the extension's mood key; destroy() resets to balanced
        this._settings = Extension.lookupByURL(import.meta.url).getSettings();
        applyMood(this._settings.get_string('mood'));
        this._settings.connectObject('changed::mood',
            () => applyMood(this._settings.get_string('mood')), this);
        const motion = this;

        // BoxPointer.open (boxpointer.js:74-128): same flow as the stock
        // method, only the visual ease differs. _muteKeys/_muteInput are the
        // stock input blockers (boxpointer.js:87, 123, 181-182).
        this._injections.overrideMethod(BoxPointer.BoxPointer.prototype, 'open',
            original => function (animate, onComplete) {
                const side = this.arrowSide;
                if (!animate || !motionEnabled() || !fromTopBar(this) ||
                    (side !== St.Side.TOP && side !== St.Side.BOTTOM))
                    return original.call(this, animate, onComplete);

                const dir = side === St.Side.TOP ? -1 : 1;
                motion._track(this);
                this.remove_all_transitions();
                this.opacity = 0;
                this._muteKeys.enabled = false;
                this.show();
                this.set_pivot_point(0.5, side === St.Side.TOP ? 0 : 1);
                this.scale_x = OPEN_SCALE;
                this.scale_y = OPEN_SCALE;
                this.translation_y = dir * RISE * scaleFactor();
                this.ease({
                    opacity: 255,
                    translation_y: 0,
                    scale_x: 1,
                    scale_y: 1,
                    duration: OPEN_TIME,
                    mode: OPEN_MODE,
                    onComplete: () => {
                        motion._untrack(this);
                        this._muteInput.enabled = false;
                        if (onComplete)
                            onComplete();
                    },
                });
                return undefined;
            });

        // BoxPointer.close (boxpointer.js:130-193)
        this._injections.overrideMethod(BoxPointer.BoxPointer.prototype, 'close',
            original => function (animate, onComplete) {
                const side = this.arrowSide;
                if (!animate || !motionEnabled() || !fromTopBar(this) ||
                    (side !== St.Side.TOP && side !== St.Side.BOTTOM))
                    return original.call(this, animate, onComplete);

                if (!this.visible)
                    return undefined;

                motion._track(this);
                this._muteInput.enabled = true;
                this._muteKeys.enabled = true;
                this.set_pivot_point(0.5, side === St.Side.TOP ? 0 : 1);
                this.remove_all_transitions();
                this.ease({
                    opacity: 0,
                    scale_x: CLOSE_SCALE,
                    scale_y: CLOSE_SCALE,
                    duration: CLOSE_TIME,
                    mode: CLOSE_MODE,
                    onComplete: () => {
                        motion._untrack(this);
                        this.scale_x = 1;
                        this.scale_y = 1;
                        this.translation_x = 0;
                        this.translation_y = 0;
                        this.hide();
                        this.opacity = 0;
                        if (onComplete)
                            onComplete();
                    },
                });
                return undefined;
            });
    }

    _track(boxPointer) {
        if (this._animating.has(boxPointer))
            return;
        this._animating.add(boxPointer);
        boxPointer.connectObject('destroy',
            () => this._animating.delete(boxPointer), this);
    }

    _untrack(boxPointer) {
        this._animating.delete(boxPointer);
        boxPointer.disconnectObject(this);
    }

    destroy() {
        this._settings.disconnectObject(this);
        this._settings = null;
        applyMood('balanced');
        this._injections.clear();
        for (const bp of this._animating) {
            bp.disconnectObject(this);
            bp.remove_all_transitions();
            bp.scale_x = 1;
            bp.scale_y = 1;
            bp.translation_x = 0;
            bp.translation_y = 0;
        }
        this._animating.clear();
    }
}
