import GdkPixbuf from 'gi://GdkPixbuf';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';

// Notification icons that are dark one-colour glyphs (Android notification
// icons forwarded by GSConnect, KDE Connect and the like: alpha masks that
// Android tints, sent as plain black PNGs) vanish on Dusk's dark banners and
// drawer. Such an icon is redrawn in Dusk's text colour, keeping its alpha.
// Only image icons (bytes or files) are checked; themed icons are left to
// the icon theme, and colourful or opaque images (photos, app logos) are
// left alone.

const TEXT_RGB = [0xE4, 0xE5, 0xEA]; // $text
const SAMPLE = 48; // icons are judged on a downscaled copy
const DARK = 80; // max channel value counted as dark
const GREY = 40; // max channel spread counted as colourless
const DARK_SHARE = 0.9; // share of visible pixels that must be dark grey

function loadPixbuf(gicon) {
    if (gicon instanceof Gio.BytesIcon) {
        const stream = Gio.MemoryInputStream.new_from_bytes(gicon.get_bytes());
        return GdkPixbuf.Pixbuf.new_from_stream(stream, null);
    }
    if (gicon instanceof Gio.FileIcon) {
        const path = gicon.get_file().get_path();
        return path ? GdkPixbuf.Pixbuf.new_from_file(path) : null;
    }
    return null;
}

function isDarkGlyph(pixbuf) {
    if (!pixbuf.get_has_alpha())
        return false;
    const small = pixbuf.scale_simple(SAMPLE, SAMPLE, GdkPixbuf.InterpType.BILINEAR);
    const pixels = small.get_pixels();
    const stride = small.get_rowstride();
    const channels = small.get_n_channels();
    let visible = 0, dark = 0, clear = 0;
    for (let y = 0; y < SAMPLE; y++) {
        for (let x = 0; x < SAMPLE; x++) {
            const i = y * stride + x * channels;
            const a = pixels[i + 3];
            if (a < 64) {
                clear++;
                continue;
            }
            visible++;
            const hi = Math.max(pixels[i], pixels[i + 1], pixels[i + 2]);
            const lo = Math.min(pixels[i], pixels[i + 1], pixels[i + 2]);
            if (hi <= DARK && hi - lo <= GREY)
                dark++;
        }
    }
    // A glyph: some see-through background, and nearly all of it dark grey
    return visible >= 20 && clear >= SAMPLE * SAMPLE * 0.1 &&
        dark / visible >= DARK_SHARE;
}

function recolor(pixbuf) {
    const width = pixbuf.get_width();
    const height = pixbuf.get_height();
    const stride = pixbuf.get_rowstride();
    const channels = pixbuf.get_n_channels();
    const pixels = pixbuf.get_pixels();
    const out = new Uint8Array(pixels.length);
    out.set(pixels);
    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            const i = y * stride + x * channels;
            out[i] = TEXT_RGB[0];
            out[i + 1] = TEXT_RGB[1];
            out[i + 2] = TEXT_RGB[2];
        }
    }
    const result = GdkPixbuf.Pixbuf.new_from_bytes(new GLib.Bytes(out),
        GdkPixbuf.Colorspace.RGB, true, 8, width, height, stride);
    const [ok, png] = result.save_to_bufferv('png', [], []);
    return ok ? Gio.BytesIcon.new(new GLib.Bytes(png)) : null;
}

export class NotificationIconFix {
    constructor() {
        this._sources = new Map(); // Source -> signal ids
        this._made = new WeakSet(); // icons this module produced
        this._notifications = new Map(); // Notification -> notify::gicon id
        this._addedId = Main.messageTray.connect('source-added',
            (_tray, source) => this._watchSource(source));
        for (const source of Main.messageTray.getSources())
            this._watchSource(source);
    }

    _watchSource(source) {
        if (this._sources.has(source))
            return;
        const ids = [
            source.connect('notification-added', (_s, notification) =>
                this._watchNotification(notification)),
            source.connect('destroy', () => this._sources.delete(source)),
        ];
        this._sources.set(source, ids);
        for (const notification of source.notifications ?? [])
            this._watchNotification(notification);
    }

    _watchNotification(notification) {
        if (this._notifications.has(notification))
            return;
        // Updated notifications can bring a new icon
        const id = notification.connect('notify::gicon', () => this._fix(notification));
        this._notifications.set(notification, id);
        notification.connect('destroy', () => this._notifications.delete(notification));
        this._fix(notification);
    }

    _fix(notification) {
        const gicon = notification.gicon;
        if (!gicon || this._made.has(gicon))
            return;
        try {
            const pixbuf = loadPixbuf(gicon);
            if (!pixbuf || !isDarkGlyph(pixbuf))
                return;
            const icon = recolor(pixbuf);
            if (!icon)
                return;
            this._made.add(icon);
            notification.gicon = icon;
        } catch (e) {
            console.debug(`dusk-shell: notification icon left as is: ${e}`);
        }
    }

    destroy() {
        Main.messageTray.disconnect(this._addedId);
        for (const [source, ids] of this._sources) {
            for (const id of ids)
                source.disconnect(id);
        }
        this._sources.clear();
        for (const [notification, id] of this._notifications)
            notification.disconnect(id);
        this._notifications.clear();
    }
}
