import Adw from 'gi://Adw';
import Gdk from 'gi://Gdk';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Gtk from 'gi://Gtk';

import {
    BOXES, UNKNOWN_BOXES, UNKNOWN_POSITIONS,
    arrange, parseKnown, parseLayout, withOrder,
} from './panelArrangerCommon.js';

const BOX_LABELS = {left: 'Left', center: 'Center', right: 'Right'};
const UNKNOWN_BOX_LABELS = {
    keep: 'Where the extension puts them',
    left: 'Left', center: 'Center', right: 'Right',
};
const UNKNOWN_POSITION_LABELS = {
    'start': 'At the start',
    'end': 'At the end',
    'before-quick-settings': 'Before Quick Settings',
};

const LAYOUT_KEYS = ['layout', 'known-items', 'unknown-box', 'unknown-position'];
const RESET_KEYS = [
    'layout', 'unknown-box', 'unknown-position',
    'left-spacing', 'center-spacing', 'right-spacing', 'side-padding',
    'even-spacing', 'even-gap',
];

// Settings handlers can fire from a widget we are about to throw away,
// so rebuilds always wait for idle.
class Rebuilder {
    constructor(settings, keys, rebuild) {
        this._settings = settings;
        this._rebuild = rebuild;
        this._idleId = 0;
        this._ids = keys.map(key =>
            settings.connect(`changed::${key}`, () => this.queue()));
        rebuild();
    }

    queue() {
        if (this._idleId)
            return;
        this._idleId = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
            this._idleId = 0;
            this._rebuild();
            return GLib.SOURCE_REMOVE;
        });
    }

    destroy() {
        this._ids.forEach(id => this._settings.disconnect(id));
        this._ids = [];
        if (this._idleId)
            GLib.source_remove(this._idleId);
        this._idleId = 0;
    }
}

function stringValue(text) {
    const value = new GObject.Value();
    value.init(GObject.TYPE_STRING);
    value.set_string(text);
    return value;
}

// The three box groups. Rows drag within and across groups; dropping on a
// group outside its rows appends to that box.
class LayoutEditor {
    constructor(settings, page) {
        this._settings = settings;
        this._groups = {};
        this._rows = {left: [], center: [], right: []};
        this._expanded = new Set();
        this._order = {left: [], center: [], right: []};
        this._known = new Map();

        for (const box of BOXES) {
            const group = new Adw.PreferencesGroup({title: BOX_LABELS[box]});
            const target = new Gtk.DropTarget({actions: Gdk.DragAction.MOVE});
            target.set_gtypes([GObject.TYPE_STRING]);
            target.connect('drop', (_t, id) => this._moveTo(id, box, this._order[box].length));
            group.add_controller(target);
            page.add(group);
            this._groups[box] = group;
        }

        this._rebuilder = new Rebuilder(settings, LAYOUT_KEYS, () => this._rebuild());
    }

    destroy() {
        this._rebuilder.destroy();
    }

    _layout() {
        return parseLayout(this._settings.get_string('layout'));
    }

    _rebuild() {
        for (const box of BOXES) {
            this._rows[box].forEach(r => this._groups[box].remove(r));
            this._rows[box] = [];
        }

        const known = parseKnown(this._settings.get_string('known-items'));
        this._known = new Map(known.map(k => [k.id, k]));
        const layout = this._layout();
        // Same placement the shell computes, so edits show before the
        // shell writes known-items back
        this._order = arrange(
            known.map(k => ({id: k.id, box: k.box, pos: k.index})),
            layout,
            {
                box: this._settings.get_string('unknown-box'),
                position: this._settings.get_string('unknown-position'),
            });

        if (known.length === 0) {
            this._addRow('left', new Adw.ActionRow({
                title: 'Nothing found yet',
                subtitle: 'Enable the extension. The list fills in once GNOME Shell has loaded it.',
            }));
            return;
        }

        for (const box of BOXES) {
            if (this._order[box].length === 0) {
                this._addRow(box, new Adw.ActionRow({
                    title: 'Empty',
                    subtitle: 'Drag items here',
                    css_classes: ['dim-label'],
                }));
                continue;
            }
            this._order[box].forEach((id, i) =>
                this._addRow(box, this._itemRow(id, box, i, layout[id])));
        }
    }

    _addRow(box, row) {
        this._groups[box].add(row);
        this._rows[box].push(row);
    }

    _itemRow(id, box, index, entry) {
        const item = this._known.get(id);
        const subtitle = item.count > 1 ? `${id}, ${item.count} items` : id;
        const row = new Adw.ExpanderRow({
            title: item.label,
            subtitle,
            use_markup: false,
            expanded: this._expanded.has(id),
        });
        row.connect('notify::expanded', () => {
            if (row.expanded)
                this._expanded.add(id);
            else
                this._expanded.delete(id);
        });

        row.add_prefix(new Gtk.Image({
            icon_name: 'list-drag-handle-symbolic',
            css_classes: ['dim-label'],
            tooltip_text: 'Drag to reorder or move to another box',
        }));

        const visible = new Gtk.Switch({
            active: !entry?.hidden,
            valign: Gtk.Align.CENTER,
            tooltip_text: 'Show',
        });
        visible.connect('notify::active', () =>
            this._edit(id, e => ({...e, hidden: !visible.active})));
        row.add_suffix(visible);

        const boxRow = new Adw.ComboRow({
            title: 'Box',
            model: Gtk.StringList.new(BOXES.map(b => BOX_LABELS[b])),
        });
        // After the model: setting a model resets the selection
        boxRow.selected = BOXES.indexOf(box);
        boxRow.connect('notify::selected', () => {
            const to = BOXES[boxRow.selected];
            if (to && to !== box)
                this._moveTo(id, to, this._order[to].length);
        });
        row.add_row(boxRow);

        const padding = new Adw.SpinRow({
            title: 'Padding (px)',
            subtitle: 'Space on each side of the item. -1 uses the theme.',
            adjustment: new Gtk.Adjustment({
                lower: -1, upper: 32, step_increment: 1, page_increment: 4,
            }),
        });
        padding.value = Number.isInteger(entry?.padding) ? entry.padding : -1;
        padding.connect('notify::value', () => {
            const value = Math.round(padding.value);
            this._edit(id, e => {
                const next = {...e};
                if (value >= 0)
                    next.padding = value;
                else
                    delete next.padding;
                return next;
            });
        });
        row.add_row(padding);

        this._makeDraggable(row, id, box, index);
        return row;
    }

    _makeDraggable(row, id, box, index) {
        let hotX = 0, hotY = 0;
        const source = new Gtk.DragSource({actions: Gdk.DragAction.MOVE});
        source.connect('prepare', (_src, x, y) => {
            hotX = x;
            hotY = y;
            return Gdk.ContentProvider.new_for_value(stringValue(id));
        });
        source.connect('drag-begin', (_src, drag) => {
            // Show a copy of the row under the pointer
            const list = new Gtk.ListBox({css_classes: ['boxed-list']});
            list.set_size_request(row.get_width(), -1);
            list.append(new Adw.ActionRow({
                title: row.title,
                subtitle: row.subtitle,
                use_markup: false,
            }));
            Gtk.DragIcon.get_for_drag(drag).child = list;
            drag.set_hotspot(hotX, hotY);
            row.opacity = 0.4;
        });
        source.connect('drag-end', () => {
            row.opacity = 1;
        });
        row.add_controller(source);

        const target = new Gtk.DropTarget({actions: Gdk.DragAction.MOVE});
        target.set_gtypes([GObject.TYPE_STRING]);
        target.connect('drop', (_tgt, dragged, _x, y) => {
            if (dragged === id || !this._known.has(dragged))
                return false;
            // Lower half of the row: after it
            const after = y > Math.min(row.get_height(), 56) / 2;
            this._moveTo(dragged, box, index + (after ? 1 : 0));
            return true;
        });
        row.add_controller(target);
    }

    // Move `id` to position `to` of `box`, counted before it is taken out
    _moveTo(id, box, to) {
        if (!this._known.has(id))
            return false;
        const order = Object.fromEntries(BOXES.map(b => [b, [...this._order[b]]]));
        for (const b of BOXES) {
            const i = order[b].indexOf(id);
            if (i < 0)
                continue;
            order[b].splice(i, 1);
            if (b === box && i < to)
                to--;
        }
        order[box].splice(Math.max(0, Math.min(to, order[box].length)), 0, id);
        // Edits made before the idle rebuild must see the new order
        this._order = order;
        this._save(withOrder(this._layout(), order));
        return true;
    }

    // Pins every listed item to its current place, then edits one entry
    _edit(id, change) {
        const layout = withOrder(this._layout(), this._order);
        layout[id] = change(layout[id]);
        this._save(layout);
    }

    _save(layout) {
        const json = JSON.stringify(layout);
        if (this._settings.get_string('layout') !== json)
            this._settings.set_string('layout', json);
    }
}

function enumComboRow(settings, key, title, values, labels) {
    const row = new Adw.ComboRow({
        title,
        model: Gtk.StringList.new(values.map(v => labels[v])),
    });
    const sync = () => {
        const i = values.indexOf(settings.get_string(key));
        if (i >= 0 && row.selected !== i)
            row.selected = i;
    };
    sync();
    row.connect('notify::selected', () => {
        const value = values[row.selected];
        if (value && settings.get_string(key) !== value)
            settings.set_string(key, value);
    });
    const id = settings.connect(`changed::${key}`, sync);
    return {row, destroy: () => settings.disconnect(id)};
}

// Pages for the Dusk Shell preferences window (formerly the Panel Arranger extension, merged into
// Dusk Shell). The settings object is kept alive with the window.
export class PanelArrangerPages {
    static fill(window, settings) {
        (window._duskArrangerSettings ??= []).push(settings);
        const owned = [];

        // Layout page
        const layoutPage = new Adw.PreferencesPage({
            title: 'Top Bar',
            icon_name: 'view-dual-symbolic',
        });
        window.add(layoutPage);

        const intro = new Adw.PreferencesGroup({
            description: 'Drag items to reorder them or move them to another box. ' +
                'Only items in the top bar right now are listed. ' +
                'App indicators and global menu buttons move as one item each.',
        });
        layoutPage.add(intro);
        owned.push(new LayoutEditor(settings, layoutPage));

        const unknownGroup = new Adw.PreferencesGroup({
            title: 'New items',
            description: 'Where items that are not placed yet go, such as an indicator from an extension you just enabled.',
        });
        layoutPage.add(unknownGroup);
        for (const combo of [
            enumComboRow(settings, 'unknown-box', 'Box', UNKNOWN_BOXES, UNKNOWN_BOX_LABELS),
            enumComboRow(settings, 'unknown-position', 'Position', UNKNOWN_POSITIONS,
                UNKNOWN_POSITION_LABELS),
        ]) {
            unknownGroup.add(combo.row);
            owned.push(combo);
        }

        // Spacing page
        const spacingPage = new Adw.PreferencesPage({
            title: 'Top Bar Spacing',
            icon_name: 'object-flip-horizontal-symbolic',
        });
        window.add(spacingPage);
        const spacingGroup = new Adw.PreferencesGroup({
            title: 'Spacing',
            description: '-1 uses the theme. The Dusk tab inset around the bar is not changed.',
        });
        spacingPage.add(spacingGroup);
        for (const [title, key, upper] of [
            ['Left box spacing (px)', 'left-spacing', 48],
            ['Center box spacing (px)', 'center-spacing', 48],
            ['Right box spacing (px)', 'right-spacing', 48],
            ['Padding at the bar ends (px)', 'side-padding', 96],
        ]) {
            const row = new Adw.SpinRow({
                title,
                adjustment: new Gtk.Adjustment({
                    lower: -1, upper, step_increment: 1, page_increment: 4,
                }),
            });
            settings.bind(key, row, 'value', Gio.SettingsBindFlags.DEFAULT);
            spacingGroup.add(row);
        }

        // Even spacing on the right, matched to the menus on the left
        const evenGroup = new Adw.PreferencesGroup({
            title: 'Even Spacing',
            description: 'Every icon and label on the right (each app indicator, each Quick Settings icon, ' +
                'the date and time, the notification dot) the same distance apart, measured as drawn. ' +
                'Replaces the right box spacing; an item\'s own padding still wins.',
        });
        spacingPage.add(evenGroup);
        const evenRow = new Adw.SwitchRow({title: 'Space the right side evenly'});
        settings.bind('even-spacing', evenRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        evenGroup.add(evenRow);
        const matchRow = new Adw.SwitchRow({
            title: 'Match the menus on the left',
            subtitle: 'The same gap as between the logo, app name and menu titles on the left',
            active: settings.get_int('even-gap') < 0,
        });
        const gapRow = new Adw.SpinRow({
            title: 'Gap (px)',
            adjustment: new Gtk.Adjustment({lower: 0, upper: 48, step_increment: 1, page_increment: 4}),
            value: Math.max(0, settings.get_int('even-gap') < 0 ? 12 : settings.get_int('even-gap')),
        });
        const syncEven = () => {
            const on = settings.get_boolean('even-spacing');
            matchRow.sensitive = on;
            gapRow.sensitive = on && !matchRow.active;
        };
        matchRow.connect('notify::active', () => {
            settings.set_int('even-gap', matchRow.active ? -1 : Math.round(gapRow.value));
            syncEven();
        });
        gapRow.connect('notify::value', () => {
            if (!matchRow.active)
                settings.set_int('even-gap', Math.round(gapRow.value));
        });
        evenRow.connect('notify::active', syncEven);
        syncEven();
        evenGroup.add(matchRow);
        evenGroup.add(gapRow);

        const resetGroup = new Adw.PreferencesGroup();
        layoutPage.add(resetGroup);
        const reset = new Adw.ButtonRow({
            title: 'Reset to Dusk defaults',
            start_icon_name: 'edit-undo-symbolic',
            css_classes: ['destructive-action'],
        });
        reset.connect('activated', () => RESET_KEYS.forEach(k => settings.reset(k)));
        resetGroup.add(reset);

        window.connect('close-request', () => {
            owned.forEach(o => o.destroy());
            return false;
        });
    }
}
