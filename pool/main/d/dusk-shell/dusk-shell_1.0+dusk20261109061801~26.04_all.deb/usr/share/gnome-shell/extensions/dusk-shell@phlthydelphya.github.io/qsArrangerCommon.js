// Shared between the shell process (extension.js) and the prefs process
// (prefs.js). Keep this free of Shell/St/Gtk imports.

export const SPACER_ID = 'spacer';
export const CUSTOM_PREFIX = 'custom:';

// Settings that only affect toggle sizing (handled by a stylesheet)
export const SIZE_KEYS = [
    'toggle-size-enabled', 'toggle-width', 'toggle-height',
    'toggle-icon-size', 'toggle-text-scale', 'grid-spacing',
];

// Friendly names for the stock quick settings items, keyed by class name.
const ITEM_LABELS = {
    SystemItem: 'System row (battery and quick actions)',
    OutputStreamSlider: 'Volume slider',
    InputStreamSlider: 'Microphone slider',
    BrightnessItem: 'Brightness slider',
    NMWiredToggle: 'Wired',
    NMWirelessToggle: 'Wi-Fi',
    NMModemToggle: 'Mobile Broadband',
    NMBluetoothToggle: 'Bluetooth Tethering',
    NMVpnToggle: 'VPN',
    BluetoothToggle: 'Bluetooth',
    PowerProfilesToggle: 'Power Mode',
    NightLightToggle: 'Night Light',
    DarkModeToggle: 'Dark Style',
    DoNotDisturbToggle: 'Do Not Disturb',
    KeyboardBrightnessToggle: 'Keyboard Backlight',
    RfkillToggle: 'Airplane Mode',
    RotationToggle: 'Auto Rotate',
    BackgroundAppsToggle: 'Background Apps',
};

const ACTION_LABELS = {
    power: 'Battery status',
    screenshot: 'Take Screenshot',
    settings: 'Settings',
    lock: 'Lock Screen',
    shutdown: 'Power Off Menu',
    [SPACER_ID]: 'Flexible space',
};

export const ACTION_CLASS_IDS = {
    PowerToggle: 'power',
    ScreenshotItem: 'screenshot',
    SettingsItem: 'settings',
    LockItem: 'lock',
    ShutdownItem: 'shutdown',
};

function splitId(id) {
    const [base, n] = id.split('#');
    return [base, n ? ` ${n}` : ''];
}

export function builtinItemLabel(id) {
    const [base, suffix] = splitId(id);
    return ITEM_LABELS[base] ? `${ITEM_LABELS[base]}${suffix}` : null;
}

export function builtinActionLabel(id) {
    const [base, suffix] = splitId(id);
    return ACTION_LABELS[base] ? `${ACTION_LABELS[base]}${suffix}` : null;
}

/**
 * Merge a user-chosen order with the current default order.
 *
 * Ids in `userOrder` keep their relative order. Ids only present in
 * `defaultOrder` (new items) are placed right after the nearest item that
 * precedes them in the default order. Ids in `userOrder` that are not in
 * `defaultOrder` are dropped.
 *
 * @param {string[]} userOrder
 * @param {string[]} defaultOrder
 * @returns {string[]}
 */
export function mergeOrder(userOrder, defaultOrder) {
    const present = new Set(defaultOrder);
    const result = [...new Set(userOrder)].filter(id => present.has(id));

    defaultOrder.forEach((id, i) => {
        if (result.includes(id))
            return;

        let pos = 0;
        for (let j = i - 1; j >= 0; j--) {
            const k = result.indexOf(defaultOrder[j]);
            if (k >= 0) {
                pos = k + 1;
                break;
            }
        }
        result.splice(pos, 0, id);
    });

    return result;
}

/**
 * @param {string} json
 * @returns {object[]} custom item definitions
 */
export function parseCustomItems(json) {
    try {
        const defs = JSON.parse(json);
        if (!Array.isArray(defs))
            return [];
        return defs.filter(d => d && typeof d.id === 'string' &&
            ['gsettings', 'launcher', 'command', 'action'].includes(d.kind));
    } catch {
        return [];
    }
}

export function parseKnown(json) {
    try {
        const list = JSON.parse(json);
        return Array.isArray(list) ? list.filter(i => typeof i?.id === 'string') : [];
    } catch {
        return [];
    }
}
