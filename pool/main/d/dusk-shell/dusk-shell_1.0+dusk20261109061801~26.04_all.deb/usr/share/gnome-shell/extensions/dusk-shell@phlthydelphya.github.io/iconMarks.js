// Dusk marks from the icon theme.
//
// An icon theme may draw its own Dusk marks: `dusk-start` (the dock's start
// button) and `dusk-logo` (the panel's logo menu). Strata, Dusk's icon theme,
// does (strata/tools/compose.py); with an icon theme that does not, the start
// button keeps the shell theme's accent-coloured mark (assets/dusk-start.svg)
// and the logo menu `start-here-symbolic`.
//
// markFile() finds a mark in the current icon theme; the start button
// (startMenu.js) and the logo menu (logoMenu.js) use it.

import St from 'gi://St';

// Path of the mark `name` in the current icon theme (or one it inherits), or
// null. A new St.IconTheme reads the theme name from St.Settings, so it is
// always the current one; marks are looked up rarely.
export function markFile(name) {
    const info = new St.IconTheme().lookup_icon(name, 128, 0);
    return info?.get_filename() ?? null;
}

// Call `callback` whenever the icon theme changes; returns a disconnect
// function. St.Settings, not the GSettings key: the shell's icon lookups
// follow St.Settings, which updates after the key.
export function watchIconTheme(callback) {
    const settings = St.Settings.get();
    const id = settings.connect('notify::gtk-icon-theme', () => callback());
    return () => settings.disconnect(id);
}
