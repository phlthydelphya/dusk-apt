#!/usr/bin/python3
"""Create one event in the desktop's default calendar; input is JSON on stdin."""
import datetime
import json
import sys
import uuid

import gi
gi.require_version('ECal', '2.0')
gi.require_version('EDataServer', '1.2')
gi.require_version('ICalGLib', '3.0')
from gi.repository import ECal, EDataServer, ICalGLib


def main():
    data = json.load(sys.stdin)
    title = data['title'].strip()
    if not title or len(title) > 512:
        raise ValueError('Enter an event title.')
    # Naive local datetimes are converted using the system timezone for the
    # selected date, including daylight-saving transitions.
    start = datetime.datetime.strptime(data['date'] + ' ' + data['time'], '%Y-%m-%d %H:%M')
    local_start = start.astimezone()
    if local_start.replace(tzinfo=None) != start:
        raise ValueError('That local time does not exist.')
    end = local_start.astimezone(datetime.timezone.utc) + datetime.timedelta(hours=1)
    utc = ICalGLib.Timezone.get_utc_timezone()
    event = ICalGLib.Component.new_vevent()
    event.set_uid(str(uuid.uuid4()))
    event.set_summary(title)
    event.set_dtstart(ICalGLib.Time.new_from_timet_with_zone(int(local_start.timestamp()), 0, utc))
    event.set_dtend(ICalGLib.Time.new_from_timet_with_zone(int(end.timestamp()), 0, utc))
    registry = EDataServer.SourceRegistry.new_sync(None)
    source = registry.ref_default_calendar()
    if source is None or not source.get_enabled():
        raise ValueError('Choose a default calendar in your calendar settings.')
    client = ECal.Client.connect_sync(source, ECal.ClientSourceType.EVENTS, 30, None)
    if client.is_readonly():
        raise ValueError('The default calendar is read-only.')
    client.create_object_sync(event, ECal.OperationFlags.DISABLE_ITIP_MESSAGE, None)
    print(source.get_display_name() or 'Calendar')


if __name__ == '__main__':
    try:
        main()
    except (Exception, KeyboardInterrupt) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
