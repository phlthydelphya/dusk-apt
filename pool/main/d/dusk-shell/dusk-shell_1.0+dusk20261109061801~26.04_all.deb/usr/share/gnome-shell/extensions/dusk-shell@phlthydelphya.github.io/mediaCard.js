import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import St from 'gi://St';

import {InjectionManager} from 'resource:///org/gnome/shell/extensions/extension.js';

const COVER_SIZE = 72;
const FALLBACK_ICON = 'audio-x-generic-symbolic';

// One Raven-style card per MPRIS player, pinned above the drawer's
// notification list. The shell would also list each player as a
// MediaMessage inside the notifications, so this hides those while enabled
// and puts them back on destroy().
//
// messageView is the date menu's MessageView (calendar.js:815). Private
// members used: _mediaSource (messageList.js:1523, the MprisSource whose
// player-added/player-removed signals feed the stock list),
// _playerToMessage (:1521), _addPlayer/_removePlayer (:1812/:1818).
export class MediaCard {
    constructor(messageView, closeDrawer) {
        this._view = messageView;
        this._closeDrawer = closeDrawer;
        // Newest first, [{player, row, changedId, ...widgets}]
        this._entries = [];

        this.actor = new St.BoxLayout({
            style_class: 'dusk-media',
            orientation: Clutter.Orientation.VERTICAL,
            x_expand: true,
            visible: false,
        });

        this._suppressStockMessages();

        const source = this._view._mediaSource;
        this._source = source;
        this._sourceSignals = [
            source.connect('player-added', (_, player) => this._addPlayer(player)),
            source.connect('player-removed', (_, player) => this._removePlayer(player)),
        ];
        for (const player of source.players)
            this._addPlayer(player);
    }

    // The stock list keeps its own MediaMessage per player. Drop the ones
    // that exist, then make _addPlayer a no-op and _removePlayer tolerant of
    // the missing message (stock _removeMessage(undefined) would throw).
    _suppressStockMessages() {
        const view = this._view;
        for (const player of [...view._playerToMessage.keys()])
            view._removePlayer(player);

        this._injections = new InjectionManager();
        const proto = Object.getPrototypeOf(view);
        this._injections.overrideMethod(proto, '_addPlayer', () => function () {});
        this._injections.overrideMethod(proto, '_removePlayer', original => function (player) {
            if (this._playerToMessage.has(player))
                original.call(this, player);
        });
    }

    _addPlayer(player) {
        if (this._entries.some(e => e.player === player))
            return;

        const row = new St.BoxLayout({style_class: 'dusk-media-card'});

        const cover = new St.Button({
            style_class: 'dusk-media-cover',
            can_focus: true,
            y_align: Clutter.ActorAlign.START,
            width: COVER_SIZE,
            height: COVER_SIZE,
        });
        const fallback = new St.Icon({
            style_class: 'dusk-media-cover-icon',
            icon_name: FALLBACK_ICON,
            x_align: Clutter.ActorAlign.CENTER,
            y_align: Clutter.ActorAlign.CENTER,
        });
        cover.set_child(fallback);
        row.add_child(cover);

        const body = new St.BoxLayout({
            style_class: 'dusk-media-body',
            orientation: Clutter.Orientation.VERTICAL,
            x_expand: true,
            y_align: Clutter.ActorAlign.CENTER,
        });
        const title = new St.Label({style_class: 'dusk-media-title'});
        const artist = new St.Label({style_class: 'dusk-media-artist'});
        const controls = new St.BoxLayout({style_class: 'dusk-media-controls'});
        const prev = this._makeButton('media-skip-backward-symbolic', 'dusk-media-button',
            () => player.previous());
        const play = this._makeButton('media-playback-start-symbolic',
            'dusk-media-button dusk-media-play', () => player.playPause());
        const next = this._makeButton('media-skip-forward-symbolic', 'dusk-media-button',
            () => player.next());
        controls.add_child(prev);
        controls.add_child(play);
        controls.add_child(next);
        body.add_child(title);
        body.add_child(artist);
        body.add_child(controls);
        row.add_child(body);

        const raise = () => {
            player.raise();
            this._closeDrawer?.();
        };
        cover.connect('clicked', raise);
        // Title is a label, so give it a click target
        const titleButton = new St.Button({
            style_class: 'dusk-media-title-button',
            can_focus: true,
            x_align: Clutter.ActorAlign.START,
            child: title,
        });
        titleButton.connect('clicked', raise);
        body.remove_child(title);
        body.insert_child_at_index(titleButton, 0);

        const entry = {player, row, cover, fallback, title, artist, prev, play, next, coverUrl: null};
        entry.changedId = player.connect('changed', () => this._update(entry));
        this._entries.unshift(entry);
        this.actor.insert_child_at_index(row, 0);
        this._update(entry);
        this._syncVisible();
    }

    _makeButton(iconName, styleClass, callback) {
        const button = new St.Button({
            style_class: styleClass,
            can_focus: true,
            child: new St.Icon({icon_name: iconName}),
        });
        button.connect('clicked', callback);
        return button;
    }

    _removePlayer(player) {
        const index = this._entries.findIndex(e => e.player === player);
        if (index < 0)
            return;
        const [entry] = this._entries.splice(index, 1);
        entry.player.disconnect(entry.changedId);
        entry.row.destroy();
        this._syncVisible();
    }

    _update(entry) {
        const {player} = entry;
        entry.title.text = player.trackTitle ?? '';
        entry.artist.text = (player.trackArtists ?? []).join(', ');

        const url = player.trackCoverUrl;
        if (url !== entry.coverUrl) {
            entry.coverUrl = url;
            // St paints background images from local files only
            const file = url ? Gio.File.new_for_uri(url) : null;
            if (file?.is_native() && file.query_exists(null)) {
                const path = file.get_path().replaceAll('\\', '\\\\').replaceAll("'", "\\'");
                entry.cover.style = `background-image: url('file://${encodeURI(path)}'); ` +
                    `background-size: ${COVER_SIZE}px ${COVER_SIZE}px;`;
                entry.fallback.visible = false;
            } else {
                entry.cover.style = null;
                entry.fallback.visible = true;
            }
        }

        entry.play.child.icon_name = player.status === 'Playing'
            ? 'media-playback-pause-symbolic'
            : 'media-playback-start-symbolic';
        this._setEnabled(entry.prev, !!player.canGoPrevious);
        this._setEnabled(entry.play, !!player.canPlay);
        this._setEnabled(entry.next, !!player.canGoNext);
    }

    _setEnabled(button, enabled) {
        button.reactive = enabled;
        button.can_focus = enabled;
        if (enabled)
            button.remove_style_pseudo_class('disabled');
        else
            button.add_style_pseudo_class('disabled');
    }

    _syncVisible() {
        this.actor.visible = this._entries.length > 0;
    }

    destroy() {
        for (const id of this._sourceSignals)
            this._source.disconnect(id);
        this._sourceSignals = [];
        for (const entry of this._entries)
            entry.player.disconnect(entry.changedId);
        this._entries = [];
        this.actor.destroy();

        // Stock list back: original methods first, then re-add what plays
        this._injections.clear();
        this._injections = null;
        const view = this._view;
        for (const player of this._source.players) {
            if (!view._playerToMessage.has(player))
                view._addPlayer(player);
        }
        this._view = null;
        this._source = null;
        this._closeDrawer = null;
    }
}
