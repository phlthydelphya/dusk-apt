// Copy text from the screen: a "Copy Text" toggle in the screenshot UI.
//
// With it on, the capture button reads the selected area, screen or window
// with Tesseract and copies the text, instead of saving a screenshot. The
// image goes to `tesseract stdin stdout` straight from memory, so nothing is
// written to ~/Pictures and no temporary file is left behind. The toggle
// turns off each time the screenshot UI closes, so the next screenshot is a
// normal one.
//
// Replaces the Tesseract OCR extension (tesseract-ocr@taygun86) and is
// written for Dusk: it hooks the one screenshot UI instance
// (Main.screenshotUI) instead of patching the class. Languages: the
// ocr-languages key ("eng+deu" style), or every installed language when it
// is empty. Without the tesseract program (package tesseract-ocr) the toggle
// is not shown.

import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Shell from 'gi://Shell';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {Tooltip} from 'resource:///org/gnome/shell/ui/screenshot.js';
import {InjectionManager, gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

const PREVIEW_CHARS = 120;

function communicate(argv, input, cancellable) {
    const flags = Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_PIPE |
        (input ? Gio.SubprocessFlags.STDIN_PIPE : 0);
    const proc = Gio.Subprocess.new(argv, flags);
    return new Promise((resolve, reject) => {
        proc.communicate_async(input, cancellable, (_p, res) => {
            try {
                const [, stdout, stderr] = proc.communicate_finish(res);
                const decode = b => (b ? new TextDecoder().decode(b.toArray()) : '');
                if (proc.get_successful())
                    resolve(decode(stdout));
                else
                    reject(new Error(decode(stderr).trim() || `${argv[0]} failed`));
            } catch (e) {
                reject(e);
            }
        });
    });
}

export class ScreenshotOcr {
    constructor(settings) {
        this._settings = settings;
        this._ui = Main.screenshotUI;
        if (!this._ui?._shotCastContainer || !this._ui._shotButton)
            return;
        if (!GLib.find_program_in_path('tesseract')) {
            console.log('dusk-shell: Copy Text needs tesseract (package tesseract-ocr)');
            return;
        }
        this._cancellable = new Gio.Cancellable();
        const ui = this._ui;

        this._button = new St.Button({
            style_class: 'screenshot-ui-shot-cast-button',
            icon_name: 'insert-text-symbolic',
            toggle_mode: true,
            accessible_name: _('Copy Text'),
        });
        ui._shotCastContainer.add_child(this._button);
        this._tooltip = new Tooltip(this._button, {
            text: _('Copy Text'),
            style_class: 'screenshot-ui-tooltip',
            visible: false,
        });
        ui.add_child(this._tooltip);

        // Copy Text is a kind of screenshot: it switches recording off, and
        // picking Screenshot or Record switches it off
        this._button.connectObject('notify::checked', () => {
            if (this._button.checked)
                ui._shotButton.checked = true;
            this._syncShotLook();
        }, this);
        ui._shotButton.connectObject(
            'clicked', () => {
                this._button.checked = false;
            },
            'notify::checked', () => this._syncShotLook(), this);
        ui._castButton?.connectObject('notify::checked', () => {
            if (ui._castButton.checked)
                this._button.checked = false;
        }, this);
        ui.connectObject('notify::visible', () => {
            if (!ui.visible)
                this._button.checked = false;
        }, this);

        const self = this;
        this._injections = new InjectionManager();
        this._injections.overrideMethod(ui, '_onCaptureButtonClicked', original =>
            async function (...args) {
                if (!self._button?.checked || !this._shotButton.checked)
                    return original.call(this, ...args);
                let png = null;
                try {
                    png = await self._grab(this);
                } catch (e) {
                    console.error(`dusk-shell: Copy Text: ${e.message}`);
                }
                this.close();
                if (png)
                    self._recognize(png).catch(e => self._report(e));
                return undefined;
            });
    }

    // The button that Copy Text stands in for looks off while it is on
    _syncShotLook() {
        const shot = this._ui._shotButton;
        if (this._button.checked)
            shot.remove_style_pseudo_class('checked');
        else if (shot.checked)
            shot.add_style_pseudo_class('checked');
    }

    // PNG bytes of what the screenshot UI has selected, without the pointer;
    // the same sources as ScreenshotUI._saveScreenshot()
    async _grab(ui) {
        let texture, geometry = [0, 0, -1, -1], scale;
        if (ui._selectionButton.checked || ui._screenButton.checked) {
            texture = ui._stageScreenshot.get_content()?.get_texture();
            geometry = ui._getSelectedGeometry(true);
            scale = ui._scale;
        } else if (ui._windowButton.checked) {
            const window = ui._windowSelectors.flatMap(s => s.windows()).find(w => w.checked);
            texture = window?.windowContent?.get_texture();
            scale = window?.bufferScale;
        }
        if (!texture)
            return null;
        const stream = Gio.MemoryOutputStream.new_resizable();
        const [x, y, w, h] = geometry;
        await Shell.Screenshot.composite_to_stream(texture, x, y, w, h, scale,
            null, 0, 0, 1, stream);
        stream.close(null);
        return stream.steal_as_bytes();
    }

    async _languages() {
        const chosen = this._settings.get_string('ocr-languages').trim();
        if (chosen)
            return chosen;
        if (!this._installed) {
            const out = await communicate(['tesseract', '--list-langs'], null, this._cancellable);
            // The first line is a header; osd is page layout, not a language
            const langs = out.split('\n').slice(1).map(l => l.trim())
                .filter(l => l && l !== 'osd');
            this._installed = langs.join('+') || 'eng';
        }
        return this._installed;
    }

    async _recognize(png) {
        const argv = ['tesseract', 'stdin', 'stdout', '-l', await this._languages()];
        const text = (await communicate(argv, png, this._cancellable)).trim();
        if (!text) {
            Main.notify(_('No text found'), _('Nothing readable was in the selection.'));
            return;
        }
        St.Clipboard.get_default().set_text(St.ClipboardType.CLIPBOARD, text);
        const preview = text.length > PREVIEW_CHARS
            ? `${text.slice(0, PREVIEW_CHARS)}…` : text;
        Main.notify(_('Text copied'), preview);
    }

    _report(e) {
        if (e instanceof GLib.Error && e.matches(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED))
            return;
        console.error(`dusk-shell: Copy Text: ${e.message}`);
        Main.notify(_('Could not copy text'), e.message);
    }

    destroy() {
        this._cancellable?.cancel();
        this._cancellable = null;
        this._injections?.clear();
        this._injections = null;
        if (this._ui) {
            this._ui.disconnectObject(this);
            this._ui._shotButton?.disconnectObject(this);
            this._ui._castButton?.disconnectObject(this);
        }
        if (this._button) {
            this._button.checked = false;
            this._tooltip.destroy();
            this._button.destroy();
        }
        this._button = null;
        this._tooltip = null;
        this._ui = null;
    }
}
