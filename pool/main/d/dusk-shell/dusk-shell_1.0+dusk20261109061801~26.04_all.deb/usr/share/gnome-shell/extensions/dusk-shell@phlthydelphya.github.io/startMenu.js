import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {ControlsState} from 'resource:///org/gnome/shell/ui/overviewControls.js';
import {InjectionManager, gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

import {AppMenu} from './appMenu.js';
import {markFile, watchIconTheme} from './iconMarks.js';

const DOCK_CONTAINER = 'dashtodockContainer';
const START_CLASS = 'dusk-start-button';
// Dusk's app icons are a 104-unit tile on a 128-unit canvas (shadow room);
// the start button's round icon fills its whole size, so it is shown at the
// same 104/128 to sit level with the app tiles in the dock, then 20% larger
// so the slab-less mark holds its own beside the tiles
const START_SCALE = 104 / 128 * 1.2;

function startContent(button) {
    return button.get_child?.() ?? null;
}

// The St.Icon the shell theme draws the start mark on (.show-apps-icon)
function startIcon(actor) {
    if (actor.has_style_class_name?.('show-apps-icon'))
        return actor;
    for (const child of actor.get_children?.() ?? []) {
        const found = startIcon(child);
        if (found)
            return found;
    }
    return null;
}
const A11Y_SCHEMA = 'org.gnome.desktop.a11y.keyboard';

// The Show Apps button of every Dash-to-Dock dock
// (dashtodockContainer → _slider → box → dash)
function dockShowAppsButtons() {
    return Main.uiGroup.get_children()
        .filter(actor => actor.name === DOCK_CONTAINER)
        .map(dock => dock._slider?.get_child()?.get_children()
            .find(child => child.name === 'dash')?.showAppsButton)
        .filter(button => button);
}

// Whether the dock gives its Show Apps icon a menu of its own (Dash to Dock
// does; Ubuntu Dock does not), which the start button then keeps
function dockHasOwnMenu(button) {
    const icon = button.get_parent?.();
    return icon?._hasPopupMenu?.() ?? false;
}

// Start button (the dock's Show Apps button, restyled) and the Super key
// both open the Dusk app menu. A right-click on the start button opens its
// own menu: Dismiss All Notifications.
export class StartMenu {
    constructor(settings, notificationActions = null) {
        this._settings = settings;
        this._actions = notificationActions;
        this._menu = new AppMenu(settings);
        this._suppress = false;
        this._resetId = 0;
        this._restyleId = 0;
        this._overlayId = 0;
        this._blockedOverlayId = 0;
        // button → destroy handler id
        this._styled = new Map();
        this._a11ySettings = new Gio.Settings({schema_id: A11Y_SCHEMA});

        // A dock's Show Apps button asks the overview for the app grid from
        // the desktop; the clicked one is still checked at that point
        const self = this;
        this._injections = new InjectionManager();
        this._injections.overrideMethod(Object.getPrototypeOf(Main.overview), 'show', original => function (state, ...args) {
            if (state === ControlsState.APP_GRID && !this.visible) {
                // Unchecking a dock's button asks for the app grid again
                if (self._suppress)
                    return;
                const button = dockShowAppsButtons().find(b => b.checked);
                if (button) {
                    self._onStartClicked(button);
                    return;
                }
            }
            original.call(this, state, ...args);
        });

        this._signals = [
            [this._settings, this._settings.connect('changed::super-opens-menu',
                () => this._syncOverlayKey())],
            // Docks are rebuilt on monitor and dock-setting changes
            [Main.uiGroup, Main.uiGroup.connect('child-added', () => this._queueRestyle())],
        ];
        // An icon theme with its own start mark (Strata) replaces the
        // shell theme's one
        this._unwatchIcons = watchIconTheme(() => {
            for (const button of this._styled.keys())
                this._applyMark(button);
        });
        this._syncOverlayKey();

        this._prepareId = GLib.idle_add(GLib.PRIORITY_LOW, () => {
            this._prepareId = 0;
            this._menu.prepare();
            this._restyle();
            return GLib.SOURCE_REMOVE;
        });
    }

    destroy() {
        this._injections.clear();
        this._injections = null;
        for (const [object, id] of this._signals)
            object.disconnect(id);
        this._signals = [];
        this._unwatchIcons?.();
        this._unwatchIcons = null;
        this._releaseOverlayKey();
        this._actions = null;
        for (const id of [this._prepareId, this._resetId, this._restyleId]) {
            if (id)
                GLib.source_remove(id);
        }
        this._prepareId = this._resetId = this._restyleId = 0;

        for (const [button, {destroyId, context}] of this._styled) {
            button.disconnect(destroyId);
            this._removeContextMenu(button, context);
            button.remove_style_class_name(START_CLASS);
            startContent(button)?.set_scale(1, 1);
            startIcon(button)?.set_style(null);
        }
        this._styled.clear();

        this._menu.destroy();
        this._menu = null;
        this._a11ySettings = null;
        this._settings = null;
    }

    _queueRestyle() {
        if (this._restyleId)
            return;
        // Dash-to-Dock fills the container after adding it
        this._restyleId = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
            this._restyleId = 0;
            this._restyle();
            return GLib.SOURCE_REMOVE;
        });
    }

    _restyle() {
        for (const button of dockShowAppsButtons()) {
            if (this._styled.has(button))
                continue;
            button.add_style_class_name(START_CLASS);
            const content = startContent(button);
            content?.set_pivot_point(0.5, 0.5);
            content?.set_scale(START_SCALE, START_SCALE);
            this._applyMark(button);
            const context = this._addContextMenu(button);
            const destroyId = button.connect('destroy', () => {
                context?.menu.destroy();
                this._styled.delete(button);
            });
            this._styled.set(button, {destroyId, context});
        }
    }

    // The start button's right-click (or Menu key) menu
    _addContextMenu(button) {
        if (!this._actions || dockHasOwnMenu(button))
            return null;
        const menu = new PopupMenu.PopupMenu(button, 0.5, St.Side.BOTTOM);
        const dismiss = menu.addAction(_('Dismiss All Notifications'),
            () => this._actions?.dismissAll());
        menu.connect('open-state-changed', (_menu, open) => {
            if (open)
                dismiss.setSensitive(this._actions?.hasActiveNotifications() ?? false);
        });
        Main.uiGroup.add_child(menu.actor);
        menu.actor.hide();
        const manager = new PopupMenu.PopupMenuManager(button);
        manager.addMenu(menu);

        const open = () => {
            this._menu.close?.();
            menu.toggle();
        };
        // No long-press: the button's own click would follow on release
        const gestures = [
            new Clutter.ClickGesture({
                required_button: Clutter.BUTTON_SECONDARY,
                recognize_on_press: true,
            }),
        ];
        for (const gesture of gestures) {
            gesture.connect('recognize', open);
            button.add_action(gesture);
        }
        const popupId = button.connect('popup-menu', open);
        return {menu, manager, gestures, popupId};
    }

    _removeContextMenu(button, context) {
        if (!context)
            return;
        button.disconnect(context.popupId);
        for (const gesture of context.gestures)
            button.remove_action(gesture);
        context.manager.removeMenu(context.menu);
        context.menu.destroy();
    }

    _applyMark(button) {
        const icon = startIcon(button);
        if (!icon)
            return;
        let file = null;
        try {
            file = markFile('dusk-start');
        } catch (e) {
            console.warn(`dusk-shell: start mark: ${e}`);
        }
        // Inline style outranks the theme's background-image (not !important)
        icon.set_style(file
            ? `background-image: url("${Gio.File.new_for_path(file).get_uri()}"); background-size: contain;`
            : null);
    }

    _onStartClicked(button) {
        this._menu.toggle(button);

        // The clicked button stays checked; clear it once its own signal
        // handlers are done
        if (!this._resetId) {
            this._resetId = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                this._resetId = 0;
                this._suppress = true;
                try {
                    for (const b of dockShowAppsButtons())
                        b.checked = false;
                } finally {
                    this._suppress = false;
                }
                return GLib.SOURCE_REMOVE;
            });
        }
    }

    _syncOverlayKey() {
        if (!this._settings)
            return;
        if (this._settings.get_boolean('super-opens-menu'))
            this._takeOverlayKey();
        else
            this._releaseOverlayKey();
    }

    _takeOverlayKey() {
        if (this._overlayId)
            return;
        // The shell's own handler (ControlsManager, overviewControls.js:463)
        // is the first one connected; block it while we own Super
        const id = GObject.signal_handler_find(global.display, {signalId: 'overlay-key'});
        if (id) {
            GObject.signal_handler_block(global.display, id);
            this._blockedOverlayId = id;
        }
        this._overlayId = global.display.connect('overlay-key', () => this._onOverlayKey());
    }

    _releaseOverlayKey() {
        if (this._overlayId)
            global.display.disconnect(this._overlayId);
        this._overlayId = 0;
        if (this._blockedOverlayId)
            GObject.signal_handler_unblock(global.display, this._blockedOverlayId);
        this._blockedOverlayId = 0;
    }

    _onOverlayKey() {
        // Same opt-out as the shell's handler
        if (this._a11ySettings.get_boolean('stickykeys-enable'))
            return;
        if (this._menu.recentlyClosed)
            return;
        if (Main.overview.visible) {
            Main.overview.hide();
            return;
        }
        this._menu.toggle(dockShowAppsButtons()[0] ?? null);
    }
}
