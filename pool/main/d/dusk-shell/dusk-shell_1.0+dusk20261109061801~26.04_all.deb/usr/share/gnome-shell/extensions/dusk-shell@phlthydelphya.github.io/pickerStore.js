// What the clipboard panel's pickers remember across logouts: recently used
// emoji, kaomoji and symbols (newest first), the skin tone, and the random
// customer id the GIF service asks for (KLIPY keeps recent GIFs itself).
// One small JSON file next to the pinned clipboard items.

import GLib from 'gi://GLib';

const MAX_RECENT = {emoji: 32, kaomoji: 16, symbols: 32};

export class PickerStore {
    constructor(dir) {
        this._dir = dir;
        this._file = GLib.build_filenamev([dir, 'recent.json']);
        this._data = {};
        this._saveId = 0;
        try {
            const [ok, bytes] = GLib.file_get_contents(this._file);
            if (ok)
                this._data = JSON.parse(new TextDecoder().decode(bytes)) ?? {};
        } catch {
            // No store yet, or unreadable: start empty
        }
    }

    get customerId() {
        if (typeof this._data.customer !== 'string') {
            this._data.customer = GLib.uuid_string_random();
            this._queueSave();
        }
        return this._data.customer;
    }

    recent(kind) {
        const list = this._data[kind];
        return Array.isArray(list) ? list : [];
    }

    addRecent(kind, value, keyOf = v => v) {
        const key = keyOf(value);
        const list = this.recent(kind).filter(v => keyOf(v) !== key);
        list.unshift(value);
        this._data[kind] = list.slice(0, MAX_RECENT[kind] ?? 24);
        this._queueSave();
    }

    get skinTone() {
        return Number.isInteger(this._data.tone) ? this._data.tone : 0;
    }

    set skinTone(tone) {
        this._data.tone = tone;
        this._queueSave();
    }

    _queueSave() {
        if (this._saveId)
            return;
        this._saveId = GLib.idle_add(GLib.PRIORITY_LOW, () => {
            this._saveId = 0;
            this.save();
            return GLib.SOURCE_REMOVE;
        });
    }

    save() {
        if (this._saveId) {
            GLib.source_remove(this._saveId);
            this._saveId = 0;
        }
        try {
            GLib.mkdir_with_parents(this._dir, 0o700);
            GLib.file_set_contents(this._file, JSON.stringify(this._data));
        } catch (e) {
            console.warn(`dusk-shell: picker recents not saved: ${e}`);
        }
    }
}
