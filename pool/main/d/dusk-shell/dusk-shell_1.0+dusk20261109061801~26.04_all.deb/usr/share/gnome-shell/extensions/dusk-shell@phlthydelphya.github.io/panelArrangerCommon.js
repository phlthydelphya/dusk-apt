// Shared between the shell process (extension.js) and the prefs process
// (prefs.js). Keep this free of Shell/St/Gtk imports.

export const UUID = 'panel-arranger@phlthydelphya.github.io';

export const BOXES = ['left', 'center', 'right'];

export const UNKNOWN_BOXES = ['keep', ...BOXES];
export const UNKNOWN_POSITIONS = ['start', 'end', 'before-quick-settings'];

// Roles that extensions create and destroy all the time, with ids that
// change between runs, are handled as one layout item each.
export const GROUPS = [
    // ubuntu-appindicators: `appindicator-${uniqueId}` (indicatorStatusIcon.js)
    {id: 'appindicators', prefix: 'appindicator-', label: 'App indicators'},
    // global-menu: `${uuid}-fallback-N`, `-native-N`, `-shortcut-N` (panelBar.js)
    {id: 'global-menu', prefix: 'global-menu@unmade.space-', label: 'Global menu'},
];

const ROLE_LABELS = {
    'activities': 'Activities',
    'quickSettings': 'Quick Settings',
    'dateMenu': 'Clock',
    'a11y': 'Accessibility menu',
    'keyboard': 'Keyboard layout',
    'dwellClick': 'Dwell click',
    'screenRecording': 'Screen recording indicator',
    'screenSharing': 'Screen sharing indicator',
    'LogoMenu': 'Logo menu',
    'ArcMenu': 'ArcMenu',
    'dusk-notif-dot': 'Notification dot',
    'places-menu': 'Places',
    'drive-menu': 'Removable drives',
    'workspace-indicator': 'Workspace indicator',
    'window-title': 'Window title',
    'window-controls': 'Window controls',
};

export function groupOf(role) {
    return GROUPS.find(g => role.startsWith(g.prefix)) ?? null;
}

// Layout id of a statusArea role: the group id, or the role itself
export function layoutId(role) {
    return groupOf(role)?.id ?? role;
}

export function roleLabel(id, fallback) {
    return ROLE_LABELS[id] ?? GROUPS.find(g => g.id === id)?.label ?? fallback ?? id;
}

/**
 * @param {string} json
 * @returns {object} layout id -> {box, index, hidden?, padding?}
 */
export function parseLayout(json) {
    try {
        const layout = JSON.parse(json);
        if (!layout || typeof layout !== 'object' || Array.isArray(layout))
            return {};
        const result = {};
        for (const [id, e] of Object.entries(layout)) {
            if (!e || !BOXES.includes(e.box))
                continue;
            result[id] = {
                ...e,
                index: Number.isFinite(e.index) ? e.index : 0,
            };
        }
        return result;
    } catch {
        return {};
    }
}

export function parseKnown(json) {
    try {
        const list = JSON.parse(json);
        return Array.isArray(list)
            ? list.filter(i => typeof i?.id === 'string' && BOXES.includes(i.box))
            : [];
    } catch {
        return [];
    }
}

/**
 * Decide the order of every present item in every box.
 *
 * Items with a layout entry go to that box, sorted by their layout index.
 * Items without one follow the unknown-items policy, in the order they
 * were first seen. With box `keep` they stay in the box their extension
 * chose, next to the items they currently sit beside.
 *
 * @param {object[]} items [{id, box, pos}] in first-seen order; box/pos
 *   are where the item is now (pos increases left to right within a box)
 * @param {object} layout from parseLayout()
 * @param {{box: string, position: string}} policy unknown-items policy
 * @returns {{left: string[], center: string[], right: string[]}}
 */
export function arrange(items, layout, policy) {
    const result = {left: [], center: [], right: []};
    const known = items.filter(i => layout[i.id]);
    const unknown = items.filter(i => !layout[i.id]);

    for (const box of BOXES) {
        result[box] = known
            .filter(i => layout[i.id].box === box)
            .sort((a, b) => layout[a.id].index - layout[b.id].index || a.pos - b.pos)
            .map(i => i.id);
    }

    const posOf = new Map(items.map(i => [i.id, i]));
    const starts = {left: 0, center: 0, right: 0};
    for (const item of unknown) {
        if (policy.box === 'keep') {
            const list = result[item.box];
            const next = list.findIndex(id => {
                const other = posOf.get(id);
                return other.box === item.box && other.pos > item.pos;
            });
            list.splice(next < 0 ? list.length : next, 0, item.id);
            continue;
        }

        const box = BOXES.includes(policy.box) ? policy.box : 'right';
        const list = result[box];
        if (policy.position === 'start') {
            list.splice(starts[box]++, 0, item.id);
        } else if (policy.position === 'end') {
            list.push(item.id);
        } else {
            const qs = list.indexOf('quickSettings');
            list.splice(qs < 0 ? list.length : qs, 0, item.id);
        }
    }
    return result;
}

/**
 * Write a new box order into a layout, keeping hidden/padding and the
 * entries of items that are not present right now.
 *
 * @param {object} layout from parseLayout()
 * @param {{left: string[], center: string[], right: string[]}} order
 * @returns {object} new layout
 */
export function withOrder(layout, order) {
    const next = {...layout};
    for (const box of BOXES) {
        order[box].forEach((id, index) => {
            next[id] = {...next[id], box, index};
        });
    }
    return next;
}
