// Shared by the shell side and prefs.js, so GLib only
import GLib from 'gi://GLib';

export const XDG_FOLDERS = {
    DESKTOP: {dir: GLib.UserDirectory.DIRECTORY_DESKTOP, icon: 'user-desktop-symbolic', name: 'Desktop'},
    DOCUMENTS: {dir: GLib.UserDirectory.DIRECTORY_DOCUMENTS, icon: 'folder-documents-symbolic', name: 'Documents'},
    DOWNLOAD: {dir: GLib.UserDirectory.DIRECTORY_DOWNLOAD, icon: 'folder-download-symbolic', name: 'Downloads'},
    MUSIC: {dir: GLib.UserDirectory.DIRECTORY_MUSIC, icon: 'folder-music-symbolic', name: 'Music'},
    PICTURES: {dir: GLib.UserDirectory.DIRECTORY_PICTURES, icon: 'folder-pictures-symbolic', name: 'Pictures'},
    PUBLIC_SHARE: {dir: GLib.UserDirectory.DIRECTORY_PUBLIC_SHARE, icon: 'folder-publicshare-symbolic', name: 'Public'},
    TEMPLATES: {dir: GLib.UserDirectory.DIRECTORY_TEMPLATES, icon: 'folder-templates-symbolic', name: 'Templates'},
    VIDEOS: {dir: GLib.UserDirectory.DIRECTORY_VIDEOS, icon: 'folder-videos-symbolic', name: 'Videos'},
    HOME: {dir: null, icon: 'user-home-symbolic', name: 'Home'},
};

/**
 * Turns a quick-folders entry into something to show and open.
 *
 * @param {string} entry an XDG name from XDG_FOLDERS or an absolute path
 * @returns {{path: string, label: string, icon: string}|null} null when the
 *   entry is unknown or the folder does not exist
 */
export function resolveFolder(entry) {
    let path = null;
    let icon = 'folder-symbolic';
    let label = null;

    const xdg = XDG_FOLDERS[entry];
    if (xdg) {
        path = xdg.dir === null ? GLib.get_home_dir() : GLib.get_user_special_dir(xdg.dir);
        icon = xdg.icon;
        label = xdg.dir === null ? xdg.name : null;
    } else if (GLib.path_is_absolute(entry)) {
        path = entry;
    }

    if (!path || !GLib.file_test(path, GLib.FileTest.IS_DIR))
        return null;

    // Basename of an XDG dir is its localized name
    return {path, icon, label: label ?? GLib.path_get_basename(path)};
}
