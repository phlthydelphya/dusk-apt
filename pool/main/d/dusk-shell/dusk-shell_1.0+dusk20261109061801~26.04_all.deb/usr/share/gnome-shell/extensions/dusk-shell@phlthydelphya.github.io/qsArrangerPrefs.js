import Adw from 'gi://Adw';
import Gdk from 'gi://Gdk';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Gtk from 'gi://Gtk';

import {SIZE_KEYS, SPACER_ID, mergeOrder, parseCustomItems, parseKnown} from './qsArrangerCommon.js';

const KIND_LABELS = {
    system: 'System row',
    slider: 'Slider',
    toggle: 'Toggle',
    item: 'Item',
    custom: 'Custom',
    action: 'Quick action button',
};

const CUSTOM_KIND_LABELS = {
    gsettings: 'Settings toggle',
    launcher: 'Program toggle',
    command: 'Command toggle',
    action: 'Quick settings button',
};

// Common choices offered when adding a toggle or a button. Commands are run
// without a shell (sh -c where one is needed); a command toggle's status
// command exits 0 when the thing is on.
const COMMON_TOGGLES = [
    {title: 'Stay Awake', subtitle: 'Never blank the screen', icon: 'preferences-desktop-screensaver-symbolic', kind: 'command',
        on: 'gsettings set org.gnome.desktop.session idle-delay 0',
        off: 'gsettings reset org.gnome.desktop.session idle-delay',
        status: "sh -c \"gsettings get org.gnome.desktop.session idle-delay | grep -q '^uint32 0$'\""},
    {title: 'Mute Microphone', icon: 'microphone-sensitivity-muted-symbolic', kind: 'command',
        on: 'wpctl set-mute @DEFAULT_AUDIO_SOURCE@ 1',
        off: 'wpctl set-mute @DEFAULT_AUDIO_SOURCE@ 0',
        status: "sh -c 'wpctl get-volume @DEFAULT_AUDIO_SOURCE@ | grep -q MUTED'"},
    {title: 'Touchpad', icon: 'input-touchpad-symbolic', kind: 'command',
        on: 'gsettings set org.gnome.desktop.peripherals.touchpad send-events enabled',
        off: 'gsettings set org.gnome.desktop.peripherals.touchpad send-events disabled',
        status: "sh -c \"gsettings get org.gnome.desktop.peripherals.touchpad send-events | grep -q '^.enabled.$'\""},
    {title: 'Large Text', icon: 'zoom-in-symbolic', kind: 'command',
        on: 'gsettings set org.gnome.desktop.interface text-scaling-factor 1.25',
        off: 'gsettings reset org.gnome.desktop.interface text-scaling-factor',
        status: "sh -c \"gsettings get org.gnome.desktop.interface text-scaling-factor | grep -qv '^1.0$'\""},
    {title: 'Automatic Suspend', icon: 'weather-clear-night-symbolic', kind: 'command',
        on: "sh -c 'gsettings reset org.gnome.settings-daemon.plugins.power sleep-inactive-ac-type; gsettings reset org.gnome.settings-daemon.plugins.power sleep-inactive-battery-type'",
        off: "sh -c 'gsettings set org.gnome.settings-daemon.plugins.power sleep-inactive-ac-type nothing; gsettings set org.gnome.settings-daemon.plugins.power sleep-inactive-battery-type nothing'",
        status: "sh -c 'gsettings get org.gnome.settings-daemon.plugins.power sleep-inactive-ac-type | grep -qv nothing'"},
    {title: 'Animations', icon: 'applications-system-symbolic', kind: 'gsettings',
        schema: 'org.gnome.desktop.interface', key: 'enable-animations'},
    {title: 'Hidden Files', icon: 'view-reveal-symbolic', kind: 'gsettings',
        schema: 'org.gtk.gtk4.Settings.FileChooser', key: 'show-hidden'},
    {title: 'Location Services', icon: 'location-services-active-symbolic', kind: 'gsettings',
        schema: 'org.gnome.system.location', key: 'enabled'},
    {title: 'Screen Reader', icon: 'preferences-desktop-accessibility-symbolic', kind: 'gsettings',
        schema: 'org.gnome.desktop.a11y.applications', key: 'screen-reader-enabled'},
    {title: 'On-Screen Keyboard', icon: 'input-keyboard-symbolic', kind: 'gsettings',
        schema: 'org.gnome.desktop.a11y.applications', key: 'screen-keyboard-enabled'},
];
const COMMON_COMMANDS = [
    {title: 'Suspend', icon: 'weather-clear-night-symbolic', command: 'systemctl suspend'},
    {title: 'Log Out', icon: 'system-log-out-symbolic', command: 'gnome-session-quit --logout'},
    {title: 'Empty Trash', icon: 'user-trash-symbolic', command: 'gio trash --empty'},
    {title: 'Downloads', icon: 'folder-download-symbolic', command: "sh -c 'gio open \"$(xdg-user-dir DOWNLOAD)\"'"},
    {title: 'Restart Wi-Fi', icon: 'network-wireless-symbolic', command: "sh -c 'nmcli radio wifi off; sleep 1; nmcli radio wifi on'"},
];


const SPAN_CHOICES = [
    ['Default width', 0],
    ['1 column', 1],
    ['2 columns', 2],
    ['3 columns', 3],
    ['4 columns', 4],
    ['Full width', -1],
];

function isBooleanKey(schemaId, key) {
    if (!schemaId || !key)
        return false;
    const schema = Gio.SettingsSchemaSource.get_default()?.lookup(schemaId, true);
    if (!schema?.has_key(key))
        return false;
    return schema.get_key(key).get_value_type().dup_string() === 'b';
}

// Keep the existing text fields for commands and icon names that are not in
// the installed application and icon lists.
function chooseFromList(parent, title, items, onChoose) {
    const window = new Gtk.Window({
        title, transient_for: parent.get_root(), modal: true,
        default_width: 480, default_height: 560,
    });
    const box = new Gtk.Box({orientation: Gtk.Orientation.VERTICAL, spacing: 8,
        margin_top: 12, margin_bottom: 12, margin_start: 12, margin_end: 12});
    const search = new Gtk.SearchEntry({placeholder_text: 'Search'});
    const list = new Gtk.ListBox({selection_mode: Gtk.SelectionMode.NONE,
        css_classes: ['boxed-list']});
    const scroll = new Gtk.ScrolledWindow({vexpand: true, child: list});
    box.append(search);
    box.append(scroll);
    window.set_child(box);
    const rebuild = () => {
        let child;
        while ((child = list.get_first_child()))
            list.remove(child);
        const query = search.text.toLocaleLowerCase();
        // Bound widget creation even for very large icon themes.
        for (const item of items.filter(i => i.search.includes(query)).slice(0, 200)) {
            const row = new Adw.ActionRow({title: item.label, subtitle: item.subtitle || '',
                use_markup: false, activatable: true});
            if (item.icon)
                row.add_prefix(new Gtk.Image({gicon: item.icon, pixel_size: 24}));
            row.connect('activated', () => {
                onChoose(item);
                window.close();
            });
            list.append(row);
        }
    };
    search.connect('search-changed', rebuild);
    rebuild();
    window.present();
    return {refresh: rebuild, window};
}

function chooseApplication(parent, onChoose) {
    const items = Gio.AppInfo.get_all()
        .filter(app => app.should_show() && app.get_id()?.endsWith('.desktop'))
        .map(app => ({label: app.get_display_name(), subtitle: app.get_id(),
            search: `${app.get_display_name()} ${app.get_id()}`.toLocaleLowerCase(),
            icon: app.get_icon(), value: app.get_id()}))
        .sort((a, b) => a.label.localeCompare(b.label));
    chooseFromList(parent, 'Choose an application', items, onChoose);
}

// Every boolean key of every installed (non-relocatable) schema
function chooseSetting(parent, onChoose) {
    const source = Gio.SettingsSchemaSource.get_default();
    const [ids] = source?.list_schemas(true) ?? [[]];
    const items = [];
    for (const id of ids) {
        const schema = source.lookup(id, true);
        if (!schema?.get_path())
            continue;
        for (const key of schema.list_keys()) {
            const info = schema.get_key(key);
            if (info.get_value_type().dup_string() !== 'b')
                continue;
            const summary = info.get_summary() || '';
            items.push({label: summary || key, subtitle: `${id}  ${key}`,
                search: `${summary} ${id} ${key}`.toLocaleLowerCase(),
                value: {schema: id, key, summary}});
        }
    }
    items.sort((a, b) => a.label.localeCompare(b.label));
    chooseFromList(parent, 'Choose a setting to toggle', items, onChoose);
}

// What a new or re-picked toggle (type 'toggle') or quick settings button
// (type 'button') does. onChoose gets the item's fields (kind included).
// Toggles: a setting, a program, a common toggle or a custom command toggle.
// Buttons: a program, a common command or a custom command.
function chooseAction(parent, type, onChoose) {
    const icon = name => Gio.ThemedIcon.new(name);
    const entry = (label, subtitle, iconName, value) => ({
        label, subtitle, icon: icon(iconName), value,
        search: `${label} ${subtitle}`.toLocaleLowerCase(),
    });
    const items = [];
    if (type === 'toggle')
        items.push(entry('A setting…', 'Turn any on/off system setting on and off', 'emblem-system-symbolic', 'setting'));
    items.push(entry('Open a program…', 'Start an application', 'application-x-executable-symbolic', 'program'));
    if (type === 'toggle') {
        for (const t of COMMON_TOGGLES)
            items.push(entry(t.title, t.subtitle ?? (t.kind === 'gsettings' ? 'Setting' : 'Command toggle'), t.icon, t));
        items.push(entry('Custom command toggle', 'Your own commands to turn something on and off', 'utilities-terminal-symbolic', 'custom'));
    } else {
        for (const c of COMMON_COMMANDS)
            items.push(entry(c.title, c.command, c.icon, c));
        items.push(entry('Custom command', 'Your own command line', 'utilities-terminal-symbolic', 'custom'));
    }
    chooseFromList(parent, type === 'toggle' ? 'What should the toggle do?' : 'What should the button do?', items, ({value}) => {
        if (value === 'setting') {
            chooseSetting(parent, ({value: v}) => onChoose({
                kind: 'gsettings', title: v.summary || v.key, icon: 'emblem-system-symbolic',
                schema: v.schema, key: v.key, invert: false,
            }));
        } else if (value === 'program') {
            chooseApplication(parent, app => onChoose({
                kind: type === 'toggle' ? 'launcher' : 'action',
                title: app.label, command: app.value,
                icon: symbolicIconFor(app.icon) ?? 'application-x-executable-symbolic',
            }));
        } else if (value === 'custom') {
            onChoose(type === 'toggle'
                ? {kind: 'command', title: 'Custom Toggle', icon: 'utilities-terminal-symbolic', on: '', off: '', status: ''}
                : {kind: 'action', title: 'Custom Button', icon: 'utilities-terminal-symbolic', command: ''});
        } else if (type === 'toggle') {
            const {subtitle: _s, ...fields} = value;
            onChoose(fields.kind === 'gsettings' ? {...fields, invert: false} : fields);
        } else {
            onChoose({kind: 'action', ...value});
        }
    });
}

// A symbolic icon for an application, when the icon theme has one
function symbolicIconFor(gicon) {
    const names = gicon instanceof Gio.ThemedIcon ? gicon.get_names() : [];
    const theme = Gtk.IconTheme.get_for_display(Gdk.Display.get_default());
    return names.map(n => `${n.replace(/-symbolic$/, '')}-symbolic`).find(n => theme.has_icon(n)) ?? null;
}

function chooseIcon(parent, onChoose) {
    const theme = Gtk.IconTheme.get_for_display(Gdk.Display.get_default());
    const names = theme.get_icon_names().sort((a, b) => a.localeCompare(b));
    const items = [];
    const picker = chooseFromList(parent, 'Choose an SVG icon', items, onChoose);
    let closed = false;
    picker.window.connect('close-request', () => { closed = true; return false; });
    let index = 0;
    GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
        if (closed)
            return GLib.SOURCE_REMOVE;
        const end = Math.min(index + 20, names.length);
        for (; index < end; index++) {
            const name = names[index];
            const paintable = theme.lookup_icon(name, null, 32, 1, Gtk.TextDirection.NONE,
                Gtk.IconLookupFlags.FORCE_REGULAR);
            if (paintable?.get_file()?.get_path()?.toLowerCase().endsWith('.svg'))
                items.push({label: name, search: name.toLocaleLowerCase(),
                    icon: Gio.ThemedIcon.new(name), value: name});
        }
        if (index % 200 === 0 || index === names.length)
            picker.refresh();
        if (index === names.length) {
            return GLib.SOURCE_REMOVE;
        }
        return GLib.SOURCE_CONTINUE;
    });
}

// Settings handlers can fire from a widget we are about to throw away,
// so rebuilds always wait for idle.
class Rebuilder {
    constructor(settings, keys, rebuild) {
        this._settings = settings;
        this._rebuild = rebuild;
        this._idleId = 0;
        this._ids = keys.map(key =>
            settings.connect(`changed::${key}`, () => this.queue()));
        rebuild();
    }

    queue() {
        if (this._idleId)
            return;
        this._idleId = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
            this._idleId = 0;
            this._rebuild();
            return GLib.SOURCE_REMOVE;
        });
    }

    destroy() {
        this._ids.forEach(id => this._settings.disconnect(id));
        if (this._idleId)
            GLib.source_remove(this._idleId);
    }
}

class OrderList {
    constructor(settings, group, opts) {
        this._settings = settings;
        this._group = group;
        this._opts = opts;
        this._rows = [];

        const keys = [opts.knownKey, opts.orderKey, opts.hiddenKey];
        if (opts.withSpans)
            keys.push('item-spans');
        this._rebuilder = new Rebuilder(settings, keys, () => this._rebuild());
    }

    _rebuild() {
        this._rows.forEach(r => this._group.remove(r));
        this._rows = [];

        const {knownKey, orderKey, hiddenKey, withSpans} = this._opts;
        const known = parseKnown(this._settings.get_string(knownKey));
        if (known.length === 0) {
            this._addRow(new Adw.ActionRow({
                title: 'Nothing found yet',
                subtitle: 'Enable the extension. The list fills in once GNOME Shell has loaded it.',
            }));
            return;
        }

        const byId = new Map(known.map(k => [k.id, k]));
        const order = mergeOrder(this._settings.get_strv(orderKey), known.map(k => k.id));
        const hidden = new Set(this._settings.get_strv(hiddenKey));
        const spans = withSpans
            ? this._settings.get_value('item-spans').deepUnpack()
            : {};

        order.forEach((id, i) => {
            const item = byId.get(id);
            const isSpacer = id === SPACER_ID;
            const row = new Adw.ActionRow({
                title: item.label,
                subtitle: isSpacer
                    ? 'Pushes the buttons after it to the far side'
                    : KIND_LABELS[item.kind] ?? '',
                use_markup: false,
            });

            if (withSpans) {
                const dropdown = Gtk.DropDown.new_from_strings(SPAN_CHOICES.map(c => c[0]));
                dropdown.valign = Gtk.Align.CENTER;
                dropdown.tooltip_text = 'Width in the grid';
                const current = SPAN_CHOICES.findIndex(c => c[1] === (spans[id] ?? 0));
                dropdown.selected = Math.max(current, 0);
                dropdown.connect('notify::selected', () =>
                    this._setSpan(id, SPAN_CHOICES[dropdown.selected][1]));
                row.add_suffix(dropdown);
            }

            if (!isSpacer) {
                const toggle = new Gtk.Switch({
                    active: !hidden.has(id),
                    valign: Gtk.Align.CENTER,
                    tooltip_text: 'Show',
                });
                toggle.connect('notify::active', () => this._setHidden(id, !toggle.active));
                row.add_suffix(toggle);
            }

            row.add_prefix(new Gtk.Image({
                icon_name: 'list-drag-handle-symbolic',
                css_classes: ['dim-label'],
                tooltip_text: 'Drag to reorder',
            }));
            this._makeDraggable(row, id, order, i);

            this._addRow(row);
        });
    }

    _makeDraggable(row, id, order, i) {
        let hotX = 0, hotY = 0;
        const source = new Gtk.DragSource({actions: Gdk.DragAction.MOVE});
        source.connect('prepare', (_src, x, y) => {
            hotX = x;
            hotY = y;
            const value = new GObject.Value();
            value.init(GObject.TYPE_STRING);
            value.set_string(id);
            return Gdk.ContentProvider.new_for_value(value);
        });
        source.connect('drag-begin', (_src, drag) => {
            // Show a copy of the row under the pointer
            const list = new Gtk.ListBox({css_classes: ['boxed-list']});
            list.set_size_request(row.get_width(), row.get_height());
            list.append(new Adw.ActionRow({
                title: row.title,
                subtitle: row.subtitle,
                use_markup: false,
            }));
            Gtk.DragIcon.get_for_drag(drag).child = list;
            drag.set_hotspot(hotX, hotY);
            row.opacity = 0.4;
        });
        source.connect('drag-end', () => {
            row.opacity = 1;
        });
        row.add_controller(source);

        const target = new Gtk.DropTarget({actions: Gdk.DragAction.MOVE});
        target.set_gtypes([GObject.TYPE_STRING]);
        target.connect('drop', (_tgt, dragged) => {
            const from = order.indexOf(dragged);
            // Ignore drops from the other list or from other apps
            if (from < 0 || from === i)
                return false;
            this._moveTo(order, from, i);
            return true;
        });
        row.add_controller(target);
    }

    _addRow(row) {
        this._group.add(row);
        this._rows.push(row);
    }

    _moveTo(order, from, to) {
        const next = [...order];
        const [id] = next.splice(from, 1);
        next.splice(to, 0, id);
        // Keep the place of items that are missing right now
        const extra = this._settings.get_strv(this._opts.orderKey)
            .filter(id => !next.includes(id));
        this._settings.set_strv(this._opts.orderKey, [...next, ...extra]);
    }

    _setHidden(id, hide) {
        const key = this._opts.hiddenKey;
        const hidden = new Set(this._settings.get_strv(key));
        if (hide)
            hidden.add(id);
        else
            hidden.delete(id);
        this._settings.set_strv(key, [...hidden]);
    }

    _setSpan(id, span) {
        const spans = this._settings.get_value('item-spans').deepUnpack();
        if (span === 0)
            delete spans[id];
        else
            spans[id] = span;
        this._settings.set_value('item-spans', new GLib.Variant('a{si}', spans));
    }

    destroy() {
        this._rebuilder.destroy();
    }
}

class CustomEditor {
    constructor(settings, group) {
        this._settings = settings;
        this._group = group;
        this._rows = [];
        this._expanded = new Set();
        this._rebuilder = new Rebuilder(settings, ['custom-items'], () => this._rebuild());
    }

    _defs() {
        return parseCustomItems(this._settings.get_string('custom-items'));
    }

    _save(defs) {
        this._settings.set_string('custom-items', JSON.stringify(defs));
    }

    // New items start from a chooser (chooseAction), so none is saved blank
    // unless the user picks a custom command, which opens for editing.
    // Closing the chooser adds nothing.
    add(type, parent) {
        chooseAction(parent, type, fields => {
            const id = GLib.uuid_string_random().slice(0, 8);
            this._expanded.add(id);
            this._save([...this._defs(), {id, ...fields}]);
        });
    }

    // Replace what an item does, keeping its id (and so its place)
    _replace(id, fields) {
        this._expanded.add(id);
        this._save(this._defs().map(d => (d.id === id ? {id, ...fields} : d)));
    }

    _update(id, changes) {
        this._save(this._defs().map(d => (d.id === id ? {...d, ...changes} : d)));
    }

    _remove(id) {
        this._expanded.delete(id);
        this._save(this._defs().filter(d => d.id !== id));
    }

    _rebuild() {
        this._rows.forEach(r => this._group.remove(r));
        this._rows = [];

        const defs = this._defs();
        if (defs.length === 0) {
            const row = new Adw.ActionRow({
                title: 'No custom items',
                subtitle: 'Use the buttons below to add one.',
            });
            this._group.add(row);
            this._rows.push(row);
            return;
        }

        for (const def of defs)
            this._addExpander(def);
    }

    _addExpander(def) {
        let subtitle = CUSTOM_KIND_LABELS[def.kind];
        if (def.kind === 'gsettings' && !isBooleanKey(def.schema, def.key))
            subtitle += ' — needs a boolean key, hidden until fixed';
        else if (def.kind === 'command' && !def.on?.trim() && !def.off?.trim())
            subtitle += ' — needs a command';
        else if (['launcher', 'action'].includes(def.kind) && !def.command?.trim())
            subtitle += ' — needs a command';

        const expander = new Adw.ExpanderRow({
            title: def.title || '(untitled)',
            subtitle,
            use_markup: false,
            expanded: this._expanded.has(def.id),
        });
        expander.add_prefix(new Gtk.Image({icon_name: def.icon || 'image-missing-symbolic'}));
        expander.connect('notify::expanded', () => {
            if (expander.expanded)
                this._expanded.add(def.id);
            else
                this._expanded.delete(def.id);
        });

        const entry = (title, field, tooltip) => {
            const row = new Adw.EntryRow({
                title,
                text: def[field] ?? '',
                show_apply_button: true,
                tooltip_text: tooltip ?? '',
            });
            row.connect('apply', () => this._update(def.id, {[field]: row.text.trim()}));
            expander.add_row(row);
        };

        const change = new Adw.ButtonRow({title: 'Change what it does…'});
        change.connect('activated', () => chooseAction(expander,
            def.kind === 'action' ? 'button' : 'toggle', fields => this._replace(def.id, fields)));
        expander.add_row(change);

        entry('Title', 'title');
        if (def.kind !== 'action')
            entry('Subtitle', 'subtitle');
        entry('Icon name', 'icon', 'A symbolic icon name, e.g. weather-clear-night-symbolic');
        const iconPicker = new Adw.ButtonRow({title: 'Choose an SVG icon'});
        iconPicker.connect('activated', () => chooseIcon(expander,
            item => this._update(def.id, {icon: item.value})));
        expander.add_row(iconPicker);

        if (def.kind === 'gsettings') {
            const settingPicker = new Adw.ButtonRow({title: 'Choose a setting'});
            settingPicker.connect('activated', () => chooseSetting(expander, ({value}) => {
                const changes = {schema: value.schema, key: value.key};
                if (!def.title || def.title === 'New toggle')
                    changes.title = value.summary || value.key;
                this._update(def.id, changes);
            }));
            expander.add_row(settingPicker);
            entry('Schema', 'schema', 'e.g. org.gnome.desktop.interface');
            entry('Key', 'key', 'A boolean key in that schema');
            const invert = new Adw.SwitchRow({title: 'Invert', active: !!def.invert});
            invert.connect('notify::active', () => this._update(def.id, {invert: invert.active}));
            expander.add_row(invert);
        } else if (def.kind === 'command') {
            entry('Command to turn on', 'on', 'Runs when the toggle is switched on, e.g. wpctl set-mute @DEFAULT_AUDIO_SOURCE@ 1. Use sh -c \'...\' for pipes or variables.');
            entry('Command to turn off', 'off', 'Runs when the toggle is switched off');
            entry('Status command (optional)', 'status', 'Exits 0 when the thing is on, so the toggle shows the real state; checked when Quick Settings opens. Empty: the toggle remembers its last click.');
        } else {
            entry('Command', 'command', 'A command line, or a .desktop file id such as org.gnome.Calculator.desktop');
            const appPicker = new Adw.ButtonRow({title: 'Choose an application'});
            appPicker.connect('activated', () => chooseApplication(expander, item => {
                const changes = {command: item.value};
                if (!def.title || /^New (button|launcher)$/.test(def.title))
                    changes.title = item.label;
                const icon = symbolicIconFor(item.icon);
                if (icon && (!def.icon || def.icon === 'application-x-executable-symbolic'))
                    changes.icon = icon;
                this._update(def.id, changes);
            }));
            expander.add_row(appPicker);
        }

        const remove = new Adw.ButtonRow({title: 'Remove', css_classes: ['destructive-action']});
        remove.connect('activated', () => this._remove(def.id));
        expander.add_row(remove);

        this._group.add(expander);
        this._rows.push(expander);
    }

    destroy() {
        this._rebuilder.destroy();
    }
}

function resetButton(onClick) {
    const button = new Gtk.Button({
        label: 'Reset',
        valign: Gtk.Align.CENTER,
        css_classes: ['flat'],
    });
    button.connect('clicked', onClick);
    return button;
}

// Pages for the Dusk Shell preferences window (formerly the Quick Settings Arranger extension, merged into
// Dusk Shell). The settings object is kept alive with the window.
export class QsArrangerPages {
    static fill(window, settings) {
        (window._duskArrangerSettings ??= []).push(settings);
        const owned = [];

        // Layout page
        const layoutPage = new Adw.PreferencesPage({
            title: 'Quick Settings',
            icon_name: 'view-grid-symbolic',
        });
        window.add(layoutPage);

        const gridGroup = new Adw.PreferencesGroup({title: 'Grid'});
        layoutPage.add(gridGroup);
        const columns = new Adw.SpinRow({
            title: 'Columns',
            subtitle: 'Items that fill a row by default, like sliders, stay full width',
            adjustment: new Gtk.Adjustment({lower: 1, upper: 4, step_increment: 1}),
            value: settings.get_int('n-columns'),
        });
        columns.connect('notify::value', () => {
            const n = Math.round(columns.value);
            if (settings.get_int('n-columns') !== n)
                settings.set_int('n-columns', n);
        });
        gridGroup.add(columns);

        const sizeGroup = new Adw.PreferencesGroup({
            title: 'Toggle size',
            header_suffix: resetButton(() => SIZE_KEYS.forEach(k => settings.reset(k))),
        });
        layoutPage.add(sizeGroup);
        const sizeRow = new Adw.ExpanderRow({
            title: 'Custom toggle size',
            subtitle: 'Width also sets the grid column width. The menu never gets narrower than its top row of buttons.',
            show_enable_switch: true,
        });
        settings.bind('toggle-size-enabled', sizeRow, 'enable-expansion',
            Gio.SettingsBindFlags.DEFAULT);
        sizeGroup.add(sizeRow);
        for (const [title, key, lower, upper, step] of [
            ['Width (px)', 'toggle-width', 80, 400, 4],
            ['Height (px)', 'toggle-height', 24, 120, 2],
            ['Icon size (px)', 'toggle-icon-size', 8, 48, 1],
            ['Text size (%)', 'toggle-text-scale', 50, 200, 5],
            ['Spacing between items (px)', 'grid-spacing', 0, 40, 1],
        ]) {
            const row = new Adw.SpinRow({
                title,
                adjustment: new Gtk.Adjustment({
                    lower,
                    upper,
                    step_increment: step,
                    page_increment: step * 5,
                }),
            });
            settings.bind(key, row, 'value', Gio.SettingsBindFlags.DEFAULT);
            sizeRow.add_row(row);
        }

        const itemsGroup = new Adw.PreferencesGroup({
            title: 'Toggles and sliders',
            description: 'Order, visibility and width of everything in the quick settings grid, including toggles added by other extensions.',
            header_suffix: resetButton(() => {
                settings.reset('grid-order');
                settings.reset('hidden-items');
                settings.reset('item-spans');
            }),
        });
        layoutPage.add(itemsGroup);
        owned.push(new OrderList(settings, itemsGroup, {
            knownKey: 'known-items',
            orderKey: 'grid-order',
            hiddenKey: 'hidden-items',
            withSpans: true,
        }));

        // Quick actions page
        const actionsPage = new Adw.PreferencesPage({
            title: 'Quick Actions',
            icon_name: 'system-shutdown-symbolic',
        });
        window.add(actionsPage);

        const actionsGroup = new Adw.PreferencesGroup({
            title: 'Quick action buttons',
            description: 'The buttons in the top row: battery, screenshot, settings, lock and power off.',
            header_suffix: resetButton(() => {
                settings.reset('action-order');
                settings.reset('hidden-actions');
            }),
        });
        actionsPage.add(actionsGroup);
        owned.push(new OrderList(settings, actionsGroup, {
            knownKey: 'known-actions',
            orderKey: 'action-order',
            hiddenKey: 'hidden-actions',
            withSpans: false,
        }));

        // Custom items page
        const customPage = new Adw.PreferencesPage({
            title: 'Custom Toggles',
            icon_name: 'list-add-symbolic',
        });
        window.add(customPage);

        const customGroup = new Adw.PreferencesGroup({
            title: 'Custom items',
            description: 'New toggles and buttons. A toggle can flip a setting, open a program, ' +
                'or run commands to turn something on and off; a button opens a program or runs a command. ' +
                'Place them on the Layout and Quick Actions pages.',
        });
        customPage.add(customGroup);
        const editor = new CustomEditor(settings, customGroup);
        owned.push(editor);

        const addGroup = new Adw.PreferencesGroup();
        customPage.add(addGroup);
        for (const [type, title] of [
            ['toggle', 'Add toggle'],
            ['button', 'Add quick settings button'],
        ]) {
            const button = new Adw.ButtonRow({title, start_icon_name: 'list-add-symbolic'});
            button.connect('activated', () => editor.add(type, button));
            addGroup.add(button);
        }

        window.connect('close-request', () => {
            owned.forEach(o => o.destroy());
            return false;
        });
    }
}
