import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import Meta from 'gi://Meta';
import GLib from 'gi://GLib';
import Pango from 'gi://Pango';
import Shell from 'gi://Shell';
import Soup from 'gi://Soup?version=3.0';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as RemoteSearch from 'resource:///org/gnome/shell/ui/remoteSearch.js';
import * as SystemActions from 'resource:///org/gnome/shell/misc/systemActions.js';
import {AppSearchProvider} from 'resource:///org/gnome/shell/ui/appDisplay.js';
import {ensureActorVisibleInScrollView} from 'resource:///org/gnome/shell/misc/animationUtils.js';
import {gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

import {Acrylic} from './acrylic.js';
import {OPEN_TIME, CLOSE_TIME, OPEN_MODE, CLOSE_MODE, timing} from './motion.js';

// Win11-style search in the top bar: a notch in the panel's center is the
// search field; the results are a tab that unrolls from under the top bar. Results come
// from the same providers as the overview search (apps and system actions,
// then every search provider enabled in Settings > Search: Files, Settings,
// Calculator, Characters, ...), plus predictive web suggestions as you type
// (search-web-suggestions; DuckDuckGo by default) and a "Search the web" row.

Gio._promisify(Soup.Session.prototype, 'send_and_read_async');
Gio._promisify(Gio.Subprocess.prototype, 'communicate_utf8_async');

const CARD_WIDTH = 680; // logical px
const CARD_HEIGHT = 520; // with results
const HINT_HEIGHT = 64; // before typing: the hint only
const SCREEN_GAP = 12; // $gap-m
const ROW_ICON = 28;
const APP_RESULTS = 6;
const PROVIDER_RESULTS = 3;
const WEB_SUGGESTIONS = 5;
const DEBOUNCE_MS = 120;
const FILE_RESULTS = 4; // per category

// Indexed files (LocalSearch, GNOME's file indexer: Settings > Search >
// Search Locations), grouped like Windows search. Queried through the
// tinysparql command line, which needs no extra GObject bindings.
const LOCALSEARCH = 'org.freedesktop.LocalSearch3';
const NFO = 'http://tracker.api.gnome.org/ontology/v3/nfo#';
const FILE_CATEGORIES = [
    ['Document', 'Documents'],
    ['Image', 'Pictures'],
    ['Audio', 'Music'],
    ['Video', 'Videos'],
    ['Folder', 'Folders'],
];
const NAUTILUS_ID = 'org.gnome.Nautilus.desktop';

function sparqlString(s) {
    return `"${s.toLowerCase().replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
}

function fileQuery(terms) {
    const filters = terms.map(term =>
        `FILTER (CONTAINS(LCASE(?name), ${sparqlString(term)}))`).join(' ');
    const types = FILE_CATEGORIES.map(([type]) => `nfo:${type}`).join(', ');
    return `SELECT DISTINCT ?url ?type ?mod WHERE {
        ?f a nfo:FileDataObject ; nie:url ?url ; nfo:fileName ?name ;
           nfo:fileLastModified ?mod ; nie:interpretedAs ?ie .
        ?ie a ?type . FILTER (?type IN (${types})) ${filters}
    } ORDER BY DESC(?mod) LIMIT 150`;
}

function fillUrl(template, query) {
    return template.replace('%s', encodeURIComponent(query));
}

class SearchFlyout {
    constructor(settings) {
        this._settings = settings;
        this._isOpen = false;
        this._grab = null;
        this._anchor = null;
        this._providers = null;
        this._cancellable = null;
        this._debounceId = 0;
        this._soup = new Soup.Session({timeout: 4});
        this._appSys = Shell.AppSystem.get_default();
        this._systemActions = SystemActions.getDefault();
        this._searchSettings = new Gio.Settings({schema_id: 'org.gnome.desktop.search-providers'});
        this._searchSettingsId = this._searchSettings.connect('changed', () => {
            this._providers = null;
        });

        this._buildUi();
        // Flat top: the tab hangs from the top bar
        this._acrylic = new Acrylic(this._card, {corners: 2});
        global.focus_manager.add_group(this.actor);
        Main.layoutManager.addTopChrome(this.actor);
        this._lockId = Main.sessionMode.connect('updated', () => {
            if (Main.sessionMode.isLocked)
                this.close(false);
        });
    }

    get isOpen() {
        return this._isOpen;
    }

    _buildUi() {
        // The backdrop takes the modal grab, so the search field typed into
        // must be inside it: an entry shaped like the top-bar notch is laid
        // exactly over the notch while open, so typing reads as typing into
        // the top bar
        this.actor = new St.Widget({name: 'duskSearchBackdrop', reactive: true, visible: false});

        this._entry = new St.Entry({
            style_class: 'dusk-search-head',
            hint_text: _('Type here to search'),
            can_focus: true,
            primary_icon: new St.Icon({
                icon_name: 'edit-find-symbolic',
                style_class: 'dusk-search-pill-icon',
            }),
        });
        this._text = this._entry.clutter_text;
        this._text.connect('text-changed', () => this._queueSearch());
        this._text.connect('activate', () => this._activateFirst());
        this.actor.add_child(this._entry);

        // The results tab unrolls from under the top bar's bottom edge: it
        // slides down inside a clip whose top is that edge
        this._clip = new St.Widget({clip_to_allocation: true});
        this.actor.add_child(this._clip);
        this._card = new St.BoxLayout({
            style_class: 'dusk-search-card',
            orientation: Clutter.Orientation.VERTICAL,
            reactive: true,
        });
        this._clip.add_child(this._card);

        this._list = new St.BoxLayout({
            style_class: 'dusk-search-list',
            orientation: Clutter.Orientation.VERTICAL,
            x_expand: true,
        });
        this._scroll = new St.ScrollView({
            style_class: 'dusk-search-scroll vfade',
            x_expand: true,
            y_expand: true,
            overlay_scrollbars: true,
            hscrollbar_policy: St.PolicyType.NEVER,
            vscrollbar_policy: St.PolicyType.EXTERNAL,
            child: this._list,
        });
        this._card.add_child(this._scroll);

        this._hint = new St.Label({
            style_class: 'dusk-search-hint',
            text: _('Search apps, files, settings and the web'),
            x_align: Clutter.ActorAlign.CENTER,
        });
        this._card.add_child(this._hint);

        const click = new Clutter.ClickGesture();
        click.connect('may-recognize', () =>
            global.stage.get_event_actor(click.get_point_event(0)) === this.actor);
        click.connect('recognize', () => this.close());
        this.actor.add_action(click);

        const keys = new Clutter.KeyController();
        keys.connect('key-press', () => this._onKeyPress(keys));
        this.actor.add_action_full('dusk-search-keys', Clutter.EventPhase.CAPTURE, keys);
    }

    destroy() {
        this.close(false);
        this._cancel();
        Main.sessionMode.disconnect(this._lockId);
        this._searchSettings.disconnect(this._searchSettingsId);
        this._acrylic.destroy();
        global.focus_manager.remove_group(this.actor);
        Main.layoutManager.removeChrome(this.actor);
        this.actor.destroy();
        this._soup.abort();
    }

    toggle(anchor) {
        if (this._isOpen)
            this.close();
        else
            this.open(anchor);
    }

    open(anchor = null) {
        if (this._isOpen || Main.sessionMode.isLocked)
            return;
        this._anchor = anchor;
        // The notch stays lit while its flyout is open; its own label is
        // hidden under the field laid over it
        if (anchor instanceof St.Button) {
            anchor.checked = true;
            if (anchor.child)
                anchor.child.opacity = 0;
        }
        this._entry.text = '';
        this._layout();
        this._showResults(false, false);

        this._grab = Main.pushModal(this.actor, {actionMode: Shell.ActionMode.POPUP});
        this._isOpen = true;
        this._card.remove_all_transitions();
        this._card.translation_y = -this._card.height;
        this._acrylic.start();
        this.actor.show();
        this._entry.grab_key_focus();
        // Unrolls down from under the top bar
        this._card.ease({
            translation_y: 0,
            duration: timing(OPEN_TIME * 1.4),
            mode: OPEN_MODE,
        });
    }

    close(animate = true) {
        if (!this._isOpen)
            return;
        this._isOpen = false;
        if (this._anchor instanceof St.Button) {
            this._anchor.checked = false;
            if (this._anchor.child)
                this._anchor.child.opacity = 255;
        }
        this._cancel();
        if (this._grab) {
            Main.popModal(this._grab);
            this._grab = null;
        }
        const done = () => {
            if (this._isOpen)
                return;
            this.actor.hide();
            this._acrylic.stop();
            this._card.translation_y = 0;
            this._entry.text = '';
            this._list.destroy_all_children();
        };
        if (!animate) {
            this._card.remove_all_transitions();
            done();
            return;
        }
        // Rolls back up under the top bar
        this._card.ease({
            translation_y: -this._card.height,
            duration: timing(CLOSE_TIME * 1.4),
            mode: CLOSE_MODE,
            onStopped: done,
        });
    }

    // The field over the notch; the results tab centered under it, its top
    // at the top bar's bottom edge
    _layout() {
        this.actor.set_position(0, 0);
        this.actor.set_size(global.stage.width, global.stage.height);
        const monitor = Main.layoutManager.primaryMonitor;
        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        const gap = SCREEN_GAP * scale;
        const width = Math.min(CARD_WIDTH * scale, monitor.width - 2 * gap);
        const [, panelY] = Main.panel.get_transformed_position();
        const top = panelY + Main.panel.height;
        this._maxHeight = Math.min(CARD_HEIGHT * scale, monitor.y + monitor.height - top - gap);

        let center = monitor.x + monitor.width / 2;
        if (this._anchor?.mapped) {
            const [ax, ay] = this._anchor.get_transformed_position();
            const [aw, ah] = this._anchor.get_transformed_size();
            center = ax + aw / 2;
            this._entry.set_position(Math.round(ax), Math.round(ay));
            this._entry.set_size(Math.round(aw), Math.round(ah));
            this._entry.show();
        } else {
            this._entry.hide();
        }
        let x = center - width / 2;
        x = Math.max(monitor.x + gap, Math.min(x, monitor.x + monitor.width - width - gap));
        this._clip.set_position(Math.round(x), Math.round(top));
        this._clip.set_size(Math.round(width), Math.round(this._maxHeight));
        this._card.set_position(0, 0);
        this._card.width = Math.round(width);
    }

    // Short with the hint, full height with results; the tab grows down
    _showResults(show, animate = true) {
        this._scroll.visible = show;
        this._hint.visible = !show;
        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        const height = Math.round(show ? this._maxHeight : Math.min(HINT_HEIGHT * scale, this._maxHeight));
        if (!animate || !this._isOpen) {
            this._card.height = height;
            return;
        }
        this._card.ease({height, duration: timing(OPEN_TIME), mode: OPEN_MODE});
    }

    _cancel() {
        if (this._debounceId) {
            GLib.source_remove(this._debounceId);
            this._debounceId = 0;
        }
        this._cancellable?.cancel();
        this._cancellable = null;
    }

    _queueSearch() {
        this._cancel();
        this._debounceId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, DEBOUNCE_MS, () => {
            this._debounceId = 0;
            this._search(this._entry.text.trim());
            return GLib.SOURCE_REMOVE;
        });
    }

    _loadProviders() {
        if (this._providers)
            return this._providers;
        const providers = [new AppSearchProvider()];
        try {
            providers.push(...RemoteSearch.loadRemoteSearchProviders(this._searchSettings));
        } catch (e) {
            console.warn(`dusk-shell: search providers unavailable: ${e}`);
        }
        this._providers = providers;
        return providers;
    }

    // Sections are placed up front in a fixed order (apps, web, then the
    // providers in Settings order) and filled as each answers
    _search(query) {
        this._list.destroy_all_children();
        if (!query) {
            this._showResults(false);
            return;
        }
        this._showResults(true);
        const cancellable = new Gio.Cancellable();
        this._cancellable = cancellable;
        const terms = query.split(/\s+/);

        const providers = this._loadProviders();
        const sections = new Map();
        const addSection = key => {
            const box = new St.BoxLayout({
                style_class: 'dusk-search-section',
                orientation: Clutter.Orientation.VERTICAL,
                visible: false,
            });
            this._list.add_child(box);
            sections.set(key, box);
            return box;
        };
        const appSection = addSection('apps');
        const fileSections = this._hasLocalSearch()
            ? FILE_CATEGORIES.map(([type, title]) => [type, _(title), addSection(type)])
            : [];
        const webSection = addSection('web');
        // The indexed-files sections replace the Files provider's short list
        const others = providers.slice(1).filter(provider =>
            !fileSections.length || provider.appInfo?.get_id() !== NAUTILUS_ID);
        for (const provider of others)
            addSection(provider);

        this._searchProvider(providers[0], terms, appSection, APP_RESULTS, cancellable,
            _('Best matches'));
        if (fileSections.length)
            this._searchFiles(terms, fileSections, cancellable);
        for (const provider of others) {
            this._searchProvider(provider, terms, sections.get(provider),
                PROVIDER_RESULTS, cancellable,
                provider.appInfo?.get_name() ?? provider.id);
        }
        this._searchWeb(query, webSection, cancellable);
    }

    async _searchProvider(provider, terms, section, max, cancellable, title) {
        try {
            const ids = await provider.getInitialResultSet(terms, cancellable);
            if (cancellable.is_cancelled() || !ids?.length)
                return;
            const shown = provider.filterResults(ids, max);
            const metas = await provider.getResultMetas(shown, cancellable);
            if (cancellable.is_cancelled() || !metas.length)
                return;
            this._sectionTitle(section, title, provider.canLaunchSearch
                ? () => this._run(() => provider.launchSearch(terms))
                : null);
            for (const meta of metas) {
                section.add_child(this._row(
                    meta.createIcon?.(ROW_ICON) ?? null,
                    meta.name, meta.description ?? '',
                    () => this._activate(provider, meta.id, terms)));
            }
            section.visible = true;
        } catch (e) {
            if (!cancellable.is_cancelled())
                console.debug(`dusk-shell: search provider ${provider.id}: ${e}`);
        }
    }

    _hasLocalSearch() {
        this._tinysparql ??= GLib.find_program_in_path('tinysparql') ?? '';
        return this._tinysparql !== '';
    }

    async _searchFiles(terms, sections, cancellable) {
        let out;
        try {
            const proc = Gio.Subprocess.new(
                [this._tinysparql, 'query', '--dbus-service', LOCALSEARCH, fileQuery(terms)],
                Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_SILENCE);
            const cancelId = cancellable.connect(() => proc.force_exit());
            try {
                [out] = await proc.communicate_utf8_async(null, null);
            } finally {
                cancellable.disconnect(cancelId);
            }
        } catch (e) {
            if (!cancellable.is_cancelled())
                console.debug(`dusk-shell: file search unavailable: ${e}`);
            return;
        }
        if (cancellable.is_cancelled() || !out)
            return;

        // Lines: "  <url>, <type uri>, <modified>"
        const byType = new Map();
        const seen = new Set();
        for (const line of out.split('\n')) {
            const m = line.match(/^\s+(\S+), (\S+)(?:, .*)?$/);
            if (!m || seen.has(m[1]) || !m[2].startsWith(NFO))
                continue;
            const path = GLib.filename_from_uri(m[1])[0];
            if (!path || path.includes('/.'))
                continue; // hidden files and folders
            seen.add(m[1]);
            const type = m[2].slice(NFO.length);
            if (!byType.has(type))
                byType.set(type, []);
            byType.get(type).push([m[1], path]);
        }

        const home = GLib.get_home_dir();
        for (const [type, title, section] of sections) {
            const files = (byType.get(type) ?? []).slice(0, FILE_RESULTS);
            if (!files.length)
                continue;
            this._sectionTitle(section, title, null);
            for (const [uri, path] of files) {
                const name = GLib.path_get_basename(path);
                let dir = GLib.path_get_dirname(path);
                if (dir === home || dir.startsWith(`${home}/`))
                    dir = `~${dir.slice(home.length)}`;
                section.add_child(this._row(this._fileIcon(name, type), name, dir,
                    () => this._run(() => this._openUri(uri))));
            }
            section.visible = true;
        }
    }

    _fileIcon(name, type) {
        let gicon = null;
        if (type === 'Folder') {
            gicon = new Gio.ThemedIcon({name: 'folder'});
        } else {
            const [contentType] = Gio.content_type_guess(name, null);
            gicon = Gio.content_type_get_icon(contentType);
        }
        return new St.Icon({gicon, icon_size: ROW_ICON});
    }

    async _searchWeb(query, section, cancellable) {
        const engine = this._settings.get_string('search-web-url');
        const rows = [];
        if (this._settings.get_boolean('search-web-suggestions') && query.length >= 2) {
            try {
                const message = Soup.Message.new('GET',
                    fillUrl(this._settings.get_string('search-suggest-url'), query));
                const bytes = await this._soup.send_and_read_async(message,
                    GLib.PRIORITY_DEFAULT, cancellable);
                if (cancellable.is_cancelled())
                    return;
                if (message.get_status() === Soup.Status.OK) {
                    const data = JSON.parse(new TextDecoder().decode(bytes.get_data()));
                    // OpenSearch suggestions: [query, [suggestion, ...]]
                    const suggestions = Array.isArray(data?.[1]) ? data[1] : [];
                    for (const s of suggestions.slice(0, WEB_SUGGESTIONS)) {
                        if (typeof s === 'string' && s.toLowerCase() !== query.toLowerCase())
                            rows.push(s);
                    }
                }
            } catch (e) {
                if (cancellable.is_cancelled())
                    return;
                console.debug(`dusk-shell: web suggestions unavailable: ${e}`);
            }
        }
        if (cancellable.is_cancelled())
            return;
        this._sectionTitle(section, _('Search the web'), null);
        const open = q => this._run(() => this._openUri(fillUrl(engine, q)));
        section.add_child(this._row(this._icon('web-browser-symbolic'),
            _('Search the web for “%s”').format(query), '', () => open(query)));
        for (const s of rows)
            section.add_child(this._row(this._icon('edit-find-symbolic'), s, '', () => open(s)));
        section.visible = true;
    }

    _icon(name) {
        return new St.Icon({icon_name: name, icon_size: ROW_ICON, style_class: 'dusk-search-row-symbolic'});
    }

    _sectionTitle(section, text, action) {
        const title = new St.Button({
            style_class: 'dusk-search-section-title',
            label: text,
            can_focus: !!action,
            reactive: !!action,
            x_align: Clutter.ActorAlign.START,
        });
        if (action)
            title.connect('clicked', action);
        section.add_child(title);
    }

    _row(icon, name, description, action) {
        // Fills the row so its contents start at the left (a button centers
        // its child otherwise)
        const box = new St.BoxLayout({style_class: 'dusk-search-row-box', x_expand: true});
        if (icon) {
            const bin = new St.Bin({style_class: 'dusk-search-row-icon', child: icon});
            box.add_child(bin);
        }
        const text = new St.BoxLayout({
            orientation: Clutter.Orientation.VERTICAL,
            y_align: Clutter.ActorAlign.CENTER,
            x_expand: true,
        });
        const title = new St.Label({style_class: 'dusk-search-row-title', text: name});
        title.clutter_text.ellipsize = Pango.EllipsizeMode.END;
        text.add_child(title);
        if (description) {
            const sub = new St.Label({style_class: 'dusk-search-row-description',
                text: description.split('\n')[0]});
            sub.clutter_text.ellipsize = Pango.EllipsizeMode.END;
            text.add_child(sub);
        }
        box.add_child(text);
        const row = new St.Button({
            style_class: 'dusk-search-row',
            can_focus: true,
            x_expand: true,
            accessible_name: name,
            child: box,
        });
        row._duskActivate = action;
        row.connect('clicked', action);
        row.connect('key-focus-in', () => ensureActorVisibleInScrollView(this._scroll, row));
        return row;
    }

    _activate(provider, id, terms) {
        this._run(() => {
            if (provider instanceof AppSearchProvider) {
                if (id.endsWith('.desktop'))
                    this._appSys.lookup_app(id)?.activate();
                else
                    this._systemActions.activateAction(id);
            } else {
                provider.activateResult(id, terms);
            }
        });
    }

    _run(action) {
        this.close();
        Main.overview.hide();
        try {
            action();
        } catch (e) {
            Main.notifyError(_('Search'), e.message);
        }
    }

    _openUri(uri) {
        Gio.AppInfo.launch_default_for_uri(uri, global.create_app_launch_context(0, -1));
    }

    _rows() {
        const rows = [];
        for (const section of this._list.get_children()) {
            if (!section.visible)
                continue;
            for (const child of section.get_children()) {
                if (child._duskActivate)
                    rows.push(child);
            }
        }
        return rows;
    }

    _activateFirst() {
        // Run any pending search first, so Enter right after typing works
        if (this._debounceId) {
            GLib.source_remove(this._debounceId);
            this._debounceId = 0;
            this._search(this._entry.text.trim());
        }
        const [first] = this._rows();
        if (first)
            first._duskActivate();
        else if (this._entry.text.trim())
            this._run(() => this._openUri(fillUrl(this._settings.get_string('search-web-url'),
                this._entry.text.trim())));
    }

    _onKeyPress(keys) {
        const [, symbol] = keys.get_key();
        const focus = global.stage.get_key_focus();
        switch (symbol) {
        case Clutter.KEY_Escape:
            if (this._entry.text !== '')
                this._entry.text = '';
            else
                this.close();
            return Clutter.EVENT_STOP;
        case Clutter.KEY_Up:
        case Clutter.KEY_Down: {
            const rows = this._rows();
            if (!rows.length)
                return Clutter.EVENT_STOP;
            let i = rows.indexOf(focus);
            i = symbol === Clutter.KEY_Down ? i + 1 : i - 1;
            if (i < 0)
                this._entry.grab_key_focus();
            else
                rows[Math.min(i, rows.length - 1)].grab_key_focus();
            return Clutter.EVENT_STOP;
        }
        }
        // Typing on a focused row goes back to the entry
        if (focus !== this._text) {
            const ch = Clutter.keysym_to_unicode(symbol);
            if (ch > 0x20 && ch !== 0x7f) {
                this._entry.grab_key_focus();
                this._entry.text += String.fromCodePoint(ch);
                this._text.set_cursor_position(-1);
                return Clutter.EVENT_STOP;
            }
        }
        return Clutter.EVENT_PROPAGATE;
    }
}

// The pill in the top bar's center
export class TopSearch {
    constructor(settings) {
        this._flyout = new SearchFlyout(settings);

        this._button = new PanelMenu.Button(0.0, _('Search'), true);
        this._button.add_style_class_name('dusk-search-button');
        // A tab hanging from the top bar's top edge (the "notch"): it fills
        // the bar's height, minus a bottom gap set in the stylesheet
        const pill = new St.Button({
            style_class: 'dusk-search-pill',
            can_focus: true,
            accessible_name: _('Search'),
            y_align: Clutter.ActorAlign.FILL,
            y_expand: true,
        });
        const box = new St.BoxLayout({style_class: 'dusk-search-pill-box'});
        box.add_child(new St.Icon({icon_name: 'edit-find-symbolic', style_class: 'dusk-search-pill-icon'}));
        box.add_child(new St.Label({text: _('Type here to search'), y_align: Clutter.ActorAlign.CENTER}));
        pill.set_child(box);
        pill.connect('clicked', () => this._flyout.toggle(pill));
        this._button.add_child(pill);
        Main.panel.addToStatusArea('dusk-search', this._button, 0, 'center');

        // Super+Space (toggle-search): GNOME's input-source switch is moved
        // off it by Dusk's dconf defaults
        Main.wm.addKeybinding('toggle-search', settings, Meta.KeyBindingFlags.NONE,
            Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW, () => {
                Main.overview.hide();
                this._flyout.toggle(pill.mapped ? pill : null);
            });
    }

    destroy() {
        Main.wm.removeKeybinding('toggle-search');
        this._flyout.destroy();
        this._flyout = null;
        this._button.destroy();
        this._button = null;
    }
}
