// Accent from wallpaper: while accent-from-wallpaper is on, Dusk sets
// org.gnome.desktop.interface accent-color to the Dusk accent nearest the
// wallpaper's colors (wallpaperColor.js): at login, when the wallpaper
// changes and when the setting is turned on. AccentFollower and dusk-accent
// then restyle the shell and apps from that key.
//
// A manual override wins: when the accent changes to something Dusk did not
// set (a pick in Settings > Appearance) and stays that way for a moment,
// accent-from-wallpaper is turned off and a notification says so. Turning it
// back on in Dusk Shell's settings goes back to the wallpaper's accent.

import Gio from 'gi://Gio';
import GLib from 'gi://GLib';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import {loadAccents, pickForFile, wallpaperFile} from './wallpaperColor.js';

const KEY = 'accent-from-wallpaper';
// Settings writes picture-uri and picture-uri-dark one after the other
const DEBOUNCE_MS = 300;
// An accent change is a manual pick only if it lasts: other tools may write
// the key and put it back within a second or two (dusk-accent's guard
// against theme-unifier)
const OVERRIDE_MS = 4000;

export class WallpaperAccent {
    constructor(settings) {
        this._settings = settings;
        this._background = new Gio.Settings({schema_id: 'org.gnome.desktop.background'});
        this._interface = new Gio.Settings({schema_id: 'org.gnome.desktop.interface'});
        this._timeoutId = 0;
        this._cancellable = null;
        this._accents = null;
        // The slot Dusk last wrote; null until the first pick, and changes
        // before it (login-time restores) are not taken as overrides
        this._ours = null;
        this._overrideId = 0;

        this._settings.connectObject(`changed::${KEY}`, () => this._schedule(), this);
        this._background.connectObject(
            'changed::picture-uri', () => this._schedule(),
            'changed::picture-uri-dark', () => this._schedule(),
            this);
        this._interface.connectObject('changed::accent-color', () => this._onAccentChanged(), this);
        // A manual pick turned the setting off, so picking at login is safe
        this._schedule();
    }

    _onAccentChanged() {
        if (!this._settings.get_boolean(KEY) || this._ours === null)
            return;
        if (this._overrideId)
            GLib.source_remove(this._overrideId);
        this._overrideId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, OVERRIDE_MS, () => {
            this._overrideId = 0;
            const current = this._interface.get_string('accent-color');
            if (this._settings.get_boolean(KEY) && this._ours !== null && current !== this._ours) {
                this._settings.set_boolean(KEY, false);
                Main.notify('Accent set by hand',
                    'Dusk stopped matching the accent to the wallpaper. Turn it back on in Dusk Shell settings.');
            }
            return GLib.SOURCE_REMOVE;
        });
    }

    _schedule() {
        if (!this._settings.get_boolean(KEY))
            return;
        if (this._timeoutId)
            GLib.source_remove(this._timeoutId);
        this._timeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, DEBOUNCE_MS, () => {
            this._timeoutId = 0;
            this._pick().catch(e => {
                if (!e.matches?.(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED))
                    console.error(`dusk-shell: wallpaper accent: ${e}`);
            });
            return GLib.SOURCE_REMOVE;
        });
    }

    async _pick() {
        this._cancellable?.cancel();
        const cancellable = this._cancellable = new Gio.Cancellable();
        const file = wallpaperFile(this._background);
        if (!file)
            return;
        this._accents ??= loadAccents();
        if (!this._accents.length)
            return;
        const {slot} = await pickForFile(file, this._accents, cancellable);
        if (cancellable.is_cancelled() || !this._settings.get_boolean(KEY))
            return;
        this._ours = slot;
        if (this._interface.get_string('accent-color') !== slot)
            this._interface.set_string('accent-color', slot);
    }

    destroy() {
        if (this._timeoutId)
            GLib.source_remove(this._timeoutId);
        this._timeoutId = 0;
        if (this._overrideId)
            GLib.source_remove(this._overrideId);
        this._overrideId = 0;
        this._cancellable?.cancel();
        this._settings.disconnectObject(this);
        this._background.disconnectObject(this);
        this._interface.disconnectObject(this);
    }
}
