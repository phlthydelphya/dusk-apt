import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Gtk from 'gi://Gtk';

import {ExtensionPreferences, gettext as _} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

import {XDG_FOLDERS, resolveFolder} from './folders.js';
import {PanelArrangerPages} from './panelArrangerPrefs.js';
import {QsArrangerPages} from './qsArrangerPrefs.js';

Gio._promisify(Gtk.FileDialog.prototype, 'select_folder', 'select_folder_finish');

export default class DuskShellPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();
        // Bindings and handlers live as long as the window
        window._duskSettings = settings;
        this._handlers = [];
        window.connect('close-request', () => {
            for (const id of this._handlers)
                settings.disconnect(id);
            this._handlers = [];
            return false;
        });

        const page = new Adw.PreferencesPage({
            title: _('Dusk'),
            icon_name: 'preferences-desktop-appearance-symbolic',
        });
        window.add(page);

        page.add(this._behaviorGroup(settings));
        page.add(this._foldersGroup(settings, window));

        // Top bar and quick settings layout (formerly the Panel Arranger and
        // Quick Settings Arranger extensions)
        window.set_default_size(680, 780);
        PanelArrangerPages.fill(window, this.getSettings('org.gnome.shell.extensions.panel-arranger'));
        QsArrangerPages.fill(window, this.getSettings('org.gnome.shell.extensions.qs-arranger'));
    }

    _behaviorGroup(settings) {
        const group = new Adw.PreferencesGroup({title: _('Behavior')});

        const superRow = new Adw.SwitchRow({
            title: _('Super Opens the App Menu'),
            subtitle: _('Pressing Super alone opens the Dusk app menu instead of the overview'),
        });
        settings.bind('super-opens-menu', superRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(superRow);

        const gesturesRow = new Adw.SwitchRow({
            title: _('Disable Swipe Gestures'),
            subtitle: _('Turns off touchpad and touchscreen swipes for the overview, app grid and workspaces'),
        });
        settings.bind('disable-gestures', gesturesRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(gesturesRow);

        // Style: the surface and accent palette; dusk-accent and accent.js
        // switch the themes and this extension's stylesheet to match
        const styles = ['dusk', 'atomic'];
        const styleRow = new Adw.ComboRow({
            title: _('Style'),
            subtitle: _('Colors of every Dusk surface. Your accent color applies to both'),
            model: Gtk.StringList.new([_('Dusk'), _('Atomic Suede')]),
        });
        styleRow.selected = Math.max(0, styles.indexOf(settings.get_string('style')));
        styleRow.connect('notify::selected', () =>
            settings.set_string('style', styles[styleRow.selected]));
        group.add(styleRow);

        // Mood: dusk-wallpaper rebuilds icons, colors, materials and the
        // wallpaper (unless the user picked their own) to match. The labels
        // are Dawn, Dusk and Moonlit; the stored values stay calm, balanced
        // and vivid.
        const moods = ['calm', 'balanced', 'vivid'];
        const moodRow = new Adw.ComboRow({
            title: _('Mood'),
            subtitle: _('Dawn is quiet and uniform, Moonlit is colorful and glassy. Changes the wallpaper unless you picked your own'),
            model: Gtk.StringList.new([_('Dawn'), _('Dusk'), _('Moonlit')]),
        });
        moodRow.selected = Math.max(0, moods.indexOf(settings.get_string('mood')));
        moodRow.connect('notify::selected', () =>
            settings.set_string('mood', moods[moodRow.selected]));
        group.add(moodRow);

        const accentRow = new Adw.SwitchRow({
            title: _('Match Colors to Wallpaper'),
            subtitle: _('The shell, apps and icons take their colors from the wallpaper. Choosing an accent in Settings turns this off.'),
        });
        settings.bind('accent-from-wallpaper', accentRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(accentRow);

        // GIF search in the clipboard panel (Super+V, Super+.)
        const gifRow = new Adw.PasswordEntryRow({
            title: _('KLIPY API Key for GIF Search'),
            show_apply_button: true,
        });
        gifRow.text = settings.get_string('gif-api-key');
        gifRow.connect('apply', () => settings.set_string('gif-api-key', gifRow.text.trim()));
        const getKey = new Gtk.LinkButton({
            label: _('Get a free key'),
            uri: 'https://partner.klipy.com',
            valign: Gtk.Align.CENTER,
        });
        gifRow.add_suffix(getKey);
        group.add(gifRow);

        const filters = ['off', 'low', 'medium', 'high'];
        const filterRow = new Adw.ComboRow({
            title: _('GIF Content Filter'),
            model: Gtk.StringList.new([_('Off'), _('Low'), _('Medium'), _('High')]),
        });
        filterRow.selected = Math.max(0, filters.indexOf(settings.get_string('gif-content-filter')));
        filterRow.connect('notify::selected', () =>
            settings.set_string('gif-content-filter', filters[filterRow.selected]));
        group.add(filterRow);

        const shortcut = new Gtk.ShortcutLabel({
            disabled_text: _('Disabled'),
            valign: Gtk.Align.CENTER,
        });
        const drawerRow = new Adw.ActionRow({
            title: _('Notification Drawer'),
            subtitle: _('Keyboard shortcut (set with dconf: toggle-drawer)'),
        });
        drawerRow.add_suffix(shortcut);
        const syncShortcut = () => {
            shortcut.accelerator = settings.get_strv('toggle-drawer')[0] ?? '';
        };
        this._handlers.push(settings.connect('changed::toggle-drawer', syncShortcut));
        syncShortcut();
        group.add(drawerRow);

        return group;
    }

    _foldersGroup(settings, window) {
        const group = new Adw.PreferencesGroup({
            title: _('Folder Shortcuts'),
            description: _('Shown in the app menu footer, left to right'),
        });

        const getFolders = () => settings.get_strv('quick-folders');
        const setFolders = folders => settings.set_strv('quick-folders', folders);

        // Standard folders not already in the list
        const actions = new Gio.SimpleActionGroup();
        const addXdg = new Gio.SimpleAction({
            name: 'add-xdg',
            parameter_type: new GLib.VariantType('s'),
        });
        addXdg.connect('activate', (action, param) => {
            const entry = param.unpack();
            const folders = getFolders();
            if (!folders.includes(entry))
                setFolders([...folders, entry]);
        });
        actions.add_action(addXdg);
        window.insert_action_group('dusk', actions);

        const addMenu = new Gio.Menu();
        const addButton = new Gtk.MenuButton({
            icon_name: 'list-add-symbolic',
            tooltip_text: _('Add Standard Folder'),
            menu_model: addMenu,
            css_classes: ['flat'],
            valign: Gtk.Align.CENTER,
        });

        const customButton = new Gtk.Button({
            icon_name: 'folder-open-symbolic',
            tooltip_text: _('Add Custom Folder…'),
            css_classes: ['flat'],
            valign: Gtk.Align.CENTER,
        });
        customButton.connect('clicked', async () => {
            const dialog = new Gtk.FileDialog({title: _('Choose a Folder')});
            try {
                const file = await dialog.select_folder(window, null);
                const path = file?.get_path();
                const folders = getFolders();
                if (path && !folders.includes(path))
                    setFolders([...folders, path]);
            } catch (e) {
                if (!e.matches?.(Gtk.DialogError, Gtk.DialogError.DISMISSED))
                    console.error(`dusk-shell prefs: ${e.message}`);
            }
        });

        const suffix = new Gtk.Box({spacing: 6});
        suffix.append(addButton);
        suffix.append(customButton);
        group.set_header_suffix(suffix);

        let rows = [];
        const rebuild = () => {
            for (const row of rows)
                group.remove(row);
            rows = [];

            const folders = getFolders();
            folders.forEach((entry, i) => {
                const row = this._folderRow(entry, i, folders, setFolders);
                group.add(row);
                rows.push(row);
            });

            if (folders.length === 0) {
                const empty = new Adw.ActionRow({title: _('No folder shortcuts')});
                empty.add_css_class('dim-label');
                group.add(empty);
                rows.push(empty);
            }

            addMenu.remove_all();
            for (const [name, info] of Object.entries(XDG_FOLDERS)) {
                if (!folders.includes(name))
                    addMenu.append(resolveFolder(name)?.label ?? info.name, `dusk.add-xdg::${name}`);
            }
            addButton.sensitive = addMenu.get_n_items() > 0;
        };
        this._handlers.push(settings.connect('changed::quick-folders', rebuild));
        rebuild();

        return group;
    }

    _folderRow(entry, index, folders, setFolders) {
        const folder = resolveFolder(entry);
        const xdg = XDG_FOLDERS[entry];
        const row = new Adw.ActionRow({
            title: GLib.markup_escape_text(folder?.label ?? xdg?.name ?? entry, -1),
            subtitle: GLib.markup_escape_text(folder?.path ?? _('Folder not found'), -1),
        });
        row.add_prefix(new Gtk.Image({icon_name: folder?.icon ?? xdg?.icon ?? 'folder-symbolic'}));

        const move = (from, to) => {
            const next = [...folders];
            const [item] = next.splice(from, 1);
            next.splice(to, 0, item);
            setFolders(next);
        };

        const button = (icon, tooltip, sensitive, callback) => {
            const b = new Gtk.Button({
                icon_name: icon,
                tooltip_text: tooltip,
                sensitive,
                css_classes: ['flat'],
                valign: Gtk.Align.CENTER,
            });
            b.connect('clicked', callback);
            row.add_suffix(b);
        };
        button('go-up-symbolic', _('Move Up'), index > 0, () => move(index, index - 1));
        button('go-down-symbolic', _('Move Down'), index < folders.length - 1, () => move(index, index + 1));
        button('user-trash-symbolic', _('Remove'), true,
            () => setFolders(folders.filter((_f, i) => i !== index)));

        return row;
    }
}
