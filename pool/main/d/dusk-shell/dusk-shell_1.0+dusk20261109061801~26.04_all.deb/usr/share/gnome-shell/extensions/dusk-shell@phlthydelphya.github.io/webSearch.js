// "Search the web" in the overview's search, through the search-web-url
// engine that the top-bar search uses (DuckDuckGo by default).
//
// Replaces Ubuntu's web-search-provider@ubuntu.com, which always searched
// Google. The top-bar search loads only the remote search providers, so
// this in-process provider shows only in the overview and is never listed
// twice. It stays out when no browser handles https, and when the default
// browser is GNOME Web, which has its own search provider.

import Gio from 'gi://Gio';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

const EPIPHANY = 'org.gnome.Epiphany.desktop';

function defaultBrowser() {
    return Gio.AppInfo.get_default_for_uri_scheme('https');
}

class WebSearchProvider {
    constructor(settings, appInfo) {
        this._settings = settings;
        this.appInfo = appInfo;
        this.id = 'dusk-web-search';
        this.isRemoteProvider = false;
        this.canLaunchSearch = true;
    }

    getInitialResultSet(terms) {
        const query = terms.join(' ').trim();
        return Promise.resolve(query ? [query] : []);
    }

    getSubsearchResultSet(_previous, terms) {
        return this.getInitialResultSet(terms);
    }

    getResultMetas(ids) {
        return Promise.resolve(ids.map(id => ({
            id,
            name: _('Search the web'),
            description: _('Search the web for “%s”').format(id),
            createIcon: size => new St.Icon({icon_name: 'web-browser-symbolic', icon_size: size}),
        })));
    }

    filterResults(results, max) {
        return results.slice(0, max);
    }

    activateResult(id) {
        this._open(id);
    }

    launchSearch(terms) {
        this._open(terms.join(' '));
    }

    _open(query) {
        const uri = this._settings.get_string('search-web-url')
            .replace('%s', encodeURIComponent(query));
        try {
            Gio.AppInfo.launch_default_for_uri(uri, global.create_app_launch_context(0, -1));
        } catch (e) {
            console.warn(`dusk-shell: web search: ${e.message}`);
        }
    }
}

export class WebSearch {
    constructor(settings) {
        const browser = defaultBrowser();
        if (!browser || browser.get_id() === EPIPHANY)
            return;
        this._controller = Main.overview.searchController;
        this._provider = new WebSearchProvider(settings, browser);
        this._controller.addProvider(this._provider);
        // A reload of the Search settings swaps only the remote providers,
        // so this one stays registered until destroy()
    }

    destroy() {
        if (this._provider)
            this._controller.removeProvider(this._provider);
        this._provider = null;
        this._controller = null;
    }
}
