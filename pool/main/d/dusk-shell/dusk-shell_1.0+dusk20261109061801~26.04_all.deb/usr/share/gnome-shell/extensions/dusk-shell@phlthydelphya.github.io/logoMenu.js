// The logo menu: the Dusk mark at the left end of the top bar, with a menu of
// system actions (About, Settings, Dusk's system apps, force quit, power).
// Each item has a symbolic icon. The overview, app grid and extensions are
// left to the start menu and dock.
//
// Formerly the Logo Menu extension (logomenu@aryan_k); Dusk Shell now draws
// it itself. The button keeps that extension's panel role, 'LogoMenu', so
// the panel arranger's saved layout still places it. The icon is the icon
// theme's `dusk-logo` mark (Strata draws one) or `start-here-symbolic`, and
// it follows icon theme changes. Each app item opens the first of its apps
// that is installed and is left out when none is.

import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Shell from 'gi://Shell';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

import {SelectionWindow} from './forceQuit.js';
import {markFile, watchIconTheme} from './iconMarks.js';

const ROLE = 'LogoMenu';

const APPS = {
    about: ['io.github.phlthydelphya.DuskAbout.desktop'],
    software: ['io.github.phlthydelphya.DuskAppHub.desktop', 'org.gnome.Software.desktop'],
    security: ['io.github.phlthydelphya.SecurityHub.desktop'],
    phone: ['io.github.phlthydelphya.staq.desktop'],
    // Resources is GNOME's monitor since 47 and what dusk-shell recommends
    monitor: ['io.missioncenter.MissionCenter.desktop', 'org.gnome.Resources.desktop',
        'org.gnome.SystemMonitor.desktop'],
    terminal: ['org.gnome.Ptyxis.desktop', 'org.gnome.Console.desktop', 'org.gnome.Terminal.desktop'],
};

// The app's own symbolic icon when the icon theme has one, then a generic one
function appIcon(app, ...fallbacks) {
    const id = app.get_id().replace(/\.desktop$/, '');
    return Gio.ThemedIcon.new_from_names([`${id}-symbolic`, ...fallbacks]);
}

function findApp(ids) {
    const appSystem = Shell.AppSystem.get_default();
    for (const id of ids) {
        const app = appSystem.lookup_app(id);
        if (app)
            return app;
    }
    return null;
}

function spawn(argv) {
    try {
        Gio.Subprocess.new(argv, Gio.SubprocessFlags.NONE);
    } catch (e) {
        console.warn(`dusk-shell: logo menu: ${argv[0]}: ${e.message}`);
    }
}

const LogoButton = GObject.registerClass(
class DuskLogoButton extends PanelMenu.Button {
    _init(extension) {
        super._init(0.5, _('Dusk Menu'));
        this._extension = extension;
        this.add_style_class_name('dusk-logo-menu');
        this._icon = new St.Icon({style_class: 'system-status-icon'});
        this.add_child(this._icon);
        this._syncIcon();
        this._unwatch = watchIconTheme(() => this._syncIcon());
        // App items depend on what is installed: rebuild on each open
        this.menu.connect('open-state-changed', (_menu, open) => {
            if (open)
                this._build();
        });
        this._build();
        this.connect('destroy', () => {
            this._unwatch?.();
            this._unwatch = null;
            if (this._idleId)
                GLib.source_remove(this._idleId);
            this._idleId = 0;
            this._selection?.stop();
            this._selection = null;
        });
    }

    _syncIcon() {
        const file = markFile('dusk-logo');
        this._icon.gicon = file
            ? Gio.FileIcon.new(Gio.File.new_for_path(file))
            : new Gio.ThemedIcon({name: 'start-here-symbolic'});
    }

    _item(label, icon, callback) {
        const item = new PopupMenu.PopupImageMenuItem(label, icon);
        item.connect('activate', () => callback());
        this.menu.addMenuItem(item);
    }

    _appItem(label, ids, ...icons) {
        const app = findApp(ids);
        if (app)
            this._item(label, appIcon(app, ...icons), () => app.activate());
    }

    _separator() {
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
    }

    _build() {
        this.menu.removeAll();
        const about = findApp(APPS.about);
        this._item(_('About This Computer'), 'help-about-symbolic', () => {
            if (about)
                about.activate();
            else
                spawn(['gnome-control-center', 'system', 'about']);
        });
        this._item(_('System Settings'), 'preferences-system-symbolic',
            () => spawn(['gnome-control-center']));
        this._item(_('Dusk Shell Settings'), 'preferences-desktop-appearance-symbolic',
            () => this._extension.openPreferences());
        this._separator();
        this._appItem(_('App Hub'), APPS.software, 'system-software-install-symbolic');
        this._appItem(_('Security Hub'), APPS.security, 'security-high-symbolic');
        this._appItem(_('Staq'), APPS.phone, 'phone-symbolic');
        this._appItem(_('System Monitor'), APPS.monitor,
            'utilities-system-monitor-symbolic', 'power-profile-performance-symbolic');
        this._appItem(_('Terminal'), APPS.terminal, 'utilities-terminal-symbolic');
        this._separator();
        this._item(_('Force Quit App…'), 'process-stop-symbolic', () => this._forceQuit());
        this._separator();
        this._item(_('Sleep'), 'weather-clear-night-symbolic', () => spawn(['systemctl', 'suspend']));
        this._item(_('Restart…'), 'system-reboot-symbolic', () => spawn(['gnome-session-quit', '--reboot']));
        this._item(_('Shut Down…'), 'system-shutdown-symbolic', () => spawn(['gnome-session-quit', '--power-off']));
        this._separator();
        this._item(_('Lock Screen'), 'system-lock-screen-symbolic', () => Main.screenShield?.lock(true));
        this._item(_('Log Out…'), 'system-log-out-symbolic', () => spawn(['gnome-session-quit', '--logout']));
    }

    _forceQuit() {
        this._selection?.stop();
        // Let the menu close first: the selection takes a modal grab
        if (this._idleId)
            return;
        this._idleId = GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
            this._idleId = 0;
            this._selection = new SelectionWindow();
            this._selection.connect('stop', () => {
                this._selection = null;
            });
            return GLib.SOURCE_REMOVE;
        });
    }
});

export class LogoMenu {
    constructor(extension) {
        // Logo Menu itself is turned off by dusk-dconf; if it still runs,
        // it holds the role and Dusk's button stays out of its way
        if (Main.panel.statusArea[ROLE])
            return;
        this._button = new LogoButton(extension);
        Main.panel.addToStatusArea(ROLE, this._button, 0, 'left');
    }

    destroy() {
        this._button?.destroy();
        this._button = null;
    }
}
