// The emoji, kaomoji and symbols tabs of the clipboard panel (clipboard.js),
// like Windows 11's: a page per category picked from the bar along the bottom
// (Most recently used first), or matches for the search field across all
// categories. Emoji with skin tones follow the tone picked at the end of the
// bar. Data: data/<kind>.json (tools/gen-picker-data.py).

import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import Pango from 'gi://Pango';
import St from 'gi://St';

import {ensureActorVisibleInScrollView} from 'resource:///org/gnome/shell/misc/animationUtils.js';
import {gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

const MAX_RESULTS = 160;
const COLUMNS = {emoji: 8, symbols: 8, kaomoji: 3};
const RECENT = 'recent';
// The skin tone picker's sample: waving hand, default then the five tones
const TONE_SAMPLE = ['👋', '👋🏻', '👋🏼', '👋🏽', '👋🏾', '👋🏿'];

const HINTS = {
    emoji: () => _('Search emoji'),
    kaomoji: () => _('Search kaomoji'),
    symbols: () => _('Search symbols'),
};

function loadGroups(dir, kind) {
    try {
        const [ok, bytes] = GLib.file_get_contents(GLib.build_filenamev([dir, 'data', `${kind}.json`]));
        if (ok) {
            const groups = JSON.parse(new TextDecoder().decode(bytes)).groups;
            for (const group of groups) {
                for (const item of group.items)
                    item.s = `${item.n} ${item.k ?? ''}`.toLowerCase();
            }
            return groups;
        }
    } catch (e) {
        console.error(`dusk-shell: picker data ${kind}: ${e}`);
    }
    return [];
}

export class CharTab {
    constructor({kind, dir, store, onPick}) {
        this.kind = kind;
        this._store = store;
        this._onPick = onPick;
        this._groups = loadGroups(dir, kind);
        this._byValue = new Map();
        for (const group of this._groups) {
            for (const item of group.items)
                this._byValue.set(item.e, item);
        }
        this._page = null;
        this._query = '';

        this.actor = new St.BoxLayout({
            style_class: `dusk-pick-tab dusk-pick-${kind}`,
            orientation: Clutter.Orientation.VERTICAL,
            x_expand: true,
            y_expand: true,
        });
        this._body = new St.BoxLayout({
            style_class: 'dusk-pick-body',
            orientation: Clutter.Orientation.VERTICAL,
            x_expand: true,
        });
        this._scroll = new St.ScrollView({
            style_class: 'dusk-pick-scroll vfade',
            x_expand: true,
            y_expand: true,
            overlay_scrollbars: true,
            hscrollbar_policy: St.PolicyType.NEVER,
            vscrollbar_policy: St.PolicyType.EXTERNAL,
            child: this._body,
        });
        this.actor.add_child(this._scroll);

        this._bar = new St.BoxLayout({style_class: 'dusk-pick-bar', x_expand: kind !== 'kaomoji'});
        this._catButtons = new Map();
        this._addCategory(RECENT, null, _('Most recently used'));
        for (const group of this._groups)
            this._addCategory(group.id, group.icon, group.name);
        if (kind === 'emoji') {
            this._bar.add_child(new St.Widget({x_expand: true}));
            this._toneButton = new St.Button({
                style_class: 'dusk-pick-cat dusk-pick-tone',
                can_focus: true,
                accessible_name: _('Skin tone'),
                label: TONE_SAMPLE[store.skinTone] ?? TONE_SAMPLE[0],
            });
            this._toneButton.connect('clicked', () => this._toggleTones());
            this._bar.add_child(this._toneButton);
            this._tones = new St.BoxLayout({style_class: 'dusk-pick-bar dusk-pick-tones', x_expand: true, visible: false});
            TONE_SAMPLE.forEach((sample, tone) => {
                const button = new St.Button({
                    style_class: 'dusk-pick-cat',
                    can_focus: true,
                    label: sample,
                    accessible_name: tone ? _('Skin tone %d').format(tone) : _('Default skin tone'),
                });
                button.connect('clicked', () => this._setTone(tone));
                this._tones.add_child(button);
            });
            this.actor.add_child(this._tones);
        }
        if (kind === 'kaomoji') {
            // Kaomoji category faces are wide: the bar scrolls sideways
            this._barScroll = new St.ScrollView({
                style_class: 'dusk-pick-bar-scroll hfade',
                x_expand: true,
                overlay_scrollbars: true,
                hscrollbar_policy: St.PolicyType.EXTERNAL,
                vscrollbar_policy: St.PolicyType.NEVER,
                child: this._bar,
            });
            // The wheel scrolls it sideways
            this._barScroll.connect('scroll-event', (_a, event) => {
                const adj = this._barScroll.hadjustment;
                const dir = event.get_scroll_direction();
                let delta = 0;
                if (dir === Clutter.ScrollDirection.SMOOTH)
                    delta = event.get_scroll_delta().reduce((a, b) => a + b, 0) * 40;
                else if (dir === Clutter.ScrollDirection.DOWN || dir === Clutter.ScrollDirection.RIGHT)
                    delta = 60;
                else
                    delta = -60;
                adj.value = Math.max(adj.lower, Math.min(adj.value + delta, adj.upper - adj.page_size));
                return Clutter.EVENT_STOP;
            });
            for (const button of this._catButtons.values()) {
                button.connect('key-focus-in', () =>
                    ensureActorVisibleInScrollView(this._barScroll, button));
            }
            this.actor.add_child(this._barScroll);
        } else {
            this.actor.add_child(this._bar);
        }
    }

    get searchHint() {
        return HINTS[this.kind]();
    }

    _addCategory(id, icon, name) {
        const button = new St.Button({
            style_class: `dusk-pick-cat${this.kind === 'kaomoji' ? ' dusk-pick-cat-wide' : ''}`,
            can_focus: true,
            accessible_name: name,
        });
        if (icon) {
            const label = new St.Label({text: icon, y_align: Clutter.ActorAlign.CENTER});
            label.clutter_text.ellipsize = Pango.EllipsizeMode.NONE;
            button.child = label;
        } else
            button.child = new St.Icon({icon_name: 'document-open-recent-symbolic', icon_size: 16});
        button.connect('clicked', () => this._showPage(id));
        this._bar.add_child(button);
        this._catButtons.set(id, button);
    }

    show(query) {
        this._fitBar();
        this._query = query.trim().toLowerCase();
        this._render();
    }

    // Kaomoji category buttons at full width, so the bar scrolls instead of
    // squeezing them: its viewport lays children out at their minimum width
    _fitBar() {
        if (!this._barScroll || this._barFitted)
            return;
        for (const button of this._catButtons.values()) {
            button.min_width_set = false;
            button.min_width = button.get_preferred_width(-1)[1];
        }
        this._barFitted = true;
    }

    hide() {
        this._tones?.hide();
        this._bar.show();
    }

    setQuery(query) {
        query = query.trim().toLowerCase();
        if (query === this._query)
            return;
        this._query = query;
        this._render();
    }

    contains(actor) {
        return this.actor.contains(actor);
    }

    focusFirst() {
        const cell = this._cells()[0];
        if (cell) {
            cell.grab_key_focus();
            return true;
        }
        return false;
    }

    navigate(from, direction) {
        // Within the grid, then the category bar
        return this._body.navigate_focus(from, direction, false) ||
            this.actor.navigate_focus(from, direction, false);
    }

    _cells() {
        const cells = [];
        for (const flow of this._body.get_children()) {
            if (flow._duskFlow)
                cells.push(...flow.get_children());
        }
        return cells;
    }

    _showPage(id) {
        this._page = id;
        this._query = '';
        this._onQueryCleared?.();
        this._render();
        this.focusFirst();
    }

    // The panel clears its search field when a category is picked
    connectQueryCleared(callback) {
        this._onQueryCleared = callback;
    }

    _render() {
        this._body.destroy_all_children();
        this._scroll.vadjustment.value = 0;
        if (this._query) {
            const items = this._search(this._query);
            if (items.length)
                this._section(null, items);
            else
                this._empty(_('No results'));
            this._markCategory(null);
            return;
        }
        let page = this._page;
        const recent = this._recentItems();
        if (!page)
            page = recent.length ? RECENT : this._groups[0]?.id;
        if (page === RECENT) {
            if (recent.length)
                this._section(_('Most recently used'), recent);
            else
                this._empty(_('Things you pick show up here.'));
        } else {
            const group = this._groups.find(g => g.id === page);
            if (group)
                this._section(group.name, group.items);
        }
        this._markCategory(page);
    }

    _markCategory(id) {
        for (const [key, button] of this._catButtons) {
            if (key === id)
                button.add_style_pseudo_class('checked');
            else
                button.remove_style_pseudo_class('checked');
        }
    }

    _recentItems() {
        return this._store.recent(this.kind)
            .map(e => this._byValue.get(e) ?? {e, n: e, s: e})
            .slice(0, 48);
    }

    // Every word must start a word of the name or keywords; names that start
    // with the query come first
    _search(query) {
        const words = query.split(/\s+/);
        const starts = [], others = [];
        for (const group of this._groups) {
            for (const item of group.items) {
                const ok = words.every(w => item.s.startsWith(w) || item.s.includes(` ${w}`) ||
                    (w.length > 2 && item.s.includes(w)) || item.e === w);
                if (!ok)
                    continue;
                (item.n.startsWith(query) ? starts : others).push(item);
                if (starts.length >= MAX_RESULTS)
                    break;
            }
        }
        return [...starts, ...others].slice(0, MAX_RESULTS);
    }

    _empty(text) {
        this._body.add_child(new St.Label({
            style_class: 'dusk-clip-empty',
            text,
            x_align: Clutter.ActorAlign.CENTER,
        }));
    }

    _section(title, items) {
        if (title) {
            this._body.add_child(new St.Label({
                style_class: 'dusk-pick-section-title',
                text: title,
            }));
        }
        // Rows of a fixed number of cells (Clutter.FlowLayout collapses
        // inside a scroll view)
        const columns = COLUMNS[this.kind];
        for (let i = 0; i < items.length; i += columns) {
            const row = new St.BoxLayout({style_class: 'dusk-pick-row', x_expand: true});
            row._duskFlow = true;
            row.layout_manager.homogeneous = this.kind === 'kaomoji';
            for (const item of items.slice(i, i + columns))
                row.add_child(this._cell(item));
            // Short last row of kaomoji: keep the cell widths
            for (let k = items.length - i; k < columns && this.kind === 'kaomoji'; k++)
                row.add_child(new St.Widget({x_expand: true}));
            this._body.add_child(row);
        }
    }

    _valueOf(item) {
        const tone = this._store.skinTone;
        return tone > 0 && item.t?.length === 5 ? item.t[tone - 1] : item.e;
    }

    _cell(item) {
        const value = this._valueOf(item);
        const cell = new St.Button({
            style_class: `dusk-pick-cell dusk-pick-cell-${this.kind}`,
            can_focus: true,
            label: value,
            accessible_name: item.n,
            x_expand: this.kind === 'kaomoji',
        });
        cell.connect('clicked', () => this._pick(item, value));
        cell.connect('key-focus-in', () => ensureActorVisibleInScrollView(this._scroll, cell));
        return cell;
    }

    _pick(item, value) {
        // Recents keep the base emoji, so a tone change applies to them too
        this._store.addRecent(this.kind, item.e);
        this._onPick(value);
    }

    _toggleTones() {
        const open = !this._tones.visible;
        this._tones.visible = open;
        this._bar.visible = !open;
        if (open)
            this._tones.get_child_at_index(this._store.skinTone)?.grab_key_focus();
    }

    _setTone(tone) {
        this._store.skinTone = tone;
        this._toneButton.label = TONE_SAMPLE[tone];
        this._toggleTones();
        this._render();
        this._toneButton.grab_key_focus();
    }

    destroy() {
        this.actor.destroy();
    }
}
