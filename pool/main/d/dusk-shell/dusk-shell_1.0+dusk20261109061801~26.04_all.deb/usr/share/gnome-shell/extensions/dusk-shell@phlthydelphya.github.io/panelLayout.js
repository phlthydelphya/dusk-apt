import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {ExtensionState} from 'resource:///org/gnome/shell/misc/extensionUtils.js';
import {gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

const ARRANGER_UUID = 'panel-arranger@phlthydelphya.github.io';

// While the panel arranger runs it owns item placement: Dusk Shell's own
// module (panelArranger.js, set before this layout starts and cleared after
// it stops), or a separate Panel Arranger extension still installed. For the
// latter, ACTIVATING counts so the stock layout is back before its enable()
// records it; DEACTIVATING so its disable() restores before Dusk takes over
// again (extensionSystem.js _callExtensionEnable / _callExtensionDisableWithRebase).
let arrangerActive = false;
export function setArrangerActive(active) {
    arrangerActive = active;
}

export function arrangerOwnsPanel() {
    if (arrangerActive)
        return true;
    const state = Main.extensionManager.lookup(ARRANGER_UUID)?.state;
    return [ExtensionState.ACTIVATING, ExtensionState.ACTIVE,
        ExtensionState.DEACTIVATING].includes(state);
}

// Clock moves from the center box to the right, after quick settings; the
// Activities button is hidden; the clock popup keeps the calendar and events.
// Main.panel re-sorts its boxes on every session-mode change
// (panel.js:652 _updatePanel), so the arrangement is re-applied then.
export class PanelLayout {
    constructor(extension) {
        this._dateMenu = Main.panel.statusArea.dateMenu ?? null;
        this._placing = false;
        this._setupCalendar(extension);

        // Connected after the panel's own handler, so it runs after it
        this._sessionId = Main.sessionMode.connect('updated', () => this._arrange());
        this._stateId = Main.extensionManager.connect('extension-state-changed',
            (_m, extension) => {
                if (extension.uuid !== ARRANGER_UUID)
                    return;
                this._syncOwner();
                this._arrange();
            });
        this._syncOwner();
        this._arrange();
    }

    destroy() {
        this._destroyed = true;
        if (this._calendarId)
            this._dateMenu?._calendar?.disconnect(this._calendarId);
        this._quickAdd?.destroy();
        Main.sessionMode.disconnect(this._sessionId);
        this._sessionId = 0;
        Main.extensionManager.disconnect(this._stateId);
        this._stateId = 0;

        this._releasePlacement();

        // Same visibility rules as DateMenuButton._sessionUpdated
        // (dateMenu.js:1003-1005)
        const dateMenu = this._dateMenu;
        if (dateMenu) {
            if (dateMenu._displaysSection)
                dateMenu._displaysSection.visible = Main.sessionMode.allowSettings;
            if (dateMenu._messageList && dateMenu.menu.actor.contains(dateMenu._messageList)) {
                dateMenu._messageList.visible = Main.sessionMode.hasNotifications &&
                    !Main.sessionMode.isGreeter;
            }
        }
        this._dateMenu = null;
    }

    _setupCalendar(extension) {
        const menu = this._dateMenu;
        const box = menu?._eventsItem?.get_parent();
        if (!box || !menu._calendar)
            return;
        this._selectedDate = menu._calendar._selectedDate;
        this._calendarId = menu._calendar.connect('selected-date-changed', (_calendar, date) => {
            this._selectedDate = new Date(date.to_unix() * 1000);
        });
        this._quickAdd = new St.BoxLayout({orientation: Clutter.Orientation.VERTICAL,
            style_class: 'dusk-calendar-add', x_expand: true});
        this._title = new St.Entry({hint_text: _('Event title'), can_focus: true, x_expand: true});
        this._time = new St.Entry({hint_text: _('Time (HH:MM)'), text: '09:00', can_focus: true});
        const hint = new St.Label({text: _('One hour · default calendar'), style_class: 'dim-label'});
        this._status = new St.Label({text: '', style_class: 'dim-label'});
        this._status.clutter_text.line_wrap = true;
        this._addButton = new St.Button({label: _('Add event'), style_class: 'button', can_focus: true});
        this._addButton.connect('clicked', () => this._addEvent(extension));
        // Enter in either field adds the event too
        for (const entry of [this._title, this._time])
            entry.clutter_text.connect('activate', () => this._addEvent(extension));
        this._quickAdd.add_child(this._title);
        this._quickAdd.add_child(this._time);
        this._quickAdd.add_child(hint);
        this._quickAdd.add_child(this._addButton);
        this._quickAdd.add_child(this._status);
        box.add_child(this._quickAdd);
    }

    _addEvent(extension) {
        const title = this._title.get_text().trim();
        const time = this._time.get_text().trim();
        if (!this._addButton.reactive)
            return;
        if (!title || !/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) {
            this._status.text = _('Enter a title and time (HH:MM).');
            return;
        }
        const date = this._selectedDate ?? new Date();
        const day = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
        this._addButton.reactive = false;
        this._status.text = _('Adding…');
        try {
            const proc = Gio.Subprocess.new(['/usr/bin/python3',
                GLib.build_filenamev([extension.path, 'data', 'calendar-quick-add.py'])],
            Gio.SubprocessFlags.STDIN_PIPE | Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_PIPE);
            proc.communicate_utf8_async(JSON.stringify({title, time, date: day}), null, (p, result) => {
                if (this._destroyed)
                    return;
                this._addButton.reactive = true;
                try {
                    const [, out, err] = p.communicate_utf8_finish(result);
                    if (!p.get_successful()) {
                        this._status.text = err.trim() || _('Could not add event.');
                        return;
                    }
                    this._title.set_text('');
                    this._status.text = _('Added to %s').format(out.trim());
                } catch (e) {
                    this._status.text = e.message;
                }
            });
        } catch (e) {
            this._addButton.reactive = true;
            this._status.text = e.message;
        }
    }

    _syncOwner() {
        const place = !arrangerOwnsPanel();
        if (place === this._placing)
            return;
        if (place) {
            // Record the layout as it is when Dusk takes over
            const container = this._dateMenu?.container;
            this._origParent = container?.get_parent() ?? null;
            this._origIndex = this._origParent?.get_children().indexOf(container) ?? -1;
            this._bannerAlignment = Main.messageTray.bannerAlignment;
            this._placing = true;
        } else {
            this._releasePlacement();
        }
    }

    _releasePlacement() {
        if (!this._placing)
            return;
        this._placing = false;

        const container = this._dateMenu?.container;
        if (container && this._origParent) {
            container.get_parent()?.remove_child(container);
            this._origParent.insert_child_at_index(container,
                Math.max(this._origIndex, 0));
        }
        Main.messageTray.bannerAlignment = this._bannerAlignment;

        if (Main.sessionMode.panel.left.includes('activities'))
            Main.panel.statusArea.activities?.container.show();
        this._origParent = null;
    }

    _arrange() {
        const dateMenu = this._dateMenu;
        if (this._placing) {
            Main.panel.statusArea.activities?.container.hide();

            // Main.panel._rightBox: panel.js:478
            const rightBox = Main.panel._rightBox;
            const container = dateMenu?.container;
            if (rightBox && container) {
                container.get_parent()?.remove_child(container);
                const quickSettings = Main.panel.statusArea.quickSettings?.container;
                const index = quickSettings?.get_parent() === rightBox
                    ? rightBox.get_children().indexOf(quickSettings) + 1
                    : rightBox.get_n_children();
                rightBox.insert_child_at_index(container, index);
                // What the panel does itself for a right-hand clock (panel.js:662)
                Main.messageTray.bannerAlignment = Clutter.ActorAlign.END;
            }
        }

        if (!dateMenu)
            return;

        // Events, world clocks and weather live in _displaysSection
        // (dateMenu.js:942); notifications in _messageList (dateMenu.js:920),
        // unless the drawer has already taken it
        if (dateMenu._displaysSection)
            dateMenu._displaysSection.visible = Main.sessionMode.allowSettings;
        if (dateMenu._messageList && dateMenu.menu.actor.contains(dateMenu._messageList))
            dateMenu._messageList.visible = false;
    }
}
