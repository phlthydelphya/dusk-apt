import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import {AcrylicMaskEffect} from './acrylic.js';

// Acrylic behind the desktop icons' (gtk4-ding) context menus, matched to the
// shell menus, which Blur my Shell draws with the "Dusk acrylic" pipeline
// (setup/bms-acrylic.py): blur radius 40, saturation x1.3, $base tint at 60%,
// grain 0.05.
//
// GTK cannot blur, and Blur my Shell only blurs normal and dialog windows, so
// ding's menus (GtkPopoverMenu = xdg_popup windows, menu types, transient for
// a ding window) were a solid fill. Each one gets an St.Widget just below its
// window actor in the window group, covering the window's frame rect: GTK sets
// a popup's window geometry to the menu without its CSS shadow.
//
// Ding's menus only open over the desktop, so what is behind them is the
// wallpaper: the widget holds a blurred clone of the monitor's background actor
// (a static blur, like Blur my Shell's), clipped to the menu and cut by
// acrylic.js's rounded mask, which adds the saturation and grain. Not a
// backdrop blur (Shell.BlurEffect BACKGROUND): inside the mask's offscreen it
// reads that empty buffer, not the stage, so it showed nothing. The blur is
// dimmed to match the shell's desktop menu as it renders (darker than the sky
// behind it, hue kept); the menu's CSS adds only a trace of $base (gtk.scss).
// In the light scheme the blur is left undimmed and the CSS tint is the light
// $base at 60% (SCHEMES below).

const DING_APP_ID = 'com.desktop.ding';
const MENU_TYPES = [
    Meta.WindowType.DROPDOWN_MENU,
    Meta.WindowType.POPUP_MENU,
    Meta.WindowType.MENU,
];
const BLUR_RADIUS = 40; // logical px, multiplied by the scale factor
const CORNER_RADIUS = 20; // $r-window: the ding menu's border-radius in gtk.scss
// Per color-scheme, read as each menu opens:
// - dark: matched to the shell's desktop menu, clearly darker than the sky
//   behind it; the menu's CSS paints only an 8% $base trace over it.
// - light: the blur is not dimmed (dark text on a darkened wallpaper was
//   unreadable); the menu's CSS paints the light $base at 60%, Blur my
//   Shell's acrylic tint (setup/bms-acrylic.py TINT_ALPHA), so it reads like
//   the light top bar and dock.
// tint is $ding-menu-bg's alpha in gtk.scss; keep the two in step.
const SCHEMES = {
    dark: {brightness: 0.4, tint: 0.08},
    light: {brightness: 1.0, tint: 0.60},
};
// Grain 0.03 (lighter than Blur my Shell's 0.05: grain lifts dark pixels),
// scaled because the menu's tint is painted over it
const GRAIN = 0.03;
const INTERFACE_SCHEMA = 'org.gnome.desktop.interface';

function isDingWindow(win) {
    return win?.get_gtk_application_id?.() === DING_APP_ID;
}

// A ding popup: transient for a ding window (popups are transient for their
// parent surface), or else from the same process as one
function isDingPopup(win) {
    for (let w = win.get_transient_for(); w; w = w.get_transient_for()) {
        if (isDingWindow(w))
            return true;
    }
    const pid = win.get_pid();
    return pid > 0 && global.get_window_actors().some(actor => {
        const other = actor.get_meta_window();
        return other !== win && isDingWindow(other) && other.get_pid() === pid;
    });
}

export class DingMenuAcrylic {
    constructor() {
        this._popups = new Map(); // MetaWindow -> teardown function
        this._interface = new Gio.Settings({schema_id: INTERFACE_SCHEMA});
        // Window actors outlive the Shell's JavaScript on shutdown, and a JS
        // handler on one then crashes the Shell: drop ours at 'shutdown'
        this._shutdownId = global.connect('shutdown', () => {
            for (const teardown of [...this._popups.values()])
                teardown();
        });
        this._createdId = global.display.connect('window-created',
            (_display, win) => this._onWindowCreated(win));
    }

    _onWindowCreated(win) {
        const actor = win.get_compositor_private();
        if (!actor)
            return;
        // The window's type and parent are final by its first frame
        const id = actor.connect('first-frame', () => {
            actor.disconnect(id);
            if (MENU_TYPES.includes(win.get_window_type()) && isDingPopup(win))
                this._addBlur(win, actor);
        });
    }

    _addBlur(win, actor) {
        if (this._popups.has(win))
            return;
        const monitor = Main.layoutManager.monitors[win.get_monitor()];
        // Private, but long-standing: one BackgroundManager per monitor
        const background = Main.layoutManager._bgManagers?.[win.get_monitor()]?.backgroundActor;
        if (!monitor || !background)
            return;
        // Same rule as accent.js: anything but prefer-dark is the light scheme
        const scheme = this._interface.get_string('color-scheme') === 'prefer-dark'
            ? SCHEMES.dark : SCHEMES.light;
        let blur, wallpaper;
        try {
            const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
            blur = new St.Widget({
                name: 'duskPopupAcrylic',
                reactive: false,
                clip_to_allocation: true,
            });
            blur.add_effect_with_name('dusk-acrylic-mask',
                new AcrylicMaskEffect({radius: CORNER_RADIUS, grain: GRAIN / (1 - scheme.tint)}));
            // The whole monitor's wallpaper is blurred (cached while it does
            // not change), so the menu's edges never sample past the picture
            wallpaper = new Clutter.Clone({source: background});
            wallpaper.add_effect_with_name('dusk-acrylic-blur', new Shell.BlurEffect({
                mode: Shell.BlurMode.ACTOR,
                brightness: scheme.brightness,
                radius: Math.round(BLUR_RADIUS * scale),
            }));
            blur.add_child(wallpaper);
            actor.get_parent().insert_child_below(blur, actor);
        } catch (e) {
            console.warn(`dusk-shell: ding menu acrylic disabled: ${e}`);
            blur?.destroy();
            return;
        }

        // The window actor sits at the buffer rect; the menu is the frame rect.
        // Follow the actor's place and size (it can be eased while mapping)
        // and its opacity and visibility.
        const fit = () => {
            const frame = win.get_frame_rect();
            const buffer = win.get_buffer_rect();
            const x = actor.x + frame.x - buffer.x;
            const y = actor.y + frame.y - buffer.y;
            blur.set_position(x, y);
            blur.set_size(frame.width, frame.height);
            wallpaper.set_position(monitor.x - x, monitor.y - y);
            blur.opacity = actor.opacity;
            blur.visible = actor.visible;
        };
        fit();
        const winIds = [
            win.connect('size-changed', fit),
            win.connect('position-changed', fit),
        ];
        const actorIds = ['notify::allocation', 'notify::opacity', 'notify::visible']
            .map(signal => actor.connect(signal, fit));

        let destroyId = 0;
        const teardown = (actorGone = false) => {
            for (const id of winIds)
                win.disconnect(id);
            if (!actorGone) {
                for (const id of [...actorIds, destroyId])
                    actor.disconnect(id);
            }
            blur.clear_effects();
            blur.destroy();
            this._popups.delete(win);
        };
        destroyId = actor.connect('destroy', () => teardown(true));
        this._popups.set(win, teardown);
    }

    destroy() {
        if (this._shutdownId) {
            global.disconnect(this._shutdownId);
            this._shutdownId = 0;
        }
        if (this._createdId) {
            global.display.disconnect(this._createdId);
            this._createdId = 0;
        }
        for (const teardown of [...this._popups.values()])
            teardown();
        this._popups.clear();
    }
}
