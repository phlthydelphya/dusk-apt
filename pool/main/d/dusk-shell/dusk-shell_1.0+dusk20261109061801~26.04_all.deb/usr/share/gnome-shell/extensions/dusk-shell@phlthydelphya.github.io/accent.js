// Accent follow: keeps this extension's stylesheet in the Dusk variant that
// matches org.gnome.desktop.interface accent-color and this extension's
// `style` key (dusk, or atomic for Atomic Suede).
//
// The shell loads stylesheet.css (dusk style, blue, the default) when the
// extension is enabled and records it as the extension's `stylesheet`. For any
// other variant this swaps it for stylesheet-<id>.css (<slot> for dusk,
// atomic-<slot> for Atomic Suede; built by build.sh) on
// the current St theme, and updates that record, so the shell's own unload on
// disable removes the variant and a theme reload (user-theme switch) carries
// it over like any custom stylesheet. A missing variant falls back to
// stylesheet.css. Changes are debounced: Settings' swatches can fire several
// times in a row.
//
// Strata theme: while the Shell theme is the user's Strata-seeded one
// (Dusk-Wallpaper, Dusk-Atomic-Wallpaper; dusk-accent picks it while its seed
// matches the wallpaper or accent setting), the user's stylesheet-wallpaper.css
// (atomic-wallpaper for Atomic Suede) in ~/.local/share/dusk, built with it,
// is used instead. dusk-wallpaper rebuilds both on every wallpaper or accent
// change and has dusk-accent reload the Shell theme, which rereads the file.
//
// Light scheme: while color-scheme is not prefer-dark (GNOME Settings' Light
// sets `default`), the -light twin of the stylesheet is used
// (stylesheet-light.css, stylesheet-<id>-light.css, stylesheet-wallpaper-
// light.css), the same rule dusk-accent follows for the Shell theme.

import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';

const IFACE = 'org.gnome.desktop.interface';
const KEY = 'accent-color';
const SCHEME_KEY = 'color-scheme';
const DEFAULT_SLOT = 'blue';
const STYLE_KEY = 'style';
const WALLPAPER_KEY = 'accent-from-wallpaper';
const USER_THEME = 'org.gnome.shell.extensions.user-theme';
// Theme names dusk-wallpaper builds (tokens/dusk_tokens.py theme_name)
const STRATA_THEMES = {dusk: 'Dusk-Wallpaper', atomic: 'Dusk-Atomic-Wallpaper'};
const DEBOUNCE_MS = 150;

export class AccentFollower {
    constructor(extension) {
        this._extension = extension;
        this._timeoutId = 0;
        this._settings = new Gio.Settings({schema_id: IFACE});
        this._changedId = this._settings.connect(`changed::${KEY}`, () => this._schedule());
        this._schemeChangedId = this._settings.connect(`changed::${SCHEME_KEY}`, () => this._schedule());
        this._extSettings = extension.getSettings();
        this._styleChangedId = this._extSettings.connect(`changed::${STYLE_KEY}`, () => this._schedule());
        this._wallpaperChangedId = this._extSettings.connect(`changed::${WALLPAPER_KEY}`, () => this._schedule());
        const schema = Gio.SettingsSchemaSource.get_default()?.lookup(USER_THEME, true);
        this._userTheme = schema ? new Gio.Settings({schema_id: USER_THEME}) : null;
        this._userThemeChangedId = this._userTheme?.connect('changed::name', () => this._schedule()) ?? 0;
        this._apply();
    }

    _schedule() {
        if (this._timeoutId)
            GLib.source_remove(this._timeoutId);
        this._timeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, DEBOUNCE_MS, () => {
            this._timeoutId = 0;
            try {
                this._apply();
            } catch (e) {
                console.error(`dusk-shell: accent: ${e}`);
            }
            return GLib.SOURCE_REMOVE;
        });
    }

    _light() {
        return this._settings.get_string(SCHEME_KEY) !== 'prefer-dark';
    }

    _wallpaperFile(style, light) {
        const sfx = light ? '-Light' : '';
        const strata = (STRATA_THEMES[style] ?? STRATA_THEMES.dusk) + sfx;
        if (this._userTheme ? this._userTheme.get_string('name') !== strata
            : !this._extSettings.get_boolean(WALLPAPER_KEY))
            return null;
        const id = (style === 'atomic' ? 'atomic-wallpaper' : 'wallpaper') + (light ? '-light' : '');
        const file = Gio.File.new_for_path(
            GLib.build_filenamev([GLib.get_user_data_dir(), 'dusk', `stylesheet-${id}.css`]));
        return file.query_exists(null) ? file : null;
    }

    _fileFor(slot, style) {
        const light = this._light();
        const wallpaper = this._wallpaperFile(style, light);
        if (wallpaper)
            return wallpaper;
        const dir = this._extension.dir;
        if (!/^[a-z]+$/.test(slot))
            slot = DEFAULT_SLOT;
        const id = (style === 'atomic' ? `atomic-${slot}` : slot) + (light ? '-light' : '');
        if (id !== DEFAULT_SLOT) {
            const variant = dir.get_child(`stylesheet-${id}.css`);
            if (variant.query_exists(null))
                return variant;
        }
        return dir.get_child('stylesheet.css');
    }

    _apply() {
        // The shell's record for this extension; it owns `stylesheet`
        const record = Main.extensionManager.lookup(this._extension.uuid);
        if (!record?.stylesheet)
            return;

        const file = this._fileFor(this._settings.get_string(KEY),
            this._extSettings.get_string(STYLE_KEY));
        if (record.stylesheet.equal(file))
            return;

        const theme = St.ThemeContext.get_for_stage(global.stage).get_theme();
        const previous = record.stylesheet;
        theme.unload_stylesheet(previous);
        try {
            theme.load_stylesheet(file);
            record.stylesheet = file;
        } catch (e) {
            theme.load_stylesheet(previous);
            throw e;
        }
    }

    destroy() {
        if (this._timeoutId) {
            GLib.source_remove(this._timeoutId);
            this._timeoutId = 0;
        }
        if (this._changedId) {
            this._settings.disconnect(this._changedId);
            this._changedId = 0;
        }
        if (this._schemeChangedId) {
            this._settings.disconnect(this._schemeChangedId);
            this._schemeChangedId = 0;
        }
        this._settings = null;
        if (this._userThemeChangedId) {
            this._userTheme.disconnect(this._userThemeChangedId);
            this._userThemeChangedId = 0;
        }
        this._userTheme = null;
        if (this._wallpaperChangedId) {
            this._extSettings.disconnect(this._wallpaperChangedId);
            this._wallpaperChangedId = 0;
        }
        if (this._styleChangedId) {
            this._extSettings.disconnect(this._styleChangedId);
            this._styleChangedId = 0;
        }
        this._extSettings = null;
        // The stylesheet stays: the shell unloads record.stylesheet right
        // after disable(); when another extension's disable only cycles this
        // one, enable() finds the variant already loaded.
    }
}
