// Strata Badges: notification count badges in the slab style, in each app's own colour.
// Formerly the strata-badges@strata extension (strata/strata/shell/), now a
// Dusk Shell module.
//
// Strata writes <icon theme>/strata-colors.json on every build: for each app icon name,
// a top colour (the app's primary colour as recoloured by the wallpaper), a lighter
// highlight for the sheen, a darker side for the slab's thickness, and a text colour.
// This module finds badge actors (Ubuntu Dock / Dash to Dock use the
// `notification-badge` style class), works out which app each belongs to, and styles it.
// Docks restyle their badges when counts change, so the dock's own inline style is kept
// as a base and Strata's colours are re-applied on top.

import GLib from 'gi://GLib';
import Gio from 'gi://Gio';
import St from 'gi://St';
import Shell from 'gi://Shell';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

const BADGE_CLASSES = ['notification-badge', 'app-notification-badge', 'dash-notification-badge', 'strata-badge'];
const SCAN_SECONDS = 2;

export class StrataBadges {
    constructor() {
        this._iface = new Gio.Settings({schema_id: 'org.gnome.desktop.interface'});
        this._badges = new Map(); // actor -> {base, applied, ids}
        this._colours = null;
        this._reload();
        this._themeId = this._iface.connect('changed::icon-theme', () => this._reload());
        this._scanId = GLib.timeout_add_seconds(GLib.PRIORITY_LOW, SCAN_SECONDS, () => {
            this._scan();
            return GLib.SOURCE_CONTINUE;
        });
        this._scan();
    }

    destroy() {
        if (this._reloadId)
            GLib.source_remove(this._reloadId);
        this._reloadId = 0;
        if (this._scanId)
            GLib.source_remove(this._scanId);
        this._scanId = 0;
        if (this._themeId)
            this._iface.disconnect(this._themeId);
        this._themeId = 0;
        this._monitor?.cancel();
        this._monitor = null;
        for (const [actor, rec] of this._badges) {
            for (const id of rec.ids)
                actor.disconnect(id);
            rec.restoring = true;
            actor.set_style(rec.base || null);
        }
        this._badges.clear();
        this._iface = null;
        this._colours = null;
    }

    // ---- colours file -------------------------------------------------------
    _colourFile() {
        const theme = this._iface.get_string('icon-theme');
        for (const dir of [GLib.get_user_data_dir(), `${GLib.get_home_dir()}/.icons`, ...GLib.get_system_data_dirs()]) {
            const base = dir.endsWith('.icons') ? dir : `${dir}/icons`;
            const f = Gio.File.new_for_path(`${base}/${theme}/strata-colors.json`);
            if (f.query_exists(null))
                return f;
        }
        return null;
    }

    _reload() {
        this._monitor?.cancel();
        this._monitor = null;
        this._colours = null;
        const f = this._colourFile();
        if (f) {
            try {
                const [, bytes] = f.load_contents(null);
                this._colours = JSON.parse(new TextDecoder().decode(bytes));
            } catch (e) {
                console.warn(`Strata Badges: couldn't read ${f.get_path()}: ${e.message}`);
            }
            // Strata swaps the whole theme directory on rebuild, so watch the parent.
            this._monitor = f.get_parent().get_parent().monitor_directory(Gio.FileMonitorFlags.WATCH_MOVES, null);
            this._monitor.connect('changed', () => {
                if (this._reloadId)
                    return;
                this._reloadId = GLib.timeout_add(GLib.PRIORITY_LOW, 1500, () => {
                    this._reloadId = 0;
                    this._reload();
                    return GLib.SOURCE_REMOVE;
                });
            });
        }
        for (const actor of this._badges.keys())
            this._apply(actor);
    }

    _colourFor(app) {
        const c = this._colours;
        if (!c)
            return null;
        const names = [];
        const icon = app?.get_app_info?.()?.get_string?.('Icon');
        if (icon)
            names.push(icon.replace(/\.(svg|png)$/, ''));
        const id = app?.get_id?.()?.replace(/\.desktop$/, '');
        if (id)
            names.push(id, `strata-${id.replace(/[^A-Za-z0-9._-]/g, '-')}`, id.toLowerCase());
        for (const n of names) {
            const i = c.apps?.[n];
            if (i !== undefined)
                return c.colours[i];
        }
        return c.colours?.[0] ?? null;
    }

    // ---- finding badges -----------------------------------------------------
    _scan() {
        const roots = Main.layoutManager.uiGroup.get_children()
            .filter(a => a !== global.window_group && a !== global.top_window_group);
        const stack = [...roots];
        while (stack.length) {
            const a = stack.pop();
            if (!a.visible)
                continue; // hidden docks are picked up the next time they show
            if (a instanceof St.Widget && !this._badges.has(a) &&
                BADGE_CLASSES.some(cls => a.has_style_class_name(cls)))
                this._track(a);
            const kids = a.get_children();
            for (let i = 0; i < kids.length; i++)
                stack.push(kids[i]);
        }
    }

    _appFor(actor) {
        for (let a = actor, i = 0; a && i < 12; a = a.get_parent(), i++) {
            if (a.app instanceof Shell.App)
                return a.app;
            if (a._delegate?.app instanceof Shell.App)
                return a._delegate.app;
            if (a.source?.app instanceof Shell.App)
                return a.source.app;
        }
        return null;
    }

    _track(actor) {
        const rec = {base: actor.get_style() ?? '', applied: null, ids: [], restoring: false};
        rec.ids.push(actor.connect('notify::style', () => {
            if (rec.restoring)
                return;
            const now = actor.get_style() ?? '';
            if (now !== rec.applied) { // the dock restyled it: keep that as the new base
                rec.base = now;
                this._apply(actor);
            }
        }));
        rec.ids.push(actor.connect('destroy', () => this._badges.delete(actor)));
        this._badges.set(actor, rec);
        this._apply(actor);
    }

    _apply(actor) {
        const rec = this._badges.get(actor);
        if (!rec)
            return;
        const c = this._colourFor(this._appFor(actor));
        if (!c)
            return;
        // The slab: highlight-to-top gradient face, a 2px darker side below, a soft cast shadow.
        const ours =
            `background-color: ${c.bg};` +
            'background-gradient-direction: vertical;' +
            `background-gradient-start: ${c.hi};` +
            `background-gradient-end: ${c.bg};` +
            `color: ${c.fg};` +
            'border-width: 0 0 2px 0;' +
            `border-color: ${c.side};` +
            'border-radius: 999px;' +
            'box-shadow: 0 2px 3px rgba(0, 0, 0, 0.28);' +
            'font-weight: 800;';
        const base = rec.base.trim();
        rec.applied = `${base}${base && !base.endsWith(';') ? ';' : ''}${ours}`;
        actor.set_style(rec.applied);
    }
}
