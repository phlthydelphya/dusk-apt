// The GIF tab of the clipboard panel (clipboard.js), like Windows 11's:
// recently used and trending GIFs, or results for the search field, in two
// columns of animated tiles with rounded corners. Picking one hands its file
// to the panel, which pastes it.
//
// Search is KLIPY (api.klipy.com; Tenor's API, which Windows uses, closed in
// June 2026). It needs a free key from partner.klipy.com in the gif-api-key
// setting; without one the tab says where to add it. Nothing is sent until
// the tab is opened. The customer id KLIPY asks for is a random id kept in
// the panel's store, not tied to the user.
//
// KLIPY's integration requirements: results are shown in the order and
// composition returned, each endpoint in its own section; media is loaded
// from the returned URLs and not kept (thumbnails live only while shown);
// recently used comes from KLIPY's per-user Recent API, fed by its Share
// Trigger on every pick.

import Clutter from 'gi://Clutter';
import Cogl from 'gi://Cogl';
import GdkPixbuf from 'gi://GdkPixbuf';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Pango from 'gi://Pango';
import Soup from 'gi://Soup?version=3.0';
import St from 'gi://St';

import {gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';
import {GlslEffect} from './glslEffect.js';

const API = 'https://api.klipy.com/api/v1';
const PER_PAGE = 24;
const RECENT_COUNT = 8;
const DEBOUNCE_MS = 400;
const COLUMN_GAP = 6;
const RADIUS = 10;
const FRAME_MS = 20; // animation tick; each tile keeps its own frame times
const MAX_GIF = 8 * 1024 * 1024; // bytes pasted at most

Gio._promisify(Soup.Session.prototype, 'send_and_read_async');

// Rounds an actor's corners: St does not clip content to border-radius
const CLIP_DECL = 'uniform vec2 size;\nuniform float radius;\n';
const CLIP_CODE = `
vec2 p = cogl_tex_coord_in[0].xy * size;
vec2 q = min(p, size - p);
if (q.x < radius && q.y < radius) {
    float d = length(vec2(radius) - q);
    cogl_color_out *= clamp(radius - d + 0.5, 0.0, 1.0);
}
`;

export const RoundedClipEffect = GObject.registerClass(
class DuskRoundedClipEffect extends GlslEffect {
    snippet() {
        return [CLIP_DECL, CLIP_CODE, false];
    }

    setGeometry(width, height, radius) {
        this.setUniform('size', 2, [width, height]);
        this.setUniform('radius', 1, [radius]);
        this.queue_repaint();
    }
});

// The rendition of a KLIPY result in a size, as {url, width, height}
function rendition(item, sizes) {
    const files = item.file ?? item.files ?? {};
    for (const size of sizes) {
        const gif = files[size]?.gif;
        if (gif?.url && gif.width > 0 && gif.height > 0)
            return {url: gif.url, width: gif.width, height: gif.height, size: gif.size ?? 0};
    }
    return null;
}

export function gifFromResult(item) {
    // Ads come only with ad parameters, which are never sent
    if (!item || item.type === 'ad')
        return null;
    const xs = rendition(item, ['xs']);
    const thumb = xs?.width >= 150 ? xs : rendition(item, ['sm', 'xs', 'md']);
    const full = rendition(item, ['md', 'hd', 'sm']);
    if (!thumb || !full)
        return null;
    return {id: String(item.slug ?? item.id ?? full.url), slug: item.slug ?? null,
        title: item.title ?? '', thumb, full};
}

class GifTile {
    constructor(gif, width, tab) {
        this.gif = gif;
        const height = Math.max(40, Math.round(width * gif.thumb.height / gif.thumb.width));
        this._picture = new St.Widget({width, height, style_class: 'dusk-gif-picture'});
        this._clip = new RoundedClipEffect();
        this._picture.add_effect(this._clip);
        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        this._clip.setGeometry(width, height, RADIUS * scale);
        this.actor = new St.Button({
            style_class: 'dusk-gif-tile',
            can_focus: true,
            accessible_name: gif.title || _('GIF'),
            child: this._picture,
        });
        this.actor._duskGif = gif;
        this.actor.connect('clicked', () => tab.pick(gif));
        this._iter = null;
        this._content = null;
        this._next = 0;
    }

    setAnimation(animation) {
        this._animation = animation;
        this._iter = animation.get_iter(null);
        const pixbuf = this._iter.get_pixbuf();
        this._content = St.ImageContent.new_with_preferred_size(pixbuf.width, pixbuf.height);
        this._picture.set_content(this._content);
        this._picture.content_gravity = Clutter.ContentGravity.RESIZE_ASPECT;
        this._show(pixbuf);
        this._schedule();
    }

    _show(pixbuf) {
        const ctx = global.stage.context.get_backend().get_cogl_context();
        this._content.set_bytes(ctx, pixbuf.read_pixel_bytes(),
            pixbuf.has_alpha ? Cogl.PixelFormat.RGBA_8888 : Cogl.PixelFormat.RGB_888,
            pixbuf.width, pixbuf.height, pixbuf.rowstride);
    }

    _schedule() {
        const delay = this._iter.get_delay_time();
        this._next = delay < 0 ? Infinity : GLib.get_monotonic_time() + Math.max(delay, 20) * 1000;
    }

    // Called on every tick; shows the next frame when it is due
    tick(now) {
        if (!this._iter || now < this._next)
            return;
        if (this._iter.advance(null))
            this._show(this._iter.get_pixbuf());
        this._schedule();
    }
}

export class GifTab {
    constructor({settings, soup, store, onPick}) {
        this._settings = settings;
        this._soup = soup;
        this._store = store;
        this._onPick = onPick;
        this._query = '';
        this._tiles = [];
        this._cancellable = null;
        this._searchId = 0;
        this._tickId = 0;

        this.actor = new St.BoxLayout({
            style_class: 'dusk-pick-tab',
            orientation: Clutter.Orientation.VERTICAL,
            x_expand: true,
            y_expand: true,
        });
        this._body = new St.BoxLayout({
            style_class: 'dusk-pick-body',
            orientation: Clutter.Orientation.VERTICAL,
            x_expand: true,
        });
        this._scroll = new St.ScrollView({
            style_class: 'dusk-pick-scroll vfade',
            x_expand: true,
            y_expand: true,
            overlay_scrollbars: true,
            hscrollbar_policy: St.PolicyType.NEVER,
            vscrollbar_policy: St.PolicyType.EXTERNAL,
            child: this._body,
        });
        this.actor.add_child(this._scroll);

        this._note = new St.Label({
            style_class: 'dusk-clip-empty',
            x_align: Clutter.ActorAlign.CENTER,
            y_align: Clutter.ActorAlign.CENTER,
            y_expand: true,
            visible: false,
        });
        this._note.clutter_text.line_wrap = true;
        this._note.clutter_text.ellipsize = Pango.EllipsizeMode.NONE;
        this.actor.add_child(this._note);

        this.actor.add_child(new St.Label({
            style_class: 'dusk-gif-attribution',
            text: _('Powered by KLIPY'),
            x_align: Clutter.ActorAlign.END,
        }));
    }

    get searchHint() {
        return _('Search GIFs');
    }

    // The tab is shown (the panel opened on it, or it was picked)
    show(query) {
        this._query = query.trim();
        this._load(0);
        this._startTicks();
    }

    hide() {
        this._stopTicks();
        this._cancellable?.cancel();
        this._cancellable = null;
        if (this._searchId)
            GLib.source_remove(this._searchId);
        this._searchId = 0;
        // Media is not kept once out of sight
        this._clear();
    }

    setQuery(query) {
        query = query.trim();
        if (query === this._query)
            return;
        this._query = query;
        this._load(DEBOUNCE_MS);
    }

    focusFirst() {
        const first = this._tiles[0]?.actor;
        if (first) {
            first.grab_key_focus();
            return true;
        }
        return false;
    }

    navigate(from, direction) {
        return this._body.navigate_focus(from, direction, false);
    }

    contains(actor) {
        return this.actor.contains(actor);
    }

    pick(gif) {
        this._share(gif);
        this._onPick(gif);
    }

    // Bytes of a GIF for pasting
    async fetchFull(gif) {
        const bytes = await this._get(gif.full.url, null);
        if (bytes.get_size() > MAX_GIF)
            throw new Error(_('The GIF is too large'));
        return bytes;
    }

    get _key() {
        return this._settings.get_string('gif-api-key').trim();
    }

    // KLIPY's Share Trigger: feeds the Recent API and its ranking
    async _share(gif) {
        const key = this._key;
        if (!key || !gif.slug)
            return;
        try {
            const url = `${API}/${encodeURIComponent(key)}/gifs/share/${encodeURIComponent(gif.slug)}`;
            const message = Soup.Message.new('POST', url);
            const body = {customer_id: this._store.customerId};
            if (this._query)
                body.q = this._query;
            message.set_request_body_from_bytes('application/json',
                new GLib.Bytes(new TextEncoder().encode(JSON.stringify(body))));
            await this._soup.send_and_read_async(message, GLib.PRIORITY_LOW, null);
        } catch (e) {
            console.debug(`dusk-shell: GIF share trigger: ${e}`);
        }
    }

    _load(delay) {
        if (this._searchId)
            GLib.source_remove(this._searchId);
        this._searchId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, Math.max(delay, 1), () => {
            this._searchId = 0;
            this._fetch().catch(e => {
                if (e.matches?.(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED))
                    return;
                console.warn(`dusk-shell: GIF search: ${e}`);
                this._message(_('Couldn’t reach KLIPY. Check the connection and the API key.'));
            });
            return GLib.SOURCE_REMOVE;
        });
    }

    _message(text) {
        this._scroll.visible = !text;
        this._note.visible = !!text;
        this._note.text = text ?? '';
        if (text)
            this._clear();
    }

    async _fetch() {
        this._cancellable?.cancel();
        const cancellable = this._cancellable = new Gio.Cancellable();
        const key = this._key;
        if (!key) {
            this._message(_('Add a free KLIPY API key (partner.klipy.com) in Dusk Shell settings to search GIFs.'));
            return;
        }
        const sections = [];
        if (this._query) {
            sections.push({title: null, gifs: await this._request(key, 'search', cancellable)});
        } else {
            // Recently used and trending, each as KLIPY returns it
            const [recent, trending] = await Promise.all([
                this._request(key, `recent/${encodeURIComponent(this._store.customerId)}`, cancellable, RECENT_COUNT)
                    .catch(() => []),
                this._request(key, 'trending', cancellable),
            ]);
            if (recent.length)
                sections.push({title: _('Recently used'), gifs: recent});
            sections.push({title: _('Trending'), gifs: trending});
        }
        if (cancellable.is_cancelled())
            return;
        if (!sections.some(section => section.gifs.length)) {
            this._message(_('No GIFs found.'));
            return;
        }
        this._message(null);
        this._render(sections.filter(section => section.gifs.length), cancellable);
    }

    async _request(key, endpoint, cancellable, perPage = PER_PAGE) {
        const params = {
            per_page: String(Math.max(perPage, 8)),
            page: '1',
            customer_id: this._store.customerId,
            content_filter: this._settings.get_string('gif-content-filter'),
            format_filter: 'gif',
        };
        // Country, as KLIPY asks: en_US -> us
        const country = (GLib.get_language_names()[0] ?? '').match(/^[a-z]+_([A-Z]{2})/)?.[1];
        if (country)
            params.locale = country.toLowerCase();
        if (this._query && endpoint === 'search')
            params.q = this._query;
        // GJS has no URLSearchParams
        const query = Object.entries(params)
            .map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&');
        const url = `${API}/${encodeURIComponent(key)}/gifs/${endpoint}?${query}`;
        const bytes = await this._get(url, cancellable);
        const json = JSON.parse(new TextDecoder().decode(bytes.toArray()));
        const list = json?.data?.data ?? [];
        return list.map(gifFromResult).filter(Boolean).slice(0, perPage);
    }

    async _get(url, cancellable) {
        const message = Soup.Message.new('GET', url);
        if (!message)
            throw new Error(`bad URL ${url}`);
        const bytes = await this._soup.send_and_read_async(message, GLib.PRIORITY_DEFAULT, cancellable);
        if (message.get_status() !== Soup.Status.OK)
            throw new Error(`HTTP ${message.get_status()}`);
        return bytes;
    }

    _clear() {
        this._body.destroy_all_children();
        this._tiles = [];
    }

    _render(sections, cancellable) {
        this._clear();
        this._scroll.vadjustment.value = 0;
        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        const avail = this._scroll.width > 0 ? this._scroll.width : 370 * scale;
        const colWidth = Math.floor((avail - COLUMN_GAP * scale) / 2) - 2 * scale;
        for (const {title, gifs} of sections) {
            if (title)
                this._body.add_child(new St.Label({style_class: 'dusk-pick-section-title', text: title}));
            const columns = new St.BoxLayout({style_class: 'dusk-gif-columns', x_expand: true});
            const cols = [0, 1].map(() => {
                const col = new St.BoxLayout({
                    style_class: 'dusk-gif-column',
                    orientation: Clutter.Orientation.VERTICAL,
                    x_expand: true,
                });
                columns.add_child(col);
                return col;
            });
            this._body.add_child(columns);
            // Masonry, in KLIPY's order: each tile into the shorter column
            const heights = [0, 0];
            for (const gif of gifs) {
                const tile = new GifTile(gif, colWidth, this);
                const i = heights[0] <= heights[1] ? 0 : 1;
                cols[i].add_child(tile.actor);
                heights[i] += tile.actor.get_preferred_height(colWidth)[1] + COLUMN_GAP * scale;
                this._tiles.push(tile);
                this._loadThumb(tile, cancellable);
            }
        }
    }

    async _loadThumb(tile, cancellable) {
        try {
            const bytes = await this._get(tile.gif.thumb.url, cancellable);
            if (cancellable?.is_cancelled() || !this._tiles.includes(tile))
                return;
            const loader = new GdkPixbuf.PixbufLoader();
            loader.write_bytes(bytes);
            loader.close();
            const animation = loader.get_animation();
            if (animation)
                tile.setAnimation(animation);
        } catch (e) {
            if (!e.matches?.(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED))
                console.debug(`dusk-shell: GIF thumbnail: ${e}`);
        }
    }

    _startTicks() {
        if (this._tickId)
            return;
        this._tickId = GLib.timeout_add(GLib.PRIORITY_DEFAULT_IDLE, FRAME_MS, () => {
            const now = GLib.get_monotonic_time();
            for (const tile of this._tiles)
                tile.tick(now);
            return GLib.SOURCE_CONTINUE;
        });
    }

    _stopTicks() {
        if (this._tickId)
            GLib.source_remove(this._tickId);
        this._tickId = 0;
    }

    destroy() {
        this.hide();
        this.actor.destroy();
    }
}
