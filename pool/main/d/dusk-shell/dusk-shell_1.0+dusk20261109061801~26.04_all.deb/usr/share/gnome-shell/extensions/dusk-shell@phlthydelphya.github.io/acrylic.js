import Clutter from 'gi://Clutter';
import GObject from 'gi://GObject';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import {GlslEffect} from './glslEffect.js';

// Win11-style acrylic behind a Dusk float card (notification drawer, app
// menu), on Blur my Shell's "Dusk acrylic (drawer and app menu)" pipeline
// (setup/bms-acrylic.py): blur radius 40, saturation x1.3, $base tint at 60%,
// grain 0.05, the same as the top bar and dock (the shell menus' "Dusk
// acrylic" until it exists).
//
// A plain St.Widget sits under the card, bound to its allocation, translation
// and opacity, and holds a Blur my Shell dynamic surface running that pipeline
// with the card's corner radius. Blur my Shell captures the backdrop itself,
// so the blur works under its rounded mask. Dusk's earlier own effects (a
// rounded mask wrapping Shell.BlurEffect in BACKGROUND mode) showed no blur:
// the mask's offscreen buffer is what the backdrop blur read. The card's CSS
// tint (.dusk-acrylic in stylesheet.scss) is painted on top; with the surface
// (.dusk-acrylic-blurred) it is the top bar's light 12% over the pipeline's
// 60%. Without Blur my Shell the card keeps an 80% tint alone.
//
// AcrylicMaskEffect (the rounded mask with saturation and grain) is still
// used by popupAcrylic.js over a static wallpaper blur.
//
// Mask approach inspired by Blur my Shell's corner and noise effects
// (effects/corner/corner.glsl, effects/texture/noise.glsl, GPL); this is an
// independent implementation.

const CORNER_RADIUS = 20; // $r-window, the card's border-radius
const SATURATION = 1.3;
// AcrylicMaskEffect's default grain, for a mask under an 85% tint: the tint
// is on top of the grain, so it is scaled up to land at 0.05
const GRAIN = 0.05 / (1 - 0.85);

const DECLARATIONS = `
uniform sampler2D tex;
uniform float width;
uniform float height;
uniform float radius;
uniform float saturation;
uniform float grain;

vec3 dusk_rgb_to_hsv(vec3 c) {
    float hi = max(c.r, max(c.g, c.b));
    float lo = min(c.r, min(c.g, c.b));
    float d = hi - lo;
    float h = 0.0;
    if (d > 0.00001) {
        if (hi == c.r)
            h = mod((c.g - c.b) / d, 6.0);
        else if (hi == c.g)
            h = (c.b - c.r) / d + 2.0;
        else
            h = (c.r - c.g) / d + 4.0;
        h /= 6.0;
    }
    return vec3(h, hi > 0.00001 ? d / hi : 0.0, hi);
}

vec3 dusk_hsv_to_rgb(vec3 c) {
    vec3 p = abs(fract(c.xxx + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}

float dusk_hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}
`;

// Signed distance to a rounded box, one stage pixel of antialiasing
const CODE = `
vec2 uv = cogl_tex_coord_in[0].xy;
vec4 color = texture2D(tex, uv);

vec2 half_size = vec2(max(width, 1.0), max(height, 1.0)) * 0.5;
vec2 p = uv * half_size * 2.0 - half_size;
float r = min(radius, min(half_size.x, half_size.y));
vec2 q = abs(p) - half_size + vec2(r);
float dist = length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0) - r;
float coverage = clamp(0.5 - dist, 0.0, 1.0);

if (color.a > 0.0) {
    vec3 hsv = dusk_rgb_to_hsv(color.rgb / color.a);
    hsv.y = clamp(hsv.y * saturation, 0.0, 1.0);
    vec3 rgb = dusk_hsv_to_rgb(hsv);
    rgb = mix(rgb, vec3(0.5), grain * (1.0 - dusk_hash(gl_FragCoord.xy)));
    color = vec4(rgb * color.a, color.a);
}

cogl_color_out = cogl_color_in * color * coverage;
`;

// Same pattern as the shell's own RadialShaderEffect (ui/lightbox.js) and
// FadeEffect (ui/messageList.js), on glslEffect.js for Shell 50 and 51.
// `radius` (logical px) and `grain` default to the float cards' values;
// popupAcrylic.js sets its own.
export const AcrylicMaskEffect = GObject.registerClass(
class AcrylicMaskEffect extends GlslEffect {
    _init(params = {}) {
        const {radius = CORNER_RADIUS, grain = GRAIN, ...rest} = params;
        super._init(rest);
        this._radius = radius;
        this._grain = grain;
    }

    snippet() {
        return [DECLARATIONS, CODE, true];
    }

    // The blur reads the live stage, so the cached offscreen is never valid
    // for long: re-render it on every paint
    vfunc_paint(node, paintContext, flags) {
        super.vfunc_paint(node, paintContext,
            flags | Clutter.EffectPaintFlags.ACTOR_DIRTY);
    }

    // Allocation and scale are read at paint time, so resizes, monitor
    // changes and scale changes never leave stale uniforms
    vfunc_paint_target(node, paintContext) {
        const actor = this.get_actor();
        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        this.setUniform('width', 1, [actor.width]);
        this.setUniform('height', 1, [actor.height]);
        this.setUniform('radius', 1, [this._radius * scale]);
        this.setUniform('saturation', 1, [SATURATION]);
        this.setUniform('grain', 1, [this._grain]);
        super.vfunc_paint_target(node, paintContext);
    }
});

// Blur my Shell's dynamic surface (render/dynamic_surface.js, Blur my Shell
// 77+). Imported from the URL Blur my Shell itself loaded it from, so it is
// the same module instance (its GObject classes register only once).
const BMS_UUID = 'blur-my-shell@aunetx';
const BMS_PIPELINE = 'pipeline_dusk_acrylic';
// The float cards' own, lighter and softer (setup/bms-acrylic.py PIPELINES);
// the shared one until Dusk's dconf has added it
const BMS_FLOAT_PIPELINE = 'pipeline_dusk_acrylic_float';
let bmsSurfaceModule = null;
let bmsLoading = null;

// Resolves to Blur my Shell's dynamic_surface.js module, or null
export function loadBlurMyShell() {
    if (bmsSurfaceModule)
        return Promise.resolve(bmsSurfaceModule);
    if (bmsLoading)
        return bmsLoading;
    const ext = Main.extensionManager.lookup(BMS_UUID);
    if (!ext?.dir)
        return Promise.resolve(null);
    bmsLoading = import(`${ext.dir.get_uri()}/render/dynamic_surface.js`)
        .then(module => {
            bmsSurfaceModule = module.DynamicPipeline ? module : null;
            return bmsSurfaceModule;
        })
        .catch(e => {
            console.warn(`dusk-shell: Blur my Shell surface unavailable: ${e}`);
            return null;
        })
        .finally(() => {
            bmsLoading = null;
        });
    return bmsLoading;
}

// Owns the blur actor under `card`. The card must already have a parent
// with a fixed layout (the full-stage backdrop). If anything fails the card
// keeps its 85% tint without blur.
export class Acrylic {
    // corners: Blur my Shell's corner selection: 0 all, 1 top, 2 bottom
    constructor(card, {corners = 0} = {}) {
        this._card = card;
        this._corners = corners;
        this._actor = null;
        this._surface = null;
        this._surfaceDestroyId = 0;
        this._bms = null;
        this._open = false;
        this._bindings = [];

        try {
            this._build();
        } catch (e) {
            console.warn(`dusk-shell: acrylic disabled: ${e}`);
            this._teardown();
            return;
        }
        loadBlurMyShell().then(() => {
            if (this._open)
                this._ensureSurface();
        });
    }

    get active() {
        return this._actor !== null;
    }

    _build() {
        const card = this._card;
        const parent = card.get_parent();
        if (!parent)
            throw new Error('card has no parent');

        this._actor = new St.Widget({
            name: 'duskAcrylic',
            reactive: false,
            visible: false,
        });
        parent.insert_child_below(this._actor, card);

        this._actor.add_constraint(new Clutter.BindConstraint({
            source: card,
            coordinate: Clutter.BindCoordinate.ALL,
        }));
        // Open/close animations ease these on the card
        for (const prop of ['translation-x', 'translation-y', 'opacity']) {
            this._bindings.push(card.bind_property(prop, this._actor, prop,
                GObject.BindingFlags.SYNC_CREATE));
        }

        card.add_style_class_name('dusk-acrylic');
    }

    // A surface from the running Blur my Shell; rebuilt if Blur my Shell was
    // restarted since (its managers are new objects then)
    _ensureSurface() {
        const bms = global.blur_my_shell;
        if (this._surface && this._bms === bms)
            return;
        this._dropSurface();
        if (!this._actor || !bmsSurfaceModule || !bms?._effects_manager || !bms._pipelines_manager)
            return;
        try {
            const pipeline = new bmsSurfaceModule.DynamicPipeline(
                bms._effects_manager, bms._pipelines_manager,
                Object.hasOwn(bms._pipelines_manager.pipelines ?? {}, BMS_FLOAT_PIPELINE)
                    ? BMS_FLOAT_PIPELINE : BMS_PIPELINE,
                {corner_radius: CORNER_RADIUS, get_corners: () => this._corners});
            this._surface = pipeline.attach_to_container(this._actor, 'duskAcrylicBlur');
            this._surfaceDestroyId = this._surface.connect('destroy', () => {
                this._surface = null;
                this._surfaceDestroyId = 0;
                this._card?.remove_style_class_name('dusk-acrylic-blurred');
            });
            this._bms = bms;
            this._card.add_style_class_name('dusk-acrylic-blurred');
        } catch (e) {
            console.warn(`dusk-shell: acrylic blur unavailable: ${e}`);
            this._dropSurface();
        }
    }

    _dropSurface() {
        if (this._surface) {
            this._surface.disconnect(this._surfaceDestroyId);
            this._surface.destroy();
        }
        this._surface = null;
        this._surfaceDestroyId = 0;
        this._bms = null;
        this._card?.remove_style_class_name('dusk-acrylic-blurred');
    }

    // Call before the open animation starts
    start() {
        if (!this._actor)
            return;
        this._open = true;
        this._ensureSurface();
        this._actor.show();
    }

    // Call once the card is hidden (after the close animation)
    stop() {
        this._open = false;
        this._actor?.hide();
    }

    destroy() {
        this._teardown();
        this._card = null;
    }

    _teardown() {
        this.stop();
        this._dropSurface();
        for (const binding of this._bindings)
            binding.unbind();
        this._bindings = [];
        this._card?.remove_style_class_name('dusk-acrylic');
        this._actor?.destroy();
        this._actor = null;
    }
}
