import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import * as Signals from 'resource:///org/gnome/shell/misc/signals.js';
import {InjectionManager, gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

import {Acrylic} from './acrylic.js';
import {MediaCard} from './mediaCard.js';
import {OPEN_TIME, CLOSE_TIME, OPEN_MODE, CLOSE_MODE, timing} from './motion.js';

const DRAWER_WIDTH = 400;
const SCREEN_GAP = 12; // $gap-m
const KEYBINDING = 'toggle-drawer';
const SHELL_KEYBINDINGS_SCHEMA = 'org.gnome.shell.keybindings';
const SHELL_NOTIFICATION_KEY = 'focus-active-notification';

// Raven-style card on the right edge under the panel. Holds the date menu's
// notification list, world clocks and weather, borrowed from the date menu
// and handed back on destroy().
export class NotificationDrawer extends Signals.EventEmitter {
    constructor(settings) {
        super();

        this._settings = settings;
        this._dateMenu = Main.panel.statusArea.dateMenu ?? null;
        this._isOpen = false;
        this._grab = null;
        // {actor, parent, index, clickedId}
        this._adopted = [];
        this._mediaCard = null;
        this._notificationSettings = new Gio.Settings({
            schema_id: 'org.gnome.desktop.notifications',
        });

        this._buildUi();
        this._acrylic = new Acrylic(this._card);
        this._adoptDateMenuParts();

        global.focus_manager.add_group(this.actor);
        Main.layoutManager.addTopChrome(this.actor);

        // Everything that closes the calendar after acting on a notification
        // or a section calls Main.panel.closeCalendar() (panel.js:629)
        const self = this;
        this._injections = new InjectionManager();
        this._injections.overrideMethod(Object.getPrototypeOf(Main.panel), 'closeCalendar', original => function (...args) {
            original.call(this, ...args);
            self.close();
        });

        this._signals = [
            [this._notificationSettings, this._notificationSettings.connect('changed::show-banners',
                () => this._syncDnd())],
            [Main.layoutManager, Main.layoutManager.connect('monitors-changed', () => this.close(false))],
            [Main.sessionMode, Main.sessionMode.connect('updated', () => {
                if (Main.sessionMode.isLocked)
                    this.close(false);
            })],
            [Main.overview, Main.overview.connect('showing', () => this.close(false))],
        ];
        this._syncDnd();

        this._takeKeybinding();
    }

    get isOpen() {
        return this._isOpen;
    }

    _buildUi() {
        // Full-stage backdrop: takes the modal grab and the outside clicks
        this.actor = new St.Widget({
            name: 'duskDrawerBackdrop',
            reactive: true,
            visible: false,
        });

        this._card = new St.BoxLayout({
            style_class: 'dusk-drawer',
            orientation: Clutter.Orientation.VERTICAL,
            reactive: true,
        });
        this.actor.add_child(this._card);

        const header = new St.BoxLayout({style_class: 'dusk-drawer-header'});
        header.add_child(new St.Label({
            style_class: 'dusk-drawer-title',
            text: _('Notifications'),
            x_expand: true,
            y_align: Clutter.ActorAlign.CENTER,
        }));

        // Shell 51 keeps Do Not Disturb in quick settings only, so the
        // drawer has its own switch on the same key
        this._dndSwitch = new PopupMenu.Switch(false);
        const dndBox = new St.BoxLayout({style_class: 'dusk-drawer-dnd-box'});
        dndBox.add_child(new St.Label({
            text: _('Do Not Disturb'),
            y_align: Clutter.ActorAlign.CENTER,
        }));
        dndBox.add_child(this._dndSwitch);
        this._dndButton = new St.Button({
            style_class: 'dusk-drawer-dnd',
            can_focus: true,
            accessible_name: _('Do Not Disturb'),
            child: dndBox,
        });
        this._dndButton.connect('clicked', () => {
            const showBanners = this._notificationSettings.get_boolean('show-banners');
            this._notificationSettings.set_boolean('show-banners', !showBanners);
        });
        header.add_child(this._dndButton);
        this._card.add_child(header);

        this._listSlot = new St.BoxLayout({
            style_class: 'dusk-drawer-list',
            orientation: Clutter.Orientation.VERTICAL,
            x_expand: true,
            y_expand: true,
        });
        this._card.add_child(this._listSlot);

        this._extras = new St.BoxLayout({
            style_class: 'dusk-drawer-extras',
            orientation: Clutter.Orientation.VERTICAL,
            x_expand: true,
        });
        this._card.add_child(this._extras);

        const click = new Clutter.ClickGesture();
        click.connect('may-recognize', () => {
            const event = click.get_point_event(0);
            return global.stage.get_event_actor(event) === this.actor;
        });
        click.connect('recognize', () => this.close());
        this.actor.add_action(click);

        // Bubble phase: the message list's own capture-phase Escape
        // (collapse an expanded group, calendar.js:878) goes first
        const keys = new Clutter.KeyController();
        keys.connect('key-press', () => {
            const [, symbol] = keys.get_key();
            if (symbol !== Clutter.KEY_Escape)
                return Clutter.EVENT_PROPAGATE;
            this.close();
            return Clutter.EVENT_STOP;
        });
        this.actor.add_action(keys);
    }

    // DateMenuButton fields, dateMenu.js:920 (_messageList),
    // :954 (_clocksItem), :957 (_weatherItem). The section classes are not
    // exported, so the live instances move.
    _adoptDateMenuParts() {
        const dateMenu = this._dateMenu;
        if (!dateMenu)
            return;

        const messageList = dateMenu._messageList;
        if (messageList) {
            this._adopt(messageList, this._listSlot);
            // CalendarMessageList.setCaptureContainer, calendar.js:895
            messageList.setCaptureContainer?.(this.actor);
            // Same rule as DateMenuButton._sessionUpdated (dateMenu.js:1005);
            // PanelLayout hid it while it sat in the date menu
            messageList.visible = Main.sessionMode.hasNotifications &&
                !Main.sessionMode.isGreeter;

            // CalendarMessageList._messageView, calendar.js:815
            const messageView = messageList._messageView;
            if (messageView?._mediaSource) {
                this._mediaCard = new MediaCard(messageView, () => this.close());
                this._card.insert_child_below(this._mediaCard.actor, this._listSlot);
            }
        }

        for (const item of [dateMenu._clocksItem, dateMenu._weatherItem]) {
            if (item)
                this._adopt(item, this._extras, true);
        }
    }

    _adopt(actor, newParent, closeOnClick = false) {
        const parent = actor.get_parent();
        const index = parent ? parent.get_children().indexOf(actor) : -1;
        parent?.remove_child(actor);
        newParent.add_child(actor);
        const clickedId = closeOnClick
            ? actor.connect('clicked', () => this.close())
            : 0;
        this._adopted.push({actor, parent, index, clickedId});
    }

    _returnDateMenuParts() {
        // Reverse order keeps the saved indices valid
        for (const {actor, parent, index, clickedId} of this._adopted.reverse()) {
            if (clickedId)
                actor.disconnect(clickedId);
            actor.get_parent()?.remove_child(actor);
            parent?.insert_child_at_index(actor, Math.max(index, 0));
        }
        this._adopted = [];
        this._dateMenu?._messageList?.setCaptureContainer?.(this._dateMenu.menu.actor);
    }

    _takeKeybinding() {
        // Super+N is also the shell's focus-active-notification. Mutter keeps
        // one handler per combo, so the shell binding steps aside while ours
        // uses the same accelerator.
        const shellKeys = new Gio.Settings({schema_id: SHELL_KEYBINDINGS_SCHEMA});
        const ours = this._settings.get_strv(KEYBINDING);
        this._removedShellBinding = shellKeys.get_strv(SHELL_NOTIFICATION_KEY)
            .some(accel => ours.includes(accel));
        if (this._removedShellBinding)
            Main.wm.removeKeybinding(SHELL_NOTIFICATION_KEY);

        Main.wm.addKeybinding(KEYBINDING, this._settings,
            Meta.KeyBindingFlags.IGNORE_AUTOREPEAT,
            Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW | Shell.ActionMode.POPUP,
            () => this.toggle());
    }

    _releaseKeybinding() {
        Main.wm.removeKeybinding(KEYBINDING);
        if (!this._removedShellBinding)
            return;
        // Re-adds what MessageTray registers at startup (messageTray.js:812-816)
        const tray = Main.messageTray;
        if (tray?._expandActiveNotification) {
            Main.wm.addKeybinding(SHELL_NOTIFICATION_KEY,
                new Gio.Settings({schema_id: SHELL_KEYBINDINGS_SCHEMA}),
                Meta.KeyBindingFlags.NONE,
                Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW,
                tray._expandActiveNotification.bind(tray));
        }
        this._removedShellBinding = false;
    }

    destroy() {
        this.close(false);
        this._releaseKeybinding();
        this._injections.clear();
        this._injections = null;
        for (const [object, id] of this._signals)
            object.disconnect(id);
        this._signals = [];

        this._mediaCard?.destroy();
        this._mediaCard = null;
        this._returnDateMenuParts();

        this._acrylic.destroy();
        this._acrylic = null;
        global.focus_manager.remove_group(this.actor);
        Main.layoutManager.removeChrome(this.actor);
        this.actor.destroy();
        this._notificationSettings = null;
        this._dateMenu = null;
        this._settings = null;
    }

    _syncDnd() {
        const dnd = !this._notificationSettings.get_boolean('show-banners');
        this._dndSwitch.state = dnd;
        this._dndButton.checked = dnd;
    }

    toggle() {
        if (this._isOpen)
            this.close();
        else
            this.open();
    }

    open() {
        if (this._isOpen || Main.sessionMode.isLocked)
            return;

        Main.panel.closeCalendar();
        this._layout();

        this._grab = Main.pushModal(this.actor, {actionMode: Shell.ActionMode.POPUP});
        this._isOpen = true;

        this._card.remove_all_transitions();
        this._card.opacity = 0;
        this._card.translation_x = this._slideDistance();
        this._acrylic.start();
        this.actor.show();
        global.stage.set_key_focus(this.actor);

        this._card.ease({
            opacity: 255,
            translation_x: 0,
            duration: timing(OPEN_TIME),
            mode: OPEN_MODE,
        });
        this.emit('open-state-changed', true);
    }

    close(animate = true) {
        if (!this._isOpen)
            return;
        this._isOpen = false;

        // Give input back right away, before the slide finishes
        if (this._grab) {
            Main.popModal(this._grab);
            this._grab = null;
        }
        this.emit('open-state-changed', false);

        const done = () => {
            // Reopened while sliding out
            if (this._isOpen)
                return;
            this.actor.hide();
            this._acrylic.stop();
            this._card.translation_x = 0;
        };

        if (!animate) {
            this._card.remove_all_transitions();
            done();
            return;
        }

        this._card.ease({
            opacity: 0,
            translation_x: this._slideDistance(),
            duration: timing(CLOSE_TIME),
            mode: CLOSE_MODE,
            onStopped: done,
        });
    }

    _slideDistance() {
        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        return this._card.width + SCREEN_GAP * scale;
    }

    // Right edge of the primary monitor, under the panel, $gap-m all round
    _layout() {
        this.actor.set_position(0, 0);
        this.actor.set_size(global.stage.width, global.stage.height);

        const layout = Main.layoutManager;
        const area = layout.getWorkAreaForMonitor(layout.primaryIndex);
        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        const gap = SCREEN_GAP * scale;
        const width = Math.min(DRAWER_WIDTH * scale, area.width - 2 * gap);
        const height = area.height - 2 * gap;

        this._card.set_position(
            Math.round(area.x + area.width - width - gap),
            Math.round(area.y + gap));
        this._card.set_size(Math.round(width), Math.round(height));
    }
}
