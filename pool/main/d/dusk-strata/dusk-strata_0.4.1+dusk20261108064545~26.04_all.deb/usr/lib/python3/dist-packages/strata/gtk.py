"""GTK 4 / libadwaita and GTK 3 colour overrides from a Scheme.

The generated CSS lives in ~/.config/strata/ and is pulled into the user's
gtk.css with a single @import between marker comments, so anything the user
already has in gtk.css is kept.
"""
from __future__ import annotations

import os
from pathlib import Path

from .scheme import Scheme

CONFIG = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
BEGIN = "/* >>> strata >>> */"
END = "/* <<< strata <<< */"

# GNOME / libadwaita stock values these overrides are derived from
LIGHT = {"window": "#fafafb", "view": "#ffffff", "headerbar": "#ffffff", "sidebar": "#ebebed",
         "card": "#ffffff", "popover": "#ffffff", "dialog": "#fafafb"}
DARK = {"window": "#222226", "view": "#1d1d20", "headerbar": "#2e2e32", "sidebar": "#2e2e32",
        "card": "#ffffff0f", "popover": "#36363a", "dialog": "#36363a"}


def _roles(s: Scheme, tint_surfaces: bool) -> tuple[dict, dict]:
    accent_bg = s.role("#3584e4")
    common = {
        "accent-bg-color": accent_bg, "accent-fg-color": "#ffffff",
        "destructive-bg-color": s.semantic("#e01b24"), "success-bg-color": s.semantic("#2ec27e"),
        "warning-bg-color": s.semantic("#e5a50a"), "error-bg-color": s.semantic("#e01b24"),
    }
    light = {**common, "accent-color": s.role("#1c71d8"), "destructive-color": s.semantic("#c01c28"),
             "success-color": s.semantic("#1b8553"), "warning-color": s.semantic("#9c6e03"), "error-color": s.semantic("#c01c28")}
    dark = {**common, "accent-color": s.role("#78aeed"), "destructive-color": s.semantic("#ff7b63"),
            "success-color": s.semantic("#78e9ab"), "warning-color": s.semantic("#ffc252"), "error-color": s.semantic("#ff7b63")}
    if tint_surfaces:
        for k, v in LIGHT.items():
            light[f"{k}-bg-color"] = s.role(v)
        for k, v in DARK.items():
            dark[f"{k}-bg-color"] = s.role(v) if len(v) == 7 else v
    return light, dark


def gtk4_css(s: Scheme, tint_surfaces: bool = True) -> str:
    light, dark = _roles(s, tint_surfaces)
    out = [f"/* strata: seed {s.palette.seed.hex}, scheme {s.name}. Generated, do not edit. */",
           ":root {"]
    out += [f"  --{k}: {v};" for k, v in light.items()]
    out += ["}", "@media (prefers-color-scheme: dark) {", "  :root {"]
    out += [f"    --{k}: {v};" for k, v in dark.items()]
    out += ["  }", "}", "/* libadwaita < 1.6 named colours */"]
    out += [f"@define-color {k.replace('-', '_')} {v};" for k, v in light.items()]
    return "\n".join(out) + "\n"


def _gtk3_colour(v: str) -> str:
    """GTK 3's CSS parser has no #rrggbbaa; write those as rgba()."""
    if len(v) == 9 and v.startswith("#"):
        r, g, b, a = (int(v[i:i + 2], 16) for i in (1, 3, 5, 7))
        return f"rgba({r},{g},{b},{round(a / 255, 3)})"
    return v


def gtk3_css(s: Scheme, dark_mode: bool, tint_surfaces: bool = True) -> str:
    light, dark = _roles(s, tint_surfaces)
    roles = {k: _gtk3_colour(v) for k, v in (dark if dark_mode else light).items()}
    out = [f"/* strata (gtk3 / adw-gtk3): seed {s.palette.seed.hex}. Generated, do not edit. */"]
    out += [f"@define-color {k.replace('-', '_')} {v};" for k, v in roles.items()]
    out.append(f"@define-color theme_selected_bg_color {roles['accent-bg-color']};")
    return "\n".join(out) + "\n"


def _inject(gtk_css: Path, import_path: Path) -> None:
    gtk_css.parent.mkdir(parents=True, exist_ok=True)
    text = gtk_css.read_text() if gtk_css.exists() else ""
    block = f'{BEGIN}\n@import url("file://{import_path}");\n{END}\n'
    if BEGIN in text and END in text:
        pre, rest = text.split(BEGIN, 1)
        post = rest.split(END, 1)[1].lstrip("\n")
        text = pre + block + post
    else:
        text = block + text  # @import must come first
    gtk_css.write_text(text)


def remove() -> None:
    for v in ("gtk-4.0", "gtk-3.0"):
        p = CONFIG / v / "gtk.css"
        if p.exists():
            t = p.read_text()
            if BEGIN in t and END in t:
                pre, rest = t.split(BEGIN, 1)
                p.write_text(pre + rest.split(END, 1)[1].lstrip("\n"))


def apply(s: Scheme, dark_mode: bool, tint_surfaces: bool = True) -> list[Path]:
    d = CONFIG / "strata"
    d.mkdir(parents=True, exist_ok=True)
    g4, g3 = d / "gtk4.css", d / "gtk3.css"
    g4.write_text(gtk4_css(s, tint_surfaces))
    g3.write_text(gtk3_css(s, dark_mode, tint_surfaces))
    _inject(CONFIG / "gtk-4.0" / "gtk.css", g4)
    _inject(CONFIG / "gtk-3.0" / "gtk.css", g3)
    return [g4, g3]
