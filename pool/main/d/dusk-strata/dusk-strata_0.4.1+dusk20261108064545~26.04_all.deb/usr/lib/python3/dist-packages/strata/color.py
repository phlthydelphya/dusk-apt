"""sRGB <-> OKLab / OKLCH, gamut mapping and hex helpers.

Kept free of dependencies and written to match web/strata.js line for line,
so the preview page and the engine produce the same colours.
"""
from __future__ import annotations

import math
import re

__all__ = [
    "srgb_to_oklab", "oklab_to_srgb", "oklch_to_srgb_clamped", "to_oklch",
    "parse_color", "fmt_hex", "hue_dist", "hue_diff", "wrap",
]


def _lin(c: float) -> float:
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def _gam(c: float) -> float:
    return 12.92 * c if c <= 0.0031308 else 1.055 * (c ** (1 / 2.4)) - 0.055


def _cbrt(x: float) -> float:
    return math.copysign(abs(x) ** (1.0 / 3.0), x)


def srgb_to_oklab(r: float, g: float, b: float) -> tuple[float, float, float]:
    """r, g, b in 0..1."""
    r, g, b = _lin(r), _lin(g), _lin(b)
    l = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b
    m = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b
    s = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b
    l, m, s = _cbrt(l), _cbrt(m), _cbrt(s)
    return (
        0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
        1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
        0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s,
    )


def oklab_to_linear(L: float, a: float, b: float) -> tuple[float, float, float]:
    l = (L + 0.3963377774 * a + 0.2158037573 * b) ** 3
    m = (L - 0.1055613458 * a - 0.0638541728 * b) ** 3
    s = (L - 0.0894841775 * a - 1.2914855480 * b) ** 3
    return (
        4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
        -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
        -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s,
    )


def oklab_to_srgb(L: float, a: float, b: float) -> tuple[float, float, float]:
    return tuple(_gam(c) for c in oklab_to_linear(L, a, b))  # type: ignore[return-value]


def to_oklch(r: float, g: float, b: float) -> tuple[float, float, float]:
    L, a, bb = srgb_to_oklab(r, g, b)
    C = math.hypot(a, bb)
    h = math.degrees(math.atan2(bb, a)) % 360.0
    return L, C, h


def _in_gamut(rgb) -> bool:
    return all(-0.0001 <= c <= 1.0001 for c in rgb)


def oklch_to_srgb_clamped(L: float, C: float, h: float) -> tuple[float, float, float]:
    """OKLCH -> sRGB, reducing chroma (keeping L and h) until it fits."""
    L = min(1.0, max(0.0, L))
    hr = math.radians(h)
    ca, sa = math.cos(hr), math.sin(hr)
    lin = oklab_to_linear(L, C * ca, C * sa)
    if not _in_gamut(lin):
        lo, hi = 0.0, C
        for _ in range(18):
            mid = (lo + hi) / 2
            if _in_gamut(oklab_to_linear(L, mid * ca, mid * sa)):
                lo = mid
            else:
                hi = mid
        lin = oklab_to_linear(L, lo * ca, lo * sa)
    return tuple(min(1.0, max(0.0, _gam(min(1.0, max(0.0, c))))) for c in lin)  # type: ignore[return-value]


def _byte(x: float) -> int:
    return int(math.floor(min(1.0, max(0.0, x)) * 255 + 0.5))


def fmt_hex(rgb, alpha: float | None = None) -> str:
    s = "#" + "".join(f"{_byte(c):02x}" for c in rgb)
    if alpha is not None and alpha < 1:
        s += f"{_byte(alpha):02x}"
    return s


_RGB_FN = re.compile(r"rgba?\(\s*([^)]*)\)", re.I)


# CSS named colours (CSS Color 4, all 148), for SVGs that paint with them
CSS_NAMES = {
    "aliceblue": "#f0f8ff", "antiquewhite": "#faebd7", "aqua": "#00ffff",
    "aquamarine": "#7fffd4", "azure": "#f0ffff", "beige": "#f5f5dc", "bisque": "#ffe4c4",
    "black": "#000000", "blanchedalmond": "#ffebcd", "blue": "#0000ff",
    "blueviolet": "#8a2be2", "brown": "#a52a2a", "burlywood": "#deb887",
    "cadetblue": "#5f9ea0", "chartreuse": "#7fff00", "chocolate": "#d2691e",
    "coral": "#ff7f50", "cornflowerblue": "#6495ed", "cornsilk": "#fff8dc",
    "crimson": "#dc143c", "cyan": "#00ffff", "darkblue": "#00008b", "darkcyan": "#008b8b",
    "darkgoldenrod": "#b8860b", "darkgray": "#a9a9a9", "darkgreen": "#006400",
    "darkgrey": "#a9a9a9", "darkkhaki": "#bdb76b", "darkmagenta": "#8b008b",
    "darkolivegreen": "#556b2f", "darkorange": "#ff8c00", "darkorchid": "#9932cc",
    "darkred": "#8b0000", "darksalmon": "#e9967a", "darkseagreen": "#8fbc8f",
    "darkslateblue": "#483d8b", "darkslategray": "#2f4f4f", "darkslategrey": "#2f4f4f",
    "darkturquoise": "#00ced1", "darkviolet": "#9400d3", "deeppink": "#ff1493",
    "deepskyblue": "#00bfff", "dimgray": "#696969", "dimgrey": "#696969",
    "dodgerblue": "#1e90ff", "firebrick": "#b22222", "floralwhite": "#fffaf0",
    "forestgreen": "#228b22", "fuchsia": "#ff00ff", "gainsboro": "#dcdcdc",
    "ghostwhite": "#f8f8ff", "gold": "#ffd700", "goldenrod": "#daa520", "gray": "#808080",
    "green": "#008000", "greenyellow": "#adff2f", "grey": "#808080", "honeydew": "#f0fff0",
    "hotpink": "#ff69b4", "indianred": "#cd5c5c", "indigo": "#4b0082", "ivory": "#fffff0",
    "khaki": "#f0e68c", "lavender": "#e6e6fa", "lavenderblush": "#fff0f5",
    "lawngreen": "#7cfc00", "lemonchiffon": "#fffacd", "lightblue": "#add8e6",
    "lightcoral": "#f08080", "lightcyan": "#e0ffff", "lightgoldenrodyellow": "#fafad2",
    "lightgray": "#d3d3d3", "lightgreen": "#90ee90", "lightgrey": "#d3d3d3",
    "lightpink": "#ffb6c1", "lightsalmon": "#ffa07a", "lightseagreen": "#20b2aa",
    "lightskyblue": "#87cefa", "lightslategray": "#778899", "lightslategrey": "#778899",
    "lightsteelblue": "#b0c4de", "lightyellow": "#ffffe0", "lime": "#00ff00",
    "limegreen": "#32cd32", "linen": "#faf0e6", "magenta": "#ff00ff", "maroon": "#800000",
    "mediumaquamarine": "#66cdaa", "mediumblue": "#0000cd", "mediumorchid": "#ba55d3",
    "mediumpurple": "#9370db", "mediumseagreen": "#3cb371", "mediumslateblue": "#7b68ee",
    "mediumspringgreen": "#00fa9a", "mediumturquoise": "#48d1cc", "mediumvioletred": "#c71585",
    "midnightblue": "#191970", "mintcream": "#f5fffa", "mistyrose": "#ffe4e1",
    "moccasin": "#ffe4b5", "navajowhite": "#ffdead", "navy": "#000080", "oldlace": "#fdf5e6",
    "olive": "#808000", "olivedrab": "#6b8e23", "orange": "#ffa500", "orangered": "#ff4500",
    "orchid": "#da70d6", "palegoldenrod": "#eee8aa", "palegreen": "#98fb98",
    "paleturquoise": "#afeeee", "palevioletred": "#db7093", "papayawhip": "#ffefd5",
    "peachpuff": "#ffdab9", "peru": "#cd853f", "pink": "#ffc0cb", "plum": "#dda0dd",
    "powderblue": "#b0e0e6", "purple": "#800080", "rebeccapurple": "#663399", "red": "#ff0000",
    "rosybrown": "#bc8f8f", "royalblue": "#4169e1", "saddlebrown": "#8b4513",
    "salmon": "#fa8072", "sandybrown": "#f4a460", "seagreen": "#2e8b57", "seashell": "#fff5ee",
    "sienna": "#a0522d", "silver": "#c0c0c0", "skyblue": "#87ceeb", "slateblue": "#6a5acd",
    "slategray": "#708090", "slategrey": "#708090", "snow": "#fffafa",
    "springgreen": "#00ff7f", "steelblue": "#4682b4", "tan": "#d2b48c", "teal": "#008080",
    "thistle": "#d8bfd8", "tomato": "#ff6347", "turquoise": "#40e0d0", "violet": "#ee82ee",
    "wheat": "#f5deb3", "white": "#ffffff", "whitesmoke": "#f5f5f5", "yellow": "#ffff00",
    "yellowgreen": "#9acd32",
}
_CSS_NAMES_RE = "|".join(sorted(CSS_NAMES, key=len, reverse=True))


def parse_color(text: str):
    """Return ((r,g,b) 0..1, alpha) or None. Handles #rgb, #rgba, #rrggbb, #rrggbbaa, rgb(), rgba()
    and the CSS named colours."""
    t = text.strip()
    if t.lower() in CSS_NAMES:
        t = CSS_NAMES[t.lower()]
    if t.startswith("#"):
        h = t[1:]
        if len(h) in (3, 4):
            h = "".join(ch * 2 for ch in h)
        if len(h) not in (6, 8) or not re.fullmatch(r"[0-9a-fA-F]+", h):
            return None
        rgb = tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
        a = int(h[6:8], 16) / 255 if len(h) == 8 else 1.0
        return rgb, a
    m = _RGB_FN.fullmatch(t)
    if m:
        parts = [p.strip() for p in re.split(r"[,\s/]+", m.group(1)) if p.strip()]
        if len(parts) < 3:
            return None
        try:
            vals = []
            for p in parts[:3]:
                vals.append(float(p[:-1]) / 100 if p.endswith("%") else float(p) / 255)
            a = 1.0
            if len(parts) > 3:
                p = parts[3]
                a = float(p[:-1]) / 100 if p.endswith("%") else float(p)
        except ValueError:
            return None
        return tuple(vals), a
    return None


def wrap(h: float) -> float:
    return h % 360.0


def hue_diff(frm: float, to: float) -> float:
    """Signed shortest rotation from `frm` to `to`, in (-180, 180]."""
    d = (to - frm) % 360.0
    return d - 360.0 if d > 180.0 else d


def hue_dist(a: float, b: float) -> float:
    return abs(hue_diff(a, b))
