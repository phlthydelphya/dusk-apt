"""Write a freedesktop icon theme from the templates, recoloured by a Scheme,
and pull every other icon the desktop uses into the same slab look."""
from __future__ import annotations

import configparser
import fnmatch
import gzip
import json
import os
import re
import shutil
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path

from . import coverage
from .aliases import ALIASES
from .scheme import Scheme
from .slab import slab, monogram
from .glyph import Glyphs, glyph, app_hue

TEMPLATES = Path(__file__).parent / "templates"
CONTEXTS = {"apps": "Applications", "places": "Places", "devices": "Devices", "mimetypes": "MimeTypes"}

HOME = Path.home()
XDG_DATA_HOME = Path(os.environ.get("XDG_DATA_HOME", HOME / ".local/share"))
USER_APPS = XDG_DATA_HOME / "applications"
OVERRIDE_KEY = "X-Strata-Override"

HICOLOR = [
    Path("/usr/share/icons/hicolor"), Path("/usr/local/share/icons/hicolor"),
    Path("/var/lib/flatpak/exports/share/icons/hicolor"), XDG_DATA_HOME / "flatpak/exports/share/icons/hicolor",
    XDG_DATA_HOME / "icons/hicolor", HOME / ".icons/hicolor",
]


def _theme_roots(name: str) -> list[Path]:
    return [p for p in (XDG_DATA_HOME / "icons" / name, HOME / ".icons" / name, Path("/usr/share/icons") / name)
            if p.is_dir()]


SNAP_ICONS = Path("/var/lib/snapd/desktop/icons")
APP_DIRS = [
    Path("/usr/share/applications"), Path("/usr/local/share/applications"),
    Path("/var/lib/flatpak/exports/share/applications"), XDG_DATA_HOME / "flatpak/exports/share/applications",
    Path("/var/lib/snapd/desktop/applications"), USER_APPS,
]

# Logos. Recoloured too unless --keep-brands: then the artwork keeps its colours
# but still sits on a wallpaper-coloured slab.
BRANDS = [
    "firefox*", "org.mozilla.*", "thunderbird*", "google-chrome*", "chromium*", "com.google.*", "brave*", "com.brave.*",
    "microsoft-*", "com.microsoft.*", "code", "code-*", "vscodium*", "com.visualstudio.*", "com.vscodium.*",
    "spotify*", "com.spotify.*", "steam*", "com.valvesoftware.*", "discord*", "com.discordapp.*", "slack*",
    "com.slack.*", "telegram*", "org.telegram.*", "signal*", "org.signal.*", "zoom*", "us.zoom.*", "obs*",
    "com.obsproject.*", "gimp*", "org.gimp.*", "inkscape*", "org.inkscape.*", "blender*", "org.blender.*",
    "libreoffice*", "org.libreoffice.*", "ubuntu-*", "distributor-logo*", "start-here*", "vlc*", "org.videolan.*",
    "1password*", "bitwarden*", "com.bitwarden.*", "proton*", "me.proton.*", "dropbox*", "com.dropbox.*",
    "nvidia*", "jetbrains-*", "com.jetbrains.*", "android-studio*", "docker*",
]

INDEX_DIRS = [
    ("scalable/apps", "Applications"), ("scalable/places", "Places"), ("scalable/devices", "Devices"),
    ("scalable/mimetypes", "MimeTypes"), ("symbolic/apps", "Applications"),
    ("symbolic/status", "Status"),
]

_HEX = re.compile(r"#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b")


def _coloured(svg: str) -> bool:
    """True when an SVG paints in a hue, not only in greys."""
    for m in _HEX.finditer(svg):
        h = m.group(1)
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
        if max(r, g, b) - min(r, g, b) > 0x30:
            return True
    return False


def _plain_status(out: Path, inherits: list[str]) -> int:
    """Symbolic status icons must be one flat colour, so the shell can tint
    them like the rest of the panel. Some inherited themes paint theirs
    (Yaru's charging and plugged-in batteries are green): shadow each of
    those with Adwaita's plain glyph of the same name. The first inherited
    theme to have a name decides, as in the icon lookup."""
    adwaita = [r / "symbolic" / "status" for r in _theme_roots("Adwaita")]
    seen: set[str] = set()
    count = 0
    for t in inherits:
        if t in ("Adwaita", "hicolor"):
            continue
        for root in _theme_roots(t):
            for f in sorted(root.glob("**/status/*-symbolic.svg")):
                if f.name in seen:
                    continue
                seen.add(f.name)
                try:
                    coloured = _coloured(f.read_text(errors="ignore"))
                except OSError:
                    continue
                # Adwaita has no full "charging" battery: its "charged" one stands in
                names = dict.fromkeys([f.name, f.name.replace("-100-charging-", "-100-charged-")])
                plain = next((d / n for n in names for d in adwaita if (d / n).is_file()), None)
                if coloured and plain:
                    out.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(plain, out / f.name)
                    count += 1
    return count


@dataclass
class BuildReport:
    templates: int = 0
    aliases: int = 0
    slabbed: int = 0
    glyphs: int = 0
    routed: int = 0
    overrides: int = 0
    missing: list[str] = field(default_factory=list)
    out: str = ""

    def to_dict(self) -> dict:
        return self.__dict__.copy()


def is_brand(name: str, extra: list[str] | None = None) -> bool:
    n = name.lower()
    return any(fnmatch.fnmatch(n, pat.lower()) for pat in BRANDS + (extra or []))


def _index_theme(name: str, scheme: Scheme, inherits: list[str]) -> str:
    s = scheme.summary()
    lines = [
        "[Icon Theme]", f"Name={name}",
        f"Comment=Wallpaper-seeded icons (seed {s['seed']}, {s['scheme']}) generated by strata",
        "Inherits=" + ",".join(dict.fromkeys([*inherits, "Adwaita", "hicolor"])),
        "Example=folder", "Directories=" + ",".join(d for d, _ in INDEX_DIRS), "",
    ]
    for d, ctx in INDEX_DIRS:
        sym = d.startswith("symbolic")
        lines += [f"[{d}]", f"Size={16 if sym else 128}", "MinSize=8", "MaxSize=512",
                  f"Context={ctx}", "Type=Scalable", ""]
    return "\n".join(lines)


# ---------------------------------------------------------------- sources
PIXMAPS = [Path("/usr/share/pixmaps"), XDG_DATA_HOME / "pixmaps", XDG_DATA_HOME / "icons", HOME / ".icons"]
OTHER_CTX = ("devices", "places", "categories", "status", "actions", "mimetypes", "emblems", "preferences", "panel")


def _size_rank(name: str) -> int:
    """scalable first, then the largest bitmap size."""
    if name.startswith("scalable"):
        return 100000
    m = re.match(r"(\d+)(?:x\d+)?(?:@(\d)x)?$", name)
    return int(m.group(1)) * int(m.group(2) or 1) if m else -1


def _variants(name: str) -> list[str]:
    out = [name, name.lower()]
    base = re.sub(r"[-_.](default|stable|bin|desktop|beta|esr|appimage|app|launcher|gtk|qt)$", "", name, flags=re.I)
    out += [base, base.lower()]
    if "." in name:
        last = name.rsplit(".", 1)[1]
        out += [last, last.lower()]
    return list(dict.fromkeys(v for v in out if v))


class Sources:
    """Finds the best artwork for an icon name: vector before raster, the
    fallback themes in order (Papirus first if installed), then the app's own,
    then /usr/share/pixmaps. Handles both size/context and context/size layouts
    and any size directory (16 to 1024, @2x)."""

    def __init__(self, themes: list[str]):
        self.themes = [r for t in themes for r in _theme_roots(t)]
        self.hicolor = [h for h in HICOLOR if h.is_dir()]
        self._dirs: dict[tuple, list[Path]] = {}

    def dirs(self, root: Path, ctx: str) -> list[Path]:
        key = (root, ctx)
        if key not in self._dirs:
            found = []
            try:
                for d in root.iterdir():
                    if (d / ctx).is_dir():
                        found.append((_size_rank(d.name), d / ctx))
                if (root / ctx).is_dir():
                    for d in (root / ctx).iterdir():
                        if d.is_dir():
                            found.append((_size_rank(d.name), d))
            except OSError:
                pass
            self._dirs[key] = [d for r, d in sorted(found, key=lambda x: -x[0]) if r >= 0]
        return self._dirs[key]

    def _look(self, roots, ctx, name, exts):
        for root in roots:
            for d in self.dirs(root, ctx):
                for ext in exts:
                    p = d / f"{name}{ext}"
                    if p.is_file():
                        return p
        return None

    def find(self, name: str, ctx: str = "apps") -> Path | None:
        for roots in (self.themes, self.hicolor):
            p = self._look(roots, ctx, name, (".svg", ".svgz"))
            if p:
                return p
        for roots in (self.hicolor, self.themes):
            p = self._look(roots, ctx, name, (".png",))
            if p:
                return p
        if ctx == "apps":
            for d in PIXMAPS:
                for ext in (".svg", ".png"):
                    p = d / f"{name}{ext}"
                    if p.is_file():
                        return p
            if SNAP_ICONS.is_dir():
                hits = sorted(SNAP_ICONS.glob(f"{name}*.png"))
                if hits:
                    return hits[0]
        return None

    def find_any(self, name: str) -> Path | None:
        """For a launcher icon: the name, then near variants ('firefox-default' -> 'firefox',
        'com.example.Foo' -> 'foo'), then non-app contexts ('search', 'dialog-information')."""
        for cand in _variants(name):
            p = self.find(cand, "apps")
            if p:
                return p
        for ctx in OTHER_CTX:
            for roots in (self.themes, self.hicolor):
                p = self._look(roots, ctx, name, (".svg", ".svgz", ".png"))
                if p:
                    return p
        return None


def _read_art(p: Path) -> tuple[bytes, str] | None:
    try:
        raw = p.resolve().read_bytes()
    except OSError:
        return None
    if p.suffix == ".svgz":
        try:
            raw = gzip.decompress(raw)
        except (OSError, EOFError):
            return None
    if p.suffix in (".svg", ".svgz"):
        return raw, "svg"
    if p.suffix == ".png":
        return raw, "png"
    return None


# ---------------------------------------------------------------- apps on this machine
def _desktop_entries():
    """(desktop_file, icon_value) for every launcher, user files shadowing system ones."""
    seen: dict[str, tuple[Path, str, str]] = {}
    for d in APP_DIRS:
        if not d.is_dir():
            continue
        for f in d.rglob("*.desktop"):
            rel = str(f.relative_to(d)).replace("/", "-")
            cp = configparser.RawConfigParser(strict=False, interpolation=None)
            cp.optionxform = str
            try:
                cp.read(f, encoding="utf-8")
                icon = cp.get("Desktop Entry", "Icon", fallback="").strip()
                label = cp.get("Desktop Entry", "Name", fallback=f.stem).strip()
                over = cp.get("Desktop Entry", OVERRIDE_KEY, fallback="")
                hidden = any(cp.get("Desktop Entry", k, fallback="").strip().lower() == "true"
                             for k in ("NoDisplay", "Hidden"))
            except (configparser.Error, UnicodeDecodeError, OSError):
                continue
            if over:
                continue  # ours; the original is what counts
            if hidden:
                seen.pop(rel, None)  # a hidden copy shadows the system one
            elif icon:
                seen[rel] = (f, icon, label)
    return seen


def _icon_id(desktop_id: str) -> str:
    return "strata-" + re.sub(r"[^A-Za-z0-9._-]", "-", desktop_id.removesuffix(".desktop"))


def _write_override(orig: Path, desktop_id: str, icon_name: str) -> bool:
    """Copy a launcher whose Icon= is a file path into ~/.local/share/applications,
    pointing at a themed icon name instead. Never touches a user's own launcher."""
    dest = USER_APPS / desktop_id
    if dest.exists():
        try:
            if OVERRIDE_KEY not in dest.read_text(errors="replace"):
                return False
        except OSError:
            return False
    try:
        lines = orig.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeDecodeError):
        return False
    out, in_main = [], False
    for ln in lines:
        s = ln.strip()
        if s.startswith("["):
            if in_main:
                out.append(f"{OVERRIDE_KEY}={orig}")
            in_main = s == "[Desktop Entry]"
        if in_main and re.match(r"Icon\s*=", s):
            ln = f"Icon={icon_name}"
        out.append(ln)
    if in_main:
        out.append(f"{OVERRIDE_KEY}={orig}")
    USER_APPS.mkdir(parents=True, exist_ok=True)
    dest.write_text("\n".join(out) + "\n")
    return True


_SCHEME: Scheme | None = None


def _init_worker(scheme: Scheme) -> None:
    global _SCHEME
    _SCHEME = scheme


def _render(job) -> tuple[str | None, str | None]:
    art_path, mode, recolor, colour_path, icon = job
    art = _read_art(art_path)
    if art is None:
        return None, None
    info: dict = {}
    if mode == "glyph":
        colour = _read_art(colour_path) if colour_path else None
        try:
            svg = glyph(_SCHEME, art[0], app_hue(*colour) if colour else None, key=icon, info=info)
            if svg is None and colour:  # the glyph can't be inlined: the app's art on a pad
                svg = slab(_SCHEME, colour[0], colour[1], mode="app", recolor=recolor, key=icon, info=info)
            return svg, info.get("primary")
        except Exception:
            return None, None
    try:
        return slab(_SCHEME, art[0], art[1], mode=mode, recolor=recolor, key=icon, info=info), info.get("primary")
    except Exception:
        return None, None


def _gnome(name: str) -> str:
    """'blue3' -> '#3584e4'."""
    from .scheme import GNOME
    return GNOME[name[:-1]][int(name[-1]) - 1]


def badge_colours(scheme: Scheme, primaries: dict[str, str]) -> dict:
    """Notification badge colours per app icon name, in the slab grammar: the app's
    primary colour on top, a darker side under it, and readable text."""
    from .color import parse_color, to_oklch, oklch_to_srgb_clamped, fmt_hex

    def entry(hx: str) -> dict:
        L, C, h = to_oklch(*parse_color(hx)[0])
        L = min(max(L, 0.42), 0.78)  # keep badges legible and distinct from both panel themes
        top = fmt_hex(oklch_to_srgb_clamped(L, C, h))
        side = fmt_hex(oklch_to_srgb_clamped(L - 0.16, C * 0.95, h))
        hi = fmt_hex(oklch_to_srgb_clamped(min(1.0, L + 0.07), C, h))
        fg = "#ffffff" if L < 0.7 else fmt_hex(oklch_to_srgb_clamped(0.22, min(C, 0.06), h))
        return {"bg": top, "hi": hi, "side": side, "fg": fg}

    colours: list[dict] = [entry(scheme.remap("#3584e4"))]  # index 0: the accent, for unknown apps
    index: dict[str, int] = {}
    apps = {}
    for name, hx in sorted(primaries.items()):
        if hx not in index:
            index[hx] = len(colours)
            colours.append(entry(hx))
        apps[name] = index[hx]
    return {"version": 2, "seed": scheme.palette.seed.hex, "colours": colours, "apps": apps}


def remove_overrides() -> int:
    n = 0
    if USER_APPS.is_dir():
        for f in USER_APPS.glob("*.desktop"):
            try:
                if OVERRIDE_KEY + "=" in f.read_text(errors="replace"):
                    f.unlink()
                    n += 1
            except OSError:
                pass
    return n


# ---------------------------------------------------------------- build
def build(scheme: Scheme, dest_root: Path | None = None, name: str = "Strata", **kw) -> BuildReport:
    """Build under an exclusive lock, so two builders (the watcher, a login hook, a
    package trigger) never write into or swap the same theme directory at once."""
    import fcntl
    dest_root = dest_root or (XDG_DATA_HOME / "icons")
    dest_root.mkdir(parents=True, exist_ok=True)
    with open(dest_root / f".{name}.lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        for stale in dest_root.glob(f".{name}.building*"):
            shutil.rmtree(stale, ignore_errors=True)  # left by a builder that was killed
        for stale in dest_root.glob(f".{name}.old*"):
            shutil.rmtree(stale, ignore_errors=True)
        return _build(scheme, dest_root, name, **kw)


def _build(scheme: Scheme, dest_root: Path | None = None, name: str = "Strata", *,
          third_party: bool = True, keep: list[str] | None = None, inherits: list[str] | None = None,
          sources: list[str] | None = None, keep_brands: bool = False, overrides: bool = True,
          slab_all: bool = True, glyphs: bool = False, glyph_themes: list[str] | None = None,
          **_ignored) -> BuildReport:
    dest_root = dest_root or (XDG_DATA_HOME / "icons")
    dest_root.mkdir(parents=True, exist_ok=True)
    final = dest_root / name
    tmp = dest_root / f".{name}.building-{os.getpid()}"
    if tmp.exists():
        shutil.rmtree(tmp)
    rep = BuildReport(out=str(final))
    inherits = [i for i in (inherits or []) if i and i != name]
    have: dict[str, set[str]] = {c: set() for c in CONTEXTS}
    try:
        drawn = json.loads((TEMPLATES / "primaries.json").read_text())
    except (OSError, ValueError):
        drawn = {}
    primaries: dict[str, str] = {k: scheme.remap(_gnome(v)) for k, v in drawn.items()}

    # 1. the drawn set
    for ctx in CONTEXTS:
        out = tmp / "scalable" / ctx
        out.mkdir(parents=True, exist_ok=True)
        for f in sorted((TEMPLATES / ctx).glob("*.svg")):
            (out / f.name).write_text(scheme.recolor_svg(f.read_text()))
            have[ctx].add(f.stem)
            rep.templates += 1
    sym = tmp / "symbolic" / "apps"
    sym.mkdir(parents=True, exist_ok=True)
    for f in (TEMPLATES / "symbolic").glob("*.svg"):
        shutil.copyfile(f, sym / f.name)
    _plain_status(tmp / "symbolic" / "status", inherits)

    def link(ctx: str, alias: str, target: str) -> None:
        p = tmp / "scalable" / ctx / f"{alias}.svg"
        if alias not in have[ctx] and not p.exists():
            p.symlink_to(f"{target}.svg")
            have[ctx].add(alias)

    for target, names in ALIASES.items():
        ctx, stem = target.split("/")
        for alias in names:
            before = len(have[ctx])
            link(ctx, alias, stem)
            rep.aliases += len(have[ctx]) - before
            if ctx == "apps" and stem in primaries:
                primaries.setdefault(alias, primaries[stem])

    if third_party:
        src = Sources(sources if sources is not None else ["Papirus", *inherits])
        fallback_names = {c: set() for c in CONTEXTS}
        for root in src.themes + src.hicolor:
            for c in CONTEXTS:
                fallback_names[c] |= coverage.theme_names(root, c)

        jobs: list[tuple] = []          # (ctx, icon, art_path, mode, recolor, colour_path)
        first: dict[tuple, tuple] = {}  # (resolved art, mode, recolor) -> (ctx, icon) already queued
        links: list[tuple] = []         # (ctx, icon, ctx_target, icon_target)

        def make(ctx: str, icon: str, art_path: Path | None, mode: str) -> bool:
            if art_path is None or icon in have[ctx]:
                return art_path is not None
            user_keep = any(fnmatch.fnmatch(icon.lower(), k.lower()) for k in (keep or []))
            recolor = not (user_keep or (keep_brands and is_brand(icon)))
            try:
                k = (str(art_path.resolve()), mode, recolor)
            except OSError:
                return False
            have[ctx].add(icon)
            if k in first:
                links.append((ctx, icon, *first[k]))
            else:
                first[k] = (ctx, icon)
                jobs.append((ctx, icon, art_path, mode, recolor, None))
            return True

        # glyph mode: the app's one-colour symbol raised on a pad in its own colour
        finder = (Glyphs(src.hicolor, [r for t in (glyph_themes or []) for r in _theme_roots(t)])
                  if glyphs else None)

        def make_glyph(icon: str, label: str) -> bool:
            if finder is None or icon in have["apps"]:
                return False
            if any(fnmatch.fnmatch(icon.lower(), k.lower()) for k in (keep or [])) or (keep_brands and is_brand(icon)):
                return False
            gp = finder.find(_variants(icon), label)
            if gp is None:
                return False
            colour = src.find_any(icon)
            try:
                k = (str(gp.resolve()), "glyph", str(colour.resolve()) if colour else "")
            except OSError:
                return False
            have["apps"].add(icon)
            if k in first:
                links.append(("apps", icon, *first[k]))
            else:
                first[k] = ("apps", icon)
                jobs.append(("apps", icon, gp, "glyph", True, colour))
            rep.glyphs += 1
            return True

        # 2. every launcher on this machine
        for desktop_id, (path, icon, label) in sorted(_desktop_entries().items()):
            if icon.startswith("/"):
                p = Path(icon)
                iid = _icon_id(desktop_id)
                if iid not in have["apps"] and p.is_file() and p.suffix in (".svg", ".svgz", ".png"):
                    if make("apps", iid, p, "app") and overrides and _write_override(path, desktop_id, iid):
                        rep.overrides += 1
                continue
            stem = icon.removesuffix(".svg").removesuffix(".png")
            if stem.endswith("-symbolic") or any(stem in have[c] for c in have):
                continue  # symbolic icons are recoloured by GTK; others already resolve in another context
            if make_glyph(stem, label):
                continue
            if not make("apps", stem, src.find_any(stem), "app"):
                info: dict = {}
                (tmp / "scalable" / "apps" / f"{stem}.svg").write_text(monogram(scheme, label, stem, info))
                primaries[stem] = info["primary"]
                have["apps"].add(stem)
                rep.missing.append(stem)

        # 3. every app icon the fallback themes ship, so apps installed later are already covered
        if slab_all:
            for icon in sorted(fallback_names["apps"] - have["apps"]):
                make("apps", icon, src.find(icon, "apps"), "app")

        # 4. places and file types route to the drawn set; devices route or get slabbed
        for icon in sorted(fallback_names["places"] - have["places"]):
            t = coverage.place_for(icon)
            if t:
                link("places", icon, t)
                rep.routed += 1
        mimes = (fallback_names["mimetypes"] | coverage.system_mime_icons()) - have["mimetypes"]
        for icon in sorted(mimes):
            t = coverage.mime_for(icon)
            if t:
                link("mimetypes", icon, t)
                rep.routed += 1
        for icon in sorted(fallback_names["devices"] - have["devices"]):
            t = coverage.device_for(icon)
            if t:
                link("devices", icon, t)
                rep.routed += 1
            else:
                make("devices", icon, src.find(icon, "devices"), "free")

        # render the queued slabs in parallel, then point duplicates at them
        done: set[tuple] = set()
        workers = max(1, min(8, (os.cpu_count() or 2)))
        with ProcessPoolExecutor(workers, initializer=_init_worker, initargs=(scheme,)) as pool:
            for (ctx, icon), (svg, primary) in zip(((j[0], j[1]) for j in jobs),
                                        pool.map(_render, [j[2:] + (j[1],) for j in jobs], chunksize=32)):
                if svg:
                    (tmp / "scalable" / ctx / f"{icon}.svg").write_text(svg)
                    done.add((ctx, icon))
                    rep.slabbed += 1
                    if primary and ctx == "apps":
                        primaries[icon] = primary
                else:
                    have[ctx].discard(icon)
                    rep.missing.append(icon)
        for ctx, icon, tctx, ticon in links:
            if (tctx, ticon) in done:
                rel = f"{ticon}.svg" if tctx == ctx else f"../{tctx}/{ticon}.svg"
                (tmp / "scalable" / ctx / f"{icon}.svg").symlink_to(rel)
                rep.aliases += 1
                if ticon in primaries:
                    primaries[icon] = primaries[ticon]

    (tmp / "index.theme").write_text(_index_theme(name, scheme, inherits))
    (tmp / "strata-colors.json").write_text(json.dumps(badge_colours(scheme, primaries), separators=(",", ":")))
    (tmp / "strata.json").write_text(json.dumps({**scheme.summary(), "build": rep.to_dict()}, indent=2))

    old = dest_root / f".{name}.old-{os.getpid()}"
    if old.exists():
        shutil.rmtree(old)
    if final.exists():
        final.rename(old)
    tmp.rename(final)
    if old.exists():
        shutil.rmtree(old)
    return rep


def apps_signature() -> str:
    """Changes when launchers are installed or removed (for the watcher)."""
    parts = []
    for d in APP_DIRS:
        if d.is_dir():
            try:
                parts.append(f"{d}:{d.stat().st_mtime_ns}:{sum(1 for _ in d.glob('*.desktop'))}")
            except OSError:
                pass
    return "|".join(parts)
