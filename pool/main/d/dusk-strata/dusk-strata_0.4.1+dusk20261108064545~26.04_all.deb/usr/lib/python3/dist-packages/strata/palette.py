"""Wallpaper -> palette.

Pixels are binned by OKLCH hue (36 bins of 10 degrees). Each bin is scored by
how much of the picture it covers (with its two neighbours, so a gradient that
straddles a boundary still counts as one colour), how colourful it is, and how
close it sits to a usable mid lightness. Swatches are then picked greedily,
at least 24 degrees apart, and the best one becomes the seed.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Iterable

from .color import srgb_to_oklab, oklch_to_srgb_clamped, fmt_hex, hue_dist

BINS = 36
MIN_CHROMA = 0.035
MIN_SHARE = 0.002
SWATCH_GAP = 24.0
MAX_SWATCHES = 5
THUMB = 96


@dataclass
class Swatch:
    L: float
    C: float
    h: float
    share: float
    score: float
    hex: str


@dataclass
class Palette:
    seed: Swatch
    swatches: list[Swatch] = field(default_factory=list)
    vibrancy: float = 1.0
    mean_lightness: float = 0.5
    achromatic: bool = False

    def to_dict(self) -> dict:
        return asdict(self)


def extract_pixels(pixels: Iterable[tuple[int, int, int]]) -> Palette:
    cnt = [0] * BINS
    sL = [0.0] * BINS
    sa = [0.0] * BINS
    sb = [0.0] * BINS
    total = 0
    sum_c = 0.0
    sum_l = 0.0
    na = nb = 0.0
    for r, g, b in pixels:
        L, a, bb = srgb_to_oklab(r / 255, g / 255, b / 255)
        C = math.hypot(a, bb)
        total += 1
        sum_c += C
        sum_l += L
        if C < MIN_CHROMA or L < 0.12 or L > 0.97:
            na += a
            nb += bb
            continue
        h = math.degrees(math.atan2(bb, a)) % 360.0
        i = int(h // 10) % BINS
        cnt[i] += 1
        sL[i] += L
        sa[i] += a
        sb[i] += bb

    if total == 0:
        return _fallback(0.5)

    cands: list[Swatch] = []
    for i in range(BINS):
        if cnt[i] == 0 or cnt[i] / total < MIN_SHARE:
            continue
        share = (cnt[(i - 1) % BINS] + cnt[i] + cnt[(i + 1) % BINS]) / total
        L = sL[i] / cnt[i]
        a = sa[i] / cnt[i]
        bb = sb[i] / cnt[i]
        C = math.hypot(a, bb)
        h = math.degrees(math.atan2(bb, a)) % 360.0
        score = math.sqrt(share) * (min(C, 0.16) / 0.16) * (1.0 - abs(L - 0.62) * 0.6)
        cands.append(Swatch(L, C, h, share, score, fmt_hex(oklch_to_srgb_clamped(L, C, h))))

    cands.sort(key=lambda s: -s.score)
    picked: list[Swatch] = []
    for s in cands:
        if all(hue_dist(s.h, p.h) >= SWATCH_GAP for p in picked):
            picked.append(s)
            if len(picked) == MAX_SWATCHES:
                break

    mean_c = sum_c / total
    mean_l = sum_l / total
    vib = min(1.15, max(0.35, mean_c / 0.075))

    if not picked:
        h = math.degrees(math.atan2(nb, na)) % 360.0 if (na or nb) else 255.0
        seed = Swatch(0.55, 0.02, h, 1.0, 0.0, fmt_hex(oklch_to_srgb_clamped(0.55, 0.02, h)))
        return Palette(seed, [seed], vib, mean_l, True)
    return Palette(picked[0], picked, vib, mean_l, False)


def _fallback(mean_l: float) -> Palette:
    seed = Swatch(0.6, 0.15, 255.0, 1.0, 1.0, "#3584e4")
    return Palette(seed, [seed], 1.0, mean_l, False)


def load_pixels(path: str | Path) -> list[tuple[int, int, int]]:
    from PIL import Image, UnidentifiedImageError  # lazily: the colour core has no hard dependency

    try:
        im = Image.open(path)
    except UnidentifiedImageError:
        # A format Pillow cannot read here, such as the JPEG XL day-cycle
        # wallpapers: decode it with GdkPixbuf's loaders, as GNOME does
        im = _pixbuf_image(path)
    with im:
        im = im.convert("RGBA")
        im.thumbnail((THUMB, THUMB), Image.Resampling.BOX)
        return [(r, g, b) for r, g, b, a in im.getdata() if a >= 128]


def _pixbuf_image(path: str | Path):
    import gi

    gi.require_version("GdkPixbuf", "2.0")
    from gi.repository import GdkPixbuf
    from PIL import Image

    pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(str(path), THUMB * 4, THUMB * 4, True)
    mode = "RGBA" if pb.get_has_alpha() else "RGB"
    return Image.frombytes(mode, (pb.get_width(), pb.get_height()), pb.get_pixels(), "raw", mode,
                           pb.get_rowstride())


def extract(path: str | Path) -> Palette:
    return extract_pixels(load_pixels(path))
