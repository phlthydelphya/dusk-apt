"""Map every other icon name a desktop asks for onto the drawn Strata set.

Places and file types are routed to the closest drawn icon by keyword, so a
folder or document always has the slab look. Devices fall back to slabbing
the best source artwork (see theme.py) when no rule matches.
"""
from __future__ import annotations

import re
from pathlib import Path

PLACE_RULES = [
    (r"home", "user-home"), (r"desktop", "user-desktop"), (r"download", "folder-download"),
    (r"music|sound|audio|podcast", "folder-music"), (r"picture|image|photo|camera|screenshot", "folder-pictures"),
    (r"video|movie|film|recording", "folder-videos"), (r"document|text|book|note", "folder-documents"),
    (r"template", "folder-templates"), (r"public|share", "folder-publicshare"),
    (r"remote|network|cloud|dropbox|nextcloud|owncloud|google-drive|onedrive|mega|sync|ftp|smb|nfs|globe|web",
     "folder-remote"),
    (r"trash.*full|full.*trash", "user-trash-full"), (r"trash", "user-trash"),
]

DEVICE_RULES = [
    (r"^drive-harddisk|^harddrive|ssd|nvme", "drive-harddisk"),
    (r"^drive-removable|^media-flash|^media-removable|^media-memory|usb|sd-?card|pendrive", "drive-removable-media"),
    (r"optical|cdrom|dvd|bluray|^media-cd", "media-optical"),
    (r"phone|smartphone|pda|tablet-android", "phone"),
    (r"printer|scanner|fax", "printer"),
    (r"^camera|webcam", "camera-photo"),
    (r"keyboard", "input-keyboard"),
    (r"mouse|touchpad|tablet|pointer|wacom", "input-mouse"),
    (r"headphone|headset|earbud", "audio-headphones"),
    (r"speaker|audio-card|soundcard|subwoofer", "audio-speakers"),
    (r"battery|ups|power", "battery"),
    (r"gaming|gamepad|joystick|controller", "input-gaming"),
    (r"^computer|display|monitor|laptop|desktop|video-display|tv", "computer"),
    (r"network|server|router|modem|wired|wireless|ethernet|nas", "network-server"),
]

MIME_RULES = [
    (r"^inode-directory|^folder", None),  # handled by places
    (r"pdf|postscript|djvu|xps", "application-pdf"),
    (r"^image-", "image-x-generic"), (r"^audio-", "audio-x-generic"), (r"^video-", "video-x-generic"),
    (r"^font-|x-font|truetype|opentype|woff", "font-x-generic"),
    (r"html|xhtml|x-mswinurl|internet-shortcut", "text-html"),
    (r"debian|x-deb|x-rpm|snap|flatpak|appimage|x-package|repository", "application-x-deb"),
    (r"zip|tar|compress|7z|rar|gzip|bzip|xz|zstd|lzma|lzip|lz4|cpio|archive|cd-image|disk-image|iso9660|cab|ace|arj",
     "package-x-generic"),
    (r"executable|sharedlib|x-object|msdownload|x-msi|portable-executable|x-ms-dos|x-elf|x-mach|x-desktop$",
     "application-x-executable"),
    (r"spreadsheet|excel|ms-excel|csv|calc|x-gnumeric|sheet|numbers|sqlite|x-sql|database", "x-office-spreadsheet"),
    (r"presentation|powerpoint|impress|keynote|slide", "x-office-presentation"),
    (r"opendocument\.text|msword|wordprocessing|rtf|abiword|epub|fictionbook|mobipocket|x-tex|latex|document|"
     r"office|writer|pages", "x-office-document"),
    (r"addon|extension|firmware|plugin|x-theme|x-gnome-shell", "application-x-addon"),
    (r"x-sh\b|shellscript|x-python|x-perl|x-ruby|x-php|x-lua|x-tcl|x-awk|x-script|x-powershell|x-bat", "text-x-script"),
    (r"json|xml|yaml|toml|javascript|typescript|ecmascript|x-c|x-java|x-rust|x-go|x-kotlin|x-swift|x-csharp|x-vala|"
     r"x-haskell|x-scala|x-dart|x-zig|x-nim|x-ocaml|x-elixir|x-erlang|x-clojure|x-lisp|x-scheme|x-fortran|"
     r"x-pascal|x-asm|x-makefile|x-cmake|x-meson|x-patch|x-diff|css|scss|sass|less|x-gettext|x-po|x-qml|"
     r"x-source|wasm|x-ipynb|x-r\b|x-matlab|x-julia|x-dockerfile|x-nix|x-svelte|x-vue|graphql|protobuf",
     "text-x-source"),
    (r"^text-|^message-|^application-x-trash|calendar|vcard|x-vcalendar|ics|x-log|plain|readme|license|"
     r"x-subrip|subtitle|markdown|x-ini|x-desktop", "text-x-generic"),
    (r"^application-|^x-|^multipart-|^model-|^chemical-|^unknown", "text-x-generic"),
]


def _match(rules, name: str):
    n = name.lower()
    for pat, target in rules:
        if re.search(pat, n):
            return target
    return "?"


def place_for(name: str) -> str | None:
    n = name.lower()
    if not (n.startswith(("folder", "user-", "inode-", "network-workgroup")) or "trash" in n):
        return None
    t = _match(PLACE_RULES, n)
    return "folder" if t == "?" else t


def device_for(name: str) -> str | None:
    t = _match(DEVICE_RULES, name)
    return None if t == "?" else t


def mime_for(name: str) -> str | None:
    t = _match(MIME_RULES, name)
    return None if t in ("?", None) else t


def system_mime_icons() -> set[str]:
    """Icon names for every MIME type shared-mime-info knows about."""
    names: set[str] = set()
    for f in (Path("/usr/share/mime/types"), Path.home() / ".local/share/mime/types"):
        try:
            for line in f.read_text().splitlines():
                line = line.strip()
                if "/" in line:
                    names.add(line.replace("/", "-"))
                    names.add(line.split("/")[0] + "-x-generic")
        except OSError:
            continue
    return names


def theme_names(root: Path, ctx: str) -> set[str]:
    """All icon names a theme ships in one context (any size)."""
    names: set[str] = set()
    if not root.is_dir():
        return names
    for d in root.iterdir():
        sub = d / ctx
        if sub.is_dir():
            for f in sub.iterdir():
                if f.suffix in (".svg", ".png", ".svgz") and not f.stem.endswith("-symbolic"):
                    names.add(f.stem)
    return names
