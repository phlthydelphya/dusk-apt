"""Palette -> colour remapper.

Icons are authored in the GNOME HIG palette. A Scheme moves every colour to the
wallpaper: it keeps OKLab lightness (so the light top / dark side contrast of
each slab survives), finds which colour family the hue belongs to, and moves
that family to a wallpaper-derived hue with a chroma scale.

Families: blue is the accent (becomes the seed), teal, purple and pink become
the secondary/tertiary companions, and red, orange, yellow, green keep their
meaning but lean toward the seed ("harmonised"). Greys get a faint seed tint.

Icon objects (recolor_svg, recolor_png) go further, one look per scheme, and
greys take a visible seed tint in all three. GTK roles (role, remap) keep the
targets above.
- harmony: the colour wheel folded around the seed. Each family keeps half its
  stock distance from blue, so the artwork stays within 90 degrees of the seed
  and red, green and yellow still differ.
- content: each family but blue takes the hue of its nearest wallpaper swatch,
  with chroma raised from the swatch's (OBJ_CONTENT_C), so the art is in the
  wallpaper's own colours.
- mono: one hue, as for GTK.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from .color import (parse_color, _CSS_NAMES_RE, to_oklch, oklch_to_srgb_clamped, fmt_hex,
                    hue_diff, hue_dist, wrap)
from .palette import Palette

# GNOME HIG palette, 1 (light) .. 5 (dark)
GNOME = {
    "blue":   ["#99c1f1", "#62a0ea", "#3584e4", "#1c71d8", "#1a5fb4"],
    "green":  ["#8ff0a4", "#57e389", "#33d17a", "#2ec27e", "#26a269"],
    "yellow": ["#f9f06b", "#f8e45c", "#f6d32d", "#f5c211", "#e5a50a"],
    "orange": ["#ffbe6f", "#ffa348", "#ff7800", "#e66100", "#c64600"],
    "red":    ["#f66151", "#ed333b", "#e01b24", "#c01c28", "#a51d2d"],
    "purple": ["#dc8add", "#c061cb", "#9141ac", "#813d9c", "#613583"],
    "brown":  ["#cdab8f", "#b5835a", "#986a44", "#865e3c", "#63452c"],
    "light":  ["#ffffff", "#f6f5f4", "#deddda", "#c0bfbc", "#9a9996"],
    "dark":   ["#77767b", "#5e5c64", "#3d3846", "#241f31", "#000000"],
}

# Family anchors (hue, chroma) measured from representative colours.
_ANCHOR_SRC = {
    "red": "#e01b24", "orange": "#ff7800", "yellow": "#f6d32d", "green": "#33d17a",
    "teal": "#2190a4", "blue": "#3584e4", "purple": "#9141ac", "pink": "#d56199",
}


def _lch(hexs: str):
    rgb, _ = parse_color(hexs)
    return to_oklch(*rgb)


ANCHORS = {k: _lch(v) for k, v in _ANCHOR_SRC.items()}  # name -> (L, C, h)
FAMILY_ORDER = list(_ANCHOR_SRC)

# GNOME Shell 47+ accent presets
ACCENTS = {
    "blue": "#3584e4", "teal": "#2190a4", "green": "#3a944a", "yellow": "#c88800",
    "orange": "#ed5b00", "red": "#e62d42", "pink": "#d56199", "purple": "#9141ac",
    "slate": "#6f8396",
}

SCHEMES = ("harmony", "content", "mono")
NEUTRAL_C = 0.025
OBJ_TINT = 0.09   # icon greys: seed chroma per unit of tint, at mid lightness
OBJ_TINT_FLOOR = 0.35  # share of that kept at the darkest and lightest greys
OBJ_FOLD = 0.5    # harmony objects: share of each family's hue distance from blue kept
OBJ_CONTENT_C = 1.6  # content objects: chroma over the swatch's own
OLIVE = 105.0


def harmonize(h: float, seed: float, limit: float = 20.0) -> float:
    d = hue_diff(h, seed)
    return wrap(h + max(-limit, min(limit, d * 0.5)))


@dataclass
class Target:
    hue: float
    factor: float


class Scheme:
    def __init__(self, palette: Palette, scheme: str = "harmony",
                 vibrancy: float | None = None, tint: float = 0.6):
        if scheme not in SCHEMES:
            raise ValueError(f"unknown scheme {scheme!r}; choose from {', '.join(SCHEMES)}")
        self.palette = palette
        self.name = scheme
        self.tint = tint
        seed = palette.seed
        S = seed.h
        v = palette.vibrancy if vibrancy is None else vibrancy
        self.vibrancy = v
        blueC = ANCHORS["blue"][1]
        fb = max(0.3, min(1.2, 0.5 * v + 0.5 * seed.C / blueC))
        if palette.achromatic:
            fb = 0.22
        self.seed_hue = S
        self.seed_chroma = seed.C

        t: dict[str, Target] = {}
        if scheme == "mono":
            for fam in FAMILY_ORDER:
                t[fam] = Target(S, fb if fam == "blue" else v * 0.9)
        else:
            t["blue"] = Target(S, fb)
            t["teal"] = Target(wrap(S - 30), v * 0.8)
            # Tertiary sits 60 degrees from the seed, on whichever side keeps it out of the
            # olive band (~105 deg), where mid-light colours turn muddy.
            sgn = 1 if hue_dist(wrap(S + 60), OLIVE) >= hue_dist(wrap(S - 60), OLIVE) else -1
            t["purple"] = Target(wrap(S + sgn * 60), v * 0.9)
            t["pink"] = Target(wrap(S + sgn * 100), v * 0.9)
            for fam in ("red", "orange", "yellow", "green"):
                t[fam] = Target(harmonize(ANCHORS[fam][2], S), v)
            if scheme == "content":
                others = palette.swatches[1:]
                for fam in ("teal", "purple", "pink", "red", "orange", "yellow", "green"):
                    best = None
                    for sw in others:
                        d = hue_dist(sw.h, t[fam].hue)
                        if d <= 40 and (best is None or d < best[0]):
                            best = (d, sw)
                    if best:
                        sw = best[1]
                        f = max(0.35, min(1.2, sw.C / ANCHORS[fam][1]))
                        t[fam] = Target(sw.h, f)
        self.targets = t
        # icon objects: the colour wheel folded around the seed (harmony) or the
        # nearest wallpaper swatch (content)
        o = dict(t)
        if scheme != "mono" and not palette.achromatic:
            for fam in FAMILY_ORDER:
                if fam == "blue":
                    continue
                if scheme == "harmony":
                    d = hue_diff(ANCHORS["blue"][2], ANCHORS[fam][2])
                    o[fam] = Target(wrap(S + d * OBJ_FOLD), v)
                else:
                    sw = min(palette.swatches, key=lambda x: hue_dist(x.h, ANCHORS[fam][2]))
                    o[fam] = Target(sw.h, max(0.5, min(1.2, OBJ_CONTENT_C * sw.C / ANCHORS[fam][1])))
        self.obj_targets = o

    def swatch_hue(self, h: float) -> float:
        """The hue of the wallpaper swatch nearest h (the seed's for a grey wallpaper)."""
        if self.palette.achromatic or not self.palette.swatches:
            return self.seed_hue
        return min(self.palette.swatches, key=lambda x: hue_dist(x.h, h)).h

    # ---- single colour ------------------------------------------------
    def family(self, h: float) -> str:
        best, bd = "blue", 999.0
        for fam in FAMILY_ORDER:
            d = hue_dist(h, ANCHORS[fam][2])
            if d < bd:
                best, bd = fam, d
        return best

    def remap_rgb(self, rgb, obj: bool = False):
        """obj: an icon's artwork, drawn in the wallpaper swatches (see the module doc)."""
        L, C, h = to_oklch(*rgb)
        if C < NEUTRAL_C:
            if L > 0.995 or L < 0.005:
                return tuple(rgb)
            w = max(0.0, 1.0 - abs(L - 0.55) * 1.3)
            sc = max(0.3, min(1.0, self.seed_chroma / 0.1))
            if obj:
                tc = self.tint * OBJ_TINT * sc * max(OBJ_TINT_FLOOR, w)
            else:
                tc = self.tint * 0.014 * sc * w
            return oklch_to_srgb_clamped(L, tc, self.seed_hue)
        fam = self.family(h)
        tg = (self.obj_targets if obj else self.targets)[fam]
        nh = wrap(h + hue_diff(ANCHORS[fam][2], tg.hue))
        return oklch_to_srgb_clamped(L, C * tg.factor, nh)

    def remap(self, text: str, obj: bool = False) -> str:
        p = parse_color(text)
        if p is None:
            return text
        rgb, a = p
        return fmt_hex(self.remap_rgb(rgb, obj), a if a < 1 else None)

    # ---- svg ----------------------------------------------------------
    _SVG_COLOR = re.compile(
        r"((?:fill|stroke|stop-color|flood-color|lighting-color|color)\s*[:=]\s*[\"']?\s*)"
        r"(#[0-9a-fA-F]{3,8}\b|rgba?\([^)]*\)|(?:" + _CSS_NAMES_RE + r")\b(?![-\w]))",
        re.I,
    )

    def recolor_svg(self, svg: str) -> str:
        cache: dict[str, str] = {}

        def sub(m: re.Match) -> str:
            c = m.group(2)
            if c not in cache:
                cache[c] = self.remap(c, obj=True)
            return m.group(1) + cache[c]

        return self._SVG_COLOR.sub(sub, svg)

    # ---- named roles for GTK / Shell ----------------------------------
    def role(self, gnome_hex: str) -> str:
        return self.remap(gnome_hex)

    def semantic(self, gnome_hex: str) -> str:
        """Status colours (destructive, success, warning) only lean 8 degrees toward the
        seed and keep stock chroma, so red still reads as danger on every wallpaper."""
        rgb, _ = parse_color(gnome_hex)
        L, C, h = to_oklch(*rgb)
        fam = self.family(h)
        nh = wrap(h + hue_diff(ANCHORS[fam][2], harmonize(ANCHORS[fam][2], self.seed_hue, 8.0)))
        return fmt_hex(oklch_to_srgb_clamped(L, C, nh))

    def accent_name(self) -> str:
        """Closest GNOME Shell accent preset to the remapped accent colour."""
        if self.palette.achromatic:
            return "slate"
        L, C, h = _lch(self.role("#3584e4"))
        best, bd = "blue", 1e9
        for name, hx in ACCENTS.items():
            l2, c2, h2 = _lch(hx)
            if name == "slate":
                d = (C - c2) ** 2 * 40 + (L - l2) ** 2
            else:
                d = (hue_dist(h, h2) / 180) ** 2 + (L - l2) ** 2 + (C - c2) ** 2 * 4
            if d < bd:
                best, bd = name, d
        return best

    def summary(self) -> dict:
        return {
            "scheme": self.name,
            "seed": self.palette.seed.hex,
            "vibrancy": round(self.vibrancy, 3),
            "accent": self.role("#3584e4"),
            "accent_preset": self.accent_name(),
            "swatches": [s.hex for s in self.palette.swatches],
            "ramps": {fam: [self.remap(c) for c in ramp] for fam, ramp in GNOME.items()},
        }
