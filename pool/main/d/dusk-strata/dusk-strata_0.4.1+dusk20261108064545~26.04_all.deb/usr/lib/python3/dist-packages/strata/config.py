"""Defaults from /etc/strata/strata.conf (the distro's) and ~/.config/strata/strata.conf
(the user's). Command-line flags beat the user file, which beats the system file.

    [strata]
    scheme = harmony
    source = Papirus
    inherit = Yaru
    wallpaper = /usr/share/backgrounds/my-distro-default.png   ; used by `generate --system`
    keep-brands = false
"""
from __future__ import annotations

import configparser
import os
from pathlib import Path

SYSTEM_CONF = Path(os.environ.get("STRATA_SYSTEM_CONF", "/etc/strata/strata.conf"))
USER_CONF = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "strata" / "strata.conf"

LISTS = {"source", "inherit", "keep"}
FLOATS = {"vibrancy", "tint"}
BOOLS = {"keep-brands", "installed-only", "no-desktop-overrides", "no-gtk", "flat-surfaces", "no-accent",
         "no-third-party"}
STRINGS = {"scheme", "name", "wallpaper", "dest"}


def load(paths=None) -> dict:
    out: dict = {}
    for p in paths or (SYSTEM_CONF, USER_CONF):
        cp = configparser.ConfigParser(inline_comment_prefixes=(";", "#"))
        try:
            if not cp.read(p, encoding="utf-8") or not cp.has_section("strata"):
                continue
        except configparser.Error as e:
            print(f"strata: ignoring {p}: {e}")
            continue
        sec = cp["strata"]
        for key, raw in sec.items():
            dest = key.replace("-", "_")
            if key in LISTS:
                out[dest] = [v.strip() for v in raw.replace(",", " ").split() if v.strip()]
            elif key in FLOATS:
                out[dest] = float(raw)
            elif key in BOOLS:
                out[dest] = sec.getboolean(key)
            elif key in STRINGS:
                out[dest] = raw.strip()
    return out
