"""strata: wallpaper-seeded icon theme and app colours for Ubuntu/GNOME."""
from __future__ import annotations

import argparse
import json
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

from . import config, gnome, gtk, theme
from .palette import extract
from .scheme import Scheme, SCHEMES

UNIT = """[Unit]
Description=Strata: regenerate icons and app colours when the wallpaper changes
PartOf=graphical-session.target
After=graphical-session.target

[Service]
Type=simple
ExecStart={exe} watch {args}
Restart=on-failure
RestartSec=5

[Install]
WantedBy=graphical-session.target
"""


def _add_build_opts(p: argparse.ArgumentParser) -> None:
    p.add_argument("--scheme", choices=SCHEMES,
                   help="harmony: accent from the wallpaper, other colours lean toward it (default); "
                        "content: use the wallpaper's own secondary colours where they fit; "
                        "mono: everything in the seed hue")
    p.add_argument("--vibrancy", type=float, help="chroma scale, 0.3-1.3 (default: measured from the wallpaper)")
    p.add_argument("--tint", type=float, help="how much the seed tints greys, 0-1 (default 0.6)")
    p.add_argument("--name", help="icon theme name (default Strata)")
    p.add_argument("--dest", type=Path, help="icon themes directory (default ~/.local/share/icons)")
    p.add_argument("--no-third-party", action="store_true", help="only the Strata set; leave other apps' icons alone")
    p.add_argument("--keep", action="append", metavar="GLOB",
                   help="keep the original colours of icons matching this pattern (still slabbed; repeatable)")
    p.add_argument("--keep-brands", action="store_true",
                   help="keep logo colours (Firefox, Chrome, Steam...) while still putting them on a slab")
    p.add_argument("--source", action="append", metavar="THEME",
                   help="icon theme to take app artwork from, in order (default: Papirus, then --inherit themes)")
    p.add_argument("--glyphs", action="store_true",
                   help="raise each app's one-colour symbol in white on a pad in its own colour (the drawn "
                        "set's look) instead of setting its artwork on a pad; apps without a symbol keep their art")
    p.add_argument("--glyph-theme", action="append", metavar="THEME",
                   help="icon theme to take symbolic app glyphs from, after the apps' own (e.g. MoreWaita)")
    p.add_argument("--installed-only", action="store_true",
                   help="only slab apps installed now (faster, smaller; new apps wait for the next run)")
    p.add_argument("--no-desktop-overrides", action="store_true",
                   help="don't add launcher copies for apps whose icon is a file path (snaps, AppImages)")
    p.add_argument("--no-gtk", action="store_true", help="don't write GTK/libadwaita colours")
    p.add_argument("--flat-surfaces", action="store_true", help="recolour accents only, keep stock window greys")
    p.add_argument("--no-accent", action="store_true", help="don't change GNOME's accent-color setting")
    p.add_argument("--no-apply", action="store_true", help="build the theme but don't switch to it")
    p.add_argument("--inherit", action="append", metavar="THEME",
                   help="fall back to this icon theme for icons Strata doesn't draw "
                        "(default: the theme you used before Strata, e.g. Yaru)")


DEFAULTS = {"scheme": "harmony", "tint": 0.6, "name": "Strata", "keep": [], "inherit": [], "source": None,
            "vibrancy": None, "dest": None, "wallpaper": None}


def _apply_config(a) -> None:
    """Fill anything not given on the command line from strata.conf (user, then system)."""
    cfg = config.load()
    for key, val in cfg.items():
        if hasattr(a, key) and getattr(a, key) in (None, False, []):
            setattr(a, key, Path(val) if key == "dest" else val)
        elif not hasattr(a, key):
            setattr(a, key, val)
    for key, val in DEFAULTS.items():
        if getattr(a, key, None) is None:
            setattr(a, key, list(val) if isinstance(val, list) else val)


def _build_args(a) -> list[str]:
    out = ["--scheme", a.scheme, "--tint", str(a.tint), "--name", a.name]
    if a.vibrancy is not None:
        out += ["--vibrancy", str(a.vibrancy)]
    if a.dest:
        out += ["--dest", str(a.dest)]
    for flag in ("no_third_party", "keep_brands", "installed_only", "no_desktop_overrides", "no_gtk",
                 "flat_surfaces", "no_accent"):
        if getattr(a, flag):
            out.append("--" + flag.replace("_", "-"))
    for k in a.keep:
        out += ["--keep", k]
    for t in a.inherit:
        out += ["--inherit", t]
    for t in a.source or []:
        out += ["--source", t]
    return out


STATE = gtk.CONFIG / "strata" / "state.json"


def _previous_theme(name: str) -> list[str]:
    """The icon theme in use before Strata took over, so apps whose icons only live
    there (Ubuntu's Yaru ships many) keep them instead of falling back to a blank page."""
    state = {}
    try:
        state = json.loads(STATE.read_text())
    except (OSError, ValueError):
        pass
    current = gnome._unquote(gnome._gs("get", gnome.IFACE, "icon-theme"))
    if current and current != name and current != state.get("previous"):
        state["previous"] = current
        STATE.parent.mkdir(parents=True, exist_ok=True)
        STATE.write_text(json.dumps(state))
    if state.get("inherit"):
        return state["inherit"]
    prev = state.get("previous")
    return [prev] if prev else []


def _remember(themes: list[str]) -> list[str]:
    try:
        STATE.parent.mkdir(parents=True, exist_ok=True)
        STATE.write_text(json.dumps({"previous": themes[0], "inherit": themes}))
    except OSError:
        pass
    return themes


def _resolve_image(a) -> Path:
    if getattr(a, "image", None):
        return Path(a.image).expanduser()
    p = gnome.wallpaper()
    if not p:
        sys.exit("strata: couldn't read the GNOME wallpaper; pass an image path")
    return p


SYSTEM_ICONS = Path("/usr/share/icons")


def _system_wallpaper(a) -> Path:
    for cand in (getattr(a, "image", None), a.wallpaper):
        if cand and Path(cand).is_file():
            return Path(cand)
    bg = Path("/usr/share/backgrounds")
    pics = sorted(p for p in bg.rglob("*") if p.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp")) \
        if bg.is_dir() else []
    if not pics:
        sys.exit("strata: no wallpaper for the system theme; set `wallpaper =` in /etc/strata/strata.conf")
    return pics[0]


def run_generate(a, image: Path | None = None) -> dict:
    if getattr(a, "system", False):
        # The distro-wide default in /usr/share/icons: seeded from the distro wallpaper,
        # never touches a user's settings. Each user's own build in ~/.local/share/icons
        # shadows it as soon as their session starts.
        image = image or _system_wallpaper(a)
        a.dest = a.dest or SYSTEM_ICONS
        a.no_apply = True
        a.no_desktop_overrides = True
        inherits = a.inherit
    else:
        image = image or _resolve_image(a)
        inherits = _remember(a.inherit) if a.inherit else _previous_theme(a.name)
    pal = extract(image)
    sch = Scheme(pal, a.scheme, a.vibrancy, a.tint)
    rep = theme.build(sch, a.dest, a.name, third_party=not a.no_third_party, keep=a.keep, inherits=inherits,
                      sources=a.source, keep_brands=a.keep_brands, overrides=not a.no_desktop_overrides,
                      slab_all=not a.installed_only, glyphs=a.glyphs, glyph_themes=a.glyph_theme)
    applied = {"icons": False, "gtk": False, "accent": None}
    if getattr(a, "system", False) and shutil.which("gtk-update-icon-cache"):
        subprocess.run(["gtk-update-icon-cache", "-f", "-q", "-t", rep.out], check=False)
    if not a.no_apply:
        gnome.set_icon_theme(a.name, Path(rep.out))
        applied["icons"] = True
        if not a.no_gtk:
            gtk.apply(sch, gnome.prefers_dark(), tint_surfaces=not a.flat_surfaces)
            applied["gtk"] = True
        if not a.no_accent:
            preset = sch.accent_name()
            applied["accent"] = preset if gnome.set_accent(preset) else None
    summary = sch.summary()
    print(f"strata: {image.name} -> seed {summary['seed']} ({a.scheme}), accent {summary['accent']} "
          f"[{summary['accent_preset']}]")
    print(f"  {rep.templates} drawn, {rep.slabbed} slabbed ({rep.glyphs} as glyphs), {rep.aliases + rep.routed} names "
          f"routed to the drawn set, {rep.overrides} launcher overrides -> {rep.out}")
    if rep.missing:
        print(f"  no artwork anywhere, given a lettered slab: {', '.join(sorted(set(rep.missing))[:20])}"
              f"{' ...' if len(set(rep.missing)) > 20 else ''}")
    return {"summary": summary, "build": rep.to_dict(), "applied": applied}


def cmd_palette(a) -> None:
    image = _resolve_image(a)
    pal = extract(image)
    sch = Scheme(pal, a.scheme, a.vibrancy, a.tint)
    if a.json:
        print(json.dumps({"palette": pal.to_dict(), "scheme": sch.summary()}, indent=2))
        return
    s = sch.summary()
    print(f"wallpaper  {image}")
    print(f"seed       {s['seed']}  vibrancy {s['vibrancy']}{'  (achromatic)' if pal.achromatic else ''}")
    print(f"swatches   {' '.join(s['swatches'])}")
    print(f"accent     {s['accent']}  -> GNOME preset '{s['accent_preset']}'")
    for fam, ramp in s["ramps"].items():
        print(f"  {fam:<7} {' '.join(ramp)}")


def cmd_watch(a) -> None:
    run_generate(a)
    print("strata: watching for wallpaper changes", flush=True)
    gnome.monitor(lambda: run_generate(a), poll=theme.apps_signature)


def cmd_install_service(a) -> None:
    exe = shutil.which("strata") or f"{sys.executable} -m strata"
    unit_dir = Path.home() / ".config/systemd/user"
    unit_dir.mkdir(parents=True, exist_ok=True)
    unit = unit_dir / "strata.service"
    unit.write_text(UNIT.format(exe=exe, args=shlex.join(_build_args(a))))
    subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)
    subprocess.run(["systemctl", "--user", "enable", "--now", "strata.service"], check=False)
    print(f"strata: installed {unit}")


def cmd_uninstall(a) -> None:
    subprocess.run(["systemctl", "--user", "disable", "--now", "strata.service"], check=False, capture_output=True)
    unit = Path.home() / ".config/systemd/user/strata.service"
    if unit.exists():
        unit.unlink()
    gtk.remove()
    try:
        subprocess.run(["gnome-extensions", "disable", BADGES_UUID], check=False, capture_output=True)
    except FileNotFoundError:
        pass
    ext = Path.home() / ".local/share/gnome-shell/extensions" / BADGES_UUID
    if ext.exists():
        shutil.rmtree(ext)
    n = theme.remove_overrides()
    if n:
        print(f"strata: removed {n} launcher overrides")
    prev = _previous_theme(a.name)
    if prev:
        gnome._gs("set", gnome.IFACE, "icon-theme", prev[0])
    else:
        gnome._gs("reset", gnome.IFACE, "icon-theme")
    gnome._gs("reset", gnome.IFACE, "accent-color")
    print("strata: removed GTK overrides, reset icon theme and accent, disabled the service "
          f"(theme files remain in {theme.XDG_DATA_HOME / 'icons' / a.name})")


BADGES_UUID = "strata-badges@strata"


def cmd_install_badges(a) -> None:
    src = Path(__file__).parent / "shell" / BADGES_UUID
    dest = Path.home() / ".local/share/gnome-shell/extensions" / BADGES_UUID
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(src, dest)
    try:
        ok = subprocess.run(["gnome-extensions", "enable", BADGES_UUID], capture_output=True).returncode == 0
    except FileNotFoundError:
        ok = False
    print(f"strata: installed {dest}")
    if not ok:
        print("  GNOME Shell only notices new extensions at login. Log out and back in, then run:\n"
              f"  gnome-extensions enable {BADGES_UUID}")
    else:
        print("  enabled. Badges restyle within a couple of seconds and follow every rebuild.")


def cmd_sheet(a) -> None:
    """Render a PNG contact sheet of a built theme or of the templates."""
    import io
    from PIL import Image, ImageDraw

    if not shutil.which("rsvg-convert"):
        sys.exit("strata: sheet needs rsvg-convert (sudo apt install librsvg2-bin)")
    src = Path(a.dir).expanduser() if a.dir else (theme.XDG_DATA_HOME / "icons" / "Strata")
    files = sorted(p for p in src.rglob("*.svg") if not p.is_symlink() and "symbolic" not in p.parts)[: a.limit]
    S, cols = 96, 10
    rows = max(1, (len(files) + cols - 1) // cols)
    im = Image.new("RGB", (cols * (S + 16) + 16, rows * (S + 30) + 16), a.bg)
    d = ImageDraw.Draw(im)
    for i, f in enumerate(files):
        png = subprocess.run(["rsvg-convert", "-w", str(S), "-h", str(S), str(f)], capture_output=True).stdout
        if not png:
            continue
        ic = Image.open(io.BytesIO(png)).convert("RGBA")
        x, y = 16 + (i % cols) * (S + 16), 16 + (i // cols) * (S + 30)
        im.paste(ic, (x, y), ic)
        d.text((x, y + S + 2), f.stem[:18], fill="#888888")
    im.save(a.out)
    print(f"strata: {len(files)} icons -> {a.out}")


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser(prog="strata", description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("palette", help="show the palette and scheme for a wallpaper")
    p.add_argument("image", nargs="?")
    p.add_argument("--scheme", choices=SCHEMES)
    p.add_argument("--vibrancy", type=float)
    p.add_argument("--tint", type=float)
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_palette)

    p = sub.add_parser("generate", help="build the icon theme (and GTK colours) and switch to it")
    p.add_argument("image", nargs="?", help="image to seed from (default: current GNOME wallpaper)")
    _add_build_opts(p)
    p.add_argument("--system", action="store_true",
                   help="build the distro-wide default theme into /usr/share/icons (as root) from the "
                        "`wallpaper` in /etc/strata/strata.conf")
    p.set_defaults(fn=lambda a: run_generate(a))

    p = sub.add_parser("watch", help="generate now, then again whenever the wallpaper changes")
    _add_build_opts(p)
    p.set_defaults(fn=cmd_watch, image=None)

    p = sub.add_parser("install-service", help="run `strata watch` as a systemd user service")
    _add_build_opts(p)
    p.set_defaults(fn=cmd_install_service)

    p = sub.add_parser("uninstall", help="undo GTK overrides, theme and accent; stop the service")
    p.add_argument("--name", default="Strata")
    p.set_defaults(fn=cmd_uninstall)

    p = sub.add_parser("install-badges", help="install the GNOME Shell extension that colours dock badges")
    p.set_defaults(fn=cmd_install_badges)

    p = sub.add_parser("sheet", help="render a PNG contact sheet of a theme directory")
    p.add_argument("out")
    p.add_argument("--dir")
    p.add_argument("--bg", default="#f6f5f4")
    p.add_argument("--limit", type=int, default=400)
    p.set_defaults(fn=cmd_sheet)

    a = ap.parse_args(argv)
    if a.cmd in ("generate", "watch", "install-service", "palette"):
        _apply_config(a)
    a.fn(a)


if __name__ == "__main__":
    main()
