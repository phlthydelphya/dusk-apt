"""Strata: a wallpaper-seeded icon theme and app colour engine for Ubuntu-based GNOME desktops."""
__version__ = "0.1.0"
