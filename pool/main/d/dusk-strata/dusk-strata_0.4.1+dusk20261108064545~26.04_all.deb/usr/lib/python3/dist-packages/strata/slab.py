"""Put any icon into the Strata slab grammar.

The source artwork (an app's own icon, Papirus, Yaru, or a PNG) becomes the
object: it casts the soft shadow, gets a dark side 6 px below it (its own
silhouette, flooded with the scheme's side colour), and sits on a pad in the
wallpaper's accent. Vector art is inlined, so it stays sharp at every size;
anything that can't be inlined safely is embedded as an image instead.
"""
from __future__ import annotations

import base64
import io
import re
import xml.etree.ElementTree as ET
import zlib
from pathlib import Path

import math

from .color import parse_color, to_oklch, hue_dist, fmt_hex, oklch_to_srgb_clamped
from .scheme import Scheme, GNOME, harmonize

_ROOT = re.compile(r"<svg\b([^>]*)>", re.S | re.I)
_ATTR = re.compile(r'([\w:.-]+)\s*=\s*("([^"]*)"|\'([^\']*)\')', re.S)
_ID = re.compile(r'\bid\s*=\s*(["\'])([^"\']+)\1')
_HEX = re.compile(r"(?:fill|stop-color|stroke)\s*[:=]\s*[\"']?\s*(#[0-9a-fA-F]{3,6}\b)", re.I)

# where the artwork goes, in the 128 canvas before the final fit
# The object stands large on the pad (Dusk): 78 units square (was 68), so an
# app's own artwork reads at dock sizes. The fit below centres the object's
# top to the pad's side vertically, so nothing clips at the canvas top.
APP_BOX = (25, 4, 78, 78)        # object above the pad
PAD_BOTTOM = 112                 # the pad's side, its lowest edge
FREE_BOX = (14, 8, 100, 100)     # devices: the object is the whole icon
FIT_K = 1.154                    # same fill as the hand-drawn set (pad 104 -> 120)


def _num(v: str | None) -> float | None:
    if not v:
        return None
    m = re.match(r"\s*([0-9.]+)", v)
    return float(m.group(1)) if m else None


def _viewbox(attrs: dict) -> tuple[float, float, float, float]:
    vb = attrs.get("viewBox") or attrs.get("viewbox")
    if vb:
        p = [float(x) for x in re.split(r"[\s,]+", vb.strip()) if x]
        if len(p) == 4 and p[2] > 0 and p[3] > 0:
            return p[0], p[1], p[2], p[3]
    w, h = _num(attrs.get("width")), _num(attrs.get("height"))
    return 0.0, 0.0, w or 128.0, h or 128.0


def _prefix_ids(svg: str, pre: str) -> str:
    ids = {m.group(2) for m in _ID.finditer(svg)}
    if not ids:
        return svg
    svg = _ID.sub(lambda m: f"id={m.group(1)}{pre}{m.group(2)}{m.group(1)}", svg)
    alt = "|".join(re.escape(i) for i in sorted(ids, key=len, reverse=True))
    svg = re.sub(rf"url\(\s*(['\"]?)#({alt})\1\s*\)", lambda m: f"url(#{pre}{m.group(2)})", svg)
    svg = re.sub(rf"(href\s*=\s*[\"'])#({alt})([\"'])", lambda m: f"{m.group(1)}#{pre}{m.group(2)}{m.group(3)}", svg)
    return svg


_FILTER_EL = re.compile(r"<filter\b.*?</filter>|<filter\b[^>]*/>", re.S | re.I)
_FILTER_ATTR = re.compile(r'\sfilter\s*=\s*(["\'])[^"\']*\1|filter\s*:\s*[^;"\']+;?', re.I)
_PRESENT = ("fill", "stroke", "stroke-width", "fill-rule", "clip-rule", "opacity", "fill-opacity", "stroke-opacity",
            "stroke-linecap", "stroke-linejoin", "style", "color")


def strip_filters(svg: str) -> str:
    """GTK 4.24's own SVG renderer aborts on some filter use, so Strata never emits filters
    and removes them from source artwork too (they are mostly soft drop shadows)."""
    return _FILTER_ATTR.sub("", _FILTER_EL.sub("", svg))


def parse_art(svg: str):
    """(viewBox, presentation attrs of the root, inner markup, xmlns attrs) or None if unsafe."""
    svg = re.sub(r"<\?xml.*?\?>|<!--.*?-->|<!DOCTYPE[^>[]*(\[.*?\])?\s*>", "", svg, flags=re.S)
    if "<!ENTITY" in svg or "&ns_" in svg:
        return None
    m = _ROOT.search(svg)
    end = svg.rfind("</svg>")
    if not m or end < m.end():
        return None
    attrs = {k: (a if q.startswith('"') else b) for k, q, a, b in _ATTR.findall(m.group(1))}
    pres = {k: v for k, v in attrs.items() if k in _PRESENT}
    ns = {k: v for k, v in attrs.items() if k.startswith("xmlns:")}
    return _viewbox(attrs), pres, strip_filters(svg[m.end():end]), ns


def placed(art, box, pre: str, fill: str | None = None) -> str:
    """The artwork as a plain transformed <g> (no nested <svg>, no <use>), ids prefixed.
    With `fill`, every paint outside masks becomes that colour: a silhouette."""
    (vx, vy, vw, vh), pres, inner, ns = art
    x, y, w, h = box
    k = min(w / vw, h / vh)
    ox, oy = x + (w - vw * k) / 2, y + (h - vh * k) / 2
    inner = _prefix_ids(inner, pre)
    pres = dict(pres)
    if fill:
        inner = silhouette(inner, fill)
        for key in ("fill", "stroke"):
            if key in pres and pres[key].strip().lower() not in ("none", "transparent"):
                pres[key] = fill
        if "style" in pres:
            pres["style"] = silhouette(pres["style"], fill)
        pres.setdefault("fill", fill)
    attrs = " ".join(f'{k_}="{v}"' for k_, v in {**ns, **pres}.items())
    return (f'<g transform="translate({ox:.3f} {oy:.3f}) scale({k:.5f}) translate({-vx} {-vy})" {attrs}>'
            f"{inner}</g>")


_PAINT_ATTR = re.compile(r'(\s(?:fill|stroke)\s*=\s*)(["\'])([^"\']*)\2', re.I)
_PAINT_CSS = re.compile(r"((?<![-\w])(?:fill|stroke)\s*:\s*)([^;\"'}]+)", re.I)
_MASK = re.compile(r"(<mask\b.*?</mask>)", re.S | re.I)


def silhouette(markup: str, colour: str) -> str:
    def attr(m):
        v = m.group(3).strip().lower()
        return m.group(0) if v in ("none", "transparent", "") else f"{m.group(1)}{m.group(2)}{colour}{m.group(2)}"

    def css(m):
        v = m.group(2).strip().lower()
        return m.group(0) if v in ("none", "transparent") else f"{m.group(1)}{colour}"

    parts = _MASK.split(markup)  # masks are luminance: leave them alone
    return "".join(p if i % 2 else _PAINT_CSS.sub(css, _PAINT_ATTR.sub(attr, p)) for i, p in enumerate(parts))


def _wrap_ok(doc: str) -> bool:
    try:
        ET.fromstring(doc)
        return True
    except ET.ParseError:
        return False


def _image(data: bytes, mime: str, box) -> str:
    x, y, w, h = box
    b = base64.b64encode(data).decode()
    return (f'<image x="{x}" y="{y}" width="{w}" height="{h}" preserveAspectRatio="xMidYMid meet" '
            f'href="data:{mime};base64,{b}"/>')


def _upsize_svg(svg: str) -> str:
    """librsvg rasterises an embedded SVG at its own width/height; make that large."""
    m = _ROOT.search(svg)
    if not m:
        return svg
    head = re.sub(r'\s(width|height)\s*=\s*(["\'])[^"\']*\2', "", m.group(1))
    return svg[:m.start()] + f'<svg width="256" height="256"{head}>' + svg[m.end():]


# ---------------------------------------------------------------- colour
def dominant_hue(svg_or_png: bytes, is_svg: bool) -> tuple[float, float, str] | None:
    """(hue, chroma, representative hex) of the artwork's most prominent saturated colour."""
    acc: dict[int, list[float]] = {}  # hue bin -> [weight, L, C, sin, cos]

    def add(rgb, w=1.0):
        L, C, h = to_oklch(*rgb)
        if C >= 0.05 and 0.25 < L < 0.95:
            k = round(h / 15) % 24
            a = acc.setdefault(k, [0.0, 0.0, 0.0, 0.0, 0.0])
            ww = w * C
            a[0] += ww; a[1] += L * ww; a[2] += C * ww
            a[3] += math.sin(math.radians(h)) * ww; a[4] += math.cos(math.radians(h)) * ww

    if is_svg:
        for hx in _HEX.findall(svg_or_png.decode("utf-8", "replace")):
            p = parse_color(hx)
            if p:
                add(p[0])
    else:
        try:
            from PIL import Image
            im = Image.open(io.BytesIO(svg_or_png)).convert("RGBA").resize((24, 24))
        except Exception:
            return None
        for r_, g_, b_, a_ in im.getdata():
            if a_ >= 128:
                add((r_ / 255, g_ / 255, b_ / 255))
    if not acc:
        return None
    w, sL, sC, ss, sc = max(acc.values(), key=lambda v: v[0])
    h = math.degrees(math.atan2(ss, sc)) % 360
    L, C = sL / w, sC / w
    return h, C, fmt_hex(oklch_to_srgb_clamped(L, C, h))


# Vivid (the content scheme): each app's pad is a tone of the app's own colour,
# leaning toward the wallpaper like the glyph pads, and kept well away from the
# art's own lightness so the object still reads on it.
VIVID_DEEP_L, VIVID_PALE_L = 0.40, 0.76
VIVID_PAD_CHROMA = 0.17
VIVID_SIDE_DL = 0.08


def _vivid_pad(scheme: Scheme, art: tuple[float, float, str]) -> tuple[str, str]:
    h, C, hx = art
    art_L = to_oklch(*parse_color(hx)[0])[0]
    L = VIVID_DEEP_L if art_L >= 0.55 else VIVID_PALE_L
    h = scheme.swatch_hue(h)
    C = min(C, VIVID_PAD_CHROMA) * (1.0 if L < 0.6 else 0.85)
    return (fmt_hex(oklch_to_srgb_clamped(L, C, h)),
            fmt_hex(oklch_to_srgb_clamped(L - VIVID_SIDE_DL, C, h)))


def _pad_colours(scheme: Scheme, art_hue: float | None,
                 art: tuple[float, float, str] | None = None) -> tuple[str, str]:
    """Accent pad. If the artwork is mostly the accent colour, the tertiary (the
    wallpaper's companion colour); if it clashes with that too, a dark pad.
    In Vivid (content scheme) a coloured app gets a pad in its own hue instead."""
    if scheme.name == "content" and art is not None:
        return _vivid_pad(scheme, art)
    for fam in ("blue", "purple"):
        top = scheme.remap(GNOME[fam][2])
        _, _, h = to_oklch(*parse_color(top)[0])
        if art_hue is None or hue_dist(art_hue, h) > 40:
            return top, scheme.remap(GNOME[fam][4])
    return scheme.remap(GNOME["dark"][1]), scheme.remap(GNOME["dark"][3])


# ---------------------------------------------------------------- compose
SHEEN = ('<linearGradient id="strata-sheen" x1="0" y1="0" x2="0" y2="1">'
         '<stop offset="0" stop-color="#ffffff" stop-opacity="0.22"/>'
         '<stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>')


def _png_silhouette(data: bytes, colour: str, alpha: float = 1.0) -> bytes:
    from PIL import Image
    im = Image.open(io.BytesIO(data)).convert("RGBA")
    rgb = tuple(int(colour[i:i + 2], 16) for i in (1, 3, 5))
    a = im.getchannel("A").point(lambda v: int(v * alpha))
    out = Image.new("RGBA", im.size, rgb + (0,))
    out.putalpha(a)
    buf = io.BytesIO()
    out.save(buf, "PNG", optimize=True)
    return buf.getvalue()


def slab(scheme: Scheme, data: bytes, kind: str, *, mode: str = "app", recolor: bool = True, key: str = "",
         info: dict | None = None) -> str:
    """kind: 'svg' or 'png'. mode: 'app' (object on a pad) or 'free' (devices, no pad).

    The object is drawn three times: a black copy at 16% opacity for the shadow, a copy
    flooded with the side colour, and the artwork itself. Plain shapes only: no <filter>,
    <use> or nested <svg>, which GTK's built-in SVG renderer handles badly or not at all."""
    pre = f"s{zlib.crc32(key.encode()) & 0xffff:x}"
    box = APP_BOX if mode == "app" else FREE_BOX
    depth = 6 if mode == "app" else 8
    side = scheme.remap(GNOME["dark"][2])
    if kind == "svg":
        text = data.decode("utf-8", "replace")
        if recolor:
            text = recolor_embedded(scheme, scheme.recolor_svg(text))
        hue = dominant_hue(text.encode(), True)
        art = parse_art(text)
        layers = None
        if art is not None:
            layers = (placed(art, box, pre + "h-", "#000000"), placed(art, box, pre + "d-", side),
                      placed(art, box, pre + "a-"))
            if not _wrap_ok('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">'
                            + "".join(layers) + "</svg>"):
                layers = None
        if layers is None:  # can't inline safely: show the art without a cast side
            layers = ("", "", _image(_upsize_svg(strip_filters(text)).encode(), "image/svg+xml", box))
    else:
        if recolor:
            data = recolor_png(scheme, data)
        hue = dominant_hue(data, False)
        try:
            layers = (_image(_png_silhouette(data, "#000000"), "image/png", box),
                      _image(_png_silhouette(data, side), "image/png", box), _image(data, "image/png", box))
        except Exception:
            layers = ("", "", _image(data, "image/png", box))

    shadow, sidel, top_art = layers
    body = ""
    if mode == "app":
        top, pside = _pad_colours(scheme, hue[0] if hue else None, hue)
        if info is not None:
            info["primary"] = hue[2] if hue else top  # the app's own colour; its pad if the art is neutral
        body += (f'<rect x="12" y="52" width="104" height="60" rx="18" fill="{pside}"/>'
                 f'<rect x="12" y="44" width="104" height="60" rx="18" fill="{top}"/>'
                 '<rect x="12" y="44" width="104" height="60" rx="18" fill="url(#strata-sheen)"/>')
    if shadow:
        body += f'<g transform="translate(0 {depth * 2})" opacity="0.16">{shadow}</g>'
    if sidel:
        body += f'<g transform="translate(0 {depth})">{sidel}</g>'
    body += top_art
    cy = (APP_BOX[1] + PAD_BOTTOM) / 2 if mode == "app" else 66
    k = FIT_K if mode == "app" else 1.12
    return ('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" '
            'width="128" height="128" viewBox="0 0 128 128">'
            f'<defs>{SHEEN}</defs><g transform="translate(64 64) scale({k}) translate(-64 -{cy})">{body}</g></svg>\n')


_EMBEDDED_PNG = re.compile(r'(href\s*=\s*["\']data:image/png;base64,)([A-Za-z0-9+/=\s]+)', re.I)


def recolor_embedded(scheme: Scheme, svg: str) -> str:
    """Recolour the PNGs embedded in an SVG. Some themes (Hatter) ship most
    of their app icons as a raster picture wrapped in an SVG, with no fill
    colours for recolor_svg() to change."""
    def sub(m: re.Match) -> str:
        try:
            raw = base64.b64decode("".join(m.group(2).split()))
        except ValueError:
            return m.group(0)
        return m.group(1) + base64.b64encode(recolor_png(scheme, raw)).decode("ascii")
    return _EMBEDDED_PNG.sub(sub, svg)


def recolor_png(scheme: Scheme, data: bytes) -> bytes:
    """Recolour a raster icon pixel by pixel through the scheme (cached per colour)."""
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(data)).convert("RGBA")
    except Exception:
        return data
    if max(im.size) > 256:
        im.thumbnail((256, 256))
    cache: dict[tuple, tuple] = {}
    px = []
    for r, g, b, a in im.getdata():
        if a == 0:
            px.append((0, 0, 0, 0))
            continue
        k = (r >> 2, g >> 2, b >> 2)
        if k not in cache:
            nr, ng, nb = scheme.remap_rgb((r / 255, g / 255, b / 255), obj=True)
            cache[k] = (int(nr * 255 + 0.5), int(ng * 255 + 0.5), int(nb * 255 + 0.5))
        px.append((*cache[k], a))
    im.putdata(px)
    out = io.BytesIO()
    im.save(out, "PNG", optimize=True)
    return out.getvalue()


MONO_FAMS = ["blue", "purple", "green", "orange", "red", "yellow"]


def monogram(scheme: Scheme, label: str, key: str, info: dict | None = None) -> str:
    """Last resort for an app with no artwork anywhere: its initial on a slab card."""
    ch = next((c for c in label if c.isalnum()), "?").upper()
    ch = {"&": "&amp;", "<": "&lt;", ">": "&gt;"}.get(ch, ch)
    fam = MONO_FAMS[zlib.crc32(key.encode()) % len(MONO_FAMS)]
    top, side = scheme.remap(GNOME[fam][2]), scheme.remap(GNOME[fam][4])
    if info is not None:
        info["primary"] = top
    ink = scheme.remap(GNOME[fam][4])
    card, cside = scheme.remap(GNOME["light"][0]), scheme.remap(GNOME["dark"][2])
    body = (f'<rect x="12" y="52" width="104" height="60" rx="18" fill="{side}"/>'
            f'<rect x="12" y="44" width="104" height="60" rx="18" fill="{top}"/>'
            '<rect x="12" y="44" width="104" height="60" rx="18" fill="url(#strata-sheen)"/>'
            '<rect x="38" y="28" width="52" height="60" rx="12" fill="#000000" opacity="0.16"/>'
            f'<rect x="38" y="22" width="52" height="60" rx="12" fill="{cside}"/>'
            f'<rect x="38" y="16" width="52" height="60" rx="12" fill="{card}"/>'
            f'<text x="64" y="61" text-anchor="middle" font-family="Cantarell, Ubuntu, \'DejaVu Sans\', sans-serif" '
            f'font-weight="800" font-size="36" fill="{ink}">{ch}</text>')
    return ('<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128">'
            f'<defs>{SHEEN}</defs><g transform="translate(64 64) scale({FIT_K}) translate(-64 -62)">{body}</g></svg>\n')
