"""GNOME integration: read the wallpaper, apply the theme, watch for changes."""
from __future__ import annotations

import shutil
import subprocess
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import unquote, urlparse

BG = "org.gnome.desktop.background"
IFACE = "org.gnome.desktop.interface"


def _gs(*args: str) -> str | None:
    if not shutil.which("gsettings"):
        return None
    r = subprocess.run(["gsettings", *args], capture_output=True, text=True)
    return r.stdout.strip() if r.returncode == 0 else None


def _unquote(v: str | None) -> str:
    if not v:
        return ""
    v = v.strip()
    if len(v) >= 2 and v[0] == v[-1] == "'":
        v = v[1:-1]
    return v


def prefers_dark() -> bool:
    return "dark" in _unquote(_gs("get", IFACE, "color-scheme"))


def _uri_to_path(uri: str) -> Path | None:
    if not uri:
        return None
    if uri.startswith("file://"):
        return Path(unquote(urlparse(uri).path))
    if uri.startswith("/"):
        return Path(uri)
    return None


def _from_slideshow(xml_path: Path) -> Path | None:
    """GNOME slideshow / dynamic wallpaper XML: take the first still image."""
    try:
        root = ET.parse(xml_path).getroot()
    except (ET.ParseError, OSError):
        return None
    for tag in ("static/file", "transition/from", ".//file", ".//size"):
        el = root.find(tag)
        if el is not None and el.text and el.text.strip():
            p = Path(el.text.strip())
            if p.is_file():
                return p
    return None


def wallpaper(dark: bool | None = None) -> Path | None:
    dark = prefers_dark() if dark is None else dark
    keys = ["picture-uri-dark", "picture-uri"] if dark else ["picture-uri"]
    for k in keys:
        p = _uri_to_path(_unquote(_gs("get", BG, k)))
        if p and p.is_file():
            if p.suffix.lower() == ".xml":
                p = _from_slideshow(p)
            if p and p.is_file():
                return p
    return None


def set_icon_theme(name: str, dest: Path) -> None:
    if shutil.which("gtk-update-icon-cache"):
        subprocess.run(["gtk-update-icon-cache", "-f", "-q", "-t", str(dest)], check=False)
    current = _unquote(_gs("get", IFACE, "icon-theme"))
    if current == name:
        # Same name: bounce through Adwaita so GTK and the Shell drop their caches.
        _gs("set", IFACE, "icon-theme", "Adwaita")
        time.sleep(0.4)
    _gs("set", IFACE, "icon-theme", name)


def set_accent(preset: str) -> bool:
    """GNOME 47+ accent-color key. Returns False on older GNOME."""
    if _gs("writable", IFACE, "accent-color") != "true":
        return False
    _gs("set", IFACE, "accent-color", preset)
    return True


def monitor(callback, debounce: float = 1.5, poll=None, poll_every: float = 30.0) -> None:
    """Block, calling `callback()` after the wallpaper or colour scheme changes, or when
    `poll()` (checked every `poll_every` s) returns something different, e.g. apps installed."""
    procs = [subprocess.Popen(["gsettings", "monitor", schema], stdout=subprocess.PIPE, text=True, bufsize=1)
             for schema in (BG, IFACE)]
    import selectors

    sel = selectors.DefaultSelector()
    for p in procs:
        sel.register(p.stdout, selectors.EVENT_READ)
    pending = 0.0
    last_sig = poll() if poll else None
    next_poll = time.monotonic() + poll_every
    try:
        while True:
            events = sel.select(timeout=0.25)
            for key, _ in events:
                line = key.fileobj.readline()
                if not line:
                    raise RuntimeError("gsettings monitor exited")
                if line.startswith(("picture-uri", "color-scheme")):
                    pending = time.monotonic() + debounce
            if poll and time.monotonic() >= next_poll:
                next_poll = time.monotonic() + poll_every
                sig = poll()
                if sig != last_sig:
                    last_sig = sig
                    pending = time.monotonic() + debounce
            if pending and time.monotonic() >= pending:
                pending = 0.0
                try:
                    callback()
                except Exception as e:  # keep watching even if one run fails
                    print(f"strata: regenerate failed: {e}", flush=True)
    finally:
        for p in procs:
            p.terminate()
