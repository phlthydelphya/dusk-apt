"""Glyph mode: an app's one-colour symbol, raised in white on a pad in the
app's own colour family. The look of the drawn set (Mail Hub, Staq) for apps
Strata does not draw, instead of their full-colour artwork set on a pad.

A glyph comes from, in order: the app's own symbolic icon
(`<icon>-symbolic` in hicolor), the glyph themes' symbolic app icons
(MoreWaita ships about 1,400), then Simple Icons' brand logos matched by the
app's name. The pad's colour family is the one nearest the hue of the app's
full-colour icon. Pads keep their family's own hue, leaning at most PAD_LEAN
degrees toward the seed: through the scheme, blue (most apps) would become the
seed itself and the set would read as one colour. The mono scheme still maps
them, since one colour is what it asks for.

The content scheme (Dusk's Vivid mood) colours the glyph too. The deep pad is
the wallpaper swatch nearest the app's hue (measured from its full-colour
icon); the symbol is a light diagonal gradient through the wallpaper's other
swatches (up to VIVID_STOPS, best-scoring first), so each emblem carries the
wallpaper's colours rather than its pad's. A one-colour wallpaper falls back
to a light tint of the pad's hue. The other schemes keep the white glyph.
"""
from __future__ import annotations

import os
import re
import zlib
from pathlib import Path

from .color import parse_color, to_oklch, hue_dist, oklch_to_srgb_clamped, fmt_hex
from .scheme import Scheme, GNOME, harmonize
from .slab import SHEEN, FIT_K, _wrap_ok, dominant_hue, parse_art, placed, strip_filters

XDG_DATA_HOME = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share"))

# Simple Icons (simpleicons.org, CC0): icons/<slug>.svg. STRATA_SIMPLE_ICONS
# overrides; the first existing folder is used
SIMPLE_ICONS = [
    *(Path(p) for p in [os.environ.get("STRATA_SIMPLE_ICONS", "")] if p),
    XDG_DATA_HOME / "strata/simple-icons", Path("/usr/share/strata/simple-icons"),
]

# pad colour families the app hue is matched against (GNOME palette, index 2 = main)
PAD_FAMS = ["blue", "green", "yellow", "orange", "red", "purple", "brown"]

GLYPH_BOX = (32, 16, 64, 64)  # the raised symbol, over the pad's top face, clear of the canvas top
DEPTH = 6
PAD_LEAN = 20.0   # most a pad's hue leans toward the seed, in degrees
PAD_CHROMA = 0.85
PAD_MAX_L = 0.70  # a paler pad (yellow) would lose the white glyph
PAD_SIDE_DL = 0.08
# Vivid (content scheme): a light glyph in the app's hue on a deep pad of it
VIVID_FACE_L = 0.90
VIVID_FACE_SIDE_L = 0.74
VIVID_PAD_L = 0.50
VIVID_STOPS = 3     # wallpaper swatches in the glyph's gradient
VIVID_FACE_C = 0.13  # most chroma a glyph stop takes (light tones clip earlier)


def simple_icons_dir() -> Path | None:
    for d in SIMPLE_ICONS:
        if (d / "icons").is_dir():
            return d / "icons"
        if d.is_dir() and any(d.glob("*.svg")):
            return d
    return None


def slug(text: str) -> str:
    """Simple Icons' file name for a title: lower case, letters and digits only."""
    text = text.lower().replace("+", "plus").replace(".", "dot").replace("&", "and")
    return re.sub(r"[^a-z0-9]", "", text)


class Glyphs:
    """Finds an app's glyph. `roots` are icon theme folders (MoreWaita) and
    hicolor folders; both are searched for symbolic/apps/<name>-symbolic.svg
    and scalable/apps/<name>-symbolic.svg."""

    def __init__(self, hicolor: list[Path], theme_roots: list[Path]):
        self.hicolor = [h for h in hicolor if h.is_dir()]
        self.themes = [t for t in theme_roots if t.is_dir()]
        self.simple = simple_icons_dir()

    @staticmethod
    def _symbolic(roots: list[Path], names: list[str]) -> Path | None:
        for root in roots:
            for sub in ("symbolic/apps", "scalable/apps", "apps/symbolic", "apps/scalable"):
                d = root / sub
                if not d.is_dir():
                    continue
                for n in names:
                    p = d / f"{n}-symbolic.svg"
                    if p.is_file():
                        return p
        return None

    def find(self, names: list[str], label: str) -> Path | None:
        """names: the icon name and its variants; label: the launcher's Name."""
        p = self._symbolic(self.hicolor, names) or self._symbolic(self.themes, names)
        if p or self.simple is None:
            return p
        for cand in [label, *names]:
            s = slug(cand)
            if s and (self.simple / f"{s}.svg").is_file():
                return self.simple / f"{s}.svg"
        return None


def _family(hue: float | None, key: str) -> str:
    """The pad family nearest the app's hue; a stable pick per app when the art is neutral."""
    if hue is None:
        return ["blue", "purple", "green", "orange", "red", "yellow"][zlib.crc32(key.encode()) % 6]
    best, bd = "blue", 999.0
    for fam in PAD_FAMS:
        _, _, h = to_oklch(*parse_color(GNOME[fam][2])[0])
        d = hue_dist(hue, h)
        if d < bd:
            best, bd = fam, d
    return best


def _pad(scheme: Scheme, fam: str) -> tuple[str, str]:
    """The pad's top and side colours for a family."""
    if scheme.name == "mono":
        top, side = scheme.remap(GNOME[fam][2]), scheme.remap(GNOME[fam][4])
        if to_oklch(*parse_color(top)[0])[0] > 0.72:
            top = scheme.remap(GNOME[fam][3])
        return top, side
    L, C, h = to_oklch(*parse_color(GNOME[fam][2])[0])
    L = min(L, PAD_MAX_L)
    h = harmonize(h, scheme.seed_hue, PAD_LEAN)
    C *= PAD_CHROMA
    return (fmt_hex(oklch_to_srgb_clamped(L, C, h)),
            fmt_hex(oklch_to_srgb_clamped(L - PAD_SIDE_DL, C, h)))


def _vivid(scheme: Scheme, fam: str, hue: float | None) -> tuple[str, str, list[str], str]:
    """Pad top, pad side, glyph face stops and glyph side for the content scheme.
    The pad is the wallpaper swatch nearest the app's hue (its family's when the
    art is neutral); the face stops are the other swatches, so the emblem is in
    the wallpaper's colours and not one tone of its pad."""
    _, C, fh = to_oklch(*parse_color(GNOME[fam][2])[0])
    h = scheme.swatch_hue(fh if hue is None else hue)
    C *= PAD_CHROMA

    def c(L: float, chroma: float, hh: float = h) -> str:
        return fmt_hex(oklch_to_srgb_clamped(L, chroma, hh))
    others = [] if scheme.palette.achromatic else [
        sw for sw in scheme.palette.swatches if hue_dist(sw.h, h) > 1.0][:VIVID_STOPS]
    if others:
        stops = [c(VIVID_FACE_L, min(VIVID_FACE_C, sw.C * 1.2), sw.h) for sw in others]
        sw0 = others[0]
        side = c(VIVID_FACE_SIDE_L, min(VIVID_FACE_C, sw0.C * 1.2), sw0.h)
    else:
        stops, side = [c(VIVID_FACE_L, C * 0.45)], c(VIVID_FACE_SIDE_L, C * 0.8)
    return c(VIVID_PAD_L, C), c(VIVID_PAD_L - PAD_SIDE_DL, C), stops, side


def _face_gradient(gid: str, stops: list[str], art) -> str:
    """A diagonal gradient over the glyph's own viewBox (userSpaceOnUse, so every
    path of the symbol shares one sweep instead of restarting per shape)."""
    vx, vy, vw, vh = art[0]
    n = len(stops)
    st = "".join(f'<stop offset="{i / (n - 1):.3f}" stop-color="{col}"/>' for i, col in enumerate(stops))
    return (f'<linearGradient id="{gid}" gradientUnits="userSpaceOnUse" '
            f'x1="{vx}" y1="{vy}" x2="{vx + vw}" y2="{vy + vh}">{st}</linearGradient>')


def app_hue(data: bytes | None, kind: str | None) -> float | None:
    if not data:
        return None
    h = dominant_hue(data, kind == "svg")
    return h[0] if h else None


def glyph(scheme: Scheme, svg: bytes, hue: float | None, key: str = "", info: dict | None = None) -> str | None:
    """The slab icon for a glyph, or None when the glyph can't be inlined."""
    art = parse_art(strip_filters(svg.decode("utf-8", "replace")))
    if art is None:
        return None
    pre = f"g{zlib.crc32(key.encode()) & 0xffff:x}"
    fam = _family(hue, key)
    grad = ""
    if scheme.name == "content":
        top, pside, stops, fside = _vivid(scheme, fam, hue)
        if len(stops) > 1:
            grad = _face_gradient(pre + "-face", stops, art)
            face = f"url(#{pre}-face)"
        else:
            face = stops[0]
    else:
        top, pside = _pad(scheme, fam)
        face, fside = scheme.remap(GNOME["light"][0]), scheme.remap(GNOME["light"][3])
    shadow = placed(art, GLYPH_BOX, pre + "h-", "#000000")
    side = placed(art, GLYPH_BOX, pre + "d-", fside)
    front = placed(art, GLYPH_BOX, pre + "a-", face)
    layers = shadow + side + front
    if not _wrap_ok('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">'
                    + layers + "</svg>"):
        return None
    if info is not None:
        info["primary"] = top
    body = (f'<rect x="12" y="52" width="104" height="60" rx="18" fill="{pside}"/>'
            f'<rect x="12" y="44" width="104" height="60" rx="18" fill="{top}"/>'
            '<rect x="12" y="44" width="104" height="60" rx="18" fill="url(#strata-sheen)"/>'
            f'<g transform="translate(0 {DEPTH * 2})" opacity="0.16">{shadow}</g>'
            f'<g transform="translate(0 {DEPTH})">{side}</g>'
            f"{front}")
    cy = (GLYPH_BOX[1] + 112) / 2
    return ('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" '
            'width="128" height="128" viewBox="0 0 128 128">'
            f'<defs>{SHEEN}{grad}</defs><g transform="translate(64 64) scale({FIT_K}) translate(-64 -{cy})">{body}</g></svg>\n')
