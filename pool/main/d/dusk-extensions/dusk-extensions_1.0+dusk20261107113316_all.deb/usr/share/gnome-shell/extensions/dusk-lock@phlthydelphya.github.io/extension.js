// Dusk Lock Screen: the user's Shell theme on the lock screen.
//
// User Themes (user-theme@) runs in the user session only. When the screen
// locks, the Shell disables it, which drops its stylesheet: the lock screen
// shows the session's stock theme. This extension runs on the lock screen
// only ("session-modes": ["unlock-dialog"]). It loads the stylesheet User
// Themes had, found by its "name" key the same way User Themes finds it, so
// the lock screen keeps Dusk in the user's accent (Dusk-<Name>).
//
// Order (extensionSystem.js): on a mode change the Shell disables extensions
// first, then enables. Locking: User Themes drops its theme, then this loads
// it. Unlocking: this drops it, then User Themes loads it again.
//
// It adds no UI and listens to nothing: the lock screen stays the Shell's own.

import Gio from 'gi://Gio';
import GLib from 'gi://GLib';

import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

const USER_THEME_UUID = 'user-theme@gnome-shell-extensions.gcampax.github.com';
const USER_THEME_SCHEMA = 'org.gnome.shell.extensions.user-theme';

function userThemeSettings() {
    let schema = Gio.SettingsSchemaSource.get_default()?.lookup(USER_THEME_SCHEMA, true);
    if (!schema) {
        // The schema ships inside the extension on some systems
        for (const dir of GLib.get_system_data_dirs()) {
            const path = GLib.build_filenamev([dir, 'gnome-shell', 'extensions', USER_THEME_UUID, 'schemas']);
            if (!GLib.file_test(GLib.build_filenamev([path, 'gschemas.compiled']), GLib.FileTest.EXISTS))
                continue;
            const source = Gio.SettingsSchemaSource.new_from_directory(
                path, Gio.SettingsSchemaSource.get_default(), false);
            schema = source.lookup(USER_THEME_SCHEMA, false);
            if (schema)
                break;
        }
    }
    return schema ? new Gio.Settings({settings_schema: schema}) : null;
}

// The theme's gnome-shell.css, where User Themes looks for it (its util.js)
function stylesheetOf(name) {
    const dirs = [
        GLib.build_filenamev([GLib.get_home_dir(), '.themes']),
        GLib.build_filenamev([GLib.get_user_data_dir(), 'themes']),
        ...GLib.get_system_data_dirs().map(dir => GLib.build_filenamev([dir, 'themes'])),
    ];
    const paths = dirs.map(dir => GLib.build_filenamev([dir, name, 'gnome-shell', 'gnome-shell.css']));
    paths.push(...GLib.get_system_data_dirs().map(dir =>
        GLib.build_filenamev([dir, 'gnome-shell', 'theme', `${name}.css`])));
    return paths.find(path => GLib.file_test(path, GLib.FileTest.EXISTS)) ?? null;
}

export default class DuskLockExtension extends Extension {
    enable() {
        let stylesheet = null;
        try {
            const name = userThemeSettings()?.get_string('name');
            stylesheet = name ? stylesheetOf(name) : null;
        } catch (e) {
            console.warn(`dusk-lock: no user theme: ${e}`);
        }
        if (!stylesheet)
            return;
        Main.setThemeStylesheet(stylesheet);
        Main.loadTheme();
        this._loaded = true;
    }

    disable() {
        if (!this._loaded)
            return;
        this._loaded = false;
        Main.setThemeStylesheet(null);
        Main.loadTheme();
    }
}
