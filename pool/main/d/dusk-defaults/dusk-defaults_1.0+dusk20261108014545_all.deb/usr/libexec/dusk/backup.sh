#!/usr/bin/env bash
# Snapshot current GNOME state into ~/dusk-backup/<timestamp>/.
# Progress goes to stderr; the backup path is the only line on stdout.
set -euo pipefail

log() { printf '%s\n' "$*" >&2; }

if ! command -v dconf >/dev/null 2>&1; then
    log "error: dconf not found"
    exit 1
fi

TS="$(date +%Y%m%d-%H%M%S)"
BK="$HOME/dusk-backup/$TS"
mkdir -p "$BK"

dconf dump /org/gnome/ > "$BK/dconf-org-gnome.ini"
log "dconf dump -> $BK/dconf-org-gnome.ini"

# Custom keybinding list (the launcher keybinding is appended to it by the
# user via the owner-run adopt command). Empty file = key was unset.
dconf read /org/gnome/settings-daemon/plugins/media-keys/custom-keybindings > "$BK/custom-keybindings.txt"
log "custom keybindings -> $BK/custom-keybindings.txt"

if command -v gnome-extensions >/dev/null 2>&1; then
    gnome-extensions list --enabled > "$BK/enabled-extensions.txt"
    log "enabled extensions -> $BK/enabled-extensions.txt"
else
    log "warn: gnome-extensions not found, extension list not saved"
fi

for d in gtk-4.0 gtk-3.0; do
    src="$HOME/.config/$d"
    if [[ -d "$src" ]]; then
        cp -a "$src" "$BK/$d"
        log "copied $src -> $BK/$d"
    else
        log "skip: $src missing"
    fi
done

# Flatpak user overrides (configure.sh edits the global one)
FP_OVERRIDES="$HOME/.local/share/flatpak/overrides"
if [[ -d "$FP_OVERRIDES" ]]; then
    cp -a "$FP_OVERRIDES" "$BK/flatpak-overrides"
    log "copied $FP_OVERRIDES -> $BK/flatpak-overrides"
else
    log "skip: $FP_OVERRIDES missing"
fi

printf '%s\n' "$BK"
