#!/usr/bin/python3
"""Desktop-entry overrides for apps whose Icon= is an absolute path.

An icon theme cannot replace `Icon=/snap/firefox/.../default256.png`: GTK loads
the file directly. For those apps this writes a copy of the app's own .desktop
file under the SAME basename (so the desktop file ID, favourites and
"open with" associations stay the same) with only `Icon=` changed to a Dusk
icon name and an `X-Dusk-Override=true` marker added. Everything else is copied
verbatim from the original at run time; nothing from the original is stored in
the repository.

Why the system copy wins: desktop file IDs are resolved by searching
$XDG_DATA_HOME/applications, then each $XDG_DATA_DIRS entry in order, first
match wins (XDG Desktop Entry spec, "Desktop File ID"; GLib's GDesktopAppInfo
does the same). The GNOME session on this machine has
  XDG_DATA_DIRS=/usr/share/ubuntu:/usr/share/gnome:~/.local/share/flatpak/exports/share:
                /var/lib/flatpak/exports/share:/usr/local/share/:/usr/share/:/var/lib/snapd/desktop
so /usr/local/share/applications shadows both /usr/share/applications and
/var/lib/snapd/desktop/applications. The script checks that order before
writing (--system refuses when /usr/local/share does not come before the
original's directory in the session order it is given or finds).

Modes:
  --system   (root, from setup/system/install-system.sh) apps in the catalog's
             "system" table -> /usr/local/share/applications
  --user     (desktop user, from dusk-adopt) apps in the catalog's "user"
             table, whose originals live in ~/.local/share/applications
             already (Chrome PWAs) -> the file is rewritten in place
             (original saved once as <name>.dusk-orig)
  --remove   delete only files carrying X-Dusk-Override=true (and, in --user
             mode, put the saved original back)
  --dry-run  print what would happen, change nothing

Never overrides an entry that already uses a theme icon name, and never
touches a file it did not write (no marker) except the --user in-place case,
where the original is kept next to it.

Usage:
  desktop-overrides.py --system [--dry-run] [--remove] [--map FILE] [--dest DIR]
  desktop-overrides.py --user   [--dry-run] [--remove] [--map FILE]
"""
import argparse
import sys as _sys
_sys.dont_write_bytecode = True
import os
import re
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
MARKER = 'X-Dusk-Override'
DEFAULT_DATA_DIRS = ['/usr/local/share', '/usr/share']
# Directories the visible-app audit always scans (task list), whatever the env says.
EXTRA_DIRS = [
    '~/.local/share/flatpak/exports/share',
    '/var/lib/flatpak/exports/share',
    '/usr/local/share',
    '/usr/share',
    '/var/lib/snapd/desktop',
]
SYSTEM_DEST = Path('/usr/local/share/applications')


# ------------------------------------------------------------ desktop entries

def data_dirs(env=None):
    """Application directories in lookup order (first match of an ID wins)."""
    env = os.environ if env is None else env
    home = Path(env.get('XDG_DATA_HOME') or Path.home() / '.local/share')
    dirs = [home] + [Path(d) for d in (env.get('XDG_DATA_DIRS') or ':'.join(DEFAULT_DATA_DIRS)).split(':') if d]
    for d in EXTRA_DIRS:
        p = Path(os.path.expanduser(d))
        if all(p.resolve() != q.resolve() for q in dirs):
            dirs.append(p)
    out = []
    for d in dirs:
        a = (d / 'applications')
        if all(a.resolve() != o.resolve() for o in out):
            out.append(a)
    return out


def parse(path):
    """Unlocalised keys of the [Desktop Entry] group, or None."""
    try:
        text = Path(path).read_text(encoding='utf-8')
    except (OSError, UnicodeDecodeError):
        return None
    group, entry = None, {}
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith('#'):
            continue
        if s.startswith('[') and s.endswith(']'):
            group = s[1:-1]
            continue
        if group == 'Desktop Entry' and '=' in s:
            k, v = s.split('=', 1)
            k = k.strip()
            if '[' not in k:
                entry.setdefault(k, v.strip())
    return entry if group is not None or entry else None


def desktop_id(appdir, f):
    return f.relative_to(appdir).as_posix().replace('/', '-')


def _bool(v):
    return (v or '').strip().lower() == 'true'


def _in_path(prog):
    if os.path.isabs(prog):
        return os.access(prog, os.X_OK)
    return shutil.which(prog) is not None


def visible(entry, desktops):
    """(visible?, reason) following the Desktop Entry spec for this desktop."""
    if entry.get('Type') != 'Application':
        return False, 'not Type=Application'
    if _bool(entry.get('Hidden')):
        return False, 'Hidden'
    if _bool(entry.get('NoDisplay')):
        return False, 'NoDisplay'
    only = [x for x in entry.get('OnlyShowIn', '').split(';') if x]
    if only and not set(only) & desktops:
        return False, 'OnlyShowIn'
    if set(x for x in entry.get('NotShowIn', '').split(';') if x) & desktops:
        return False, 'NotShowIn'
    if entry.get('TryExec') and not _in_path(entry['TryExec']):
        return False, 'TryExec missing'
    return True, ''


def scan(env=None):
    """Effective entries: [(desktop_id, path, entry)] for visible apps, one per
    ID (the first in lookup order wins; a Hidden one hides the rest)."""
    env = os.environ if env is None else env
    desktops = set((env.get('XDG_CURRENT_DESKTOP') or 'ubuntu:GNOME').split(':'))
    seen, out = set(), []
    for appdir in data_dirs(env):
        if not appdir.is_dir():
            continue
        for f in sorted(appdir.rglob('*.desktop')):
            did = desktop_id(appdir, f)
            if did in seen:
                continue
            seen.add(did)
            e = parse(f)
            if e is None:
                continue
            ok, _ = visible(e, desktops)
            if ok:
                out.append((did, f, e))
    return out


def find_original(did, skip, env=None):
    """First file for desktop ID `did` in lookup order, ignoring directories in
    `skip` and any file carrying our marker."""
    for appdir in data_dirs(env):
        if any(appdir.resolve() == s.resolve() for s in skip):
            continue
        f = appdir / did
        if f.is_file():
            e = parse(f)
            if e is not None and not _bool(e.get(MARKER)):
                return appdir, f, e
    return None


# ------------------------------------------------------------ override text

ICON_LINE = re.compile(r'^Icon\s*=')


def exec_program(exec_line):
    """Absolute program of an Exec= value, skipping an `env VAR=x` prefix."""
    for tok in exec_line.split():
        if tok == 'env' or ('=' in tok and not tok.startswith('/')):
            continue
        return tok if os.path.isabs(tok) else None
    return None


def override_text(src_text, icon):
    """The original text with every unlocalised Icon= line in every group
    replaced (actions have their own Icon=; an absolute one there would show
    the vendor art in menus) and the marker added to [Desktop Entry]. When the
    original has no TryExec=, one naming its absolute program is added, so the
    copy hides itself if the app is removed before the next reinstall."""
    entry = {}
    group = None
    for line in src_text.splitlines():
        s = line.strip()
        if s.startswith('[') and s.endswith(']'):
            group = s[1:-1]
        elif group == 'Desktop Entry' and '=' in s:
            entry.setdefault(s.split('=', 1)[0].strip(), s.split('=', 1)[1].strip())
    extra = [f'{MARKER}=true']
    prog = exec_program(entry.get('Exec', ''))
    if 'TryExec' not in entry and prog:
        extra.append(f'TryExec={prog}')
    out, group, marked = [], None, False
    for line in src_text.splitlines():
        s = line.strip()
        if s.startswith('[') and s.endswith(']'):
            if group == 'Desktop Entry' and not marked:
                out.extend(extra)
                marked = True
            group = s[1:-1]
            out.append(line)
            continue
        if group is not None and ICON_LINE.match(s):
            v = s.split('=', 1)[1].strip()
            if group == 'Desktop Entry' or os.path.isabs(v):
                out.append(f'Icon={icon}')
                continue
        if group == 'Desktop Entry' and s.split('=', 1)[0].strip() == MARKER:
            continue
        out.append(line)
    if group == 'Desktop Entry' and not marked:
        out.extend(extra)
    return '\n'.join(out) + '\n'


def load_map(path):
    import json
    m = json.loads(Path(path).read_text())
    return m.get('system', {}), m.get('user', {})


def default_map():
    for p in (HERE / 'catalog' / 'overrides.json', HERE / 'icon-overrides.json',
              Path('/usr/share/dusk/icon-overrides.json')):
        if p.is_file():
            return p
    return HERE / 'catalog' / 'overrides.json'


def say(dry, msg):
    print(('would ' if dry else '') + msg)


def write_atomic(dest, text, dry, mode=0o644):
    if dry:
        return
    tmp = dest.with_name(dest.name + '.dusk-tmp')
    tmp.write_text(text, encoding='utf-8')
    os.chmod(tmp, mode)
    os.replace(tmp, dest)


def session_order_ok(dest_dir, src_dir, env):
    """True when dest_dir is searched before src_dir in env's lookup order."""
    order = [d.resolve() for d in data_dirs(env)]
    try:
        return order.index(dest_dir.resolve()) < order.index(src_dir.resolve())
    except ValueError:
        return False


def session_env():
    """XDG_DATA_DIRS of the running GNOME session when root has none of its
    own: /etc/environment.d and systemd generators set it per session, so
    read it from a gnome-shell process. Falls back to os.environ."""
    env = dict(os.environ)
    if 'snapd' in env.get('XDG_DATA_DIRS', ''):
        return env
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            if (p / 'comm').read_text().strip() != 'gnome-shell':
                continue
            for kv in (p / 'environ').read_bytes().split(b'\0'):
                if kv.startswith(b'XDG_DATA_DIRS='):
                    env['XDG_DATA_DIRS'] = kv.split(b'=', 1)[1].decode()
                    return env
        except OSError:
            continue
    return env


def run_system(table, dest, dry, remove):
    env = session_env()
    if remove:
        n = 0
        if dest.is_dir():
            for f in sorted(dest.glob('*.desktop')):
                e = parse(f)
                if e and _bool(e.get(MARKER)):
                    say(dry, f'remove {f}')
                    if not dry:
                        f.unlink()
                    n += 1
        print(f'{n} override(s) {"to remove" if dry else "removed"} from {dest}')
        return 0
    written = 0
    for did, icon in sorted(table.items()):
        # the system copy is for every account: ignore the caller's own
        # ~/.local/share/applications (data_dirs()[0]) when finding the original
        found = find_original(did, skip=[dest, data_dirs(env)[0]], env=env)
        if not found:
            print(f'skip {did}: not installed')
            continue
        src_dir, src, e = found
        cur = e.get('Icon', '')
        if not os.path.isabs(cur):
            print(f'skip {did}: Icon={cur} is a theme name; the theme covers it')
            continue
        if not session_order_ok(dest, src_dir, env):
            print(f'skip {did}: {dest} is not searched before {src_dir} '
                  f'(XDG_DATA_DIRS={env.get("XDG_DATA_DIRS")}); an override there would not win')
            continue
        target = dest / did
        if target.exists():
            te = parse(target)
            if not (te and _bool(te.get(MARKER))):
                print(f'skip {did}: {target} exists and is not a Dusk override')
                continue
        text = override_text(src.read_text(encoding='utf-8'), icon)
        say(dry, f'write {target}  (Icon={icon}, from {src})')
        if not dry:
            dest.mkdir(parents=True, exist_ok=True)
        write_atomic(target, text, dry)
        written += 1
    # overrides from an earlier install whose app left the table
    if dest.is_dir():
        for f in sorted(dest.glob('*.desktop')):
            e = parse(f)
            if f.name not in table and e and _bool(e.get(MARKER)):
                say(dry, f'remove stale {f}')
                if not dry:
                    f.unlink()
    print(f'{written} override(s) {"planned" if dry else "written"} in {dest}')
    return 0


def run_user(table, dry, remove):
    home = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local/share') / 'applications'
    n = 0
    for did, icon in sorted(table.items()):
        f = home / did
        orig = f.with_name(f.name + '.dusk-orig')
        if remove:
            e = parse(f) if f.is_file() else None
            if e and _bool(e.get(MARKER)):
                if orig.is_file():
                    say(dry, f'restore {f} from {orig.name}')
                    if not dry:
                        os.replace(orig, f)
                else:
                    say(dry, f'remove {f}')
                    if not dry:
                        f.unlink()
                n += 1
            continue
        if not f.is_file():
            print(f'skip {did}: not installed for this user')
            continue
        e = parse(f) or {}
        if _bool(e.get(MARKER)):
            if e.get('Icon') == icon:
                print(f'ok   {did}: already overridden')
                continue
        elif not os.path.isabs(e.get('Icon', '')):
            print(f'skip {did}: Icon={e.get("Icon", "")} is a theme name; the theme covers it')
            continue
        src_text = f.read_text(encoding='utf-8')
        if not _bool(e.get(MARKER)) and not orig.exists():
            say(dry, f'save original as {orig}')
            if not dry:
                shutil.copy2(f, orig)
        say(dry, f'rewrite {f}  (Icon={icon})')
        write_atomic(f, override_text(src_text, icon), dry, mode=f.stat().st_mode & 0o777)
        n += 1
    print(f'{n} user override(s) {"planned" if dry else "done"}')
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument('--system', action='store_true')
    mode.add_argument('--user', action='store_true')
    ap.add_argument('--remove', action='store_true')
    ap.add_argument('--dry-run', action='store_true')
    ap.add_argument('--map', type=Path, default=None)
    ap.add_argument('--dest', type=Path, default=SYSTEM_DEST)
    a = ap.parse_args()
    system, user = load_map(a.map or default_map())
    if a.system:
        if not a.dry_run and os.geteuid() != 0:
            sys.exit('--system writes /usr/local/share/applications: run as root, or use --dry-run')
        return run_system(system, a.dest, a.dry_run, a.remove)
    if os.geteuid() == 0:
        sys.exit('--user runs as the desktop user, not root')
    return run_user(user, a.dry_run, a.remove)


if __name__ == '__main__':
    sys.exit(main())
