#!/usr/bin/env bash
# Restore a backup made by backup.sh.
# Usage: restore.sh <backup-dir>
# Current gtk dirs are moved aside to <dir>.dusk-removed (never deleted).
set -euo pipefail

log() { printf '%s\n' "$*" >&2; }
die() { log "error: $*"; exit 1; }

if [[ $# -ne 1 ]]; then
    die "usage: restore.sh <backup-dir>"
fi
BK="$1"

[[ -d "$BK" ]] || die "not a directory: $BK"
[[ -f "$BK/dconf-org-gnome.ini" ]] || die "missing $BK/dconf-org-gnome.ini"
[[ -f "$BK/enabled-extensions.txt" ]] || die "missing $BK/enabled-extensions.txt"

# 1. dconf settings.
dconf load /org/gnome/ < "$BK/dconf-org-gnome.ini"
log "restored dconf /org/gnome/"

# 1b. Custom keybinding list: dconf load only adds keys, so put the saved
# list back exactly (an empty file means it was unset).
CK=/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings
if [[ -f "$BK/custom-keybindings.txt" ]]; then
    ck_saved="$(cat "$BK/custom-keybindings.txt")"
    if [[ -n "$ck_saved" ]]; then
        dconf write "$CK" "$ck_saved"
        log "restored custom keybinding list"
    else
        dconf reset "$CK"
        log "reset custom keybinding list (unset in backup)"
    fi
else
    log "skip: no custom-keybindings.txt in backup"
fi

# 2. GTK config dirs. Current dir is renamed aside, never removed.
for d in gtk-4.0 gtk-3.0; do
    if [[ ! -d "$BK/$d" ]]; then
        log "skip: $BK/$d not in backup"
        continue
    fi
    cur="$HOME/.config/$d"
    if [[ -e "$cur" || -L "$cur" ]]; then
        aside="$cur.dusk-removed"
        if [[ -e "$aside" || -L "$aside" ]]; then
            aside="$aside.$(date +%Y%m%d-%H%M%S)"
        fi
        mv -- "$cur" "$aside"
        log "moved $cur -> $aside"
    fi
    cp -a -- "$BK/$d" "$cur"
    log "restored $cur"
done

# 2b. Flatpak user overrides. Current dir is renamed aside, never removed.
FP_OVERRIDES="$HOME/.local/share/flatpak/overrides"
if [[ -d "$BK/flatpak-overrides" ]]; then
    if [[ -e "$FP_OVERRIDES" ]]; then
        aside="$FP_OVERRIDES.dusk-removed"
        if [[ -e "$aside" ]]; then
            aside="$aside.$(date +%Y%m%d-%H%M%S)"
        fi
        mv -- "$FP_OVERRIDES" "$aside"
        log "moved $FP_OVERRIDES -> $aside"
    fi
    cp -a -- "$BK/flatpak-overrides" "$FP_OVERRIDES"
    log "restored $FP_OVERRIDES"
else
    log "skip: no flatpak-overrides in backup"
fi

# 2c. theme-unifier: put back the theme it had applied before Dusk
if [[ -f "$BK/theme-unifier-applied.txt" ]] && python3 -I -c 'import theme_unifier' 2>/dev/null; then
    prev="$(head -n1 "$BK/theme-unifier-applied.txt")"
    python3 -I -m theme_unifier revert || log "theme-unifier revert reported a problem; see its status"
    python3 -I -m theme_unifier apply "$prev" || log "theme-unifier could not re-apply $prev"
    log "theme-unifier re-applied $prev"
fi

# 3. Extensions: enable exactly the saved list, disable every other installed one.
mapfile -t WANT < "$BK/enabled-extensions.txt"
mapfile -t HAVE < <(gnome-extensions list)

in_want() {
    local u="$1" w
    for w in "${WANT[@]}"; do
        [[ "$w" == "$u" ]] && return 0
    done
    return 1
}

for uuid in "${HAVE[@]}"; do
    [[ -n "$uuid" ]] || continue
    if in_want "$uuid"; then
        if ! gnome-extensions enable "$uuid"; then
            log "warn: could not enable $uuid"
        fi
    else
        if ! gnome-extensions disable "$uuid"; then
            log "warn: could not disable $uuid"
        fi
    fi
done

for uuid in "${WANT[@]}"; do
    [[ -n "$uuid" ]] || continue
    if ! grep -qx -- "$uuid" <<<"$(printf '%s\n' "${HAVE[@]}")"; then
        log "warn: saved extension not installed: $uuid"
    fi
done

log "restore done. Log out and back in to apply shell changes (Wayland)."
