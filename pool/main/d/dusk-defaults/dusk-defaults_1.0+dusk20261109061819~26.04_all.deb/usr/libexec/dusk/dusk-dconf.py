#!/usr/bin/env python3
"""Dusk dconf helper for the system-wide install.

Four modes:

  dusk-dconf.py keyfile [--schemadir DIR]... [--icon-theme NAME] [--cursor-theme NAME]
      Print the dconf system-db keyfile (/etc/dconf/db/local.d/40-dusk) to
      stdout. Holds every setting setup/configure.sh applies. Each value is
      typed and range-checked against its GSettings schema; a key whose schema
      cannot be found is skipped with a warning (a mistyped dconf value is
      silently ignored by GSettings, so nothing unchecked is written).
      --schemadir adds an extension's schemas dir (Blur my Shell and
      global-menu keep theirs in the extension dir; Ubuntu Dock's dash-to-dock
      schema is system-wide).
      --icon-theme has no default here: install-system.sh passes
      `--icon-theme Strata` (Dusk's icon theme, which inherits
      Papirus and Yaru). Without it no icon-theme key is written.

  dusk-dconf.py adopt KEYFILE [--keep-choices] [--dry-run]
      Run as a desktop user. Make that user's dconf follow the Dusk system
      defaults: every key in KEYFILE is reset in the user db (so the system
      value shows through), except accent-color, which is left as the user set
      it (KEEP_USER), and three keys that are merged instead so the user's
      own entries survive:
        /org/gnome/shell/enabled-extensions   user list + Dusk set - Dusk off set
        /org/gnome/shell/disabled-extensions  user list + Dusk off set - Dusk set
        /org/gnome/shell/extensions/blur-my-shell/pipelines
                                              user pipelines + Dusk acrylic
      --keep-choices also keeps the user's own icon theme, cursor and
      wallpapers (USER_CHOICES): dusk-adopt passes it once the user has been
      adopted before, so a reinstall (new keyfile) doesn't put back Dusk's
      defaults over what the user picked since.
      --dry-run prints the dconf commands and changes nothing.

  dusk-dconf.py session-mode
      print the Shell session mode for the Dusk session (modes/dusk.json):
      Ubuntu's mode with Dusk's extensions as mode extensions

  dusk-dconf.py bms-stock [--dry-run]
      adds the loaded Blur my Shell's stock pipelines missing from the user
      value (run every login by dusk-adopt; see cmd_bms_stock)
"""
import importlib.util
import os
import subprocess
import sys

from gi.repository import Gio, GLib

BMS = 'org.gnome.shell.extensions.blur-my-shell'
TA = 'org.gnome.shell.extensions.tiling-assistant'
GM = 'org.gnome.shell.extensions.global-menu'
DASH = 'org.gnome.shell.extensions.dash-to-dock'
IFACE = 'org.gnome.desktop.interface'

# Same lists as setup/configure.sh
DISABLE_UUIDS = [
    # Upstream GNOME Shell Cast: Dusk Cast (cast/) is Dusk's fork of it;
    # both at once would show two cast indicators
    'gnome-shell-cast@oxygenws.com',
    # The Vicinae launcher companion: Dusk's launcher was replaced by the
    # top-bar search (Dusk Shell); install-system.sh removes it
    'vicinae@dagimg-dot',
    # GSConnect: the owner's own phone link replaces it
    'gsconnect@andyholmes.github.io',
    # Now Dusk Shell modules (settings keep their schemas)
    'panel-arranger@phlthydelphya.github.io',
    'qs-arranger@phlthydelphya.github.io',
    'cupertino-dock-lite@rinzler69-wastaken.github.com',
    'wack-shell@rinzler69-wastaken.github.com',
    'dash-to-panel@jderose9.github.com',
    'bottom-dash-panel@fthx',
    'openbar@neuromorph',
    # Ubuntu Dock is the same extension (Dash to Dock, same schema and actors)
    # and Ubuntu ships and updates it; it turns itself off while this is on
    'dash-to-dock@micxgx.gmail.com',
    'launchpad@phlthydelphya.github.io',
    'kiwi@kemma',
    # Now Dusk Shell modules too: the logo menu, Strata's dock badges, the
    # overview's web search and the screenshot UI's Copy Text
    'logomenu@aryan_k',
    'strata-badges@strata',
    'web-search-provider@ubuntu.com',
    'tesseract-ocr@taygun86',
]
ENABLE_UUIDS = [
    'user-theme@gnome-shell-extensions.gcampax.github.com',
    'ubuntu-dock@ubuntu.com',
    'blur-my-shell@aunetx',
    'rounded-window-corners@fxgn',
    'global-menu@unmade.space',
    'ubuntu-appindicators@ubuntu.com',
    'dusk-shell@phlthydelphya.github.io',
    'dusk-lock@phlthydelphya.github.io',
    'tiling-assistant@ubuntu.com',
    'gtk4-ding@smedius.gitlab.com',
    'dusk-cast@phlthydelphya.github.io',
    'staq@phlthydelphya.github.io',
]
# Ubuntu's session-mode extensions that Dusk replaces: Desktop Icons NG
# (gtk4-ding) instead of Ubuntu's, and Dusk Shell's overview web search
# instead of Ubuntu's (a mode extension cannot be switched off, so both would
# answer). Ubuntu Dock stays: it is Dash to Dock.
MODE_REPLACED = ['ding@rastersoft.com', 'web-search-provider@ubuntu.com']
UBUNTU_MODE = '/usr/share/gnome-shell/modes/ubuntu.json'

EXT_ENABLED = '/org/gnome/shell/enabled-extensions'
EXT_DISABLED = '/org/gnome/shell/disabled-extensions'
BMS_PIPELINES = '/org/gnome/shell/extensions/blur-my-shell/pipelines'
MERGED = (EXT_ENABLED, EXT_DISABLED, BMS_PIPELINES)
# Keys the keyfile only defaults: adopt never resets the user's own value.
# accent-color: Dusk's default is blue (Periwinkle; Ubuntu ships orange), but
# the user picks any slot in Settings and dusk-accent switches to the matching
# Dusk-<Name> theme.
# Ptyxis's profile list: a user's own profiles (made before Dusk, or in
# Ptyxis later) stay theirs; Dusk's profile is only the default for an
# account that has none.
KEEP_USER = (
    '/org/gnome/desktop/interface/accent-color',
    '/org/gnome/Ptyxis/default-profile-uuid',
    '/org/gnome/Ptyxis/profile-uuids',
)
# Picks the user makes after adoption (Dusk Shell's Icons row offers Dusk and
# Dusk Plush; Settings > Appearance the wallpapers): Dusk's values apply on the
# first adoption, and a later re-adopt (after a reinstall) keeps the user's.
USER_CHOICES = (
    '/org/gnome/desktop/interface/icon-theme',
    '/org/gnome/desktop/interface/cursor-theme',
    '/org/gnome/desktop/background/picture-uri',
    '/org/gnome/desktop/background/picture-uri-dark',
    '/org/gnome/desktop/background/picture-options',
    '/org/gnome/desktop/screensaver/picture-uri',
)


def warn(msg):
    print(f'warn: {msg}', file=sys.stderr)


# ------------------------------------------------------------------ keyfile

# Ptyxis makes its first profile on first launch, so a new account has no
# profile for dusk-adopt to give the Dusk palette and opacity until Ptyxis
# has run once. Dusk's own profile is the default instead. Ptyxis paints its
# window from the palette at this alpha (its own CSS beats the theme's), so
# below 1 Blur my Shell shows through.
PTYXIS_PROFILE = '0dc8b76edf9a4c50b8315cd9bde49c59'


def ptyxis_settings():
    """(schema, key, gvariant text, path or None) for Dusk's Ptyxis profile."""
    profile = f'/org/gnome/Ptyxis/Profiles/{PTYXIS_PROFILE}/'
    return [
        ('org.gnome.Ptyxis', 'profile-uuids', f"['{PTYXIS_PROFILE}']", None),
        ('org.gnome.Ptyxis', 'default-profile-uuid', f"'{PTYXIS_PROFILE}'", None),
        ('org.gnome.Ptyxis.Profile', 'palette', "'Dusk'", profile),
        ('org.gnome.Ptyxis.Profile', 'opacity', '0.5', profile),
        ('org.gnome.Ptyxis.Profile', 'bold-is-bright', 'true', profile),
    ]


def text_settings(icon_theme, cursor_theme):
    """(schema, key, gvariant text) in configure.sh order."""
    s = [
        (IFACE, 'gtk-theme', "'Dusk'"),
    ]
    if icon_theme:
        s.append((IFACE, 'icon-theme', f"'{icon_theme}'"))
    if cursor_theme:
        s.append((IFACE, 'cursor-theme', f"'{cursor_theme}'"))
    # Dusk wallpaper: one static image for desktop and lock screen (installed
    # by install-system.sh). The owner chose it over the hourly slideshow.
    bg = "'file:///usr/share/backgrounds/dusk/dusk-memphis-plum.png'"
    s += [
        ('org.gnome.desktop.background', 'picture-uri', bg),
        ('org.gnome.desktop.background', 'picture-uri-dark', bg),
        ('org.gnome.desktop.background', 'picture-options', "'zoom'"),
        ('org.gnome.desktop.screensaver', 'picture-uri', bg),
    ]
    s += [
        (IFACE, 'color-scheme', "'prefer-dark'"),
        (IFACE, 'font-name', "'Open Runde 11'"),
        (IFACE, 'document-font-name', "'Open Runde 11'"),
        (IFACE, 'monospace-font-name', "'Monospace 11'"),
        (IFACE, 'enable-hot-corners', 'false'),
        # Default only (Periwinkle): not locked, and adopt keeps the user's
        # choice (KEEP_USER); dusk-accent follows it with the Dusk-<Name> theme
        (IFACE, 'accent-color', "'blue'"),
        ('org.gnome.mutter', 'edge-tiling', 'false'),
        (TA, 'enable-tiling-popup', 'true'),
        (TA, 'enable-layout-picker', 'true'),
        (TA, 'window-gap', '12'),
        (TA, 'single-screen-gap', '12'),
        (TA, 'focus-hint', '0'),
        (f'{BMS}.overview', 'blur', 'true'),
        # Acrylic behind app windows (owner's choice): every app but browsers,
        # whose pages and popups would be see-through. The GTK4 theme makes
        # the window frame translucent ($frame-acrylic in gtk.scss), so the
        # blur shows through the headerbar and sidebar of every window,
        # focused or not, and in the overview. Opacity stays 255: below it
        # Blur my Shell fades the whole window, text included
        (f'{BMS}.applications', 'blur', 'true'),
        (f'{BMS}.applications', 'enable-all', 'true'),
        (f'{BMS}.applications', 'whitelist', '@as []'),
        (f'{BMS}.applications', 'blacklist', repr([
            'Plank', 'Conky', 'google-chrome', 'chromium*', 'Chromium*', 'firefox*',
            'org.mozilla.firefox', 'brave-browser', 'microsoft-edge', 'org.gnome.Epiphany',
            'chrome-*',
            # Apps that draw their own frame and shadow inside a transparent
            # margin (Staq, called Phone Link before, under its old app id):
            # the blur would fill the margin, a dark halo round the window
            'io.github.phlthydelphya.gnomelink', 'io.github.phlthydelphya.staq'])),
        (f'{BMS}.applications', 'pipeline', "'pipeline_dusk_acrylic'"),
        (f'{BMS}.applications', 'static-blur', 'false'),
        (f'{BMS}.applications', 'dynamic-opacity', 'false'),
        (f'{BMS}.applications', 'opacity', '255'),
        (f'{BMS}.applications', 'blur-on-overview', 'true'),
        (f'{BMS}.applications', 'corner-radius', '20'),
        (f'{BMS}.applications', 'rounded-corners', '0'),
        # Rounded Window Corners skips libadwaita apps only; apps that draw
        # their own rounded frame and shadow (Staq, ex Phone Link; Qt) are
        # skipped too, or it adds a second rim and shadow around their
        # transparent margin
        ('org.gnome.shell.extensions.rounded-window-corners-reborn', 'blacklist',
         "['io.github.phlthydelphya.gnomelink', 'io.github.phlthydelphya.staq']"),
        # Chrome rounds only its top corners, so it keeps the extension, but
        # with a 10px radius and no inset: the default 15px corner with a 1px
        # inset clipped the close button's hover circle at the top right
        # Every window keeps its rounded corners when maximized or fullscreen
        # (libadwaita ones through the GTK theme, the rest through this)
        ('org.gnome.shell.extensions.rounded-window-corners-reborn', 'global-rounded-corner-settings',
         "{'padding': <{'left': uint32 1, 'right': uint32 1, 'top': uint32 1, 'bottom': uint32 1}>, 'keepRoundedCorners': <{'maximized': true, 'fullscreen': true}>, 'borderRadius': <uint32 15>, 'smoothing': <0.0>, 'borderColor': <(0.9976811408996582, 0.97333335876464844, 1.0, 1.0)>, 'enabled': <true>}"),
        ('org.gnome.shell.extensions.rounded-window-corners-reborn', 'custom-rounded-corner-settings',
         "{'google-chrome': <{'padding': <{'left': uint32 0, 'right': uint32 0, 'top': uint32 0, 'bottom': uint32 0}>, 'keepRoundedCorners': <{'maximized': true, 'fullscreen': true}>, 'borderRadius': <uint32 10>, 'smoothing': <0.0>, 'borderColor': <(0.9976811408996582, 0.97333335876464844, 1.0, 1.0)>, 'enabled': <true>}>}"),
        # <Super>space opens the top-bar search (Dusk Shell); GNOME's
        # input-source switch moves to the keyboard key and Shift+Super+Space
        ('org.gnome.desktop.wm.keybindings', 'switch-input-source', "['XF86Keyboard']"),
        ('org.gnome.desktop.wm.keybindings', 'switch-input-source-backward',
         "['<Shift><Super>space', '<Shift>XF86Keyboard']"),
        # <Super>v opens the clipboard history (Dusk Shell, like Win+V); the
        # notification list keeps <Super>m (Dusk's drawer is <Super>n)
        ('org.gnome.shell.keybindings', 'toggle-message-tray', "['<Super>m']"),
        (GM, 'blur-popups', 'true'),
        (GM, 'popup-blur-sigma', '37'),
        (GM, 'popup-blur-brightness', '0.55'),
        (GM, 'popup-opacity', '20'),
        (GM, 'popup-corner-radius', '14'),
        (GM, 'hide-popup-arrow', 'true'),
        ('org.gnome.shell.extensions.user-theme', 'name', "'Dusk'"),
        (DASH, 'dock-position', "'BOTTOM'"),
        (DASH, 'extend-height', 'false'),
        (DASH, 'dock-fixed', 'true'),
        (DASH, 'show-apps-at-top', 'true'),
        (DASH, 'show-show-apps-button', 'true'),
        (DASH, 'show-trash', 'true'),
        (DASH, 'show-mounts', 'false'),
        (DASH, 'show-mounts-network', 'false'),
        (DASH, 'show-favorites', 'true'),
        (DASH, 'show-running', 'true'),
        (DASH, 'apply-custom-theme', 'true'),
        (DASH, 'custom-theme-shrink', 'true'),
        (DASH, 'force-straight-corner', 'false'),
        (DASH, 'transparency-mode', "'DEFAULT'"),
        (DASH, 'custom-background-color', 'false'),
        # 52: Strata's slab icons need the room for an app's own artwork to read
        (DASH, 'dash-max-icon-size', '52'),
        (DASH, 'running-indicator-style', "'DEFAULT'"),
        (DASH, 'isolate-workspaces', 'false'),
        ('org.gnome.shell', 'enabled-extensions', repr(ENABLE_UUIDS)),
        ('org.gnome.shell', 'disabled-extensions', repr(DISABLE_UUIDS)),
    ]
    return s


def load_bms_acrylic():
    """Import ../bms-acrylic.py so the acrylic effect chain has one source."""
    here = os.path.dirname(os.path.realpath(__file__))
    path = os.path.join(os.path.dirname(here), 'bms-acrylic.py')
    if not os.path.isfile(path):
        return None
    spec = importlib.util.spec_from_file_location('dusk_bms_acrylic', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def bms_settings(source):
    """Variant-valued Blur my Shell keys, mirroring bms-acrylic.py."""
    acr = load_bms_acrylic()
    if acr is None:
        warn('setup/bms-acrylic.py not found; skipping Blur my Shell acrylic keys')
        return []
    root = source.lookup(BMS, True)
    if root is None:
        warn(f'schema {BMS} not found; skipping Blur my Shell acrylic keys')
        return []
    # Schema default pipelines (pipeline_default) + the two Dusk pipelines
    default = root.get_key('pipelines').get_default_value()
    b = GLib.VariantBuilder.new(GLib.VariantType.new('a{sa{sv}}'))
    for i in range(default.n_children()):
        entry = default.get_child_value(i)
        if not entry.get_child_value(0).get_string().startswith('pipeline_dusk_acrylic'):
            b.add_value(entry)
    for key, title, prefix, radius, alpha in acr.PIPELINES:
        b.add_value(GLib.Variant.new_dict_entry(GLib.Variant('s', key),
                                                acr.pipeline(title, prefix, radius, alpha)))

    V = GLib.Variant
    out = [(BMS, 'pipelines', b.end())]
    panel = f'{BMS}.panel'
    out += [
        (panel, 'blur', V('b', True)),
        (panel, 'pipeline', V('s', 'pipeline_dusk_acrylic')),
        (panel, 'static-blur', V('b', False)),
        (panel, 'override-background', V('b', True)),
        (panel, 'corner-radius', V('i', 16)),
        (panel, 'rounded-corners', V('i', 2)),
        (panel, 'style-panel', V('i', 0)),
    ]
    popup = f'{BMS}.popup'
    out += [
        (popup, 'blur', V('b', True)),
        (popup, 'pipeline', V('s', 'pipeline_dusk_acrylic')),
        (popup, 'static-blur', V('b', False)),
        (popup, 'override-background', V('b', True)),
        (popup, 'preserve-shell-theme', V('b', True)),
        (popup, 'style-popup', V('i', 0)),
    ]
    for key in ('corner-radius', 'quick-settings-corner-radius', 'menu-corner-radius',
                'calendar-corner-radius', 'dialog-corner-radius', 'notification-corner-radius',
                'osd-corner-radius', 'osd-window-corner-radius', 'candidate-corner-radius',
                'resize-popup-corner-radius'):
        out.append((popup, key, V('i', 20)))
    out.append((popup, 'submenu-corner-radius', V('i', 16)))
    dock = f'{BMS}.dash-to-dock'
    out += [
        (dock, 'blur', V('b', True)),
        (dock, 'pipeline', V('s', 'pipeline_dusk_acrylic_dock')),
        (dock, 'static-blur', V('b', False)),
        (dock, 'override-background', V('b', True)),
        (dock, 'style-dash-to-dock', V('i', 0)),
    ]
    return out


def build_source(schemadirs):
    source = Gio.SettingsSchemaSource.get_default()
    for d in schemadirs:
        if os.path.isfile(os.path.join(d, 'gschemas.compiled')):
            source = Gio.SettingsSchemaSource.new_from_directory(d, source, False)
        else:
            warn(f'no gschemas.compiled in {d}; ignoring')
    return source


def cmd_keyfile(argv):
    schemadirs, icon, cursor = [], None, None
    it = iter(argv)
    for a in it:
        if a == '--schemadir':
            schemadirs.append(next(it))
        elif a == '--icon-theme':
            icon = next(it)
        elif a == '--cursor-theme':
            cursor = next(it)
        else:
            sys.exit(f'unknown argument: {a}')
    source = build_source(schemadirs)

    groups = {}   # dconf dir -> [(key, text)]
    order = []
    skipped_schemas = set()

    def put(schema_id, key, value, path=None):
        schema = source.lookup(schema_id, True)
        if schema is None:
            if schema_id not in skipped_schemas:
                warn(f'schema {schema_id} not found; skipping its keys')
                skipped_schemas.add(schema_id)
            return
        if not schema.has_key(key):
            warn(f'{schema_id} has no key {key}; skipping')
            return
        sk = schema.get_key(key)
        vtype = sk.get_value_type()
        if isinstance(value, str):
            value = GLib.Variant.parse(vtype, value, None, None)
        if not value.is_of_type(vtype):
            warn(f'{schema_id} {key}: value type {value.get_type_string()} '
                 f'!= schema type {vtype.dup_string()}; skipping')
            return
        if not sk.range_check(value):
            warn(f'{schema_id} {key}: value out of range; skipping')
            return
        path = path or schema.get_path()
        if path is None:
            warn(f'{schema_id} is relocatable; skipping')
            return
        group = path.strip('/')
        if group not in groups:
            groups[group] = []
            order.append(group)
        # Typed text: dconf stores exactly the schema's type
        groups[group].append((key, value.print_(True)))

    for schema_id, key, text in text_settings(icon, cursor):
        put(schema_id, key, text)
    for schema_id, key, value in bms_settings(source):
        put(schema_id, key, value)
    for schema_id, key, text, path in ptyxis_settings():
        put(schema_id, key, text, path)

    print('# Dusk system defaults. Generated by setup/system/dusk-dconf.py;')
    print('# installed by setup/system/install-system.sh. Do not edit by hand.')
    print('# Applies only to keys a user has not set; dusk-adopt resets those.')
    for group in order:
        print(f'\n[{group}]')
        for key, text in groups[group]:
            print(f'{key}={text}')


# -------------------------------------------------------------------- adopt

def dconf_read(path):
    out = subprocess.run(['dconf', 'read', path], check=True,
                         capture_output=True, text=True).stdout.strip()
    return out or None


def dconf_cmd(dry, *args):
    print('+ dconf ' + ' '.join(GLib.shell_quote(a) for a in args))
    if not dry:
        subprocess.run(['dconf', *args], check=True)


def dconf_reset(dry, path):
    """Reset a key. A locked key (an admin's dconf lock; Dusk itself locks
    nothing) refuses writes; the system value already wins there, so a
    refusal is not an error."""
    print('+ dconf reset ' + GLib.shell_quote(path))
    if dry:
        return
    r = subprocess.run(['dconf', 'reset', path], capture_output=True, text=True)
    if r.returncode != 0:
        warn(f'{path}: reset refused ({r.stderr.strip() or r.returncode}); '
             'key is probably locked, system value applies')


def merge_value(path, system_value, user_text):
    """Return the merged GVariant for one of the MERGED keys."""
    user = GLib.Variant.parse(system_value.get_type(), user_text, None, None)
    if path in (EXT_ENABLED, EXT_DISABLED):
        add = ENABLE_UUIDS if path == EXT_ENABLED else DISABLE_UUIDS
        drop = DISABLE_UUIDS if path == EXT_ENABLED else ENABLE_UUIDS
        cur = [u for u in user.unpack() if u not in drop]
        cur += [u for u in add if u not in cur]
        return GLib.Variant('as', cur)
    # BMS pipelines: user's own pipelines kept, Dusk's replaced
    b = GLib.VariantBuilder.new(GLib.VariantType.new('a{sa{sv}}'))
    for i in range(user.n_children()):
        entry = user.get_child_value(i)
        if not entry.get_child_value(0).get_string().startswith('pipeline_dusk_acrylic'):
            b.add_value(entry)
    for i in range(system_value.n_children()):
        entry = system_value.get_child_value(i)
        if entry.get_child_value(0).get_string().startswith('pipeline_dusk_acrylic'):
            b.add_value(entry)
    return b.end()


def cmd_adopt(argv):
    dry = '--dry-run' in argv
    keep = KEEP_USER + (USER_CHOICES if '--keep-choices' in argv else ())
    args = [a for a in argv if a not in ('--dry-run', '--keep-choices')]
    if len(args) != 1:
        sys.exit('usage: dusk-dconf.py adopt KEYFILE [--keep-choices] [--dry-run]')
    kf = GLib.KeyFile.new()
    kf.load_from_file(args[0], GLib.KeyFileFlags.NONE)
    groups, _ = kf.get_groups()
    for group in groups:
        keys, _ = kf.get_keys(group)
        for key in keys:
            path = f'/{group}/{key}'
            system_value = GLib.Variant.parse(None, kf.get_value(group, key), None, None)
            current = dconf_read(path)
            if path in keep:
                print(f'= {path} kept ({current or "system default"})')
                continue
            if path in MERGED and current is not None:
                try:
                    merged = merge_value(path, system_value, current)
                except GLib.Error as e:
                    warn(f'{path}: cannot parse user value ({e.message}); resetting instead')
                    dconf_reset(dry, path)
                    continue
                if merged.print_(True) == GLib.Variant.parse(
                        system_value.get_type(), current, None, None).print_(True):
                    print(f'= {path} already merged')
                else:
                    dconf_cmd(dry, 'write', path, merged.print_(True))
            else:
                # Reset is idempotent: with no user value it changes nothing
                dconf_reset(dry, path)


BMS_SCHEMA_DIRS = (
    os.path.expanduser('~/.local/share/gnome-shell/extensions/blur-my-shell@aunetx/schemas'),
    '/usr/share/gnome-shell/extensions/blur-my-shell@aunetx/schemas',
)


def cmd_bms_stock(argv):
    """Add the loaded Blur my Shell's stock pipelines missing from the user
    value. Blur my Shell's settings migration copies them from the key's
    default, which Dusk's system keyfile overrides; after a Blur my Shell
    update adds new stock pipelines, the migration reads undefined and the
    extension fails to load ("pipeline is undefined")."""
    dry = '--dry-run' in argv
    d = next((x for x in BMS_SCHEMA_DIRS if os.path.isfile(os.path.join(x, 'gschemas.compiled'))), None)
    if d is None:
        return
    src = Gio.SettingsSchemaSource.new_from_directory(d, Gio.SettingsSchemaSource.get_default(), False)
    schema = src.lookup(BMS, False)
    if schema is None or not schema.has_key('pipelines'):
        return
    stock = schema.get_key('pipelines').get_default_value()  # the schema's own default, not dconf's
    settings = Gio.Settings.new_full(schema, None, None)
    cur = settings.get_value('pipelines')
    have = {cur.get_child_value(i).get_child_value(0).get_string() for i in range(cur.n_children())}
    b = GLib.VariantBuilder.new(GLib.VariantType.new('a{sa{sv}}'))
    for i in range(cur.n_children()):
        b.add_value(cur.get_child_value(i))
    added = []
    for i in range(stock.n_children()):
        entry = stock.get_child_value(i)
        name = entry.get_child_value(0).get_string()
        if name not in have:
            b.add_value(entry)
            added.append(name)
    if not added:
        return
    print(f"dusk-dconf: Blur my Shell stock pipelines {'would be ' if dry else ''}added: {', '.join(added)}",
          file=sys.stderr)
    if not dry:
        settings.set_value('pipelines', b.end())
        Gio.Settings.sync()


def cmd_session_mode(argv):
    """Print the Shell session mode for the Dusk session (modes/dusk.json):
    Ubuntu's mode, with Dusk's extensions as mode extensions (loaded with the
    session; the Extensions app cannot turn them off) in place of the Ubuntu
    ones Dusk replaces, and a dark color scheme."""
    import json
    if argv:
        sys.exit('usage: dusk-dconf.py session-mode')
    try:
        with open(UBUNTU_MODE, encoding='utf-8') as f:
            mode = json.load(f)
    except (OSError, ValueError):
        mode = {'parentMode': 'user'}
    exts = [e for e in mode.get('enabledExtensions', []) if e not in MODE_REPLACED]
    exts += [e for e in ENABLE_UUIDS if e not in exts]
    mode['enabledExtensions'] = exts
    mode['colorScheme'] = 'prefer-dark'
    print(json.dumps(mode, indent=4))


def main():
    if len(sys.argv) < 2 or sys.argv[1] in ('-h', '--help'):
        print(__doc__, file=sys.stderr)
        sys.exit(0 if len(sys.argv) >= 2 else 2)
    mode, rest = sys.argv[1], sys.argv[2:]
    if mode == 'keyfile':
        cmd_keyfile(rest)
    elif mode == 'adopt':
        cmd_adopt(rest)
    elif mode == 'bms-stock':
        cmd_bms_stock(rest)
    elif mode == 'session-mode':
        cmd_session_mode(rest)
    else:
        sys.exit(f'unknown mode: {mode}')


if __name__ == '__main__':
    main()
