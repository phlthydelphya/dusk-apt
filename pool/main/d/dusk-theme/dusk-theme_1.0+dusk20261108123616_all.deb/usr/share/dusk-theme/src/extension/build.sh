#!/usr/bin/env bash
# Builds the Dusk Shell extension in place: the stylesheets from
# stylesheet.scss (tokens from ../tokens) and the compiled settings schema.
#   stylesheet.css          dusk style, blue (Periwinkle, default): the
#                           shell loads it
#   stylesheet-<id>.css     every other variant (gitignored): <slot> for the
#                           dusk style, atomic-<slot> for Atomic Suede.
#                           accent.js swaps to it from accent-color and the
#                           extension's style key
#   stylesheet-<id>-light.css  the same in the light scheme (DUSK_SCHEME=light),
#                           blue too (stylesheet-blue-light.css); accent.js
#                           uses them while color-scheme is not prefer-dark
# Usage: build.sh [VARIANT...]   (default: every variant and the schema;
#                                 with variants: only those stylesheets)
set -euo pipefail

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

for tool in sassc glib-compile-schemas python3; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        echo "build.sh: $tool not found" >&2
        exit 1
    fi
done

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

for scheme in dark light; do
while IFS=$'\t' read -r id style slot _name _theme _stem; do
    # Arguments name dark ids; each builds its -light twin too
    if (( $# )) && ! printf '%s\n' "$@" | grep -qx -- "${id%-light}"; then
        continue
    fi
    if [[ "$id" == blue ]]; then
        out="$here/stylesheet.css"
    else
        out="$here/stylesheet-$id.css"
    fi
    # The wallpaper slot's colours come from $DUSK_SEED (tokens/dusk_seed.py)
    seed_line=""
    [[ "$slot" == wallpaper ]] && seed_line="$(DUSK_SCHEME="$scheme" python3 -I "$here/../tokens/dusk_tokens.py" seed-scss "$style")"
    printf "\$dusk-scheme: %s;\n\$dusk-style: %s;\n\$dusk-accent-slot: %s;\n%s\n@import \"%s\";\n" "$scheme" "$style" "$slot" "$seed_line" "$here/stylesheet.scss" > "$tmp/$id.scss"
    sassc --style expanded "$tmp/$id.scss" "$out"
    echo "built $out"
done < <(DUSK_SCHEME="$scheme" python3 -I "$here/../tokens/dusk_tokens.py" variants)
done

(( $# )) && exit 0
glib-compile-schemas --strict "$here/schemas"
echo "built $here/schemas/gschemas.compiled"
