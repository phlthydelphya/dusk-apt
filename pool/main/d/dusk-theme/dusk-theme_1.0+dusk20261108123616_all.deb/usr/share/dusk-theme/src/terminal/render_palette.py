#!/usr/bin/env python3
"""Render terminal/Dusk.palette.in for one variant: the [Dark] section from
the dark tokens and the [Light] section from the light ones.

dusk_tokens.render reads the scheme from $DUSK_SCHEME, so the template is
rendered once per scheme and each section is taken from its own pass.

Usage: render_palette.py SLOT IN OUT [STYLE]
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'tokens'))
import dusk_tokens  # noqa: E402


def render(slot, text, style='dusk'):
    out = {}
    saved = os.environ.get('DUSK_SCHEME')
    try:
        for scheme in ('dark', 'light'):
            os.environ['DUSK_SCHEME'] = scheme
            out[scheme] = dusk_tokens.render(text, slot, style=style)
    finally:
        if saved is None:
            os.environ.pop('DUSK_SCHEME', None)
        else:
            os.environ['DUSK_SCHEME'] = saved
    head = out['dark'].split('[Light]\n')[0]
    return head + '[Light]\n' + out['light'].split('[Light]\n')[1]


def main(argv):
    if len(argv) not in (3, 4):
        sys.exit(__doc__.strip().splitlines()[-1])
    slot, src, dest = argv[:3]
    style = argv[3] if len(argv) == 4 else 'dusk'
    Path(dest).write_text(render(slot, Path(src).read_text(encoding='utf-8'), style), encoding='utf-8')


if __name__ == '__main__':
    main(sys.argv[1:])
