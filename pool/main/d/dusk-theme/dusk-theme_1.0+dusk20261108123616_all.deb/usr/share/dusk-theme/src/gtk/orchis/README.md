# Orchis (vendored) for Dusk

GTK3 and GTK4 SCSS from the Orchis GTK theme by vinceliuice
(https://github.com/vinceliuice/Orchis-theme), tag `2022-10-19`,
commit `1acc747f1ce2423d3a4cc00e118a58159c956c8d`. License: GPL-3.0, see `COPYING`.
Dusk's GTK stylesheets that are built from these sources are GPL-3.0 as well.

Only what the Dusk build needs is kept: `src/_sass/` (shared + `gtk/`), the dark
slider / selection-mode PNGs and `scalable/` SVGs from `src/gtk/assets/`
(in `assets-src/`). Entry files `gtk-3.0.scss` / `gtk-4.0.scss` replace upstream's
`src/gtk/{3.0,4.0}/gtk-Dark.scss`.

## Dusk changes

- `_sass/_dusk.scss` (new): imports `tokens/_dusk.scss` and re-exports tokens as
  `$dusk-*`, plus `$dusk-selection-item` (selected-item tint, rgba($accent, 0.22)).
- `_colors.scss`: Orchis's basic/misc/text colors set from Dusk tokens (frame
  `$background`/`$titlebar`, content `$base`, `$surface` = popover, buttons and
  entries `$raised`, primary = `$accent-bg`, new `$primary-text` = `$accent`,
  status colors, borders). Every `color: $primary` became `color: $primary-text`.
- `_variables.scss`: radii from tokens (`$r-window`, `$r-control`, `$r-card`, `$r-pill`).
  `$window-radius - $space-size` became `$r-card` everywhere.
- `_tweaks.scss`: `tweaks-temp` import renamed to `tweaks`; `$check_radio: 'primary'`;
  new `$dusk-frame-layout: 'true'`, which replaces every
  `$topbar == 'dark' and $variant == 'light'` check (Orchis's dark-titlebar layout,
  used here with the dark variant).
- `gtk/apps/_gnome-4.0.scss`: Nautilus sidebar ported to Nautilus 49
  (`.sidebar-pane toolbarview > placessidebar > scrolledwindow > viewport
  list.navigation-sidebar > row`), the 9-slice moved from `row > revealer > box`
  to the row itself (spans icon + label to the card edge), box padding adjusted
  for the tab, list metrics enlarged with the tab (32px padding, -16px rows, 72px
  labels: 16px curve + 40px pill + 16px curve, so the first tab meets the card's
  16px corner in one S), panes
  transparent, headerbar highlight removed, the old per-view content insets disabled
  (the generic content card in `../gtk-4.0/gtk.scss` replaces them); fixed an
  invalid `scrolledwindow.frame >` selector.
- `gtk/apps/_libadwaita.scss`: `gtkmix()` (rejected by GTK) replaced with Sass `mix()`.
- `gtk/_common-4.0.scss`: fixed the aboutdialog selector that compiled to a
  dangling `>`.
- `tools/render-assets.py` (new) replaces upstream's Inkscape render scripts: draws
  `row-selected-dark{,@2}.png` (the shape of the `row-selected` group in upstream
  `src/gtk/assets.svg`, enlarged to 144x72 with 16px inward curves; tab = `$base`,
  outside = frame) and recolors the Orchis-blue PNGs to `$accent-bg`.
- `assets-src/scalable/dusk-window-*-symbolic.svg` (new, Dusk-original): window
  button glyphs.
