#!/usr/bin/env bash
# Builds terminal/Dusk.palette (Ptyxis) from Dusk.palette.in and ../tokens.
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
command -v python3 >/dev/null || { echo "python3 not found" >&2; exit 1; }
python3 -I "$here/render_palette.py" blue "$here/Dusk.palette.in" "$here/Dusk.palette"
echo "built $here/Dusk.palette"
