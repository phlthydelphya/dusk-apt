#!/usr/bin/env python3
"""Seed Dusk's colours from a wallpaper, the Strata way.

Strata (strata/, Dusk's icon engine) reads a wallpaper's colours: the strongest
becomes the seed, and every GNOME palette colour is remapped toward it (scheme
harmony, content or mono; greys take a faint seed tint; status colours only
lean 8 degrees). This module applies the same remap to Dusk's own tokens and
writes a seed file for the `wallpaper` accent slot (tokens/dusk_tokens.py,
tokens/_dusk.scss):

    accent      Strata's remap of GNOME's dark accent colour (#78aeed)
    accent-bg   Strata's remap of GNOME's accent background (#3584e4)
    frame, base, card, popover, raised
                Dusk's surfaces for the style, turned to the seed hue with at
                least Strata's grey tint (lightness steps kept; see surface())
    error, success, warning
                Dusk's status colours, leaned toward the seed

then holds them to the contrast floors in tokens/_dusk.scss: $accent and the
status colours are lightened until they meet $contrast-accent /
$contrast-status on the tinted $card, $accent-bg darkened until
$accent-fg on it meets $contrast-accent-bg. Hue and chroma are kept.

The light scheme's colours go under "light" in the same file: Dusk's light
surfaces turned to the seed hue the same way, $accent (from the accent-bg
role) and the status colours darkened until they meet the light floors on
the light $card, $accent-bg as in the dark scheme.

A mood (MOODS, Dusk Shell's `mood` key) picks how loud the whole desktop is:
the Strata scheme, vibrancy and grey tint for the icons and these colours,
whether the surfaces take the seed hue at all, and the material tokens
(translucency, slab depth, transition times) the seed file carries to
tokens/_dusk.scss. Balanced's values are the stock ones.

CLI:
    dusk_seed.py WALLPAPER OUT.json [--style dusk|atomic] [--mood calm|balanced|vivid]
                 [--scheme harmony|content|mono] [--vibrancy V] [--tint T]

Strata is imported from the repo (../strata) when present, else as installed.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
_REPO_STRATA = HERE.parent / 'strata'
if (_REPO_STRATA / 'strata' / '__init__.py').is_file():
    sys.path.insert(0, str(_REPO_STRATA))
sys.path.insert(0, str(HERE))

import dusk_tokens  # noqa: E402
from strata.color import oklch_to_srgb_clamped, fmt_hex, parse_color, to_oklch  # noqa: E402
from strata.palette import extract  # noqa: E402
from strata.scheme import SCHEMES, Scheme  # noqa: E402

# GNOME colours Strata remaps for these roles (strata/strata/gtk.py, dark)
GNOME_ACCENT = '#78aeed'     # accent-color, dark
GNOME_ACCENT_BG = '#3584e4'  # accent-bg-color
SURFACES = ('frame', 'base', 'card', 'popover', 'raised')
STATUS = ('error', 'success', 'warning')

# Moods. scheme, vibrancy, tint: Strata's (strata/strata/scheme.py; vibrancy
# None measures it from the wallpaper). flat: surfaces keep Dusk's stock greys
# (vivid too: its colour is in the icons and accent, windows stay neutral).
# surface-c: the least OKLCh chroma a surface takes at the seed hue (Strata's
# grey tint is at most 0.014, under most of Dusk's own surface chroma).
# material: tokens/_dusk.scss values ($panel-alpha, $float-alpha and
# $acrylic-card alphas, $slab-depth, $slab-depth-card, $dur-hover,
# $dur-select, $notch-tint: the search notches' accent tint, Vivid's only
# coloured surface); balanced's are the stock values there.
MOODS = {
    'calm': {'scheme': 'mono', 'vibrancy': 0.6, 'tint': 0.3, 'flat': True, 'surface-c': 0.0,
             'material': {'mood-panel-a': 0.30, 'mood-float-a': 0.85, 'mood-acrylic-a': 0.60,
                          'mood-slab': '1px', 'mood-slab-card': '2px',
                          'mood-dur-hover': '90ms', 'mood-dur-select': '200ms'}},
    'balanced': {'scheme': 'harmony', 'vibrancy': None, 'tint': 0.6, 'flat': False, 'surface-c': 0.0,
                 'material': {'mood-panel-a': 0.12, 'mood-float-a': 0.72, 'mood-acrylic-a': 0.45,
                              'mood-slab': '2px', 'mood-slab-card': '3px',
                              'mood-dur-hover': '120ms', 'mood-dur-select': '280ms'}},
    'vivid': {'scheme': 'content', 'vibrancy': 1.2, 'tint': 0.85, 'flat': True, 'surface-c': 0.0,
              'material': {'mood-panel-a': 0.06, 'mood-float-a': 0.62, 'mood-acrylic-a': 0.35,
                           'mood-slab': '3px', 'mood-slab-card': '4px',
                           'mood-dur-hover': '140ms', 'mood-dur-select': '320ms',
                           'mood-notch-tint': 0.18}},
}
DEFAULT_MOOD = 'balanced'


def _rgb(hexs):
    rgb, _ = parse_color(hexs)
    return rgb


def luminance(hexs):
    def lin(c):  # Strata's parse_color gives channels in 0..1
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (lin(c) for c in _rgb(hexs))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    la, lb = luminance(a), luminance(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def fit(hexs, against, floor, lighten):
    """Move `hexs` in OKLab lightness (hue and chroma kept, gamut clamped)
    until it has `floor` contrast with `against`."""
    L, C, h = to_oklch(*_rgb(hexs))
    out = hexs
    for _ in range(200):
        if contrast(out, against) >= floor:
            return out
        L = min(1.0, L + 0.005) if lighten else max(0.0, L - 0.005)
        out = fmt_hex(oklch_to_srgb_clamped(L, C, h))
        if L in (0.0, 1.0):
            break
    if contrast(out, against) < floor:
        raise ValueError(f'cannot fit {hexs} to {floor}:1 against {against}')
    return out


def surface(s, hexs, min_c=0.0):
    """A Dusk surface turned to the seed hue. Strata tints greys faintly and
    re-hues coloured greys (Atomic Suede's slate) by family; Dusk's surfaces
    straddle that line, so each one keeps its own lightness and the larger of
    its own chroma and Strata's grey tint at that lightness, and takes the
    seed hue: the steps between surfaces stay as the tokens set them.
    `min_c` raises that chroma (a mood's surface-c)."""
    L, C, _ = to_oklch(*_rgb(hexs))
    grey = fmt_hex(oklch_to_srgb_clamped(L, 0.0, 0.0))
    _, tint_c, _ = to_oklch(*_rgb(s.role(grey)))
    return fmt_hex(oklch_to_srgb_clamped(L, max(C, tint_c, min_c), s.seed_hue))


def mood_scheme(pal, mood=DEFAULT_MOOD):
    """The Strata Scheme for `mood` over palette `pal`: the icons and the
    theme take the same one, so they match."""
    m = MOODS[mood]
    return Scheme(pal, m['scheme'], vibrancy=m['vibrancy'], tint=m['tint'])


def seed(wallpaper, style='dusk', scheme='harmony', vibrancy=None, tint=0.6, mood=None):
    """Dusk's colours seeded from the wallpaper image at `wallpaper`."""
    return seed_palette(extract(wallpaper), style, scheme, vibrancy, tint,
                        source='wallpaper', wallpaper=str(wallpaper), mood=mood)


def seed_palette(pal, style='dusk', scheme='harmony', vibrancy=None, tint=0.6,
                 source='wallpaper', wallpaper='', mood=None):
    """Dusk's colours seeded from a Strata palette. dusk-wallpaper passes the
    wallpaper's, or in accent mode a palette of the chosen accent alone
    (source 'accent:<slot>'), so the Shell and GTK themes take the same
    Strata remap as the icons either way. A `mood` (MOODS) replaces scheme,
    vibrancy and tint with its own and adds its surfaces and material."""
    stock = dusk_tokens.tokens('blue', style=style, scheme='dark')
    m = MOODS[mood] if mood else {'flat': False, 'surface-c': 0.0, 'material': {}}
    if mood:
        scheme, vibrancy, tint = m['scheme'], m['vibrancy'], m['tint']
    s = Scheme(pal, scheme, vibrancy=vibrancy, tint=tint)

    def surf(hexs):
        return hexs if m['flat'] else surface(s, hexs, m['surface-c'])

    out = {k: surf(stock[k]).upper() for k in SURFACES}
    card = out['card']
    out['accent'] = fit(s.role(GNOME_ACCENT), card, float(stock['contrast-accent']), lighten=True).upper()
    out['accent-bg'] = fit(s.role(GNOME_ACCENT_BG), stock['accent-fg'],
                           float(stock['contrast-accent-bg']), lighten=False).upper()
    for k in STATUS:
        out[k] = fit(s.semantic(stock[k]), card, float(stock['contrast-status']), lighten=True).upper()
    lstock = dusk_tokens.tokens('blue', style=style, scheme='light')
    light = {k: surf(lstock[k]).upper() for k in SURFACES}
    lcard = light['card']
    light['accent-bg'] = out['accent-bg']
    light['accent'] = fit(out['accent-bg'], lcard, float(lstock['contrast-accent']), lighten=False).upper()
    for k in STATUS:
        light[k] = fit(s.semantic(lstock[k]), lcard, float(lstock['contrast-status']), lighten=False).upper()
    summary = s.summary()
    return {
        'style': style,
        'name': 'Wallpaper',
        **out,
        'light': light,
        # what it came from ('wallpaper', or 'accent:<slot>'; dusk-accent
        # applies the theme only while this matches the current setting), and
        # GNOME's nearest accent preset (accent-color)
        'source': source,
        'wallpaper': wallpaper,
        'scheme': scheme,
        'seed': summary['seed'],
        'vibrancy': summary['vibrancy'],
        'tint': tint,
        'accent_preset': summary['accent_preset'],
        'mood': mood or '',
        **m['material'],
    }


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split('\n\n')[0])
    ap.add_argument('wallpaper', type=Path)
    ap.add_argument('out', type=Path)
    ap.add_argument('--style', choices=dusk_tokens.STYLES, default='dusk')
    ap.add_argument('--scheme', choices=SCHEMES, default='harmony')
    ap.add_argument('--vibrancy', type=float)
    ap.add_argument('--tint', type=float, default=0.6)
    ap.add_argument('--mood', choices=tuple(MOODS), help='overrides --scheme, --vibrancy and --tint')
    a = ap.parse_args(argv)
    data = seed(a.wallpaper, a.style, a.scheme, a.vibrancy, a.tint, mood=a.mood)
    a.out.parent.mkdir(parents=True, exist_ok=True)
    tmp = a.out.with_suffix(a.out.suffix + '.tmp')
    tmp.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    tmp.replace(a.out)
    print(json.dumps({k: data[k] for k in ('seed', 'accent', 'accent-bg', 'base', 'accent_preset')}))


if __name__ == '__main__':
    main()
