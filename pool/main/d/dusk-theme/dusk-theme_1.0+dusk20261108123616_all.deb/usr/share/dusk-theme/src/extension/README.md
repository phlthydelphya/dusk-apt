# Dusk Shell

Companion GNOME Shell 51 extension for the Dusk theme
(`dusk-shell@phlthydelphya.github.io`, schema `org.gnome.shell.extensions.dusk-shell`).

## Features

| Module | What it does |
|---|---|
| `startMenu.js` + `appMenu.js` | Dash to Dock's Show Apps button becomes the pill start button (`dusk-start-button`). It and Super alone open the Dusk app menu above the dock. A right-click on it (or the Menu key) opens Dismiss All Notifications: every notification is dismissed and every app's dock badge count, launcher counts included, is marked seen until new ones come in. Docks whose Show Apps icon has a menu of its own (Dash to Dock) keep that menu instead. The menu has a search field, drawer tabs, and three views of All, picked beside the tabs (`app-menu-view`): category folders made from each app's freedesktop Categories, opened in the menu's pane; a packed 4-column A–Z grid; and the A–Z grid in rows under letter headers, with the letter index. The search hangs from the card's top edge like the top-bar search notch. Folder shortcuts sit in the footer. |
| `panelLayout.js` | Moves the clock to the right, after quick settings. Hides Activities. The clock popup keeps the clock, the calendar and its events, with a quick add for a one-hour event on the selected day in the default calendar (`data/calendar-quick-add.py`, Evolution Data Server). Notifications stay out. |
| `drawer.js` | A notification drawer that slides in from the right edge. It holds the shell's notification list and Clear button, a Do Not Disturb switch, world clocks and weather. Super+N or the dot opens it. Esc or a click outside closes it. |
| `notificationActions.js` | Dismiss an app’s notifications from its dock icon menu or an expanded notification group. The dock menu offers it for any app with an active badge count, including one that comes only from the app’s launcher count; dismissing clears that count too. |
| `messageExpand.js` | Makes a notification's expand button show more of its body. In Shell 51 the body wraps and ellipsizes, which Pango keeps to one line, so expanding grew nothing (stock Shell too). While a message is expanded its body is not ellipsized; the shell still caps it at 6 lines. |
| `notifDot.js` | The last item in the panel. Its states are `dusk-notif-dot--unread`, `--empty` and `--dnd`. A click toggles the drawer. |
| `inlineReply.js` | Reply inside a notification, like a Windows toast. Apps opt in: GNOME Shell reports the capability `x-dusk-inline-reply`, and a notification with the action `inline-reply` and the hint `x-dusk-inline-reply` gets an entry and a Send button (`dusk-reply`). The shell sends Plasma's `NotificationReplied(id, text)` from `org.gnome.Shell`, because GNOME's notification proxy doesn't pass that signal on. Staq uses it. |
| `gestures.js` | Turns off the shell's swipe trackers for the overview, workspace switching, workspaces view and app grid. The lock screen and on-screen keyboard swipes stay on. |
| `iconMarks.js` | Dusk marks from the icon theme. When the icon theme has `dusk-start` (Dusk-Plush does), the start button shows it instead of the shell theme's accent mark; when it has `dusk-logo`, the logo menu shows it. Both follow icon theme changes. |
| `logoMenu.js` + `forceQuit.js` | The logo menu at the left of the top bar (formerly the Logo Menu extension, `logomenu@aryan_k`; it keeps that extension's panel role, `LogoMenu`): About This Computer (About Dusk when installed), System Settings, Activities, App Grid, App Hub, System Monitor, Terminal, Extensions, Force Quit App (click a window; Esc or right-click cancels), Sleep, Restart, Shut Down, Lock Screen and Log Out. App items are left out when none of their apps is installed. `forceQuit.js` is Logo Menu's force quit (MIT, notice in the file). |
| `strataBadges.js` | Dock notification badges as Strata slabs in each app's own colour, read from `<icon theme>/strata-colors.json` (formerly `strata-badges@strata`). |
| `webSearch.js` | "Search the web" in the overview's search, through `search-web-url` (DuckDuckGo by default). Replaces `web-search-provider@ubuntu.com`, which always used Google. Left out when no browser handles https or the browser is GNOME Web. |
| `desktopMenu.js` | One desktop menu: a right click on the empty desktop opens the Shell's desktop menu with the desktop icons' (gtk4-ding) items above Change Background, Display Settings and Settings, so it has the Shell's acrylic. Ding sends its menu (labels, enabled and checked state) as JSON over `org.gnome.Shell.Extensions.DuskShell.DesktopMenu.Show`; items activate ding's actions on `com.desktop.ding`. Needs ding patched by `setup/system/patch-ding.py` (install-system.sh does it); without this module ding shows its own menu. The icons' own menu stays ding's. |
| `ocr.js` | Copy Text: a toggle in the screenshot UI (Print Screen) that reads the selection, screen or window with Tesseract and copies the text instead of saving a screenshot; nothing is written to disk. Languages: `ocr-languages`, or all installed ones. Needs `tesseract-ocr`; replaces `tesseract-ocr@taygun86`. |
| `accent.js` | Follows Settings > Appearance > Accent Color (`org.gnome.desktop.interface accent-color`) and the `style` key (Dusk or Atomic Suede): swaps the extension's `stylesheet.css` (Dusk, blue) for `stylesheet-<slot>.css` or `stylesheet-atomic-<slot>.css` on the St theme, debounced. `build.sh` compiles one stylesheet per variant from the tokens. |
| `wallpaperAccent.js`, `wallpaperColor.js` | Accent from wallpaper (`accent-from-wallpaper`, off by default): on a wallpaper change, reads the picture at 96 px, lets each colorful pixel vote (weighted by chroma) for the nearest Dusk accent by CIEDE2000 with lightness at half weight, and sets `accent-color` (at login, on a wallpaper change, and when turned on); few colorful pixels give Slate. A hand pick (an accent change Dusk did not make that lasts 4 s) turns the setting off, with a notification. |
| `clipboard.js` + `charTab.js`, `gifTab.js`, `pickerStore.js` | The clipboard panel, like Windows 11's: Super+V opens it on Clipboard history, Super+. (or Super+;) on Emoji. Tabs: Emoji (categories, search, skin tone), GIF (KLIPY search, trending and recently used; needs a free key in `gif-api-key`), Kaomoji, Symbols and Clipboard history (pin, delete, clear all; secrets skipped). It opens under the app's text cursor when known. Emoji, kaomoji and symbols go in through the input method, so the clipboard is untouched; apps without it get a paste and the clipboard back. GIFs are pasted as `image/gif`. Recents, skin tone and pins live in `~/.local/share/dusk/clipboard/`. Lists: `data/*.json` from `tools/gen-picker-data.py`. |
| `prefs.js` | Edit folder shortcuts (add, remove, reorder, custom path), Super behaviour and gestures. It also shows the drawer shortcut. |

Everything is undone in `disable()`.

## Settings

| Key | Type | Default |
|---|---|---|
| `super-opens-menu` | b | `true` |
| `quick-folders` | as | `['DOCUMENTS','DOWNLOAD','PICTURES','MUSIC','VIDEOS','HOME']`, XDG names or absolute paths |
| `disable-gestures` | b | `true` |
| `toggle-drawer` | as | `['<Super>n']` |
| `style` | s | `'dusk'`, or `'atomic'` for the Atomic Suede colors |

## Build

```sh
./build.sh   # stylesheet.scss -> stylesheet.css (sassc), schemas -> gschemas.compiled
```

## Notes

- `<Super>n` is also the shell's `focus-active-notification` key. While both
  keys are the same, the extension unregisters the shell's binding and
  registers it again on disable.
- Launchpad's `replace-app-grid` also catches the dock's Show Apps button.
  Turn it off, or Launchpad and Dusk will compete for the same click. Super+A
  still goes to the app grid (or Launchpad), not the Dusk menu.
- The menu and drawer are not blurred. In shell 51, `Shell.BlurEffect` cannot
  clip to rounded corners, so a blur would show square edges.

## Test in a nested session

```sh
cp -r . ~/.local/share/gnome-shell/extensions/dusk-shell@phlthydelphya.github.io  # setup/ does this
# A private XDG_RUNTIME_DIR is required: otherwise the nested session's
# xdg-document-portal lazily unmounts the real /run/user/$UID/doc
# (xdg-desktop-portal#2140) and every Flatpak launch on the host fails
# until `systemctl --user restart xdg-document-portal.service`.
# The devkit window still opens on the real session: its Wayland socket is
# passed as an absolute path (WAYLAND_DISPLAY is read relative to
# XDG_RUNTIME_DIR otherwise). Assignments expand left to right, so
# WAYLAND_DISPLAY sees the real XDG_RUNTIME_DIR.
WAYLAND_DISPLAY="$XDG_RUNTIME_DIR/$WAYLAND_DISPLAY" \
XDG_RUNTIME_DIR=$(mktemp -d /tmp/xdgrt.XXXXXX) \
  dbus-run-session gnome-shell --devkit --wayland
# in the nested session's terminal:
gnome-extensions enable dusk-shell@phlthydelphya.github.io
```

GNOME 51 has no `--nested` flag; `--devkit` is the nested mode (see `gnome-shell --help`).
Logs: `journalctl --user -f -o cat /usr/bin/gnome-shell`.
