#!/usr/bin/env bash
# Build Dusk GTK4 and GTK3 stylesheets with sassc. Writes only inside gtk/.
# Base: vendored Orchis GTK theme (orchis/, tag 2022-10-19, GPL-3.0), recolored
# to Dusk tokens; each gtk.scss imports it and layers Dusk rules on top.
#
# One full theme per variant: style (dusk, atomic) x accent slot
# (tokens/_dusk.scss; ids from `dusk_tokens.py variants`: "<slot>" for dusk,
# "atomic-<slot>" for Atomic Suede):
#   variants/<id>/index.theme              Name/GtkTheme = Dusk, Dusk-<Name>,
#                                          Dusk-Atomic or Dusk-Atomic-<Name>
#   variants/<id>/gtk-3.0/{gtk.css,gtk-dark.css,assets,assets-light}
#   variants/<id>/gtk-4.0/{gtk.css,gtk-dark.css,assets,assets-light}
# Each theme is paired, the way GTK and theme-unifier expect: gtk.css is the
# light scheme (DUSK_SCHEME=light tokens, assets in assets-light/), gtk-dark.css
# the dark one (assets/). theme-unifier's watcher switches libadwaita between
# them on color-scheme changes; dusk-accent imports the matching GTK3 sheet.
# variants/ is gitignored; install-system.sh installs every variant from it.
# The blue (Periwinkle, default) dark build is also copied to the tracked paths
# gtk-4.0/{gtk.css,assets} and Dusk/gtk-3.0/{gtk.css,assets} (per-user install).
# Usage: build.sh [VARIANT...]   (default: every variant)
set -euo pipefail

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
g4="$here/gtk-4.0"
g3="$here/Dusk/gtk-3.0"
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

command -v sassc >/dev/null || { echo "sassc not found" >&2; exit 1; }
command -v python3 >/dev/null || { echo "python3 not found" >&2; exit 1; }
tok() { python3 -I "$here/../tokens/dusk_tokens.py" "$@"; }

if (( $# )); then
  ids=("$@")
else
  mapfile -t ids < <(DUSK_SCHEME=dark tok variants | cut -f1)
fi
light_ids=()
for id in "${ids[@]}"; do light_ids+=("$id-light"); done

# Assets: breakout-tab 9-slice (drawn once per style) + Orchis PNGs and GTK3
# hover glyphs recolored to each variant's accent, per scheme.
DUSK_SCHEME=dark python3 -I "$here/orchis/tools/render-assets.py" "$tmp/assets" "${ids[@]}"
DUSK_SCHEME=light python3 -I "$here/orchis/tools/render-assets.py" "$tmp/assets" "${light_ids[@]}"

# One stylesheet: sassc of gtk.scss for a scheme, style and slot
sheet() {  # sheet SCHEME STYLE SLOT GTKDIR OUT
  local seed_line=""
  # The wallpaper slot's colours come from $DUSK_SEED (tokens/dusk_seed.py)
  [[ "$3" == wallpaper ]] && seed_line="$(DUSK_SCHEME="$1" tok seed-scss "$2")"
  printf "\$dusk-scheme: %s;\n\$dusk-style: %s;\n\$dusk-accent-slot: %s;\n%s\n@import \"%s\";\n" \
    "$1" "$2" "$3" "$seed_line" "$4/gtk.scss" > "$tmp/entry.scss"
  sassc -t expanded "$tmp/entry.scss" "$5"
}

preview() {  # preview STYLE SLOT: Settings' light and dark preview windows (_preview.scss)
  local sc seed_line
  for sc in light dark; do
    seed_line=""
    [[ "$2" == wallpaper ]] && seed_line="$(DUSK_SCHEME="$sc" tok seed-scss "$1")"
    printf "\$dusk-scheme: %s;\n\$dusk-style: %s;\n\$dusk-accent-slot: %s;\n%s\n@import \"%s\";\n" \
      "$sc" "$1" "$2" "$seed_line" "$g4/_preview.scss" > "$tmp/preview.scss"
    sassc -t expanded "$tmp/preview.scss"
  done
}

while IFS=$'\t' read -r id style slot _name theme _stem; do
  printf '%s\n' "${ids[@]}" | grep -qx -- "$id" || continue
  out="$here/variants/$id"
  rm -rf -- "$out"
  mkdir -p "$out/gtk-3.0" "$out/gtk-4.0"
  for gv in gtk-3.0 gtk-4.0; do
    cp -R "$tmp/assets/$id" "$out/$gv/assets"
    cp -R "$tmp/assets/$id-light" "$out/$gv/assets-light"
  done
  sheet dark "$style" "$slot" "$g4" "$out/gtk-4.0/gtk-dark.css"
  sheet dark "$style" "$slot" "$g3" "$out/gtk-3.0/gtk-dark.css"
  # The light sheet's url("assets/...") point at its own assets-light/
  for gv in gtk-3.0 gtk-4.0; do
    gdir="$g4"; [[ "$gv" == gtk-3.0 ]] && gdir="$g3"
    sheet light "$style" "$slot" "$gdir" "$tmp/light.css"
    sed -e 's#url("assets/#url("assets-light/#g' -e "s#url('assets/#url('assets-light/#g" \
      "$tmp/light.css" > "$out/$gv/gtk.css"
  done
  preview "$style" "$slot" > "$tmp/preview.css"
  cat "$tmp/preview.css" >> "$out/gtk-4.0/gtk.css"
  cat "$tmp/preview.css" >> "$out/gtk-4.0/gtk-dark.css"
  sed -e "s/^Name=Dusk$/Name=$theme/" -e "s/^GtkTheme=Dusk$/GtkTheme=$theme/" \
      "$here/Dusk/index.theme" > "$out/index.theme"
  echo "wrote variants/$id ($theme)"
  if [[ "$id" == blue ]]; then
    for dir in "$g4" "$g3"; do
      mkdir -p "$dir/assets"
      cp -r "$tmp/assets/blue/." "$dir/assets/"
    done
    cp -- "$out/gtk-4.0/gtk-dark.css" "$g4/gtk.css"
    cp -- "$out/gtk-3.0/gtk-dark.css" "$g3/gtk.css"
    echo "wrote gtk-4.0/{gtk.css,assets} and Dusk/gtk-3.0/{gtk.css,assets} (blue)"
  fi
done < <(DUSK_SCHEME=dark tok variants)
