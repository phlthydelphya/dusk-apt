#!/usr/bin/env bash
# Build the Dusk Kvantum themes (Qt Widgets apps), one per variant: style
# (dusk, atomic) x accent slot, named like the GTK themes (Dusk,
# Dusk-Lavender, Dusk-Atomic-Pink, ...), into kvantum/variants/<Name>/
# (gitignored; the dusk-theme package installs them to /usr/share/Kvantum).
# The wallpaper slot (Dusk-Wallpaper, from $DUSK_SEED) is built per account
# by dusk-wallpaper, not here.
# Usage: build.sh [VARIANT...]   (default: every fixed variant)
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

if (( $# )); then
    ids=("$@")
else
    mapfile -t ids < <(env -u DUSK_SEED python3 -I ../tokens/dusk_tokens.py variants | cut -f1)
fi
rm -rf variants.new
for id in "${ids[@]}"; do
    python3 -I generate.py variants.new "$id" >/dev/null
done
mkdir -p variants
for d in variants.new/*/; do
    name="$(basename "$d")"
    rm -rf "variants/$name"
    mv "$d" "variants/$name"
done
rm -rf variants.new
echo "kvantum: built ${#ids[@]} theme(s) in $(pwd)/variants"
