#!/usr/bin/env bash
# Build the login screen (GDM) theme: gdm/gnome-shell-theme.gresource.
#
# GDM's Shell loads its theme from one resource bundle
# (/usr/share/gnome-shell/gdm-theme.gresource, an update-alternatives link;
# install-system.sh points it at Dusk's). The bundle holds:
#   - every file of Ubuntu's Yaru bundle (spinners, icons, pad-osd.css, ...),
#     so anything the Shell asks the theme for is still there;
#   - gdm.css and gnome-shell.css: the Dusk Shell theme in one variant (style
#     and accent), plus the login background;
#   - assets/ from that variant's build;
#   - dusk-login.jpg: the style's balanced-mood wallpaper (Dusk Memphis Plum,
#     or Dusk Atomic Slate for Atomic Suede), blurred and dimmed the way the
#     Shell blurs it on the lock screen (unlockDialog.js: radius 90, brightness
#     0.65), since GDM shows no wallpaper of its own.
#
# Usage: build-gdm.sh [VARIANT]   (default: your Dusk Shell style and Settings
#   accent, else blue; VARIANT is an id from `dusk_tokens.py variants`)
# Needs shell/build.sh to have built variants/<id>, python3-pil and
# glib-compile-resources. Run as yourself, not root.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

YARU=/usr/share/gnome-shell/theme/Yaru/gnome-shell-theme.gresource
PREFIX=/org/gnome/shell/theme
# DUSK_GDM_OUT: another output dir (packaging/build-debs.sh builds every variant)
OUT="${DUSK_GDM_OUT:-gdm}"

command -v glib-compile-resources >/dev/null || { echo "glib-compile-resources not found (libglib2.0-dev-bin)" >&2; exit 1; }
[[ -f "$YARU" ]] || { echo "$YARU not found (yaru-theme-gnome-shell)" >&2; exit 1; }

tok() { python3 -I ../tokens/dusk_tokens.py "$@"; }
id="${1:-}"
if [[ -z "$id" ]]; then
  slot="$(gsettings get org.gnome.desktop.interface accent-color 2>/dev/null | tr -d "'" || true)"
  style="$(gsettings --schemadir ../extension/schemas get org.gnome.shell.extensions.dusk-shell style 2>/dev/null | tr -d "'" || true)"
  id="$slot"
  [[ "$style" == atomic ]] && id="atomic-$slot"
fi
row="$(tok variants | awk -F'\t' -v id="$id" '$1 == id')"
if [[ -z "$row" ]]; then
  id=blue
  row="$(tok variants | awk -F'\t' '$1 == "blue"')"
fi
IFS=$'\t' read -r _id style slot _name _theme _stem <<<"$row"
base="$(tok get "$slot" base "$style")"
WALLPAPER=../wallpapers/dusk-memphis-plum.png
[[ "$style" == atomic ]] && WALLPAPER=../wallpapers/dusk-atomic-slate.jpg
css="variants/$id/gnome-shell.css"
[[ -f "$css" ]] || { echo "$css missing: run shell/build.sh $id first" >&2; exit 1; }

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
root="$tmp/root"
mkdir -p "$root"

# Yaru's files first, at their resource paths
while IFS= read -r path; do
  rel="${path#"$PREFIX"/}"
  mkdir -p "$root/$(dirname "$rel")"
  gresource extract "$YARU" "$path" > "$root/$rel"
done < <(gresource list "$YARU")

# Dusk on top
rm -rf -- "$root/assets"
cp -R -- "variants/$id/assets" "$root/assets"
cp -- "$css" "$root/gnome-shell.css"
{
  cat -- "$css"
  cat <<EOF

/* ---- Dusk login screen ---- */
#lockDialogGroup {
  background-color: $base;
  background-image: url("dusk-login.jpg");
  background-size: cover;
  background-position: center;
}
EOF
} > "$root/gdm.css"

python3 -I - "$WALLPAPER" "$root/dusk-login.jpg" <<'EOF'
import sys
from PIL import Image, ImageEnhance, ImageFilter
src, dst = sys.argv[1], sys.argv[2]
W, H = 1920, 1080
im = Image.open(src).convert('RGB')
scale = max(W / im.width, H / im.height)
im = im.resize((round(im.width * scale), round(im.height * scale)), Image.LANCZOS)
left, top = (im.width - W) // 2, (im.height - H) // 2
im = im.crop((left, top, left + W, top + H))
# The Shell's blur: radius 90 (sigma = radius / 2), then brightness 0.65
im = im.filter(ImageFilter.GaussianBlur(45))
im = ImageEnhance.Brightness(im).enhance(0.65)
im.save(dst, quality=90, optimize=True, progressive=True)
EOF

{
  printf '<?xml version="1.0" encoding="UTF-8"?>\n<gresources>\n  <gresource prefix="%s">\n' "$PREFIX"
  (cd "$root" && find . -type f | sed 's|^\./||' | LC_ALL=C sort) | while IFS= read -r f; do
    printf '    <file>%s</file>\n' "$f"
  done
  printf '  </gresource>\n</gresources>\n'
} > "$tmp/dusk-gdm.gresource.xml"

mkdir -p "$OUT"
glib-compile-resources --sourcedir="$root" --target="$OUT/gnome-shell-theme.gresource" "$tmp/dusk-gdm.gresource.xml"
printf '%s\n' "$slot" > "$OUT/slot"
printf '%s\n' "$style" > "$OUT/style"
printf '%s\n' "$id" > "$OUT/variant"
gresource list "$OUT/gnome-shell-theme.gresource" | grep -qx "$PREFIX/gdm.css" \
  || { echo "built bundle has no gdm.css" >&2; exit 1; }
echo "built $(pwd)/$OUT/gnome-shell-theme.gresource (style: $style, accent: $slot, $(du -h "$OUT/gnome-shell-theme.gresource" | cut -f1))"
