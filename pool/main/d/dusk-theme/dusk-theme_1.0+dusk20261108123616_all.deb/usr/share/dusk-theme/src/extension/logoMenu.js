// The logo menu: the Dusk mark at the left end of the top bar, with a menu of
// system actions (About, Settings, apps, force quit, power).
//
// Formerly the Logo Menu extension (logomenu@aryan_k); Dusk Shell now draws
// it itself. The button keeps that extension's panel role, 'LogoMenu', so
// the panel arranger's saved layout still places it. The icon is the icon
// theme's `dusk-logo` mark (Strata draws one) or `start-here-symbolic`, and
// it follows icon theme changes. Each app item opens the first of its apps
// that is installed and is left out when none is.

import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Shell from 'gi://Shell';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

import {SelectionWindow} from './forceQuit.js';
import {markFile, watchIconTheme} from './iconMarks.js';

const ROLE = 'LogoMenu';

const APPS = {
    about: ['io.github.phlthydelphya.DuskAbout.desktop'],
    software: ['io.github.phlthydelphya.DuskAppHub.desktop', 'org.gnome.Software.desktop'],
    monitor: ['io.missioncenter.MissionCenter.desktop', 'org.gnome.SystemMonitor.desktop'],
    terminal: ['org.gnome.Ptyxis.desktop', 'org.gnome.Console.desktop', 'org.gnome.Terminal.desktop'],
    extensions: ['org.gnome.Shell.Extensions.desktop', 'com.mattjakeman.ExtensionManager.desktop'],
};

function findApp(ids) {
    const appSystem = Shell.AppSystem.get_default();
    for (const id of ids) {
        const app = appSystem.lookup_app(id);
        if (app)
            return app;
    }
    return null;
}

function spawn(argv) {
    try {
        Gio.Subprocess.new(argv, Gio.SubprocessFlags.NONE);
    } catch (e) {
        console.warn(`dusk-shell: logo menu: ${argv[0]}: ${e.message}`);
    }
}

const LogoButton = GObject.registerClass(
class DuskLogoButton extends PanelMenu.Button {
    _init() {
        super._init(0.5, _('Dusk Menu'));
        this.add_style_class_name('dusk-logo-menu');
        this._icon = new St.Icon({style_class: 'system-status-icon'});
        this.add_child(this._icon);
        this._syncIcon();
        this._unwatch = watchIconTheme(() => this._syncIcon());
        // App items depend on what is installed: rebuild on each open
        this.menu.connect('open-state-changed', (_menu, open) => {
            if (open)
                this._build();
        });
        this._build();
        this.connect('destroy', () => {
            this._unwatch?.();
            this._unwatch = null;
            if (this._idleId)
                GLib.source_remove(this._idleId);
            this._idleId = 0;
            this._selection?.stop();
            this._selection = null;
        });
    }

    _syncIcon() {
        const file = markFile('dusk-logo');
        this._icon.gicon = file
            ? Gio.FileIcon.new(Gio.File.new_for_path(file))
            : new Gio.ThemedIcon({name: 'start-here-symbolic'});
    }

    _item(label, callback) {
        const item = new PopupMenu.PopupMenuItem(label);
        item.connect('activate', () => callback());
        this.menu.addMenuItem(item);
    }

    _appItem(label, ids) {
        const app = findApp(ids);
        if (app)
            this._item(label, () => app.activate());
    }

    _separator() {
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
    }

    _build() {
        this.menu.removeAll();
        const about = findApp(APPS.about);
        this._item(_('About This Computer'), () => {
            if (about)
                about.activate();
            else
                spawn(['gnome-control-center', 'system', 'about']);
        });
        this._item(_('System Settings'), () => spawn(['gnome-control-center']));
        this._separator();
        this._item(_('Activities'), () => Main.overview.toggle());
        this._item(_('App Grid'), () => Main.overview.showApps());
        this._appItem(_('App Hub'), APPS.software);
        this._appItem(_('System Monitor'), APPS.monitor);
        this._appItem(_('Terminal'), APPS.terminal);
        this._appItem(_('Extensions'), APPS.extensions);
        this._separator();
        this._item(_('Force Quit App…'), () => this._forceQuit());
        this._separator();
        this._item(_('Sleep'), () => spawn(['systemctl', 'suspend']));
        this._item(_('Restart…'), () => spawn(['gnome-session-quit', '--reboot']));
        this._item(_('Shut Down…'), () => spawn(['gnome-session-quit', '--power-off']));
        this._separator();
        this._item(_('Lock Screen'), () => Main.screenShield?.lock(true));
        this._item(_('Log Out…'), () => spawn(['gnome-session-quit', '--logout']));
    }

    _forceQuit() {
        this._selection?.stop();
        // Let the menu close first: the selection takes a modal grab
        if (this._idleId)
            return;
        this._idleId = GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
            this._idleId = 0;
            this._selection = new SelectionWindow();
            this._selection.connect('stop', () => {
                this._selection = null;
            });
            return GLib.SOURCE_REMOVE;
        });
    }
});

export class LogoMenu {
    constructor() {
        // Logo Menu itself is turned off by dusk-dconf; if it still runs,
        // it holds the role and Dusk's button stays out of its way
        if (Main.panel.statusArea[ROLE])
            return;
        this._button = new LogoButton();
        Main.panel.addToStatusArea(ROLE, this._button, 0, 'left');
    }

    destroy() {
        this._button?.destroy();
        this._button = null;
    }
}
