#!/usr/bin/env python3
"""Generate the Dusk Kvantum theme (Qt Widgets apps: buttons, entries, menus,
tabs, lists, scroll bars, check boxes ...).

Usage: generate.py OUT_DIR VARIANT [--name NAME]
  OUT_DIR  receives NAME/NAME.kvconfig and NAME/NAME.svg (Kvantum's layout:
           ~/.config/Kvantum/NAME/ or /usr/share/Kvantum/NAME/), and
           NAME/dusk-decoration.conf, the colours of Dusk's Qt window bars
           (qtdecoration/; Kvantum ignores the file)
  VARIANT  an id from `tokens/dusk_tokens.py variants` (blue, purple,
           atomic-pink, ...; `wallpaper` and `atomic-wallpaper` read
           $DUSK_SEED, the Strata seed dusk-wallpaper writes)
  NAME     theme folder and file name (default: the variant's GTK theme name,
           Dusk, Dusk-Lavender, Dusk-Wallpaper, ...)

Every colour is a Dusk token (tokens/_dusk.scss), the same as the GTK and
Shell themes: window $frame, views $base, buttons and entries $raised, menus
$popover, highlights the accent tints, on-toggles solid $accent-bg. Dark only.

Kvantum draws each widget from named SVG elements: a 9-slice frame (corners,
sides) around a stretched interior, one set per state (normal, focused =
hovered, pressed, toggled, disabled). Each piece is drawn here directly as
paths (QtSvg's clip-path support is too thin to cut pieces from one shape).
Buttons are Strata slabs, like Dusk's shell (tokens/_dusk.scss slab): a face
with a sheen at its top edge and a darker side showing under it.
"""
import argparse
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'tokens'))
import dusk_tokens  # noqa: E402

STATES = ('normal', 'focused', 'pressed', 'toggled', 'disabled')
STRIP = 4  # length of the stretched side and interior pieces


# ---------------------------------------------------------------- colour
def rgba(value):
    """A token value -> (r, g, b, a), 0-255 channels, alpha 0-1."""
    v = value.strip()
    if v.startswith('rgba('):
        r, g, b, a = (x.strip() for x in v[5:-1].split(','))
        return int(r), int(g), int(b), float(a)
    r, g, b = dusk_tokens.hex_rgb(v)
    return r, g, b, 1.0


def over(top, bottom):
    """`top` composited over opaque `bottom` -> opaque (r, g, b, 1)."""
    r1, g1, b1, a = top
    r2, g2, b2, _ = bottom
    return (round(r1 * a + r2 * (1 - a)), round(g1 * a + g2 * (1 - a)), round(b1 * a + b2 * (1 - a)), 1.0)


def mix(c, toward, t):
    """`c` moved fraction t toward `toward` (an (r, g, b) triple); alpha kept."""
    r, g, b, a = c
    return (round(r + (toward[0] - r) * t), round(g + (toward[1] - g) * t), round(b + (toward[2] - b) * t), a)


def alpha(c, a):
    return c[0], c[1], c[2], a


def hexa(c):
    return '#%02X%02X%02X' % c[:3]


def paint(c):
    """SVG fill attributes for colour c."""
    out = f'fill="{hexa(c)}"'
    return out if c[3] >= 1 else out + f' fill-opacity="{c[3]:.3f}"'


def slab_hi(c):
    return mix(c, (255, 255, 255), 0.10)


def slab_side(c):
    s = mix(c, (0, 0, 0), 0.45)
    return alpha(s, min(1.0, c[3] + 0.25))


# ---------------------------------------------------------------- pieces
class Sheet:
    """The SVG under construction: pieces laid out left to right in rows."""

    def __init__(self):
        self.defs, self.body = [], []
        self.x = self.y = 0
        self.row_h = 0
        self.n = 0

    def place(self, w, h):
        if self.x + w > 2000:
            self.x, self.y, self.row_h = 0, self.y + self.row_h + 4, 0
        x, y = self.x, self.y
        self.x += w + 4
        self.row_h = max(self.row_h, h)
        return x, y

    def gradient(self, top, bottom):
        self.n += 1
        gid = f'g{self.n}'
        self.defs.append(
            f'<linearGradient id="{gid}" x1="0" y1="0" x2="0" y2="1">'
            f'<stop offset="0" stop-color="{hexa(top)}" stop-opacity="{top[3]:.3f}"/>'
            f'<stop offset="1" stop-color="{hexa(bottom)}" stop-opacity="{bottom[3]:.3f}"/>'
            f'</linearGradient>')
        return f'fill="url(#{gid})"'

    def piece(self, pid, w, h, shapes, mirror=False):
        """A named element w x h. `shapes` are drawn in local coordinates;
        with `mirror` they are flipped left-right (right-hand pieces). A
        transparent rect spans the whole piece so its bounds are exact."""
        x, y = self.place(w, h)
        tf = f'translate({x + w} {y}) scale(-1 1)' if mirror else f'translate({x} {y})'
        self.body.append(f'<g id="{pid}" transform="{tf}">'
                         f'<rect width="{w}" height="{h}" fill="#000000" fill-opacity="0"/>'
                         + ''.join(shapes) + '</g>')

    def svg(self):
        return ('<svg xmlns="http://www.w3.org/2000/svg" width="2000" '
                f'height="{self.y + self.row_h + 4}"><defs>{"".join(self.defs)}</defs>'
                + ''.join(self.body) + '</svg>\n')


def quarter(cx, cy, r, quadrant):
    """A quarter disc of radius r centred (cx, cy). quadrant 'tl' (the top
    left quarter of a circle, for a top-left corner) or 'bl'."""
    if r <= 0:
        return ''
    if quadrant == 'tl':
        return f'M{cx - r},{cy} A{r},{r} 0 0 1 {cx},{cy - r} L{cx},{cy} Z'
    return f'M{cx - r},{cy} A{r},{r} 0 0 0 {cx},{cy + r} L{cx},{cy} Z'


def box(sheet, name, state, R, face, border=None, bw=1, side=None, d=0, sheen=False):
    """One state of a 9-slice element `name`: rounded corners of radius R, a
    `face` fill, an optional `border` (bw px), an optional slab `side` d px
    deep below the face, and an optional sheen (the top pieces fade from
    slab_hi(face) to face)."""
    p = f'{name}-{state}' if state else name
    top_fill = sheet.gradient(slab_hi(face), face) if sheen and face[3] > 0 else paint(face)
    fill = paint(face)
    b = bw if border else 0
    bfill = paint(border) if border else ''

    def corner_top():
        out = []
        if border:  # a quarter ring, so a clear face leaves its middle clear
            out.append(f'<path d="{quarter(R, R, R, "tl")} {quarter(R, R, R - b, "tl")}" '
                       f'fill-rule="evenodd" {bfill}/>')
        out.append(f'<path d="{quarter(R, R, R - b, "tl")}" {top_fill}/>')
        return out

    def side_top():
        out = []
        if border:
            out.append(f'<rect width="{STRIP}" height="{b}" {bfill}/>')
        out.append(f'<rect y="{b}" width="{STRIP}" height="{R - b}" {top_fill}/>')
        return out

    def side_left():
        out = []
        if border:
            out.append(f'<rect width="{b}" height="{STRIP}" {bfill}/>')
        out.append(f'<rect x="{b}" width="{R - b}" height="{STRIP}" {fill}/>')
        return out

    def corner_bottom():
        out = []
        if side and d:
            out.append(f'<path d="{quarter(R, d, R, "bl")}" {paint(side)}/>')
        if border:
            out.append(f'<path d="{quarter(R, 0, R, "bl")} {quarter(R, 0, R - b, "bl")}" '
                       f'fill-rule="evenodd" {bfill}/>')
        out.append(f'<path d="{quarter(R, 0, R - b, "bl")}" {fill}/>')
        return out

    def side_bottom():
        out = []
        if side and d:
            out.append(f'<rect width="{STRIP}" height="{R + d}" {paint(side)}/>')
        if border:
            out.append(f'<rect y="{R - b}" width="{STRIP}" height="{b}" {bfill}/>')
        out.append(f'<rect width="{STRIP}" height="{R - b}" {fill}/>')
        return out

    hb = R + d
    sheet.piece(f'{p}-topleft', R, R, corner_top())
    sheet.piece(f'{p}-top', STRIP, R, side_top())
    sheet.piece(f'{p}-topright', R, R, corner_top(), mirror=True)
    sheet.piece(f'{p}-left', R, STRIP, side_left())
    sheet.piece(f'{p}-right', R, STRIP, side_left(), mirror=True)
    sheet.piece(f'{p}-bottomleft', R, hb, corner_bottom())
    sheet.piece(f'{p}-bottom', STRIP, hb, side_bottom())
    sheet.piece(f'{p}-bottomright', R, hb, corner_bottom(), mirror=True)
    sheet.piece(p, STRIP, STRIP, [f'<rect width="{STRIP}" height="{STRIP}" {fill}/>'])


def element(sheet, name, R, faces, **kw):
    """All five states; `faces` maps state -> face colour (missing: normal's).
    Keyword values may be per-state dicts too."""
    for st in STATES:
        args = {k: (v.get(st, v.get('normal')) if isinstance(v, dict) else v) for k, v in kw.items()}
        box(sheet, name, st, R, faces.get(st, faces['normal']), **args)


# ---------------------------------------------------------------- indicators
def glyph(sheet, pid, size, shapes):
    sheet.piece(pid, size, size, shapes)


def stroke(d, c, w=2.0):
    extra = '' if c[3] >= 1 else f' stroke-opacity="{c[3]:.3f}"'
    return (f'<path d="{d}" fill="none" stroke="{hexa(c)}"{extra} stroke-width="{w}" '
            'stroke-linecap="round" stroke-linejoin="round"/>')


ARROWS = {  # 16 x 16 chevrons
    'down': 'M4.5,6.5 L8,10 L11.5,6.5', 'up': 'M4.5,9.5 L8,6 L11.5,9.5',
    'left': 'M9.5,4.5 L6,8 L9.5,11.5', 'right': 'M6.5,4.5 L10,8 L6.5,11.5',
    'plus': 'M8,4 V12 M4,8 H12', 'minus': 'M4,8 H12',
}


def indicators(sheet, t):
    text, dim, accent = rgba(t['text']), rgba(t['text-dim']), rgba(t['accent'])
    dis = alpha(dim, 0.45)
    ink = {'normal': dim, 'focused': text, 'pressed': accent, 'toggled': text, 'disabled': dis}
    for name, d in ARROWS.items():
        for st in STATES:
            glyph(sheet, f'arrow-{name}-{st}', 16, [stroke(d, ink[st])])

    raised, border = rgba(t['raised']), rgba(t['border'])
    acc_bg, acc_fg = rgba(t['accent-bg']), rgba(t['accent-fg'])
    hover = over(rgba(t['hover']), raised)
    box_face = {'normal': raised, 'focused': hover, 'pressed': hover, 'toggled': hover,
                'disabled': alpha(raised, 0.5)}
    on_face = {'normal': acc_bg, 'focused': mix(acc_bg, (255, 255, 255), 0.08),
               'pressed': mix(acc_bg, (0, 0, 0), 0.10), 'toggled': acc_bg, 'disabled': alpha(acc_bg, 0.4)}
    edge = over(alpha((255, 255, 255), 0.16), raised)

    def check_box(face, edge_c):
        return (f'<rect x="1" y="1" width="16" height="16" rx="5" {paint(edge_c)}/>'
                f'<rect x="2" y="2" width="14" height="14" rx="4" {paint(face)}/>')

    for st in STATES:
        glyph(sheet, f'checkbox-{st}', 18, [check_box(box_face[st], edge)])
        glyph(sheet, f'checkbox-checked-{st}', 18, [
            f'<rect x="1" y="1" width="16" height="16" rx="5" {paint(on_face[st])}/>',
            stroke('M5,9.2 L7.8,12 L13,6.4', acc_fg if st != 'disabled' else alpha(acc_fg, 0.5), 2.2)])
        glyph(sheet, f'checkbox-tristate-{st}', 18, [
            f'<rect x="1" y="1" width="16" height="16" rx="5" {paint(on_face[st])}/>',
            stroke('M5.5,9 H12.5', acc_fg if st != 'disabled' else alpha(acc_fg, 0.5), 2.2)])
        glyph(sheet, f'radio-{st}', 18, [
            f'<circle cx="9" cy="9" r="8" {paint(edge)}/><circle cx="9" cy="9" r="7" {paint(box_face[st])}/>'])
        glyph(sheet, f'radio-checked-{st}', 18, [
            f'<circle cx="9" cy="9" r="8" {paint(on_face[st])}/>'
            f'<circle cx="9" cy="9" r="3.2" {paint(acc_fg if st != "disabled" else alpha(acc_fg, 0.5))}/>'])

    # Slider handle: a round slab ($text face, darker side under it)
    knob = {'normal': over(alpha((255, 255, 255), 0.88), raised), 'focused': (255, 255, 255, 1.0),
            'pressed': (255, 255, 255, 1.0), 'toggled': (255, 255, 255, 1.0), 'disabled': alpha(dim, 0.5)}
    for st in STATES:
        f = knob[st]
        glyph(sheet, f'slidercursor-{st}', 20, [
            f'<circle cx="10" cy="11.5" r="7.5" {paint(slab_side(alpha(f, 0.75)))}/>',
            f'<circle cx="10" cy="9.5" r="7.5" {paint(f)}/>'])

    # Grips: three dots
    for st in STATES:
        dots = ''.join(f'<circle cx="{x}" cy="8" r="1.2" {paint(ink[st])}/>' for x in (4.5, 8, 11.5))
        for g in ('grip', 'splitter-grip'):
            glyph(sheet, f'{g}-{st}', 16, [dots])
        glyph(sheet, f'resize-grip-{st}', 16, [stroke('M13,7 L7,13 M13,11 L11,13', ink[st], 1.5)])


# ---------------------------------------------------------------- the theme
def build(t, name):
    sheet = Sheet()
    frame, base, card, popover, raised = (rgba(t[k]) for k in ('frame', 'base', 'card', 'popover', 'raised'))
    text, dim = rgba(t['text']), rgba(t['text-dim'])
    border = rgba(t['border'])
    hover, active = rgba(t['hover']), rgba(t['active'])
    sel, sel_item, sel_strong = rgba(t['selection']), rgba(t['selection-item']), rgba(t['selection-strong'])
    acc, acc_bg = rgba(t['accent']), rgba(t['accent-bg'])
    clear = (0, 0, 0, 0.0)
    disabled = alpha(raised, 0.5)

    # Buttons: slabs on $raised; toggled (on) solid $accent-bg
    btn = {'normal': raised, 'focused': over(hover, raised), 'pressed': over(active, raised),
           'toggled': acc_bg, 'disabled': disabled}
    element(sheet, 'button', 10, btn, side={s: slab_side(c) for s, c in btn.items()}, d=2, sheen=True)
    # Tool buttons: flat at rest, slab tints when hovered, pressed or on
    tb = {'normal': clear, 'focused': over(hover, frame), 'pressed': over(sel_strong, frame),
          'toggled': over(sel_item, frame), 'disabled': clear}
    element(sheet, 'tbutton', 10, tb, side={s: (slab_side(c) if c[3] else None) for s, c in tb.items()},
            d=2, sheen=True)
    # Entries: $raised with a thin edge; focus: the accent edge
    le_border = {'normal': over(alpha((255, 255, 255), 0.10), raised), 'focused': acc, 'pressed': acc,
                 'toggled': acc, 'disabled': border}
    element(sheet, 'lineedit', 10, {'normal': raised, 'disabled': disabled}, border=le_border, bw=1)
    # Frames. Scroll areas (lists, text views) sit in `common`: its ring is
    # $base like their viewport, so a view reads as one rounded $base card
    element(sheet, 'common', 10, {'normal': base}, border=over(border, frame), bw=1)
    element(sheet, 'group', 12, {'normal': over(alpha(card, 0.5), frame)}, border=over(border, frame), bw=1)
    element(sheet, 'tabframe', 12, {'normal': base}, border=over(border, frame), bw=1)
    # Keyboard focus: a 2px accent ring around the control (Dusk's ring).
    # Kvantum draws <frame element>-focus in place of its dashed rectangle
    # Buttons and tabs (focusFrame in their sections) get a ring of their
    # own shape, everything else Kvantum's [Focus] frame around the focus
    # rectangle
    for el, r in (('button', 10), ('tbutton', 10), ('tab', 8)):
        box(sheet, el, 'focus', r, clear, border=acc, bw=2)
    box(sheet, 'focus', None, 6, clear, border=acc, bw=2)
    # Default push button: no extra mark (Kvantum's fallback is a triangle)
    sheet.piece('button-default-indicator', 4, 4, [])
    element(sheet, 'toolbar', 1, {'normal': clear})
    # Menus and tooltips: $popover cards
    element(sheet, 'menu', 12, {'normal': popover}, border=over(border, popover), bw=1)
    element(sheet, 'tooltip', 10, {'normal': popover}, border=over(border, popover), bw=1)
    pill = {'normal': clear, 'focused': sel_item, 'pressed': sel_strong, 'toggled': sel_strong, 'disabled': clear}
    element(sheet, 'menuitem', 8, pill)
    element(sheet, 'menubaritem', 8, pill)
    # Tabs: the current one a raised slab
    tab = {'normal': clear, 'focused': hover, 'pressed': active, 'toggled': raised, 'disabled': clear}
    element(sheet, 'tab', 8, tab, side={'toggled': slab_side(raised)}, d=2, sheen=True)
    # Lists and trees: selection pills
    iv = {'normal': clear, 'focused': hover, 'pressed': sel_strong, 'toggled': sel_item, 'disabled': clear}
    element(sheet, 'itemview', 8, iv)
    element(sheet, 'header', 1, {'normal': clear, 'focused': hover, 'pressed': active})
    # Scroll bars: a thin pill on a clear groove
    element(sheet, 'scrollbargroove', 4, {'normal': clear})
    sl = {'normal': alpha(dim, 0.45), 'focused': alpha(text, 0.6), 'pressed': acc, 'toggled': alpha(text, 0.6),
          'disabled': alpha(dim, 0.2)}
    element(sheet, 'scrollbarslider', 4, sl)
    element(sheet, 'ss', 3, {'normal': alpha(dim, 0.45), 'focused': alpha(text, 0.6)})
    # Sliders and progress bars: $raised track, $accent-bg fill
    element(sheet, 'slider', 3, {'normal': raised, 'focused': raised, 'toggled': acc_bg, 'disabled': disabled})
    element(sheet, 'progress', 4, {'normal': raised, 'disabled': disabled})
    element(sheet, 'progress-pattern', 4, {'normal': acc_bg, 'disabled': alpha(acc_bg, 0.4)})
    element(sheet, 'splitter', 1, {'normal': clear})
    element(sheet, 'titlebar', 1, {'normal': frame})
    indicators(sheet, t)

    return sheet.svg(), kvconfig(t, name)


def kvconfig(t, name):
    c = {k: dusk_tokens.color(t[k], 'hex') if not t[k].startswith('rgba') else None
         for k in ('frame', 'base', 'card', 'popover', 'raised', 'text', 'text-dim', 'accent', 'accent-bg',
                   'accent-fg')}
    raised, base = rgba(t['raised']), rgba(t['base'])
    alt = hexa(over(alpha((255, 255, 255), 0.03), base))
    sel_item = hexa(over(rgba(t['selection-item']), base))
    sel_inactive = hexa(over(rgba(t['selection']), base))
    dim_dis = hexa(over(alpha(rgba(t['text']), 0.40), rgba(t['frame'])))
    light = hexa(over(alpha((255, 255, 255), 0.10), raised))
    dark = hexa(mix(rgba(t['frame']), (0, 0, 0), 0.4))
    text, accent, accent_fg = c['text'], c['accent'], c['accent-fg']
    return f"""# Dusk Kvantum theme ({name}), generated by kvantum/generate.py from
# Dusk's tokens (tokens/_dusk.scss); do not edit, regenerate.
[%General]
author=Dusk
comment=Dusk: Dusk's colours and Strata slabs for Qt apps
x11drag=menubar_and_primary_toolbar
alt_mnemonic=true
left_tabs=false
attach_active_tab=false
group_toolbar_buttons=false
spread_progressbar=true
progressbar_thickness=6
composite=true
translucent_windows=false
blurring=false
popup_blurring=false
menu_shadow_depth=0
tooltip_shadow_depth=0
spread_menuitems=true
menu_separator_height=9
splitter_width=7
scroll_width=10
scroll_min_extent=48
scroll_arrows=false
transient_scrollbar=true
transient_groove=false
center_toolbar_handle=true
combo_as_lineedit=false
combo_menu=true
inline_spin_indicators=true
vertical_spin_indicators=false
slider_width=6
slider_handle_width=20
slider_handle_length=20
check_size=18
tooltip_delay=-1
toolbar_icon_size=font
toolbar_interior_spacing=4
toolbar_item_spacing=2
layout_spacing=6
layout_margin=12
small_icon_size=16
large_icon_size=32
button_icon_size=16
animate_states=true
no_inactiveness=false
no_window_pattern=true
respect_DE=true
dialog_button_layout=2
menubar_mouse_tracking=true
fill_rubberband=true
scrollable_menu=true
submenu_overlap=0
submenu_delay=150
click_behavior=1
drag_from_buttons=false

[GeneralColors]
window.color={c['frame']}
base.color={c['base']}
alt.base.color={alt}
button.color={c['raised']}
light.color={light}
mid.light.color={c['raised']}
dark.color={dark}
mid.color={c['card']}
highlight.color={c['accent-bg']}
inactive.highlight.color={sel_inactive}
tooltip.base.color={c['popover']}
text.color={text}
window.text.color={text}
button.text.color={text}
disabled.text.color={dim_dis}
tooltip.text.color={text}
highlight.text.color={accent_fg}
link.color={accent}
link.visited.color={accent}
progress.indicator.text.color={text}

[Hacks]
respect_darkness=true
transparent_dolphin_view=false
force_size_grip=false
iconless_pushbutton=false
iconless_menu=false
disabled_icon_opacity=50
lxqtmainmenu_iconsize=16
normal_default_pushbutton=true
single_top_toolbar=true
tint_on_mouseover=0
no_selection_tint=true
transparent_arrow_button=true
middle_click_scroll=false
kcapacitybar_as_progressbar=true

[PanelButtonCommand]
frame=true
frame.element=button
frame.top=10
frame.bottom=12
frame.left=10
frame.right=10
interior=true
interior.element=button
indicator.size=16
text.normal.color={text}
text.focus.color={text}
text.press.color={text}
text.toggle.color={accent_fg}
text.shadow=0
text.margin.top=0
text.margin.bottom=0
text.margin.left=4
text.margin.right=4
text.iconspacing=6
indicator.element=arrow
focusFrame=true
min_height=2.2font
min_width=+0.5font

[PanelButtonTool]
inherits=PanelButtonCommand
frame.element=tbutton
interior.element=tbutton
text.toggle.color={text}
min_height=+0

[ToolbarButton]
inherits=PanelButtonTool

[Dock]
inherits=PanelButtonCommand
interior.element=common
frame.element=common
frame.top=12
frame.bottom=12

[DockTitle]
inherits=PanelButtonCommand
frame=false
interior=false
text.bold=true

[IndicatorSpinBox]
inherits=PanelButtonCommand
frame=false
interior=false
indicator.element=arrow
indicator.size=16

[RadioButton]
inherits=PanelButtonCommand
frame=false
interior.element=radio
text.toggle.color={text}

[CheckBox]
inherits=PanelButtonCommand
frame=false
interior.element=checkbox
text.toggle.color={text}

[GenericFrame]
inherits=PanelButtonCommand
frame=true
interior=false
frame.element=common
interior.element=common
frame.top=10
frame.bottom=10
frame.left=10
frame.right=10

[Focus]
frame=true
frame.element=focus
interior=false
frame.top=6
frame.bottom=6
frame.left=6
frame.right=6

[LineEdit]
inherits=PanelButtonCommand
focusFrame=false
frame.element=lineedit
interior.element=lineedit
frame.top=10
frame.bottom=10
text.margin.left=2
text.margin.right=2

[DropDownButton]
inherits=PanelButtonCommand
indicator.element=arrow-down

[IndicatorArrow]
indicator.element=arrow
indicator.size=16

[ToolboxTab]
inherits=PanelButtonCommand

[Tab]
inherits=PanelButtonCommand
interior.element=tab
frame.element=tab
indicator.element=tab
frame.top=8
frame.bottom=10
frame.left=8
frame.right=8
text.margin.left=6
text.margin.right=6
text.toggle.color={text}
text.normal.color={c['text-dim']}
min_height=2.2font

[TabFrame]
inherits=PanelButtonCommand
frame.element=tabframe
interior=false
frame.top=12
frame.bottom=12
frame.left=12
frame.right=12

[TreeExpander]
inherits=PanelButtonCommand
frame=false
interior=false
indicator.element=arrow
indicator.size=16

[HeaderSection]
inherits=PanelButtonCommand
interior.element=header
frame.element=header
frame.top=1
frame.bottom=1
frame.left=1
frame.right=1
text.normal.color={c['text-dim']}
text.bold=true
min_height=+0

[SizeGrip]
inherits=PanelButtonCommand
frame=false
interior=false
indicator.element=resize-grip
indicator.size=16

[Toolbar]
inherits=PanelButtonCommand
indicator.element=grip
indicator.size=16
text.margin=0
frame.element=toolbar
interior.element=toolbar
frame.top=1
frame.bottom=1
frame.left=1
frame.right=1
min_height=+0

[Slider]
inherits=PanelButtonCommand
frame.element=slider
interior.element=slider
frame.top=3
frame.bottom=3
frame.left=3
frame.right=3

[SliderCursor]
inherits=PanelButtonCommand
frame=false
interior.element=slidercursor

[Progressbar]
inherits=PanelButtonCommand
frame.element=progress
interior.element=progress
frame.top=4
frame.bottom=4
frame.left=4
frame.right=4
text.margin=0
text.bold=true
text.toggle.color={text}

[ProgressbarContents]
inherits=PanelButtonCommand
frame=true
frame.element=progress-pattern
interior.element=progress-pattern
frame.top=4
frame.bottom=4
frame.left=4
frame.right=4

[ItemView]
inherits=PanelButtonCommand
frame.element=itemview
interior.element=itemview
frame.top=8
frame.bottom=8
frame.left=8
frame.right=8
text.margin.top=2
text.margin.bottom=2
text.margin.left=2
text.margin.right=2
text.toggle.color={text}
text.press.color={text}
min_height=+0

[Splitter]
inherits=PanelButtonCommand
interior.element=splitter
frame.element=splitter
frame.top=0
frame.bottom=0
frame.left=0
frame.right=0
indicator.element=splitter-grip
indicator.size=16

[Scrollbar]
inherits=PanelButtonCommand
indicator.element=arrow
indicator.size=10

[ScrollbarSlider]
inherits=PanelButtonCommand
frame.element=scrollbarslider
interior.element=scrollbarslider
frame.top=4
frame.bottom=4
frame.left=4
frame.right=4
indicator.element=grip
indicator.size=0

[ScrollbarTransientSlider]
frame=true
frame.element=ss
interior=false
frame.top=3
frame.bottom=3
frame.left=3
frame.right=3

[ScrollbarGroove]
inherits=PanelButtonCommand
interior.element=scrollbargroove
frame.element=scrollbargroove
frame=false
interior=false

[MenuItem]
inherits=PanelButtonCommand
frame=true
frame.element=menuitem
interior.element=menuitem
indicator.element=arrow
frame.top=8
frame.bottom=8
frame.left=8
frame.right=8
text.margin.top=0
text.margin.bottom=0
text.margin.left=4
text.margin.right=4
text.focus.color={text}
text.press.color={text}
text.toggle.color={text}
min_height=+0

[MenuBar]
inherits=PanelButtonCommand
frame=false
interior=false

[MenuBarItem]
inherits=PanelButtonCommand
interior.element=menubaritem
frame.element=menubaritem
frame.top=8
frame.bottom=8
frame.left=8
frame.right=8
text.margin.left=2
text.margin.right=2
text.margin.top=0
text.margin.bottom=0
text.toggle.color={text}
min_height=+0

[TitleBar]
inherits=PanelButtonCommand
frame=false
interior.element=titlebar
indicator.size=16
text.normal.color={c['text-dim']}
text.focus.color={text}
text.bold=true

[ComboBox]
inherits=PanelButtonCommand
indicator.element=arrow

[Menu]
inherits=PanelButtonCommand
frame.top=12
frame.bottom=12
frame.left=12
frame.right=12
frame.element=menu
interior.element=menu
text.toggle.color={text}

[GroupBox]
inherits=GenericFrame
frame=true
frame.element=group
interior=true
interior.element=group
text.bold=true

[TabBarFrame]
inherits=GenericFrame
frame=false
interior=false

[ToolTip]
inherits=GenericFrame
frame.element=tooltip
interior.element=tooltip
interior=true
frame.top=10
frame.bottom=10
frame.left=10
frame.right=10

[StatusBar]
inherits=GenericFrame
frame=false
interior=false

[Window]
interior=false
"""


def decoration_conf(t, name):
    """Colours for Dusk's Qt window bars (qtdecoration/, the `dusk` Qt
    Wayland decoration), kept beside the Kvantum theme of the same variant:
    dusk-accent copies it to ~/.local/share/dusk/qt-decoration.conf, which
    the decoration watches. #RRGGBB, or #RRGGBBAA with alpha last."""
    def col(key):
        r, g, b, a = rgba(t[key])
        return '#%02X%02X%02X' % (r, g, b) + ('' if a >= 1 else '%02X' % round(a * 255))
    keys = ('frame', 'text', 'text-dim', 'accent', 'selection-item', 'selection-strong', 'border')
    return (f'# Dusk Qt window bar colours ({name}), generated by kvantum/generate.py\n'
            '[Colors]\n' + ''.join(f'{k}={col(k)}\n' for k in keys))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split('\n\n')[0])
    ap.add_argument('out', type=Path)
    ap.add_argument('variant')
    ap.add_argument('--name')
    a = ap.parse_args(argv)
    row = next((v for v in dusk_tokens.variants() if v['id'] == a.variant), None)
    if row is None:
        sys.exit(f'generate.py: unknown variant {a.variant!r}')
    t = dusk_tokens.tokens(row['slot'], style=row['style'])
    name = a.name or row['theme']
    svg, cfg = build(t, name)
    d = a.out / name
    d.mkdir(parents=True, exist_ok=True)
    (d / f'{name}.svg').write_text(svg, encoding='utf-8')
    (d / f'{name}.kvconfig').write_text(cfg, encoding='utf-8')
    (d / 'dusk-decoration.conf').write_text(decoration_conf(t, name), encoding='utf-8')
    print(f'generate.py: {d} ({row["theme"]})')


if __name__ == '__main__':
    main()
