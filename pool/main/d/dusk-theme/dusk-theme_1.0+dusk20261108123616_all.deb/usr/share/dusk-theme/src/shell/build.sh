#!/usr/bin/env bash
# Build gnome-shell.css = stock base (_base.css) + Dusk overrides (gnome-shell.scss via sassc),
# once per variant: style (dusk, atomic) x accent slot (tokens/_dusk.scss; ids
# from `dusk_tokens.py variants`: "<slot>" for dusk, "atomic-<slot>" for Atomic Suede):
#   variants/<id>/gnome-shell.css   every variant (gitignored; install-system.sh reads these)
#   variants/<id>/assets/           assets/ plus dusk-start.svg rendered from
#                                   dusk-start.svg.in in the variant's accent
#   gnome-shell.css, assets/dusk-start.svg   copies of the blue (Periwinkle, default) build
# Each variant is built in both schemes: <id> dark (base _base.css), <id>-light
# light (DUSK_SCHEME=light tokens over the stock light theme, _base-light.css).
# Usage: build.sh [VARIANT...]   (default: every variant; dark ids, each builds
#                                 its -light twin too)
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
command -v sassc >/dev/null || { echo "sassc not found" >&2; exit 1; }
tok() { python3 -I ../tokens/dusk_tokens.py "$@"; }

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

if (( $# )); then ids=("$@"); else mapfile -t ids < <(DUSK_SCHEME=dark tok variants | cut -f1); fi

for scheme in dark light; do
export DUSK_SCHEME="$scheme"
base_css=_base.css
[[ "$scheme" == light ]] && base_css=_base-light.css
for id0 in "${ids[@]}"; do
  id="$id0"
  [[ "$scheme" == light ]] && id="$id0-light"
  row="$(tok variants | awk -F'\t' -v id="$id" '$1 == id')"
  [[ -n "$row" ]] || { echo "unknown variant: $id" >&2; exit 1; }
  IFS=$'\t' read -r _id style slot _name _theme _stem <<<"$row"
  accent_bg="$(tok get "$slot" accent-bg "$style")"
  accent_fg="$(tok get "$slot" accent-fg "$style")"
  [[ -n "$accent_bg" && -n "$accent_fg" ]] || { echo "accent tokens not found for $id" >&2; exit 1; }
  out="variants/$id"
  mkdir -p "$out"
  # The wallpaper slot's colours come from $DUSK_SEED (tokens/dusk_seed.py)
  seed_line=""
  [[ "$slot" == wallpaper ]] && seed_line="$(tok seed-scss "$style")"
  printf "\$dusk-scheme: %s;\n\$dusk-style: %s;\n\$dusk-accent-slot: %s;\n%s\n@import \"%s/gnome-shell.scss\";\n" "$scheme" "$style" "$slot" "$seed_line" "$PWD" > "$tmp/$id.scss"
  sassc -t expanded "$tmp/$id.scss" "$tmp/$id.css"
  base_in="$base_css"
  if [[ "$scheme" == light ]]; then
    # _base-light.css is two sheets: the stock light one, then (from its second
    # "Base:" header) the same supplementary sheet as _base.css, which only
    # exists in dark colours: #dedede text, #afafaf secondary text and their
    # rgba() tints. Unchanged, they put light grey text on the light surfaces
    # (entry hints, calendar, popup items, notification and dialog text).
    # Remap those four to this build's light $text and $text-dim, alpha kept.
    # White stays: the overview and lock screen keep light text in both schemes.
    text="$(tok get "$slot" text "$style")"
    dim="$(tok get "$slot" text-dim "$style")"
    rgb() { printf '%d, %d, %d' "0x${1:1:2}" "0x${1:3:2}" "0x${1:5:2}"; }
    second="$(grep -n '^/\* Base: stock' "$base_css" | sed -n 2p | cut -d: -f1)"
    [[ -n "$second" ]] || { echo "$base_css: second sheet header not found" >&2; exit 1; }
    base_in="$tmp/base-$id.css"
    sed -e "${second},\$ {
      s/#dedede/$text/g; s/#afafaf/$dim/g
      s/rgba(222, 222, 222, /rgba($(rgb "$text"), /g
      s/rgba(175, 175, 175, /rgba($(rgb "$dim"), /g
    }" "$base_css" > "$base_in"
  fi
  {
    # St takes -st-accent-color from the system accent setting; pin it to this
    # build's Dusk accent (the slot's $accent-bg).
    # Flat matte: drop Ubuntu's white inner glows and 2px accent focus rings
    sed -e "s/-st-accent-fg-color/$accent_fg/g" -e "s/-st-accent-color/$accent_bg/g" \
        -e 's/box-shadow: inset 0 0 [1-9][0-9]*px rgba(255, 255, 255, [0-9.]*) !important;/box-shadow: none !important;/' \
        -e 's/box-shadow: inset 0 0 0 2px st-transparentize([^;]*);/box-shadow: none;/' \
        -e 's/box-shadow: inset 0 0 0 2px st-transparentize([^;]*) !important;/box-shadow: none !important;/' \
        "$base_in"
    printf '\n/* ---- Dusk overrides (style: %s, accent: %s) ---- */\n' "$style" "$slot"
    cat "$tmp/$id.css"
  } > "$out/gnome-shell.css"
  echo "built $(pwd)/$out/gnome-shell.css ($(wc -l < "$out/gnome-shell.css") lines)"
  # Accent-colored assets: the start button mark
  rm -rf -- "$out/assets"
  cp -R -- assets "$out/assets"
  tok render "$slot" dusk-start.svg.in "$out/assets/dusk-start.svg" "$style"
  if [[ "$id" == blue ]]; then
    cp -- "$out/gnome-shell.css" gnome-shell.css
    cp -- "$out/assets/dusk-start.svg" assets/dusk-start.svg
    echo "built $(pwd)/gnome-shell.css and assets/dusk-start.svg (blue)"
  fi
done
done
