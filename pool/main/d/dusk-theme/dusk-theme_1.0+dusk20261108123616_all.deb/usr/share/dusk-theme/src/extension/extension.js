import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

import {AccentFollower} from './accent.js';
import {WallpaperAccent} from './wallpaperAccent.js';
import {DingMenuAcrylic} from './popupAcrylic.js';
import {DesktopMenu} from './desktopMenu.js';
import {NotificationIconFix} from './notifIcons.js';
import {NotificationActions} from './notificationActions.js';
import {MessageExpandFix} from './messageExpand.js';
import {TopSearch} from './topSearch.js';
import {ClipboardHistory} from './clipboard.js';
import {GestureBlocker} from './gestures.js';
import {NotificationDot} from './notifDot.js';
import {NotificationDrawer} from './drawer.js';
import {PanelLayout} from './panelLayout.js';
import {PanelArranger} from './panelArranger.js';
import {QuickSettingsArranger} from './qsArranger.js';
import {PopupMotion} from './motion.js';
import {StartMenu} from './startMenu.js';
import {LogoMenu} from './logoMenu.js';
import {StrataBadges} from './strataBadges.js';
import {WebSearch} from './webSearch.js';
import {ScreenshotOcr} from './ocr.js';
import {InlineReply} from './inlineReply.js';

export default class DuskShellExtension extends Extension {
    enable() {
        this._settings = this.getSettings();

        // Order matters: the clock moves before the dot is appended after
        // it, and the drawer borrows date menu parts the layout hides.
        // disable() tears down in reverse.
        this._modules = [];
        try {
            // The arrangers (formerly separate extensions) keep their own
            // settings schemas. The panel arranger first: while it runs it
            // owns top-bar placement, and the layout below defers to it.
            this._add(new QuickSettingsArranger(
                this.getSettings('org.gnome.shell.extensions.qs-arranger')));
            this._add(new PanelArranger(
                this.getSettings('org.gnome.shell.extensions.panel-arranger')));
            this._add(new PanelLayout(this));
            this._add(new PopupMotion());
            const drawer = this._add(new NotificationDrawer(this._settings));
            this._add(new NotificationDot(drawer));
            this._add(new MessageExpandFix());
            const actions = this._add(new NotificationActions());
            this._add(new StartMenu(this._settings, actions));
            this._add(new LogoMenu());
            this._add(new GestureBlocker(this._settings));
            this._add(new AccentFollower(this));
            this._add(new WallpaperAccent(this._settings));
            this._add(new DingMenuAcrylic());
            this._add(new DesktopMenu());
            this._add(new NotificationIconFix());
            this._add(new InlineReply());
            this._add(new TopSearch(this._settings));
            this._add(new ClipboardHistory(this._settings));
            // Formerly separate extensions: strata-badges@strata,
            // web-search-provider@ubuntu.com, tesseract-ocr@taygun86
            this._add(new StrataBadges());
            this._add(new WebSearch(this._settings));
            this._add(new ScreenshotOcr(this._settings));
        } catch (e) {
            // The shell never calls disable() after a failed enable()
            this.disable();
            throw e;
        }
    }

    disable() {
        for (const module of (this._modules ?? []).reverse()) {
            try {
                module.destroy();
            } catch (e) {
                console.error(`dusk-shell: ${module.constructor.name}: ${e}`);
            }
        }
        this._modules = null;
        this._settings = null;
    }

    _add(module) {
        this._modules.push(module);
        return module;
    }
}
