# Dusk Kvantum theme (Qt Widgets apps)

`generate.py` draws a Kvantum theme from Dusk's tokens (`tokens/_dusk.scss`),
the same colours as the GTK and Shell themes: window `$frame`, views `$base`,
buttons and entries `$raised`, menus `$popover`, highlights the accent tints,
on-toggles solid `$accent-bg`, a 2px `$accent` focus ring. Buttons, tool
buttons and the current tab are Strata slabs, as in the shell: a sheen along
the top edge and a darker side under the face.

- `bash kvantum/build.sh [VARIANT...]` builds every fixed variant (Dusk,
  Dusk-Lavender, Dusk-Atomic-Pink, ...) into `kvantum/variants/` (gitignored);
  the dusk-theme package installs them to `/usr/share/Kvantum/`.
- `dusk-wallpaper` builds the account's Strata-seeded one
  (`~/.config/Kvantum/Dusk-Wallpaper`, from the wallpaper or the accent).
- `dusk-accent` points `~/.config/Kvantum/kvantum.kvconfig` at the Kvantum
  theme named like the GTK theme it applies, while Kvantum's theme is unset or
  already a Dusk one (a theme picked in Kvantum Manager is left alone).
- The dusk-theme package sets `QT_STYLE_OVERRIDE=kvantum` for the session
  (`/usr/lib/environment.d/90-dusk-qt.conf`).

Kvantum styles Qt Widgets only. Qt Quick apps with their own style (Staq uses
Qt Quick's Basic style and draws its own frame) are not affected, and window
title bars on Wayland come from the Qt Wayland decoration plugin
(`qtdecoration/`), not from Kvantum.

Check a change offscreen: build a small Qt Widgets window and grab it with
`QT_QPA_PLATFORM=offscreen QT_STYLE_OVERRIDE=kvantum` and a scratch
`XDG_CONFIG_HOME` whose `Kvantum/kvantum.kvconfig` names the theme.
