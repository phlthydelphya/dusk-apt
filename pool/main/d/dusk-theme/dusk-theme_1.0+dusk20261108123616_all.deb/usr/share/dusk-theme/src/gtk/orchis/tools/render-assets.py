#!/usr/bin/env python3
"""Render Dusk's GTK assets for the Orchis-based build.

1. row-selected-dark.png / row-selected-dark@2.png: the Nautilus sidebar
   "breakout tab" 9-slice. Shape of Orchis's assets.svg group "row-selected",
   enlarged (see TAB_* below; 160x88 at 1x, incl. a 16px solid tail):
     - outside is transparent (whatever is under the row shows: the frame,
       or the neighbouring row's label where the 16px curve strips overlap it),
     - tab (content color, $base): a left half-pill (radius 28, from x=24)
       running to the right edge, y 16..72,
     - inward curves (radius 16 = $r-card) top-right and bottom-right where
       the frame meets the tab.
   Used with border-image-slice 17 33 17 54 (see _sass/gtk/apps/_gnome-4.0.scss
   and gtk-4.0/gtk.scss).
   Drawn by supersampling and written with zlib + struct (no dependencies).

3. Window-button glyphs (assets-src/scalable/dusk-window-*-symbolic.svg)
   pre-colored for GTK3: dusk-window-NAME-{rest,hover,backdrop}.svg.

2. Orchis's dark slider / selection-mode PNGs (assets-src/) recoloured from
   Orchis blue (#3281EA) to Dusk $accent-bg. Needs Pillow; without it the
   upstream PNGs are copied unchanged and a warning is printed.

Colors come from tokens/_dusk.scss (through tokens/dusk_tokens.py). Only 2.
and the hover glyphs of 3. use the accent; 1. is drawn once and copied.

Usage: render-assets.py OUT_ROOT VARIANT...
  VARIANT: a variant id from `dusk_tokens.py variants` (an accent slot for
  the dusk style, "atomic-<slot>" for Atomic Suede); writes OUT_ROOT/<id>/
  (one full assets dir per variant)
"""
import shutil
import struct
import sys
import zlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
ORCHIS = HERE.parent
sys.path.insert(0, str(ORCHIS.parent.parent / "tokens"))
import dusk_tokens  # noqa: E402

ORCHIS_BLUE = (0x32, 0x81, 0xEA)


def token_rgb(toks, name):
    value = toks.get(name, "")
    if not value.startswith("#"):
        sys.exit(f"tokens/_dusk.scss: ${name} is not a solid color ({value!r})")
    return dusk_tokens.hex_rgb(value)


def write_png(path, w, h, rows):
    raw = b"".join(b"\x00" + bytes(r) for r in rows)

    def chunk(tag, data):
        c = tag + data
        return struct.pack(">I", len(data)) + c + struct.pack(">I", zlib.crc32(c) & 0xFFFFFFFF)

    png = b"\x89PNG\r\n\x1a\n"
    png += chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))  # 8-bit RGBA
    png += chunk(b"IDAT", zlib.compress(raw, 9))
    png += chunk(b"IEND", b"")
    path.write_bytes(png)


# Breakout-tab geometry (1x px). Dusk enlarges Orchis's tab (body 36, curves 9)
# so the inward curve radius equals the content card radius ($r-card): the
# first row's top curve and the card's top-left corner then meet in one S.
TAB_W = 160                 # image width (144 + the 16px tail)
TAB_CURVE = 16              # inward curve radius = $r-card
TAB_BODY = 56               # pill height
TAB_MARGIN = 24             # frame left of the pill (Orchis: 24)
TAB_TAIL = 16               # solid strip past the inward curves (= $r-card)
TAB_H = 2 * TAB_CURVE + TAB_BODY   # 88
TAB_R = TAB_BODY / 2        # half-pill radius


def in_tab(x, y, tail=True):
    """Tab shape in 1x units (image TAB_W x TAB_H; TAB_W - TAB_TAIL without tail).

    The inward curves sit TAB_TAIL px before the right edge, at the content
    card's edge; the last TAB_TAIL px are solid. That tail lies under/over the
    card's left strip (same colour, invisible) and, for a first row flush with
    the card top, fills the card's rounded top-left corner so it reads square.
    """
    c, top, bot = TAB_CURVE, TAB_CURVE, TAB_CURVE + TAB_BODY
    if tail and x >= TAB_W - TAB_TAIL:
        return True
    cx = TAB_W - TAB_TAIL - c
    if x >= cx:
        if y < top:
            return (x - cx) ** 2 + y ** 2 >= c * c
        if y > bot:
            return (x - cx) ** 2 + (y - TAB_H) ** 2 >= c * c
        return True
    if not top <= y <= bot:
        return False
    px = TAB_MARGIN + TAB_R
    if x >= px:
        return True
    return (x - px) ** 2 + (y - (top + TAB_R)) ** 2 <= TAB_R ** 2


def render_row_selected(path, scale, tab, ss=4, tail=True):
    w, h = (TAB_W if tail else TAB_W - TAB_TAIL) * scale, TAB_H * scale
    rows = []
    n = ss * ss
    for py in range(h):
        row = []
        for px in range(w):
            hits = 0
            for sy in range(ss):
                for sx in range(ss):
                    x = (px + (sx + 0.5) / ss) / scale
                    y = (py + (sy + 0.5) / ss) / scale
                    hits += in_tab(x, y, tail)
            a = hits / n
            row.extend((*tab, round(255 * a)))
        rows.append(row)
    write_png(path, w, h, rows)


def recolor(src, dst, accent):
    try:
        from PIL import Image
    except ImportError:
        print(f"warning: Pillow missing, copying {src.name} unchanged", file=sys.stderr)
        shutil.copyfile(src, dst)
        return
    im = Image.open(src).convert("RGBA")
    px = im.load()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = px[x, y]
            if a and b - r > 20:  # Orchis blue and its shades
                k = b / ORCHIS_BLUE[2]
                px[x, y] = tuple(min(255, round(c * k)) for c in accent) + (a,)
    im.save(dst, optimize=True)


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    root = Path(sys.argv[1])
    by_id = {v["id"]: v for v in dusk_tokens.variants()}
    unknown = [v for v in sys.argv[2:] if v not in by_id]
    if unknown:
        sys.exit(f"unknown variant(s): {' '.join(unknown)}")
    wanted = [by_id[v] for v in sys.argv[2:]]
    # Accent-independent: the breakout tab is the variant's $base, drawn once
    # per distinct colour (each style's stock $base; the Strata-seeded
    # `wallpaper` slot tints its own, so it gets its own tab)
    shared_of = {}
    base_of = {v["id"]: token_rgb(dusk_tokens.tokens(v["slot"], style=v["style"]), "base") for v in wanted}
    for base in sorted(set(base_of.values())):
        shared = root / (".shared-%02x%02x%02x" % base)
        shared.mkdir(parents=True, exist_ok=True)
        render_row_selected(shared / "row-selected-dark.png", 1, base)
        render_row_selected(shared / "row-selected-dark@2.png", 2, base)
        # GTK3 (file chooser, Disks): no card overlaps the sidebar there, so the tab
        # ends at its inward curves (slice 17 17 17 54)
        render_row_selected(shared / "row-selected-plain-dark.png", 1, base, tail=False)
        render_row_selected(shared / "row-selected-plain-dark@2.png", 2, base, tail=False)
        shared_of[base] = shared
    for v in wanted:
        toks = dusk_tokens.tokens(v["slot"], style=v["style"])
        out = root / v["id"]
        out.mkdir(parents=True, exist_ok=True)
        for png in shared_of[base_of[v["id"]]].glob("*.png"):
            shutil.copyfile(png, out / png.name)
        accent_bg = token_rgb(toks, "accent-bg")
        for src in sorted((ORCHIS / "assets-src").glob("*.png")):
            recolor(src, out / src.name, accent_bg)
        shutil.copytree(ORCHIS / "assets-src" / "scalable", out / "scalable", dirs_exist_ok=True)
        # Pre-colored window-button glyphs for GTK3, whose -gtk-recolor() renders
        # these as solid discs. GTK4 recolors the symbolic originals instead.
        text_dim = token_rgb(toks, "text-dim")
        accent = token_rgb(toks, "accent")
        for name in ("close", "minimize", "maximize"):
            src = (ORCHIS / "assets-src" / "scalable" / f"dusk-window-{name}-symbolic.svg").read_text()
            for state, rgb, alpha in (("rest", text_dim, 1), ("hover", accent, 1), ("backdrop", text_dim, 0.6)):
                fill = "#%02x%02x%02x" % rgb
                svg = src.replace('fill="#000"', f'fill="{fill}" fill-opacity="{alpha}"')
                (out / "scalable" / f"dusk-window-{name}-{state}.svg").write_text(svg)
    for shared in shared_of.values():
        shutil.rmtree(shared)


if __name__ == "__main__":
    main()
