#!/usr/bin/env python3
"""Read the Dusk design tokens (tokens/_dusk.scss) from Python and shell.

The SCSS file is the single source of truth. This module parses it without
sassc: plain `$name: value;` tokens, the `$dusk-accents` palette map (one
slot per line), and the few accent-derived tokens (`$accent`, `$accent-bg`,
`$selection`, `$selection-item`), which it resolves for a given slot.

Styles: "dusk" (the plain tokens and `$dusk-accents`) and "atomic" (Atomic
Suede: `$atomic-<token>` replaces `$<token>`, `$atomic-accents` replaces the
palette). A variant is one style + one accent slot; its id names its build
outputs: the slot for dusk ("blue", "teal", ...), "atomic-<slot>" for atomic.

Schemes: "dark" (default) and "light" (`$light-<token>` / `$atomic-light-
<token>` replace the tokens, `$dusk-light-accents` / `$atomic-light-accents`
the palette). The scheme comes from $DUSK_SCHEME (dark when unset), so every
build script builds the light set by running again with DUSK_SCHEME=light.
Light variants add "-light" to the id ("blue-light", "atomic-rose-light")
and "-Light" to the theme name ("Dusk-Light", "Dusk-Atomic-Rose-Light").

Library:
    palette(style)     [{'slot', 'name', 'accent', 'accent_bg', 'theme',
                         'stem', 'style', 'id'}...] in GNOME enum order
    variants()         palette('dusk') + palette('atomic')
    tokens(slot, style=)  {name: value} for one variant; colors as '#RRGGBB'
                       or 'rgba(r, g, b, a)', sizes as 'Npx', strings quoted
    theme_name(slot, style=)  'Dusk' / 'Dusk-<Name>' (dusk),
                       'Dusk-Atomic' / 'Dusk-Atomic-<Name>' (atomic)
    render(text, slot, style=)  fill {{token}} placeholders (see `render`)

CLI (for build scripts; STYLE defaults to dusk):
    dusk_tokens.py slots [STYLE]              slot<TAB>name<TAB>theme<TAB>stem
    dusk_tokens.py variants                   id<TAB>style<TAB>slot<TAB>name<TAB>theme<TAB>stem
    dusk_tokens.py get SLOT TOKEN [STYLE]     one resolved token value
    dusk_tokens.py json                       the palettes as JSON
    dusk_tokens.py render SLOT IN OUT [STYLE] render a template file
    dusk_tokens.py seed-scss [STYLE]          the $dusk-seed SCSS line for builds
                                              (empty without a seed)
    dusk_tokens.py scheme                     the scheme ($DUSK_SCHEME: dark|light)

Wallpaper accent: with DUSK_SEED set to a seed file from tokens/dusk_seed.py
(one style), that style's palette gains the slot "wallpaper" (theme
Dusk-Wallpaper / Dusk-Atomic-Wallpaper), whose accent, surfaces and status
colours come from the seed, and `variants` lists it, so every build script
can build it like any other slot. A seed file carries both schemes: the
dark colours at the top level and the light ones under "light".
"""
import json
import os
import re
import sys
from pathlib import Path

TOKENS = Path(__file__).resolve().parent / '_dusk.scss'

_PLAIN = re.compile(r'^\$([a-z0-9-]+):\s*([^;]+?)\s*;', re.M)
_ENTRY = re.compile(
    r'^\s*([a-z]+):\s*\(name:\s*"([^"]+)",\s*accent:\s*(#[0-9A-Fa-f]{6}),'
    r'\s*accent-bg:\s*(#[0-9A-Fa-f]{6})\)\s*,?\s*$', re.M)
_DEFAULT_SLOT = re.compile(r'^\$dusk-accent-slot:\s*([a-z]+)\s*!default\s*;', re.M)
_RGBA_OF = re.compile(r'^rgba\(\s*\$([a-z0-9-]+)\s*,\s*([0-9.]+)\s*\)$')
_HEX = re.compile(r'^#[0-9A-Fa-f]{6}$')
_RGBA = re.compile(r'^rgba\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([0-9.]+)\s*\)$')


def _text(path=None):
    return Path(path or TOKENS).read_text(encoding='utf-8')


STYLES = ('dusk', 'atomic')
SCHEMES = ('dark', 'light')
_PREFIX = {'dusk': 'Dusk', 'atomic': 'Dusk-Atomic'}


def _check_style(style):
    if style not in STYLES:
        raise KeyError(f'unknown style {style!r} (have: {", ".join(STYLES)})')


def current_scheme(scheme=None):
    """`scheme`, else $DUSK_SCHEME, else dark."""
    scheme = scheme or os.environ.get('DUSK_SCHEME') or 'dark'
    if scheme not in SCHEMES:
        raise KeyError(f'unknown scheme {scheme!r} (have: {", ".join(SCHEMES)})')
    return scheme


def variant_id(slot, style='dusk', scheme=None):
    vid = slot if style == 'dusk' else f'{style}-{slot}'
    return vid + ('-light' if current_scheme(scheme) == 'light' else '')


def theme_name(slot, name=None, style='dusk', scheme=None):
    _check_style(style)
    suffix = '-Light' if current_scheme(scheme) == 'light' else ''
    if slot == 'blue':
        return _PREFIX[style] + suffix
    if name is None:
        name = {p['slot']: p['name'] for p in palette(style=style, scheme='dark')}[slot]
    return f'{_PREFIX[style]}-{name}{suffix}'


# Tokens a wallpaper seed replaces (besides accent and accent-bg)
SEEDED = ('frame', 'base', 'card', 'popover', 'raised', 'error', 'success', 'warning')
# Material a mood's seed adds (tokens/dusk_seed.py MOODS); an older seed has none
MOOD_MATERIAL = ('mood-panel-a', 'mood-float-a', 'mood-acrylic-a', 'mood-slab',
                 'mood-slab-card', 'mood-dur-hover', 'mood-dur-select', 'mood-notch-tint')


def seed(style='dusk', scheme=None):
    """The wallpaper seed for `style` from $DUSK_SEED, or None. Light: the
    seed's "light" colours over its dark ones (None for an older seed
    without them)."""
    path = os.environ.get('DUSK_SEED')
    if not path:
        return None
    data = json.loads(Path(path).read_text(encoding='utf-8'))
    if data.get('style') != style:
        return None
    if current_scheme(scheme) == 'light':
        if not isinstance(data.get('light'), dict):
            return None
        data = {**data, **data['light']}
    for key in ('name', 'accent', 'accent-bg') + SEEDED:
        if key not in data:
            raise ValueError(f'{path}: seed has no {key!r}')
    return data


def palette(path=None, style='dusk', scheme=None):
    _check_style(style)
    scheme = current_scheme(scheme)
    text = _text(path)
    key = f'${style}-light-accents:' if scheme == 'light' else f'${style}-accents:'
    start = text.index(key)
    block = text[start:text.index(');', start)]
    out = []
    for slot, name, accent, accent_bg in _ENTRY.findall(block):
        theme = theme_name(slot, name, style, scheme)
        out.append({
            'slot': slot,
            'name': name,
            'accent': accent.upper(),
            'accent_bg': accent_bg.upper(),
            'theme': theme,
            # file-name stem for per-variant outputs: dusk, dusk-lagoon,
            # dusk-atomic, dusk-atomic-lagoon, dusk-lagoon-light, ...
            'stem': theme.lower(),
            'style': style,
            'scheme': scheme,
            'id': variant_id(slot, style, scheme),
        })
    if not out:
        raise ValueError(f'{path or TOKENS}: no {key[:-1]} entries found')
    sd = seed(style, scheme)
    if sd:
        theme = theme_name('wallpaper', sd['name'], style, scheme)
        out.append({'slot': 'wallpaper', 'name': sd['name'],
                    'accent': sd['accent'].upper(), 'accent_bg': sd['accent-bg'].upper(),
                    'theme': theme, 'stem': theme.lower(), 'style': style,
                    'scheme': scheme, 'id': variant_id('wallpaper', style, scheme)})
    return out


def variants(path=None, scheme=None):
    return [v for style in STYLES for v in palette(path, style, scheme)]


def default_slot(path=None):
    m = _DEFAULT_SLOT.search(_text(path))
    return m.group(1) if m else 'blue'


def hex_rgb(value):
    h = value.lstrip('#')
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def tokens(slot=None, path=None, style='dusk', scheme=None):
    """Every plain token, plus the accent tokens resolved for `slot`, in
    `style` (atomic: each `$atomic-<name>` replaces `$<name>`) and `scheme`
    (light: `$light-<name>`, then for atomic `$atomic-light-<name>`)."""
    scheme = current_scheme(scheme)
    text = _text(path)
    slot = slot or default_slot(path)
    entries = {p['slot']: p for p in palette(path, style, scheme)}
    if slot not in entries:
        raise KeyError(f'unknown accent slot {slot!r} (have: {", ".join(entries)})')
    entry = entries[slot]
    plain = _PLAIN.findall(text)
    # Override prefixes, weakest first
    prefixes = [] if style == 'dusk' else [f'{style}-']
    if scheme == 'light':
        prefixes += ['light-'] + ([] if style == 'dusk' else [f'{style}-light-'])
    overrides = {}
    for prefix in prefixes:
        for name, value in plain:
            rest = name[len(prefix):]
            # `$atomic-light-x` is not an atomic override of `light-x`
            if name.startswith(prefix) and not (prefix == f'{style}-' and rest.startswith('light-')):
                overrides[rest] = value
    if slot == 'wallpaper':
        sd = seed(style, scheme)
        overrides.update({k: sd[k].upper() for k in SEEDED})
    found = {}
    for name, value in plain:
        if name.startswith('dusk-') or name.startswith('light-'):
            continue
        if any(name.startswith(f'{s}-') for s in STYLES if s != 'dusk'):
            continue
        value = overrides.get(name, value)
        if name == 'accent':
            value = entry['accent']
        elif name == 'accent-bg':
            value = entry['accent_bg']
        else:
            m = _RGBA_OF.match(value)
            if m:
                base = found.get(m.group(1))
                if base is None or not _HEX.match(base):
                    raise ValueError(f'${name}: cannot resolve {value}')
                r, g, b = hex_rgb(base)
                value = f'rgba({r}, {g}, {b}, {m.group(2)})'
            elif value.startswith('map-get('):
                continue
        found[name] = value
    return found


def color(value, fmt='toml'):
    """'#RRGGBB' / 'rgba(...)' -> TOML string ("#RRGGBB" or Qt's "#AARRGGBB")
    or, with fmt='hex', a bare '#RRGGBB' (alpha not allowed)."""
    if _HEX.match(value):
        v = '#' + value[1:].upper()
        return v if fmt == 'hex' else f'"{v}"'
    m = _RGBA.match(value)
    if m and fmt != 'hex':
        r, g, b = (int(x) for x in m.group(1, 2, 3))
        a = round(float(m.group(4)) * 255)
        return f'"#{a:02X}{r:02X}{g:02X}{b:02X}"'
    raise ValueError(f'not a {"solid " if fmt == "hex" else ""}color: {value}')


_PLACEHOLDER = re.compile(r'\{\{(?:([a-z]+)\.)?([a-z0-9-]+)(?:\|(px|str|hex|onbase))?\}\}')


def on_base(value, base):
    """A translucent color blended over the solid `base`: '#RRGGBB'."""
    m = _RGBA.match(value)
    if not m:
        return color(value, 'hex')
    a = float(m.group(4))
    b = [int(base[i:i + 2], 16) for i in (1, 3, 5)]
    rgb = [round(b[i] + (int(m.group(i + 1)) - b[i]) * a) for i in range(3)]
    return '#' + ''.join(f'{c:02X}' for c in rgb)


def render(text, slot=None, source='template', path=None, style='dusk'):
    """Fill placeholders:
      {{token}}        color as a TOML value: "#RRGGBB", or "#AARRGGBB" with alpha
      {{token|hex}}    bare #RRGGBB
      {{token|onbase}} the color blended over $base, as a solid "#RRGGBB"
                       (for apps that mis-blend translucent colors)
      {{token|px}}     integer pixels (28px -> 28)
      {{token|str}}    string without quotes ("Open Runde" -> Open Runde)
      {{slot.token}}   the token resolved for that accent slot instead, e.g.
                       {{blue.accent|hex}} (a fixed hue, not the chosen accent)
      {{meta.name}} {{meta.slot}} {{meta.theme}} {{meta.stem}}
                       the palette entry of the slot being rendered
    Every token must exist, or this raises."""
    slot = slot or default_slot(path)
    cache = {}
    entry = {p['slot']: p for p in palette(path, style)}[slot]

    def toks(s):
        if s not in cache:
            cache[s] = tokens(s, path, style)
        return cache[s]

    def sub(m):
        scope, name, kind = m.group(1), m.group(2), m.group(3)
        if scope == 'meta':
            if name not in entry:
                raise KeyError(f'{source}: unknown {{{{meta.{name}}}}}')
            return entry[name]
        t = toks(scope or slot)
        if name not in t:
            raise KeyError(f'{source}: token ${name} not found in tokens/_dusk.scss')
        value = t[name]
        if kind == 'px':
            return str(int(re.fullmatch(r'(\d+)px', value).group(1)))
        if kind == 'str':
            return value.strip('"\'')
        if kind == 'onbase':
            return f'"{on_base(value, color(t["base"], "hex"))}"'
        return color(value, 'hex' if kind == 'hex' else 'toml')
    return _PLACEHOLDER.sub(sub, text)


def main(argv):
    if len(argv) in (1, 2) and argv[0] == 'slots':
        for p in palette(style=argv[1] if len(argv) == 2 else 'dusk'):
            print(f"{p['slot']}\t{p['name']}\t{p['theme']}\t{p['stem']}")
    elif len(argv) == 1 and argv[0] == 'variants':
        for p in variants():
            print(f"{p['id']}\t{p['style']}\t{p['slot']}\t{p['name']}\t{p['theme']}\t{p['stem']}")
    elif len(argv) in (3, 4) and argv[0] == 'get':
        print(tokens(argv[1], style=argv[3] if len(argv) == 4 else 'dusk')[argv[2]])
    elif len(argv) == 1 and argv[0] == 'json':
        # "accents": the dusk style (what older readers expect);
        # "styles": every style's palette; "bases": every style's $base
        # (dusk-accent tints Blur my Shell's acrylic with it)
        # "light": the same for the light scheme (its themes are the dark
        # names plus "-Light"; dusk-accent picks them by color-scheme)
        print(json.dumps({'default': default_slot(), 'accents': palette(scheme='dark'),
                          'styles': {s: palette(style=s, scheme='dark') for s in STYLES},
                          'bases': {s: tokens(None, style=s, scheme='dark')['base'] for s in STYLES},
                          'light': {
                              'styles': {s: palette(style=s, scheme='light') for s in STYLES},
                              'bases': {s: tokens(None, style=s, scheme='light')['base']
                                        for s in STYLES}}},
                         indent=2))
    elif len(argv) == 1 and argv[0] == 'scheme':
        print(current_scheme())
    elif len(argv) in (1, 2) and argv[0] == 'seed-scss':
        sd = seed(argv[1] if len(argv) == 2 else 'dusk')
        if sd:
            items = [f'name: "{sd["name"]}"', f'accent: {sd["accent"]}',
                     f'accent-bg: {sd["accent-bg"]}'] + [f'{k}: {sd[k]}' for k in SEEDED]
            items += [f'{k}: {sd[k]}' for k in MOOD_MATERIAL if k in sd]
            print(f'$dusk-seed: ({", ".join(items)});')
    elif len(argv) in (4, 5) and argv[0] == 'render':
        src = Path(argv[2])
        style = argv[4] if len(argv) == 5 else 'dusk'
        Path(argv[3]).write_text(render(src.read_text(encoding='utf-8'), argv[1], src.name,
                                        style=style), encoding='utf-8')
    else:
        sys.exit(__doc__)


if __name__ == '__main__':
    main(sys.argv[1:])
